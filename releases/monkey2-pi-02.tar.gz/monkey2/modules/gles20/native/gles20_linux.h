
#ifndef BB_GLES20_LINUX_H
#define BB_GLES20_LINUX_H

#define GL_GLEXT_PROTOTYPES
#include <GL/gl.h>	

#endif
