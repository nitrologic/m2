
# The stb-image-write module

stb-image-write is an open source library for writing png, bmp, tga and hdr files.

More information about stb-image-write can be found at <a href=https://github.com/nothings/stb>https://github.com/nothings/stb/</a>.
