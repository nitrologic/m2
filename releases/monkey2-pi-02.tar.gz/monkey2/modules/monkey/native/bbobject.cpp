
#include "bbobject.h"
#include "bbdebug.h"
#include "bbarray.h"

bbNullCtor_t bbNullCtor;

/*
bbException::bbException(){

	_debugStack=bbDB::stack();
}

bbException::bbException( bbString message ):bbException(){

	_message=message;
}
*/
