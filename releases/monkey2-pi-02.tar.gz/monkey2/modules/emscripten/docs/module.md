
# The emscripten module

The emscripten module provides a monkey2 wrapper for the emscripten.h include file.

More information about emscripten can be found at <a href=http://kripken.github.io/emscripten-site/ target=blank>http://kripken.github.io/emscripten-site/</a>
