
#include "../../desktop_release_pi/sdl2_makefile_0pi.h"

// ***** External *****

// ***** Internal *****

void mx2_sdl2_makefile_0pi_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_sdl2_makefile_0pi_init_v("sdl2_makefile_0pi",&mx2_sdl2_makefile_0pi_init);
