
#ifndef MX2_SDL2_SDL2_H
#define MX2_SDL2_SDL2_H

#include <bbmonkey.h>
#include <SDL.h>

// ***** External *****

// ***** Internal *****

#endif
