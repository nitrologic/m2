
#ifndef MX2_SDL2_MAKEFILE_H
#define MX2_SDL2_MAKEFILE_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

#endif
