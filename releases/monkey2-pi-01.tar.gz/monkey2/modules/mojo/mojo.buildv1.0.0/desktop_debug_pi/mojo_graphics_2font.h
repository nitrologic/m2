
#ifndef MX2_MOJO_GRAPHICS_2FONT_H
#define MX2_MOJO_GRAPHICS_2FONT_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec2.h"

struct t_std_collections_Map_1sTt_mojo_graphics_Font_2;
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Font_2**);
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Font_2**);
struct t_mojo_graphics_Shader;
bbString bbDBType(t_mojo_graphics_Shader**);
bbString bbDBValue(t_mojo_graphics_Shader**);
struct t_mojo_graphics_Image;
bbString bbDBType(t_mojo_graphics_Image**);
bbString bbDBValue(t_mojo_graphics_Image**);

// ***** Internal *****

struct t_mojo_graphics_Font;
struct t_mojo_graphics_Glyph;

extern bbGCRootVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2> g_mojo_graphics_Font__0openFonts;

extern t_mojo_graphics_Font* g_mojo_graphics_Font_Open(bbString l_path,bbFloat l_height);
extern t_mojo_graphics_Font* g_mojo_graphics_Font_Load(bbString l_path,bbFloat l_height,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader);

struct t_mojo_graphics_Glyph{
  const char *typeName()const{return "t_mojo_graphics_Glyph";}

  t_std_geom_Rect_1i m_rect{};
  t_std_geom_Vec2_1f m_offset{};
  bbFloat m_advance{};
  static void dbEmit(t_mojo_graphics_Glyph*);

  t_mojo_graphics_Glyph(t_std_geom_Rect_1i l_rect,t_std_geom_Vec2_1f l_offset,bbFloat l_advance);

  t_mojo_graphics_Glyph(){
  }

  t_mojo_graphics_Glyph(bbNullCtor_t){
  }
};
bbString bbDBType(t_mojo_graphics_Glyph*);
bbString bbDBValue(t_mojo_graphics_Glyph*);

int bbCompare(const t_mojo_graphics_Glyph&x,const t_mojo_graphics_Glyph&y);
struct t_mojo_graphics_Font : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_Font";}

  bbGCVar<t_mojo_graphics_Image> m__0image{};
  bbFloat m__0height{};
  bbInt m__0firstChar{};
  bbGCVar<bbArray<t_mojo_graphics_Glyph>> m__0glyphs{};

  void gcMark();
  void dbEmit();

  t_mojo_graphics_Font(t_mojo_graphics_Image* l_image,bbFloat l_height,bbInt l_firstChar,bbArray<t_mojo_graphics_Glyph>* l_glyphs);

  bbFloat m_TextWidth(bbString l_text);
  bbInt m_NumChars();
  t_mojo_graphics_Image* m_Image();
  bbFloat m_Height();
  bbArray<t_mojo_graphics_Glyph>* m_Glyphs();
  t_mojo_graphics_Glyph m_GetGlyph(bbInt l_char);
  bbInt m_FirstChar();

  t_mojo_graphics_Font(){
  }
};
bbString bbDBType(t_mojo_graphics_Font**);
bbString bbDBValue(t_mojo_graphics_Font**);

#endif
