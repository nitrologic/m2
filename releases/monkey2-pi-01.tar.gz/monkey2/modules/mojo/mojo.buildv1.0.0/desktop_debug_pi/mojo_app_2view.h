
#ifndef MX2_MOJO_APP_2VIEW_H
#define MX2_MOJO_APP_2VIEW_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2affinemat3.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec2.h"

struct t_std_collections_Stack_1Tt_mojo_app_View_2;
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_app_View_2**);
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_app_View_2**);
struct t_mojo_app_Style;
bbString bbDBType(t_mojo_app_Style**);
bbString bbDBValue(t_mojo_app_Style**);
struct t_mojo_app_MouseEvent;
bbString bbDBType(t_mojo_app_MouseEvent**);
bbString bbDBValue(t_mojo_app_MouseEvent**);
struct t_mojo_app_KeyEvent;
bbString bbDBType(t_mojo_app_KeyEvent**);
bbString bbDBValue(t_mojo_app_KeyEvent**);
struct t_mojo_graphics_Canvas;
bbString bbDBType(t_mojo_graphics_Canvas**);
bbString bbDBValue(t_mojo_graphics_Canvas**);
struct t_mojo_app_Window;
bbString bbDBType(t_mojo_app_Window**);
bbString bbDBValue(t_mojo_app_Window**);

// ***** Internal *****

struct t_mojo_app_View;

struct t_mojo_app_View : public bbObject{

  const char *typeName()const{return "t_mojo_app_View";}

  bbInt m__0dirty=1;
  bbGCVar<t_mojo_app_View> m__0parent{};
  bbGCVar<t_std_collections_Stack_1Tt_mojo_app_View_2> m__0children{};
  bbBool m__0visible=true;
  bbBool m__0enabled=true;
  bbGCVar<t_mojo_app_Style> m__0style{};
  bbString m__0styleState{};
  bbString m__0layout{};
  t_std_geom_Vec2_1f m__0gravity{};
  t_std_geom_Vec2_1i m__0offset{};
  t_std_geom_Vec2_1i m__0minSize{};
  t_std_geom_Vec2_1i m__0maxSize{};
  t_std_geom_Rect_1i m__0frame{};
  bbGCVar<t_mojo_app_Style> m__0rstyle{};
  t_std_geom_Rect_1i m__0styleBounds{};
  t_std_geom_Vec2_1i m__0measuredSize{};
  t_std_geom_Vec2_1i m__0layoutSize{};
  t_std_geom_Rect_1i m__0rect{};
  t_std_geom_Rect_1i m__0bounds{};
  t_std_geom_AffineMat3_1f m__0matrix{};
  t_std_geom_AffineMat3_1f m__0rmatrix{};
  t_std_geom_Rect_1i m__0rbounds{};
  t_std_geom_Rect_1i m__0rclip{};
  t_std_geom_Rect_1i m__0clip{};

  void init();

  void gcMark();
  void dbEmit();

  t_mojo_app_View();

  bbInt m_Width();
  void m_Visible(bbBool l_visible);
  bbBool m_Visible();
  void m_ValidateStyle();
  void m_UpdateLayout();
  t_std_geom_Vec2_1i m_TransformWindowPointToView(t_std_geom_Vec2_1i l_point);
  t_std_geom_Rect_1i m_TransformRectToView(t_std_geom_Rect_1i l_rect,t_mojo_app_View* l_view);
  t_std_geom_Rect_1i m_TransformRectFromView(t_std_geom_Rect_1i l_rect,t_mojo_app_View* l_view);
  t_std_geom_Vec2_1i m_TransformPointToView(t_std_geom_Vec2_1i l_point,t_mojo_app_View* l_view);
  t_std_geom_Vec2_1i m_TransformPointFromView(t_std_geom_Vec2_1i l_point,t_mojo_app_View* l_view);
  void m_StyleState(bbString l_styleState);
  bbString m_StyleState();
  t_std_geom_Rect_1i m_StyleBounds();
  void m_Style(t_mojo_app_Style* l_style);
  t_mojo_app_Style* m_Style();
  void m_SendMouseEvent(t_mojo_app_MouseEvent* l_event);
  void m_SendKeyEvent(t_mojo_app_KeyEvent* l_event);
  t_mojo_app_Style* m_RenderStyle();
  t_std_geom_Rect_1i m_RenderRect();
  t_std_geom_AffineMat3_1f m_RenderMatrix();
  t_std_geom_Rect_1i m_RenderBounds();
  void m_Render(t_mojo_graphics_Canvas* l_canvas);
  void m_RemoveChild(t_mojo_app_View* l_view);
  t_std_geom_Rect_1i m_Rect();
  bbBool m_ReallyVisible();
  bbBool m_ReallyEnabled();
  t_mojo_app_View* m_Parent();
  virtual void m_OnValidateStyle();
  virtual void m_OnRenderBounds(t_mojo_graphics_Canvas* l_canvas);
  virtual void m_OnRender(t_mojo_graphics_Canvas* l_canvas);
  virtual void m_OnMouseEvent(t_mojo_app_MouseEvent* l_event);
  virtual t_std_geom_Vec2_1i m_OnMeasure2(t_std_geom_Vec2_1i l_size);
  virtual t_std_geom_Vec2_1i m_OnMeasure();
  virtual void m_OnMakeKeyView();
  virtual void m_OnLayout();
  virtual void m_OnKeyEvent(t_mojo_app_KeyEvent* l_event);
  void m_Offset(t_std_geom_Vec2_1i l_offset);
  t_std_geom_Vec2_1i m_Offset();
  t_std_geom_Vec2_1i m_MouseLocation();
  void m_MinSize(t_std_geom_Vec2_1i l_minSize);
  t_std_geom_Vec2_1i m_MinSize();
  t_std_geom_Vec2_1i m_MeasuredSize();
  t_std_geom_Vec2_1i m_Measure2(t_std_geom_Vec2_1i l_size);
  void m_Measure();
  void m_MaxSize(t_std_geom_Vec2_1i l_maxSize);
  t_std_geom_Vec2_1i m_MaxSize();
  void m_MakeKeyView();
  t_std_geom_AffineMat3_1f m_LocalMatrix();
  t_std_geom_Vec2_1i m_LayoutSize();
  void m_Layout(bbString l_layout);
  bbString m_Layout();
  bbBool m_IsChildOf(t_mojo_app_View* l_view);
  void m_InvalidateStyle();
  bbInt m_Height();
  void m_Gravity(t_std_geom_Vec2_1f l_gravity);
  t_std_geom_Vec2_1f m_Gravity();
  void m_Frame(t_std_geom_Rect_1i l_frame);
  t_std_geom_Rect_1i m_Frame();
  virtual t_mojo_app_Window* m_FindWindow();
  t_mojo_app_View* m_FindViewAtWindowPoint(t_std_geom_Vec2_1i l_point);
  void m_Enabled(bbBool l_enabled);
  bbBool m_Enabled();
  virtual t_mojo_app_View* m_Container();
  t_std_geom_Rect_1i m_ClipRect();
  t_std_geom_Rect_1i m_Bounds();
  void m_AddChild(t_mojo_app_View* l_view);
};
bbString bbDBType(t_mojo_app_View**);
bbString bbDBValue(t_mojo_app_View**);

#endif
