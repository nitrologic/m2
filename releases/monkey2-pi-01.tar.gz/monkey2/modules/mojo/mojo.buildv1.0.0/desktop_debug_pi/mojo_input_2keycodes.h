
#ifndef MX2_MOJO_INPUT_2KEYCODES_H
#define MX2_MOJO_INPUT_2KEYCODES_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

#endif
