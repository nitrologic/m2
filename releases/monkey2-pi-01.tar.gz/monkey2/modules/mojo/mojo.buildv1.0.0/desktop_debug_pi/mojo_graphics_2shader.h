
#ifndef MX2_MOJO_GRAPHICS_2SHADER_H
#define MX2_MOJO_GRAPHICS_2SHADER_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2mat4.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec4.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_graphics_2color.h"

struct t_std_collections_Map_1si;
bbString bbDBType(t_std_collections_Map_1si**);
bbString bbDBValue(t_std_collections_Map_1si**);
struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2;
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Shader_2**);
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Shader_2**);
struct t_mojo_graphics_Texture;
bbString bbDBType(t_mojo_graphics_Texture**);
bbString bbDBValue(t_mojo_graphics_Texture**);

// ***** Internal *****

struct t_mojo_graphics_Uniform;
struct t_mojo_graphics_ParamBuffer;
struct t_mojo_graphics_ShaderProgram;
struct t_mojo_graphics_ShaderParam;
struct t_mojo_graphics_ShaderEnv;
struct t_mojo_graphics_Shader;

extern bbGCRootVar<t_std_collections_Map_1si> g_mojo_graphics_ShaderParam__0ids;
extern bbInt g_mojo_graphics_ShaderParam__0nextId;
extern bbInt g_mojo_graphics_ShaderEnv__0nextId;
extern bbGCRootVar<t_mojo_graphics_ShaderProgram> g_mojo_graphics_Shader__0bound;
extern bbInt g_mojo_graphics_Shader__0seq;
extern bbGCRootVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2> g_mojo_graphics_Shader__0shaders;

extern t_mojo_graphics_Shader* g_mojo_graphics_Shader_GetShader(bbString l_name);
extern bbInt g_mojo_graphics_ShaderParam_ParamId(bbString l_name);
extern void g_mojo_graphics_BindUniforms(bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_uniforms,t_mojo_graphics_ParamBuffer* l_params,bbBool l_filter);

struct t_mojo_graphics_Uniform : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_Uniform";}

  bbString m_name{};
  bbInt m_id{};
  bbInt m_location{};
  bbInt m_texunit{};
  bbInt m_size{};
  bbInt m_type{};
  void dbEmit();

  t_mojo_graphics_Uniform(bbString l_name,bbInt l_location,bbInt l_texunit,bbInt l_size,bbInt l_type);

  t_mojo_graphics_Uniform(){
  }
};
bbString bbDBType(t_mojo_graphics_Uniform**);
bbString bbDBValue(t_mojo_graphics_Uniform**);

struct t_mojo_graphics_ShaderParam{
  const char *typeName()const{return "t_mojo_graphics_ShaderParam";}

  bbFloat m_scalar{};
  t_std_geom_Vec4_1f m_vector{};
  t_std_geom_Mat4_1f m_matrix{};
  bbGCVar<t_mojo_graphics_Texture> m_texture{};
  static void dbEmit(t_mojo_graphics_ShaderParam*);

  t_mojo_graphics_ShaderParam(){
  }

  t_mojo_graphics_ShaderParam(bbNullCtor_t){
  }
};
bbString bbDBType(t_mojo_graphics_ShaderParam*);
bbString bbDBValue(t_mojo_graphics_ShaderParam*);

int bbCompare(const t_mojo_graphics_ShaderParam&x,const t_mojo_graphics_ShaderParam&y);

void bbGCMark(const t_mojo_graphics_ShaderParam&);

struct t_mojo_graphics_ParamBuffer : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_ParamBuffer";}

  bbGCVar<bbArray<t_mojo_graphics_ShaderParam>> m__0params{};

  void init();

  void gcMark();
  void dbEmit();

  void m_SetVector(bbString l_name,t_std_geom_Vec4_1f l_value);
  void m_SetTexture(bbString l_name,t_mojo_graphics_Texture* l_value);
  void m_SetMatrix(bbString l_name,t_std_geom_Mat4_1f l_value);
  void m_SetColor(bbString l_name,t_std_graphics_Color l_value);

  t_mojo_graphics_ParamBuffer(){
    init();
  }
};
bbString bbDBType(t_mojo_graphics_ParamBuffer**);
bbString bbDBValue(t_mojo_graphics_ParamBuffer**);

struct t_mojo_graphics_ShaderProgram : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_ShaderProgram";}

  bbGCVar<bbArray<bbString>> m__0sources{};
  bbInt m__0seq{};
  bbUInt m__0glProgram{};
  bbGCVar<bbArray<bbGCVar<t_mojo_graphics_Uniform>>> m__0envUniforms{};
  bbGCVar<bbArray<bbGCVar<t_mojo_graphics_Uniform>>> m__0uniforms{};

  void gcMark();
  void dbEmit();

  t_mojo_graphics_ShaderProgram(bbArray<bbString>* l_sources);

  bbArray<bbGCVar<t_mojo_graphics_Uniform>>* m_Uniforms();
  bbArray<bbString>* m_Sources();
  bbUInt m_GLProgram();
  bbArray<bbGCVar<t_mojo_graphics_Uniform>>* m_EnvUniforms();
  void m_EnumUniforms();
  void m_BuildProgram();

  t_mojo_graphics_ShaderProgram(){
  }
};
bbString bbDBType(t_mojo_graphics_ShaderProgram**);
bbString bbDBValue(t_mojo_graphics_ShaderProgram**);

struct t_mojo_graphics_ShaderEnv : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_ShaderEnv";}

  bbString m__0source{};
  bbInt m__0id{};
  void dbEmit();

  t_mojo_graphics_ShaderEnv(bbString l_sourceCode);

  bbString m_SourceCode();
  bbInt m_Id();

  t_mojo_graphics_ShaderEnv(){
  }
};
bbString bbDBType(t_mojo_graphics_ShaderEnv**);
bbString bbDBValue(t_mojo_graphics_ShaderEnv**);

struct t_mojo_graphics_Shader : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_Shader";}

  bbString m__0source{};
  bbGCVar<bbArray<bbGCVar<t_mojo_graphics_ShaderProgram>>> m__0programs{};

  void init();

  void gcMark();
  void dbEmit();

  t_mojo_graphics_Shader(bbString l_sourceCode);

  bbString m_SourceCode();
  void m_BindParams(t_mojo_graphics_ParamBuffer* l_params,bbBool l_filter);
  void m_BindEnvParams(t_mojo_graphics_ParamBuffer* l_params);
  void m_Bind(t_mojo_graphics_ShaderEnv* l_env);

  t_mojo_graphics_Shader(){
    init();
  }
};
bbString bbDBType(t_mojo_graphics_Shader**);
bbString bbDBValue(t_mojo_graphics_Shader**);

#endif
