
#ifndef MX2_MOJO_APP_2APP_H
#define MX2_MOJO_APP_2APP_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../sdl2/sdl2.buildv1.0.0/desktop_debug_pi/sdl2_sdl2.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec2.h"

struct t_std_collections_Map_1iFvE;
bbString bbDBType(t_std_collections_Map_1iFvE**);
bbString bbDBValue(t_std_collections_Map_1iFvE**);
struct t_std_collections_Map_1iz;
bbString bbDBType(t_std_collections_Map_1iz**);
bbString bbDBValue(t_std_collections_Map_1iz**);
struct t_mojo_app_KeyEvent;
bbString bbDBType(t_mojo_app_KeyEvent**);
bbString bbDBValue(t_mojo_app_KeyEvent**);
struct t_mojo_app_MouseEvent;
bbString bbDBType(t_mojo_app_MouseEvent**);
bbString bbDBValue(t_mojo_app_MouseEvent**);
struct t_mojo_graphics_Font;
bbString bbDBType(t_mojo_graphics_Font**);
bbString bbDBValue(t_mojo_graphics_Font**);
struct t_mojo_app_View;
bbString bbDBType(t_mojo_app_View**);
bbString bbDBValue(t_mojo_app_View**);
struct t_mojo_app_Window;
bbString bbDBType(t_mojo_app_Window**);
bbString bbDBValue(t_mojo_app_Window**);
struct t_std_collections_Stack_1Tt_mojo_app_View_2;
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_app_View_2**);
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_app_View_2**);

// ***** Internal *****

struct t_mojo_app_AppInstance;
struct t_mojo_app_DisplayMode;

extern bbGCRootVar<t_mojo_app_AppInstance> g_mojo_app_App;
extern bbGCRootVar<t_std_collections_Map_1iFvE> g_mojo_app_AppInstance__0asyncCallbacks;
extern bbGCRootVar<t_std_collections_Map_1iz> g_mojo_app_AppInstance__0disabledCallbacks;
extern bbInt g_mojo_app_AppInstance__0nextCallbackId;

extern bbInt g_mojo_app_AppInstance__0EventFilter(void* l_userData,SDL_Event* l_event);
extern void g_mojo_app_AppInstance_RemoveAsyncCallback(bbInt l_id);
extern void g_mojo_app_AppInstance_EnableAsyncCallback(bbInt l_id);
extern void g_mojo_app_AppInstance_EmscriptenMainLoop();
extern void g_mojo_app_AppInstance_DisableAsyncCallback(bbInt l_id);
extern bbInt g_mojo_app_AppInstance_AddAsyncCallback(bbFunction<void()> l_func);

struct t_mojo_app_DisplayMode{
  const char *typeName()const{return "t_mojo_app_DisplayMode";}

  bbInt m_width{};
  bbInt m_height{};
  bbInt m_hertz{};
  static void dbEmit(t_mojo_app_DisplayMode*);

  t_mojo_app_DisplayMode(){
  }

  t_mojo_app_DisplayMode(bbNullCtor_t){
  }
};
bbString bbDBType(t_mojo_app_DisplayMode*);
bbString bbDBValue(t_mojo_app_DisplayMode*);

int bbCompare(const t_mojo_app_DisplayMode&x,const t_mojo_app_DisplayMode&y);
struct t_mojo_app_AppInstance : public bbObject{

  const char *typeName()const{return "t_mojo_app_AppInstance";}

  bbFunction<void()> m_Idle{};
  bbFunction<void()> m_NextIdle{};
  bbFunction<void(t_mojo_app_KeyEvent*)> m_KeyEventFilter{};
  bbFunction<void(t_mojo_app_MouseEvent*)> m_MouseEventFilter{};
  bbUInt m__0sdlThread{};
  SDL_Window* m__0glWindow{};
  void* m__0glContext{};
  bbGCVar<t_mojo_graphics_Font> m__0defaultFont{};
  bbGCVar<t_mojo_graphics_Font> m__0defaultMonoFont{};
  bbBool m__0requestRender{};
  bbGCVar<t_mojo_app_View> m__0hoverView{};
  bbGCVar<t_mojo_app_View> m__0mouseView{};
  bbFloat m__0fps{};
  bbInt m__0fpsFrames{};
  bbInt m__0fpsMillis{};
  bbGCVar<t_mojo_app_Window> m__0window{};
  bbInt m__0key{};
  bbInt m__0rawKey{};
  bbString m__0keyChar{};
  bbInt m__0modifiers{};
  bbInt m__0mouseButton{};
  t_std_geom_Vec2_1i m__0mouseLocation{};
  t_std_geom_Vec2_1i m__0mouseWheel{};
  bbGCVar<t_mojo_app_View> m__0modalView{};
  bbGCVar<t_std_collections_Stack_1Tt_mojo_app_View_2> m__0modalStack{};
  bbBool m__0polling{};

  void init();

  void gcMark();
  void dbEmit();

  t_mojo_app_AppInstance();

  void m_UpdateFPS();
  void m_UpdateEvents();
  void m_Terminate();
  void m_SendWindowEvent(bbInt l_type);
  void m_SendMouseEvent(bbInt l_type,t_mojo_app_View* l_view);
  void m_SendKeyEvent(bbInt l_type);
  void m_Run();
  void m_RequestRender();
  t_mojo_app_View* m_MouseView();
  t_std_geom_Vec2_1i m_MouseLocation();
  bbInt m_Millisecs();
  void m_MainLoop();
  void m_KeyView(t_mojo_app_View* l_keyView);
  t_mojo_app_View* m_KeyView();
  t_mojo_app_View* m_HoverView();
  bbArray<t_mojo_app_DisplayMode>* m_GetDisplayModes();
  bbFloat m_FPS();
  bbInt m_EventFilter(void* l_userData,SDL_Event* l_event);
  void m_EndModal();
  void m_DispatchEvent(SDL_Event* l_event);
  t_std_geom_Vec2_1i m_DesktopSize();
  bbString m_DefaultMonoFontName();
  t_mojo_graphics_Font* m_DefaultMonoFont();
  bbString m_DefaultFontName();
  t_mojo_graphics_Font* m_DefaultFont();
  bbBool m_ClipboardTextEmpty();
  void m_ClipboardText(bbString l_text);
  bbString m_ClipboardText();
  void m_BeginModal(t_mojo_app_View* l_view);
  t_mojo_app_Window* m_ActiveWindow();
};
bbString bbDBType(t_mojo_app_AppInstance**);
bbString bbDBValue(t_mojo_app_AppInstance**);

#endif
