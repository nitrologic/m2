
#ifndef MX2_MOJO_GRAPHICS_2VERTEX_H
#define MX2_MOJO_GRAPHICS_2VERTEX_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec2.h"

// ***** Internal *****

struct t_mojo_graphics_Vertex2f;

struct t_mojo_graphics_Vertex2f{
  const char *typeName()const{return "t_mojo_graphics_Vertex2f";}

  bbFloat m_x{};
  bbFloat m_y{};
  bbFloat m_s0{};
  bbFloat m_t0{};
  bbFloat m_ix{};
  bbFloat m_iy{};
  bbUInt m_color{};
  static void dbEmit(t_mojo_graphics_Vertex2f*);

  t_mojo_graphics_Vertex2f(bbFloat l_x,bbFloat l_y,bbFloat l_s0,bbFloat l_t0,bbFloat l_ix,bbFloat l_iy,bbUInt l_colorARGB);
  t_mojo_graphics_Vertex2f(t_std_geom_Vec2_1f l_position,t_std_geom_Vec2_1f l_texCoord0,t_std_geom_Vec2_1f l_tangent,bbUInt l_colorARGB);
  t_mojo_graphics_Vertex2f(bbNullCtor_t);

  void m_TexCoord0(t_std_geom_Vec2_1f l_texCoord0);
  t_std_geom_Vec2_1f m_TexCoord0();
  void m_Tangent(t_std_geom_Vec2_1f l_tangent);
  t_std_geom_Vec2_1f m_Tangent();
  void m_Position(t_std_geom_Vec2_1f l_position);
  t_std_geom_Vec2_1f m_Position();
  void m_ColorARGB(bbUInt l_colorARGB);
  bbUInt m_ColorARGB();

  t_mojo_graphics_Vertex2f(){
  }
};
bbString bbDBType(t_mojo_graphics_Vertex2f*);
bbString bbDBValue(t_mojo_graphics_Vertex2f*);

int bbCompare(const t_mojo_graphics_Vertex2f&x,const t_mojo_graphics_Vertex2f&y);

#endif
