
#ifndef MX2_MOJO_GRAPHICS_2MATERIAL_H
#define MX2_MOJO_GRAPHICS_2MATERIAL_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2mat4.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec4.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_graphics_2color.h"

struct t_mojo_graphics_Shader;
bbString bbDBType(t_mojo_graphics_Shader**);
bbString bbDBValue(t_mojo_graphics_Shader**);
struct t_mojo_graphics_ParamBuffer;
bbString bbDBType(t_mojo_graphics_ParamBuffer**);
bbString bbDBValue(t_mojo_graphics_ParamBuffer**);
struct t_mojo_graphics_Texture;
bbString bbDBType(t_mojo_graphics_Texture**);
bbString bbDBValue(t_mojo_graphics_Texture**);

// ***** Internal *****

struct t_mojo_graphics_Material;

struct t_mojo_graphics_Material : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_Material";}

  bbGCVar<t_mojo_graphics_Shader> m__0shader{};
  bbGCVar<t_mojo_graphics_ParamBuffer> m__0params{};

  void init();

  void gcMark();
  void dbEmit();

  t_mojo_graphics_Material(t_mojo_graphics_Shader* l_shader);

  t_mojo_graphics_Shader* m_Shader();
  void m_SetVector(bbString l_name,t_std_geom_Vec4_1f l_value);
  void m_SetTexture(bbString l_name,t_mojo_graphics_Texture* l_value);
  void m_SetMatrix(bbString l_name,t_std_geom_Mat4_1f l_value);
  void m_SetColor(bbString l_name,t_std_graphics_Color l_value);
  t_mojo_graphics_ParamBuffer* m_Params();

  t_mojo_graphics_Material(){
    init();
  }
};
bbString bbDBType(t_mojo_graphics_Material**);
bbString bbDBValue(t_mojo_graphics_Material**);

#endif
