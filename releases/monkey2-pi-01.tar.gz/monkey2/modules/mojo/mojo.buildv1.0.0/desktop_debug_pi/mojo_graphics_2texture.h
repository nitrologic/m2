
#ifndef MX2_MOJO_GRAPHICS_2TEXTURE_H
#define MX2_MOJO_GRAPHICS_2TEXTURE_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_graphics_2color.h"

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2;
bbString bbDBType(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2**);
bbString bbDBValue(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2**);
struct t_std_graphics_Pixmap;
bbString bbDBType(t_std_graphics_Pixmap**);
bbString bbDBValue(t_std_graphics_Pixmap**);
struct t_mojo_graphics_GraphicsDevice;
bbString bbDBType(t_mojo_graphics_GraphicsDevice**);
bbString bbDBValue(t_mojo_graphics_GraphicsDevice**);

// ***** Internal *****

struct t_mojo_graphics_Texture;

extern bbGCRootVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2> g_mojo_graphics_Texture__0colorTextures;

extern t_mojo_graphics_Texture* g_mojo_graphics_Texture_Load(bbString l_path,bbInt l_flags);
extern t_mojo_graphics_Texture* g_mojo_graphics_Texture_ColorTexture(t_std_graphics_Color l_color);

struct t_mojo_graphics_Texture : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_Texture";}

  bbFunction<void()> m_OnDiscarded{};
  t_std_geom_Rect_1i m__0rect{};
  bbInt m__0format{};
  bbInt m__0flags{};
  bbGCVar<t_std_graphics_Pixmap> m__0managed{};
  bbBool m__0discarded{};
  bbInt m__0texSeq{};
  bbBool m__0texDirty{};
  bbBool m__0mipsDirty{};
  bbUInt m__0glTexture{};
  bbInt m__0fbSeq{};
  bbUInt m__0glFramebuffer{};

  void gcMark();
  void dbEmit();

  t_mojo_graphics_Texture(bbInt l_width,bbInt l_height,bbInt l_format,bbInt l_flags);
  t_mojo_graphics_Texture(t_std_graphics_Pixmap* l_pixmap,bbInt l_flags);

  bbInt m_Width();
  t_std_geom_Rect_1i m_Rect();
  void m_PastePixmap(t_std_graphics_Pixmap* l_pixmap,bbInt l_x,bbInt l_y);
  void m_Modified(t_mojo_graphics_GraphicsDevice* l_device);
  bbInt m_Height();
  bbUInt m_GLTexture();
  bbUInt m_GLFramebuffer();
  bbInt m_Format();
  bbInt m_Flags();
  void m_Discard();

  t_mojo_graphics_Texture(){
  }
};
bbString bbDBType(t_mojo_graphics_Texture**);
bbString bbDBValue(t_mojo_graphics_Texture**);

#endif
