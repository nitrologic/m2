
#ifndef MX2_MOJO_APP_2EVENT_H
#define MX2_MOJO_APP_2EVENT_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec2.h"

struct t_mojo_app_View;
bbString bbDBType(t_mojo_app_View**);
bbString bbDBValue(t_mojo_app_View**);
struct t_mojo_app_Window;
bbString bbDBType(t_mojo_app_Window**);
bbString bbDBValue(t_mojo_app_Window**);

// ***** Internal *****

struct t_mojo_app_Event;
struct t_mojo_app_KeyEvent;
struct t_mojo_app_MouseEvent;
struct t_mojo_app_WindowEvent;

struct t_mojo_app_Event : public bbObject{

  const char *typeName()const{return "t_mojo_app_Event";}

  bbInt m__0type{};
  bbGCVar<t_mojo_app_View> m__0view{};

  void gcMark();
  void dbEmit();

  t_mojo_app_Event(bbInt l_type,t_mojo_app_View* l_view);

  t_mojo_app_View* m_View();
  bbInt m_Type();
  bbBool m_Eaten();
  void m_Eat();

  t_mojo_app_Event(){
  }
};
bbString bbDBType(t_mojo_app_Event**);
bbString bbDBValue(t_mojo_app_Event**);

struct t_mojo_app_KeyEvent : public t_mojo_app_Event{

  const char *typeName()const{return "t_mojo_app_KeyEvent";}

  bbInt m__0key{};
  bbInt m__0rawKey{};
  bbInt m__0modifiers{};
  bbString m__0text{};
  void dbEmit();

  t_mojo_app_KeyEvent(bbInt l_type,t_mojo_app_View* l_view,bbInt l_key,bbInt l_rawKey,bbInt l_modifiers,bbString l_text);

  bbString m_Text();
  bbInt m_RawKey();
  bbInt m_Modifiers();
  bbInt m_Key();

  t_mojo_app_KeyEvent(){
  }
};
bbString bbDBType(t_mojo_app_KeyEvent**);
bbString bbDBValue(t_mojo_app_KeyEvent**);

struct t_mojo_app_MouseEvent : public t_mojo_app_Event{

  const char *typeName()const{return "t_mojo_app_MouseEvent";}

  t_std_geom_Vec2_1i m__0location{};
  bbInt m__0button{};
  t_std_geom_Vec2_1i m__0wheel{};
  bbInt m__0modifiers{};
  void dbEmit();

  t_mojo_app_MouseEvent(bbInt l_type,t_mojo_app_View* l_view,t_std_geom_Vec2_1i l_location,bbInt l_button,t_std_geom_Vec2_1i l_wheel,bbInt l_modifiers);

  t_std_geom_Vec2_1i m_Wheel();
  bbInt m_Modifiers();
  t_std_geom_Vec2_1i m_Location();
  bbInt m_Button();

  t_mojo_app_MouseEvent(){
  }
};
bbString bbDBType(t_mojo_app_MouseEvent**);
bbString bbDBValue(t_mojo_app_MouseEvent**);

struct t_mojo_app_WindowEvent : public t_mojo_app_Event{

  const char *typeName()const{return "t_mojo_app_WindowEvent";}

  bbGCVar<t_mojo_app_Window> m__0window{};

  void gcMark();
  void dbEmit();

  t_mojo_app_WindowEvent(bbInt l_type,t_mojo_app_Window* l_window);

  t_mojo_app_Window* m_Window();

  t_mojo_app_WindowEvent(){
  }
};
bbString bbDBType(t_mojo_app_WindowEvent**);
bbString bbDBValue(t_mojo_app_WindowEvent**);

#endif
