
#ifndef MX2_MOJO_GRAPHICS_2IMAGE_H
#define MX2_MOJO_GRAPHICS_2IMAGE_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec2.h"

struct t_mojo_graphics_Shader;
bbString bbDBType(t_mojo_graphics_Shader**);
bbString bbDBValue(t_mojo_graphics_Shader**);
struct t_mojo_graphics_Material;
bbString bbDBType(t_mojo_graphics_Material**);
bbString bbDBValue(t_mojo_graphics_Material**);
struct t_mojo_graphics_Texture;
bbString bbDBType(t_mojo_graphics_Texture**);
bbString bbDBValue(t_mojo_graphics_Texture**);
struct t_std_graphics_Pixmap;
bbString bbDBType(t_std_graphics_Pixmap**);
bbString bbDBValue(t_std_graphics_Pixmap**);

// ***** Internal *****

struct t_mojo_graphics_Image;

extern t_mojo_graphics_Image* g_mojo_graphics_Image_Load(bbString l_path,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader);

struct t_mojo_graphics_Image : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_Image";}

  bbFunction<void()> m_OnDiscarded{};
  bbGCVar<t_mojo_graphics_Material> m__0material{};
  bbGCVar<t_mojo_graphics_Texture> m__0texture{};
  t_std_geom_Rect_1i m__0rect{};
  bbBool m__0discarded{};
  t_std_geom_Vec2_1f m__0handle{};
  t_std_geom_Vec2_1f m__0scale{};
  t_std_geom_Rect_1f m__0vertices{};
  t_std_geom_Rect_1f m__0texCoords{};
  bbFloat m__0radius{};

  void init();

  void gcMark();
  void dbEmit();

  t_mojo_graphics_Image(t_mojo_graphics_Material* l_material,t_mojo_graphics_Texture* l_texture,t_std_geom_Rect_1i l_rect);
  t_mojo_graphics_Image(t_mojo_graphics_Texture* l_texture,t_mojo_graphics_Shader* l_shader);
  t_mojo_graphics_Image(t_mojo_graphics_Image* l_image,t_std_geom_Rect_1i l_rect);
  t_mojo_graphics_Image(bbInt l_width,bbInt l_height,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader);
  t_mojo_graphics_Image(t_std_graphics_Pixmap* l_pixmap,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader);

  bbInt m_Width();
  t_std_geom_Rect_1f m_Vertices();
  void m_UpdateVertices();
  void m_UpdateTexCoords();
  t_mojo_graphics_Texture* m_Texture();
  t_std_geom_Rect_1f m_TexCoords();
  void m_Scale(t_std_geom_Vec2_1f l_scale);
  t_std_geom_Vec2_1f m_Scale();
  t_std_geom_Rect_1i m_Rect();
  bbFloat m_Radius();
  t_mojo_graphics_Material* m_Material();
  void m_Init(t_mojo_graphics_Material* l_material,t_mojo_graphics_Texture* l_texture,t_std_geom_Rect_1i l_rect,t_mojo_graphics_Shader* l_shader);
  bbInt m_Height();
  void m_Handle(t_std_geom_Vec2_1f l_handle);
  t_std_geom_Vec2_1f m_Handle();
  void m_Discard();
  t_std_geom_Rect_1f m_Bounds();

  t_mojo_graphics_Image(){
    init();
  }
};
bbString bbDBType(t_mojo_graphics_Image**);
bbString bbDBValue(t_mojo_graphics_Image**);

#endif
