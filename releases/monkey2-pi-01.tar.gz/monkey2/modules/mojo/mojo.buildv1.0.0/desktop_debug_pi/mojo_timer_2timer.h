
#ifndef MX2_MOJO_TIMER_2TIMER_H
#define MX2_MOJO_TIMER_2TIMER_H

#include <bbmonkey.h>
#include "../../timer/native/timer.h"

// ***** External *****

// ***** Internal *****

#endif
