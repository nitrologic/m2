
#include "../../desktop_release_pi/mojo_monkey_math.h"

// ***** External *****

// ***** Internal *****

bbFloat g_monkey_math_Clamp_1f(bbFloat l_value,bbFloat l_min,bbFloat l_max){
  if((l_value<=l_min)){
    return l_min;
  }
  if((l_value>=l_max)){
    return l_max;
  }
  return l_value;
}

void mx2_mojo_monkey_math_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_monkey_math_init_v("mojo_monkey_math",&mx2_mojo_monkey_math_init);
