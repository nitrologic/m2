
#include "../../desktop_release_pi/mojo_std_collections_2map.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_app_2style.h"
#include "../../desktop_release_pi/mojo_app_2window.h"
#include "../../desktop_release_pi/mojo_graphics_2font.h"
#include "../../desktop_release_pi/mojo_graphics_2image.h"
#include "../../desktop_release_pi/mojo_graphics_2shader.h"
#include "../../desktop_release_pi/mojo_graphics_2texture.h"

// ***** Internal *****

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value,bbInt l_color,t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

t_mojo_graphics_Texture* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_graphics_Color t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_Copy(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_graphics_Color t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_mojo_graphics_Texture* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2(){
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m__idxeq(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value){
  this->m_Set(l_key,l_value);
}

t_mojo_graphics_Texture* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m__idx(t_std_graphics_Color l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return ((t_mojo_graphics_Texture*)0);
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Values(){
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues(this);
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Update(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Set(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(l_key,l_value,0,((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_RotateRight(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_RotateLeft(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_RemoveNode(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_child{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Remove(t_std_graphics_Color l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Keys(){
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys(this);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_InsertFixup(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    f0_t(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

t_mojo_graphics_Texture* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Get(t_std_graphics_Color l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return ((t_mojo_graphics_Texture*)0);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_FindNode(t_std_graphics_Color l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0);
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_DeleteFixup(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node,t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node,t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2>(f0.l_root);
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Contains(t_std_graphics_Color l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Clear(){
  this->m__0root=((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Add(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(l_key,l_value,0,((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1si_Node::gcMark(){
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1si_Node::t_std_collections_Map_1si_Node(bbString l_key,bbInt l_value,bbInt l_color,t_std_collections_Map_1si_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

bbInt t_std_collections_Map_1si_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1si_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1si_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

bbString t_std_collections_Map_1si_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1si_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si_Node::m_Copy(t_std_collections_Map_1si_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1si_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1si_Iterator::t_std_collections_Map_1si_Iterator(t_std_collections_Map_1si_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1si_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1si_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1si_Iterator&x,const t_std_collections_Map_1si_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1si_KeyIterator::t_std_collections_Map_1si_KeyIterator(t_std_collections_Map_1si_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1si_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1si_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1si_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1si_KeyIterator&x,const t_std_collections_Map_1si_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1si_MapKeys::t_std_collections_Map_1si_MapKeys(t_std_collections_Map_1si* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1si_KeyIterator t_std_collections_Map_1si_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1si_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1si_MapKeys&x,const t_std_collections_Map_1si_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1si_ValueIterator::t_std_collections_Map_1si_ValueIterator(t_std_collections_Map_1si_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1si_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbInt t_std_collections_Map_1si_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1si_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1si_ValueIterator&x,const t_std_collections_Map_1si_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1si_MapValues::t_std_collections_Map_1si_MapValues(t_std_collections_Map_1si* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1si_ValueIterator t_std_collections_Map_1si_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1si_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1si_MapValues&x,const t_std_collections_Map_1si_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1si::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1si::t_std_collections_Map_1si(t_std_collections_Map_1si_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1si::t_std_collections_Map_1si(){
}

void t_std_collections_Map_1si::m__idxeq(bbString l_key,bbInt l_value){
  this->m_Set(l_key,l_value);
}

bbInt t_std_collections_Map_1si::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return 0;
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1si_MapValues t_std_collections_Map_1si::m_Values(){
  return t_std_collections_Map_1si_MapValues(this);
}

bbBool t_std_collections_Map_1si::m_Update(bbString l_key,bbInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1si::m_Set(bbString l_key,bbInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1si_Node>(l_key,l_value,0,((t_std_collections_Map_1si_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1si_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1si::m_RotateRight(t_std_collections_Map_1si_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1si::m_RotateLeft(t_std_collections_Map_1si_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1si::m_RemoveNode(t_std_collections_Map_1si_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_child{};
    t_std_collections_Map_1si_Node* l_parent{};
    t_std_collections_Map_1si_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1si::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1si_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1si_MapKeys t_std_collections_Map_1si::m_Keys(){
  return t_std_collections_Map_1si_MapKeys(this);
}

void t_std_collections_Map_1si::m_InsertFixup(t_std_collections_Map_1si_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    f0_t(t_std_collections_Map_1si_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1si_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1si_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

bbInt t_std_collections_Map_1si::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return 0;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1si_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1si_Node*)0);
}

bbBool t_std_collections_Map_1si::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1si_Node*)0));
}

void t_std_collections_Map_1si::m_DeleteFixup(t_std_collections_Map_1si_Node* l_node,t_std_collections_Map_1si_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    f0_t(t_std_collections_Map_1si_Node* l_node,t_std_collections_Map_1si_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1si_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1si_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1si::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1si* t_std_collections_Map_1si::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1si_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1si>(f0.l_root);
}

bbBool t_std_collections_Map_1si::m_Contains(bbString l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1si_Node*)0));
}

void t_std_collections_Map_1si::m_Clear(){
  this->m__0root=((t_std_collections_Map_1si_Node*)0);
}

t_std_collections_Map_1si_Iterator t_std_collections_Map_1si::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1si_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1si::m_Add(bbString l_key,bbInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1si_Node>(l_key,l_value,0,((t_std_collections_Map_1si_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1si_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node(bbString l_key,t_mojo_graphics_Shader* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

t_mojo_graphics_Shader* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Shader_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_mojo_graphics_Shader* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Shader_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2::t_std_collections_Map_1sTt_mojo_graphics_Shader_2(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2::t_std_collections_Map_1sTt_mojo_graphics_Shader_2(){
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m__idxeq(bbString l_key,t_mojo_graphics_Shader* l_value){
  this->m_Set(l_key,l_value);
}

t_mojo_graphics_Shader* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return ((t_mojo_graphics_Shader*)0);
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Values(){
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues(this);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Update(bbString l_key,t_mojo_graphics_Shader* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Set(bbString l_key,t_mojo_graphics_Shader* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_child{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Keys(){
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys(this);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

t_mojo_graphics_Shader* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return ((t_mojo_graphics_Shader*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2>(f0.l_root);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Contains(bbString l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Clear(){
  this->m__0root=((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Add(bbString l_key,t_mojo_graphics_Shader* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node(bbString l_key,t_mojo_graphics_Font* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

t_mojo_graphics_Font* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys::t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Font_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_mojo_graphics_Font* t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues::t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Font_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2::t_std_collections_Map_1sTt_mojo_graphics_Font_2(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2::t_std_collections_Map_1sTt_mojo_graphics_Font_2(){
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m__idxeq(bbString l_key,t_mojo_graphics_Font* l_value){
  this->m_Set(l_key,l_value);
}

t_mojo_graphics_Font* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return ((t_mojo_graphics_Font*)0);
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Values(){
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues(this);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Update(bbString l_key,t_mojo_graphics_Font* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Set(bbString l_key,t_mojo_graphics_Font* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_child{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Keys(){
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys(this);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

t_mojo_graphics_Font* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return ((t_mojo_graphics_Font*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2>(f0.l_root);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Contains(bbString l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Clear(){
  this->m__0root=((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Add(bbString l_key,t_mojo_graphics_Font* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node::t_std_collections_Map_1jTt_mojo_app_Window_2_Node(bbUInt l_key,t_mojo_app_Window* l_value,bbInt l_color,t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

t_mojo_app_Window* t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

bbUInt t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_Copy(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbUInt t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys::t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys(t_std_collections_Map_1jTt_mojo_app_Window_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_mojo_app_Window* t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues::t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues(t_std_collections_Map_1jTt_mojo_app_Window_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1jTt_mojo_app_Window_2::t_std_collections_Map_1jTt_mojo_app_Window_2(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1jTt_mojo_app_Window_2::t_std_collections_Map_1jTt_mojo_app_Window_2(){
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m__idxeq(bbUInt l_key,t_mojo_app_Window* l_value){
  this->m_Set(l_key,l_value);
}

t_mojo_app_Window* t_std_collections_Map_1jTt_mojo_app_Window_2::m__idx(bbUInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return ((t_mojo_app_Window*)0);
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues t_std_collections_Map_1jTt_mojo_app_Window_2::m_Values(){
  return t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues(this);
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Update(bbUInt l_key,t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Set(bbUInt l_key,t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(l_key,l_value,0,((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_RotateRight(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_RotateLeft(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_RemoveNode(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_child{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Remove(bbUInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys t_std_collections_Map_1jTt_mojo_app_Window_2::m_Keys(){
  return t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys(this);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_InsertFixup(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    f0_t(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

t_mojo_app_Window* t_std_collections_Map_1jTt_mojo_app_Window_2::m_Get(bbUInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return ((t_mojo_app_Window*)0);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2::m_FindNode(bbUInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0);
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_DeleteFixup(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node,t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node,t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1jTt_mojo_app_Window_2::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1jTt_mojo_app_Window_2* t_std_collections_Map_1jTt_mojo_app_Window_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2>(f0.l_root);
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Contains(bbUInt l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_Clear(){
  this->m__0root=((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator t_std_collections_Map_1jTt_mojo_app_Window_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Add(bbUInt l_key,t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(l_key,l_value,0,((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node(bbString l_key,t_mojo_graphics_Image* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

t_mojo_graphics_Image* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys::t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Image_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_mojo_graphics_Image* t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues::t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Image_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2::t_std_collections_Map_1sTt_mojo_graphics_Image_2(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2::t_std_collections_Map_1sTt_mojo_graphics_Image_2(){
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m__idxeq(bbString l_key,t_mojo_graphics_Image* l_value){
  this->m_Set(l_key,l_value);
}

t_mojo_graphics_Image* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return ((t_mojo_graphics_Image*)0);
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Values(){
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues(this);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Update(bbString l_key,t_mojo_graphics_Image* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Set(bbString l_key,t_mojo_graphics_Image* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_child{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Keys(){
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys(this);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

t_mojo_graphics_Image* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return ((t_mojo_graphics_Image*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2>(f0.l_root);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Contains(bbString l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Clear(){
  this->m__0root=((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Add(bbString l_key,t_mojo_graphics_Image* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node::t_std_collections_Map_1sTt_mojo_app_Style_2_Node(bbString l_key,t_mojo_app_Style* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

t_mojo_app_Style* t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

bbString t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_Copy(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys::t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys(t_std_collections_Map_1sTt_mojo_app_Style_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_mojo_app_Style* t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues::t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues(t_std_collections_Map_1sTt_mojo_app_Style_2* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1sTt_mojo_app_Style_2::t_std_collections_Map_1sTt_mojo_app_Style_2(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1sTt_mojo_app_Style_2::t_std_collections_Map_1sTt_mojo_app_Style_2(){
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m__idxeq(bbString l_key,t_mojo_app_Style* l_value){
  this->m_Set(l_key,l_value);
}

t_mojo_app_Style* t_std_collections_Map_1sTt_mojo_app_Style_2::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return ((t_mojo_app_Style*)0);
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues t_std_collections_Map_1sTt_mojo_app_Style_2::m_Values(){
  return t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues(this);
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Update(bbString l_key,t_mojo_app_Style* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Set(bbString l_key,t_mojo_app_Style* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_RotateRight(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_RotateLeft(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_RemoveNode(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_child{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys t_std_collections_Map_1sTt_mojo_app_Style_2::m_Keys(){
  return t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys(this);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_InsertFixup(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    f0_t(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

t_mojo_app_Style* t_std_collections_Map_1sTt_mojo_app_Style_2::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return ((t_mojo_app_Style*)0);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0);
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_DeleteFixup(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node,t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node,t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1sTt_mojo_app_Style_2::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1sTt_mojo_app_Style_2* t_std_collections_Map_1sTt_mojo_app_Style_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2>(f0.l_root);
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Contains(bbString l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_Clear(){
  this->m__0root=((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator t_std_collections_Map_1sTt_mojo_app_Style_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Add(bbString l_key,t_mojo_app_Style* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1iFvE_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1iFvE_Node::t_std_collections_Map_1iFvE_Node(bbInt l_key,bbFunction<void()> l_value,bbInt l_color,t_std_collections_Map_1iFvE_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

bbFunction<void()> t_std_collections_Map_1iFvE_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1iFvE_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1iFvE_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

bbInt t_std_collections_Map_1iFvE_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1iFvE_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE_Node::m_Copy(t_std_collections_Map_1iFvE_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1iFvE_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1iFvE_Iterator::t_std_collections_Map_1iFvE_Iterator(t_std_collections_Map_1iFvE_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iFvE_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1iFvE_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1iFvE_Iterator&x,const t_std_collections_Map_1iFvE_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1iFvE_KeyIterator::t_std_collections_Map_1iFvE_KeyIterator(t_std_collections_Map_1iFvE_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iFvE_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbInt t_std_collections_Map_1iFvE_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1iFvE_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1iFvE_KeyIterator&x,const t_std_collections_Map_1iFvE_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1iFvE_MapKeys::t_std_collections_Map_1iFvE_MapKeys(t_std_collections_Map_1iFvE* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1iFvE_KeyIterator t_std_collections_Map_1iFvE_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1iFvE_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1iFvE_MapKeys&x,const t_std_collections_Map_1iFvE_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1iFvE_ValueIterator::t_std_collections_Map_1iFvE_ValueIterator(t_std_collections_Map_1iFvE_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iFvE_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbFunction<void()> t_std_collections_Map_1iFvE_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1iFvE_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1iFvE_ValueIterator&x,const t_std_collections_Map_1iFvE_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1iFvE_MapValues::t_std_collections_Map_1iFvE_MapValues(t_std_collections_Map_1iFvE* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1iFvE_ValueIterator t_std_collections_Map_1iFvE_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1iFvE_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1iFvE_MapValues&x,const t_std_collections_Map_1iFvE_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1iFvE::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1iFvE::t_std_collections_Map_1iFvE(t_std_collections_Map_1iFvE_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1iFvE::t_std_collections_Map_1iFvE(){
}

void t_std_collections_Map_1iFvE::m__idxeq(bbInt l_key,bbFunction<void()> l_value){
  this->m_Set(l_key,l_value);
}

bbFunction<void()> t_std_collections_Map_1iFvE::m__idx(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return bbFunction<void()>{};
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1iFvE_MapValues t_std_collections_Map_1iFvE::m_Values(){
  return t_std_collections_Map_1iFvE_MapValues(this);
}

bbBool t_std_collections_Map_1iFvE::m_Update(bbInt l_key,bbFunction<void()> l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1iFvE::m_Set(bbInt l_key,bbFunction<void()> l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1iFvE_Node>(l_key,l_value,0,((t_std_collections_Map_1iFvE_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1iFvE_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1iFvE::m_RotateRight(t_std_collections_Map_1iFvE_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1iFvE::m_RotateLeft(t_std_collections_Map_1iFvE_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1iFvE::m_RemoveNode(t_std_collections_Map_1iFvE_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_child{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    t_std_collections_Map_1iFvE_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1iFvE::m_Remove(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1iFvE_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1iFvE_MapKeys t_std_collections_Map_1iFvE::m_Keys(){
  return t_std_collections_Map_1iFvE_MapKeys(this);
}

void t_std_collections_Map_1iFvE::m_InsertFixup(t_std_collections_Map_1iFvE_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    f0_t(t_std_collections_Map_1iFvE_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1iFvE_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1iFvE_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

bbFunction<void()> t_std_collections_Map_1iFvE::m_Get(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return bbFunction<void()>{};
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1iFvE_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE::m_FindNode(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1iFvE_Node*)0);
}

bbBool t_std_collections_Map_1iFvE::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1iFvE_Node*)0));
}

void t_std_collections_Map_1iFvE::m_DeleteFixup(t_std_collections_Map_1iFvE_Node* l_node,t_std_collections_Map_1iFvE_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    f0_t(t_std_collections_Map_1iFvE_Node* l_node,t_std_collections_Map_1iFvE_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1iFvE_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1iFvE_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1iFvE::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1iFvE* t_std_collections_Map_1iFvE::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1iFvE_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1iFvE>(f0.l_root);
}

bbBool t_std_collections_Map_1iFvE::m_Contains(bbInt l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1iFvE_Node*)0));
}

void t_std_collections_Map_1iFvE::m_Clear(){
  this->m__0root=((t_std_collections_Map_1iFvE_Node*)0);
}

t_std_collections_Map_1iFvE_Iterator t_std_collections_Map_1iFvE::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1iFvE_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1iFvE::m_Add(bbInt l_key,bbFunction<void()> l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1iFvE_Node>(l_key,l_value,0,((t_std_collections_Map_1iFvE_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1iFvE_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1iz_Node::gcMark(){
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

t_std_collections_Map_1iz_Node::t_std_collections_Map_1iz_Node(bbInt l_key,bbBool l_value,bbInt l_color,t_std_collections_Map_1iz_Node* l_parent){
  this->m__0key=l_key;
  this->m__0value=l_value;
  this->m__0color=l_color;
  this->m__0parent=l_parent;
}

bbBool t_std_collections_Map_1iz_Node::m_Value(){
  return this->m__0value;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1iz_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0left;
    while(bbBool(f1.l_node->m__0right)){
      f1.l_node=f1.l_node->m__0right;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1iz_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    f1.l_node=this->m__0right;
    while(bbBool(f1.l_node->m__0left)){
      f1.l_node=f1.l_node->m__0left;
    }
    return f1.l_node;
  }
  f0.l_node=this;
  f0.l_parent=this->m__0parent;
  while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
    f0.l_node=f0.l_parent;
    f0.l_parent=f0.l_parent->m__0parent;
  }
  return f0.l_parent;
}

bbInt t_std_collections_Map_1iz_Node::m_Key(){
  return this->m__0key;
}

bbInt t_std_collections_Map_1iz_Node::m_Count(bbInt l_n){
  if(bbBool(this->m__0left)){
    l_n=this->m__0left->m_Count(l_n);
  }
  if(bbBool(this->m__0right)){
    l_n=this->m__0right->m_Count(l_n);
  }
  return (l_n+1);
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz_Node::m_Copy(t_std_collections_Map_1iz_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=bbGCNew<t_std_collections_Map_1iz_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  if(bbBool(this->m__0left)){
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  if(bbBool(this->m__0right)){
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  return f0.l_node;
}

t_std_collections_Map_1iz_Iterator::t_std_collections_Map_1iz_Iterator(t_std_collections_Map_1iz_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iz_Iterator::m_Valid(){
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz_Iterator::m_Current(){
  return (*this).m__0node;
}

void t_std_collections_Map_1iz_Iterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1iz_Iterator&x,const t_std_collections_Map_1iz_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_Iterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1iz_KeyIterator::t_std_collections_Map_1iz_KeyIterator(t_std_collections_Map_1iz_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iz_KeyIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbInt t_std_collections_Map_1iz_KeyIterator::m_Current(){
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1iz_KeyIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1iz_KeyIterator&x,const t_std_collections_Map_1iz_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_KeyIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1iz_MapKeys::t_std_collections_Map_1iz_MapKeys(t_std_collections_Map_1iz* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1iz_KeyIterator t_std_collections_Map_1iz_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1iz_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1iz_MapKeys&x,const t_std_collections_Map_1iz_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_MapKeys&t){
  bbGCMark(t.m__0map);
}

t_std_collections_Map_1iz_ValueIterator::t_std_collections_Map_1iz_ValueIterator(t_std_collections_Map_1iz_Node* l_node){
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iz_ValueIterator::m_Valid(){
  return bbBool((*this).m__0node);
}

bbBool t_std_collections_Map_1iz_ValueIterator::m_Current(){
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1iz_ValueIterator::m_Bump(){
  (*this).m__0node=(*this).m__0node->m_NextNode();
}

int bbCompare(const t_std_collections_Map_1iz_ValueIterator&x,const t_std_collections_Map_1iz_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_ValueIterator&t){
  bbGCMark(t.m__0node);
}

t_std_collections_Map_1iz_MapValues::t_std_collections_Map_1iz_MapValues(t_std_collections_Map_1iz* l_map){
  (*this).m__0map=l_map;
}

t_std_collections_Map_1iz_ValueIterator t_std_collections_Map_1iz_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1iz_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}

int bbCompare(const t_std_collections_Map_1iz_MapValues&x,const t_std_collections_Map_1iz_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1iz::gcMark(){
  bbGCMark(m__0root);
}

t_std_collections_Map_1iz::t_std_collections_Map_1iz(t_std_collections_Map_1iz_Node* l_root){
  this->m__0root=l_root;
}

t_std_collections_Map_1iz::t_std_collections_Map_1iz(){
}

void t_std_collections_Map_1iz::m__idxeq(bbInt l_key,bbBool l_value){
  this->m_Set(l_key,l_value);
}

bbBool t_std_collections_Map_1iz::m__idx(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  return f0.l_node->m__0value;
}

t_std_collections_Map_1iz_MapValues t_std_collections_Map_1iz::m_Values(){
  return t_std_collections_Map_1iz_MapValues(this);
}

bbBool t_std_collections_Map_1iz::m_Update(bbInt l_key,bbBool l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  f0.l_node->m__0value=l_value;
  return true;
}

bbBool t_std_collections_Map_1iz::m_Set(bbInt l_key,bbBool l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1iz_Node>(l_key,l_value,0,((t_std_collections_Map_1iz_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      f0.l_node->m__0value=l_value;
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1iz_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void t_std_collections_Map_1iz::m_RotateRight(t_std_collections_Map_1iz_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0left;
  l_node->m__0left=f0.l_child->m__0right;
  if(bbBool(f0.l_child->m__0right)){
    f0.l_child->m__0right->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0right)){
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0right=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1iz::m_RotateLeft(t_std_collections_Map_1iz_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  f0.l_child=l_node->m__0right;
  l_node->m__0right=f0.l_child->m__0left;
  if(bbBool(f0.l_child->m__0left)){
    f0.l_child->m__0left->m__0parent=l_node;
  }
  f0.l_child->m__0parent=l_node->m__0parent;
  if(bbBool(l_node->m__0parent)){
    if((l_node==l_node->m__0parent->m__0left)){
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    this->m__0root=f0.l_child;
  }
  f0.l_child->m__0left=l_node;
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1iz::m_RemoveNode(t_std_collections_Map_1iz_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_child{};
    t_std_collections_Map_1iz_Node* l_parent{};
    t_std_collections_Map_1iz_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  if(!bbBool(l_node->m__0left)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0right;
  }else if(!bbBool(l_node->m__0right)){
    f0.l_splice=l_node;
    f0.l_child=l_node->m__0left;
  }else{
    f0.l_splice=l_node->m__0left;
    while(bbBool(f0.l_splice->m__0right)){
      f0.l_splice=f0.l_splice->m__0right;
    }
    f0.l_child=f0.l_splice->m__0left;
    l_node->m__0key=f0.l_splice->m__0key;
    l_node->m__0value=f0.l_splice->m__0value;
  }
  f0.l_parent=f0.l_splice->m__0parent;
  if(bbBool(f0.l_child)){
    f0.l_child->m__0parent=f0.l_parent;
  }
  if(!bbBool(f0.l_parent)){
    this->m__0root=f0.l_child;
    return;
  }
  if((f0.l_splice==f0.l_parent->m__0left)){
    f0.l_parent->m__0left=f0.l_child;
  }else{
    f0.l_parent->m__0right=f0.l_child;
  }
  if((f0.l_splice->m__0color==1)){
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1iz::m_Remove(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(!bbBool(f0.l_node)){
    return false;
  }
  this->m_RemoveNode(f0.l_node);
  return true;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1iz_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0right)){
    f0.l_node=f0.l_node->m__0right;
  }
  return f0.l_node;
}

t_std_collections_Map_1iz_MapKeys t_std_collections_Map_1iz::m_Keys(){
  return t_std_collections_Map_1iz_MapKeys(this);
}

void t_std_collections_Map_1iz::m_InsertFixup(t_std_collections_Map_1iz_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    f0_t(t_std_collections_Map_1iz_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
    if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1iz_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0right)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateLeft(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1iz_Node* l_uncle{};
        void gcMark(){
          bbGCMarkPtr(l_uncle);
        }
      }f2{};
      f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
      if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
        f0.l_node->m__0parent->m__0color=1;
        f2.l_uncle->m__0color=1;
        f2.l_uncle->m__0parent->m__0color=0;
        f0.l_node=f2.l_uncle->m__0parent;
      }else{
        if((f0.l_node==f0.l_node->m__0parent->m__0left)){
          f0.l_node=f0.l_node->m__0parent;
          this->m_RotateRight(f0.l_node);
        }
        f0.l_node->m__0parent->m__0color=1;
        f0.l_node->m__0parent->m__0parent->m__0color=0;
        this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
      }
    }
  }
  this->m__0root->m__0color=1;
}

bbBool t_std_collections_Map_1iz::m_Get(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m_FindNode(l_key);
  if(bbBool(f0.l_node)){
    return f0.l_node->m__0value;
  }
  return false;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    return ((t_std_collections_Map_1iz_Node*)0);
  }
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node->m__0left)){
    f0.l_node=f0.l_node->m__0left;
  }
  return f0.l_node;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz::m_FindNode(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  f0.l_node=this->m__0root;
  while(bbBool(f0.l_node)){
    bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return f0.l_node;
    }
  }
  return ((t_std_collections_Map_1iz_Node*)0);
}

bbBool t_std_collections_Map_1iz::m_Empty(){
  return (this->m__0root==((t_std_collections_Map_1iz_Node*)0));
}

void t_std_collections_Map_1iz::m_DeleteFixup(t_std_collections_Map_1iz_Node* l_node,t_std_collections_Map_1iz_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    f0_t(t_std_collections_Map_1iz_Node* l_node,t_std_collections_Map_1iz_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
    if((f0.l_node==f0.l_parent->m__0left)){
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1iz_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0right;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateLeft(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0right;
      }
      if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
          f2.l_sib->m__0left->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateRight(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0right;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0right->m__0color=1;
        this->m_RotateLeft(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }else{
      struct f2_t : public bbGCFrame{
        t_std_collections_Map_1iz_Node* l_sib{};
        void gcMark(){
          bbGCMarkPtr(l_sib);
        }
      }f2{};
      f2.l_sib=f0.l_parent->m__0left;
      if((f2.l_sib->m__0color==0)){
        f2.l_sib->m__0color=1;
        f0.l_parent->m__0color=0;
        this->m_RotateRight(f0.l_parent);
        f2.l_sib=f0.l_parent->m__0left;
      }
      if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
        f2.l_sib->m__0color=0;
        f0.l_node=f0.l_parent;
        f0.l_parent=f0.l_parent->m__0parent;
      }else{
        if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
          f2.l_sib->m__0right->m__0color=1;
          f2.l_sib->m__0color=0;
          this->m_RotateLeft(f2.l_sib);
          f2.l_sib=f0.l_parent->m__0left;
        }
        f2.l_sib->m__0color=f0.l_parent->m__0color;
        f0.l_parent->m__0color=1;
        f2.l_sib->m__0left->m__0color=1;
        this->m_RotateRight(f0.l_parent);
        f0.l_node=this->m__0root;
      }
    }
  }
  if(bbBool(f0.l_node)){
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1iz::m_Count(){
  if(!bbBool(this->m__0root)){
    return bbInt(0);
  }
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1iz* t_std_collections_Map_1iz::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  if(bbBool(this->m__0root)){
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1iz_Node*)0));
  }
  return bbGCNew<t_std_collections_Map_1iz>(f0.l_root);
}

bbBool t_std_collections_Map_1iz::m_Contains(bbInt l_key){
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1iz_Node*)0));
}

void t_std_collections_Map_1iz::m_Clear(){
  this->m__0root=((t_std_collections_Map_1iz_Node*)0);
}

t_std_collections_Map_1iz_Iterator t_std_collections_Map_1iz::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  return t_std_collections_Map_1iz_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1iz::m_Add(bbInt l_key,bbBool l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  if(!bbBool(this->m__0root)){
    this->m__0root=bbGCNew<t_std_collections_Map_1iz_Node>(l_key,l_value,0,((t_std_collections_Map_1iz_Node*)0));
    return true;
  }
  f0.l_node=this->m__0root;
  bbInt l_cmp{};
  while(bbBool(f0.l_node)){
    f0.l_parent=f0.l_node;
    l_cmp=bbCompare(l_key,f0.l_node->m__0key);
    if((l_cmp>bbInt(0))){
      f0.l_node=f0.l_node->m__0right;
    }else if((l_cmp<bbInt(0))){
      f0.l_node=f0.l_node->m__0left;
    }else{
      return false;
    }
  }
  f0.l_node=bbGCNew<t_std_collections_Map_1iz_Node>(l_key,l_value,0,f0.l_parent);
  if((l_cmp>bbInt(0))){
    f0.l_parent->m__0right=f0.l_node;
  }else{
    f0.l_parent->m__0left=f0.l_node;
  }
  this->m_InsertFixup(f0.l_node);
  return true;
}

void mx2_mojo_std_collections_2map_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_collections_2map_init_v("mojo_std_collections_2map",&mx2_mojo_std_collections_2map_init);
