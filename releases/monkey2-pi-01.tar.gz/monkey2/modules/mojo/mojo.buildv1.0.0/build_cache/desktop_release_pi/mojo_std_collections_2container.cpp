
#include "../../desktop_release_pi/mojo_std_collections_2container.h"

// ***** External *****

// ***** Internal *****

void mx2_mojo_std_collections_2container_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_collections_2container_init_v("mojo_std_collections_2container",&mx2_mojo_std_collections_2container_init);
