
#include "../../desktop_release_pi/mojo_graphics_2canvas.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_graphics_2device.h"
#include "../../desktop_release_pi/mojo_graphics_2font.h"
#include "../../desktop_release_pi/mojo_graphics_2image.h"
#include "../../desktop_release_pi/mojo_graphics_2material.h"
#include "../../desktop_release_pi/mojo_graphics_2shader.h"
#include "../../desktop_release_pi/mojo_graphics_2texture.h"
#include "../../desktop_release_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_collections_2stack.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_graphics_2pixmap.h"

extern t_std_geom_Rect_1i g_std_geom_TransformRecti_1f(t_std_geom_Rect_1i l_rect,t_std_geom_AffineMat3_1f l_matrix);
extern bbString g_std_stringio_LoadString(bbString l_path);
extern bbInt g_monkey_math_Min_1i(bbInt l_x,bbInt l_y);
extern bbInt g_monkey_math_Max_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

bbGCRootVar<t_mojo_graphics_ShaderEnv> g_mojo_graphics_Canvas__0ambientEnv;
bbGCRootVar<t_mojo_graphics_Font> g_mojo_graphics_Canvas__0defaultFont;
bbBool g_mojo_graphics_Canvas__0inited;
bbGCRootVar<t_mojo_graphics_Shader> g_mojo_graphics_Canvas__0nullShader;

void t_mojo_graphics_DrawOp::gcMark(){
  bbGCMark(m_material);
}

void t_mojo_graphics_Canvas::init(){
  m__0renderMatrixStack=bbGCNew<t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2>();
  m__0renderBoundsStack=bbGCNew<t_std_collections_Stack_1Tt_std_geom_Rect_1i_2>();
  m__0matrixStack=bbGCNew<t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2>();
  m__0ops=bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2>();
  m__0op=bbGCNew<t_mojo_graphics_DrawOp>();
  m__0vertices=bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2>();
  m__0materials=bbArray<bbGCVar<t_mojo_graphics_Material>>::create(6);
}

void t_mojo_graphics_Canvas::gcMark(){
  bbGCMark(m__0target);
  bbGCMark(m__0envParams);
  bbGCMark(m__0device);
  bbGCMark(m__0renderMatrixStack);
  bbGCMark(m__0renderBoundsStack);
  bbGCMark(m__0font);
  bbGCMark(m__0matrixStack);
  bbGCMark(m__0ops);
  bbGCMark(m__0op);
  bbGCMark(m__0vertices);
  bbGCMark(m__0vertexData);
  bbGCMark(m__0materials);
}

t_mojo_graphics_Canvas::t_mojo_graphics_Canvas(bbInt l_width,bbInt l_height){
  init();
  this->m_Init(((t_mojo_graphics_Texture*)0),t_std_geom_Vec2_1i(l_width,l_height),t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_width,l_height));
}

t_mojo_graphics_Canvas::t_mojo_graphics_Canvas(t_mojo_graphics_Texture* l_texture){
  init();
  this->m_Init(l_texture,l_texture->m_Rect().m_Size(),l_texture->m_Rect());
  this->m_BeginRender(l_texture->m_Rect(),t_std_geom_AffineMat3_1f(bbNullCtor));
}

t_mojo_graphics_Canvas::t_mojo_graphics_Canvas(t_mojo_graphics_Image* l_image){
  init();
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* t0{};
    t_mojo_graphics_Texture* t1{};
    void gcMark(){
      bbGCMarkPtr(t0);
      bbGCMarkPtr(t1);
    }
  }f0{};
  this->m_Init(f0.t0=l_image->m_Texture(),(f0.t1=l_image->m_Texture())->m_Rect().m_Size(),l_image->m_Rect());
  this->m_BeginRender(t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_image->m_Rect().m_Size()),t_std_geom_AffineMat3_1f(bbNullCtor));
}

void t_mojo_graphics_Canvas::m_Viewport(t_std_geom_Rect_1i l_viewport){
  this->m_Flush();
  this->m__0viewport=l_viewport;
  this->m__0dirty|=6;
}

t_std_geom_Rect_1i t_mojo_graphics_Canvas::m_Viewport(){
  return this->m__0viewport;
}

void t_mojo_graphics_Canvas::m_ViewMatrix(t_std_geom_Mat4_1f l_viewMatrix){
  this->m_Flush();
  this->m__0viewMatrix=l_viewMatrix;
  this->m__0dirty|=4;
}

t_std_geom_Mat4_1f t_mojo_graphics_Canvas::m_ViewMatrix(){
  return this->m__0viewMatrix;
}

void t_mojo_graphics_Canvas::m_Validate(){
  if(!bbBool(this->m__0dirty)){
    return;
  }
  if(bbBool((this->m__0dirty&1))){
    t_std_geom_Mat4_1f l_projMatrix{};
    t_std_geom_Rect_1i l_viewport=this->m__0targetRect;
    if(bbBool(this->m__0target)){
      l_projMatrix=g_std_geom_Mat4_1f_Ortho(0.0f,bbFloat(l_viewport.m_Width()),0.0f,bbFloat(l_viewport.m_Height()),bbFloat(-1),1.0f);
    }else{
      l_viewport.m_min.m_y=(this->m__0targetSize.m_y-l_viewport.m_max.m_y);
      l_viewport.m_max.m_y=(l_viewport.m_min.m_y+l_viewport.m_Height());
      l_projMatrix=g_std_geom_Mat4_1f_Ortho(0.0f,bbFloat(l_viewport.m_Width()),bbFloat(l_viewport.m_Height()),0.0f,bbFloat(-1),1.0f);
    }
    this->m__0device->m_RenderTarget(this->m__0target);
    this->m__0device->m_Viewport(this->m__0targetRect);
    this->m__0envParams->m_SetMatrix(BB_T("mx2_ProjectionMatrix"),l_projMatrix);
    this->m__0dirty|=4;
  }
  if(bbBool((this->m__0dirty&4))){
    t_std_geom_AffineMat3_1f l_renderMatrix=this->m__0renderMatrix.m_Translate(t_std_geom_Vec2_1f(bbFloat(this->m__0viewport.m_X()),bbFloat(this->m__0viewport.m_Y())));
    t_std_geom_Mat4_1f l_modelViewMatrix=this->m__0viewMatrix.m__mul(this->m__0modelMatrix).m__mul(t_std_geom_Mat4_1f(l_renderMatrix));
    this->m__0envParams->m_SetMatrix(BB_T("mx2_ModelViewMatrix"),l_modelViewMatrix);
    this->m__0envParams->m_SetColor(BB_T("mx2_AmbientLight"),this->m__0ambientLight);
    this->m__0envParams->m_SetColor(BB_T("mx2_RenderColor"),this->m__0renderColor);
    this->m__0device->m_EnvParams(this->m__0envParams);
  }
  if(bbBool((this->m__0dirty&2))){
    t_std_geom_Rect_1i l_scissor=g_std_geom_TransformRecti_1f(this->m__0viewport.m__and(this->m__0scissor.m__add(this->m__0viewport.m_Origin())),this->m__0renderMatrix);
    l_scissor=l_scissor.m__and(this->m__0renderBounds).m__add(this->m__0targetRect.m_Origin());
    if(!bbBool(this->m__0target)){
      bbInt l_h=l_scissor.m_Height();
      l_scissor.m_min.m_y=(this->m__0targetSize.m_y-l_scissor.m_max.m_y);
      l_scissor.m_max.m_y=(l_scissor.m_min.m_y+l_h);
    }
    this->m__0device->m_Scissor(l_scissor);
  }
  this->m__0dirty=bbInt(0);
}

void t_mojo_graphics_Canvas::m_Translate(bbFloat l_tx,bbFloat l_ty){
  this->m_Matrix(this->m_Matrix().m_Translate(l_tx,l_ty));
}

void t_mojo_graphics_Canvas::m_TextureFilteringEnabled(bbBool l_enabled){
  this->m_Flush();
  this->m__0filter=l_enabled;
}

bbBool t_mojo_graphics_Canvas::m_TextureFilteringEnabled(){
  return this->m__0filter;
}

void t_mojo_graphics_Canvas::m_Scissor(t_std_geom_Rect_1i l_scissor){
  this->m_Flush();
  this->m__0scissor=l_scissor;
  this->m__0dirty|=2;
}

t_std_geom_Rect_1i t_mojo_graphics_Canvas::m_Scissor(){
  return this->m__0scissor;
}

void t_mojo_graphics_Canvas::m_Scale(bbFloat l_sx,bbFloat l_sy){
  this->m_Matrix(this->m_Matrix().m_Scale(l_sx,l_sy));
}

void t_mojo_graphics_Canvas::m_Rotate(bbFloat l_rz){
  this->m_Matrix(this->m_Matrix().m_Rotate(bbDouble(l_rz)));
}

void t_mojo_graphics_Canvas::m_Resize(t_std_geom_Vec2_1i l_size){
  this->m_Flush();
  this->m__0targetSize=l_size;
  this->m__0targetRect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_size);
  this->m__0dirty|=1;
}

void t_mojo_graphics_Canvas::m_RenderDrawOps(){
  t_mojo_graphics_Vertex2f* l_p=this->m__0vertexData->data();
  this->m__0device->m_FilteringEnabled(this->m__0filter);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    f1.l_0=this->m__0ops->m_All();
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_DrawOp* l_op{};
        t_mojo_graphics_Shader* t0{};
        t_mojo_graphics_ParamBuffer* t1{};
        void gcMark(){
          bbGCMarkPtr(l_op);
          bbGCMarkPtr(t0);
          bbGCMarkPtr(t1);
        }
      }f2{};
      f2.l_op=f1.l_0.m_Current();
      this->m__0device->m_BlendMode(f2.l_op->m_blendMode);
      this->m__0device->m_Shader(f2.t0=f2.l_op->m_material->m_Shader());
      this->m__0device->m_Params(f2.t1=f2.l_op->m_material->m_Params());
      this->m__0device->m_Render(l_p,f2.l_op->m_order,f2.l_op->m_count);
      l_p=(l_p+(f2.l_op->m_order*f2.l_op->m_count));
    }
  }
}

void t_mojo_graphics_Canvas::m_RenderColor(t_std_graphics_Color l_renderColor){
  this->m_Flush();
  this->m__0renderColor=l_renderColor;
  this->m__0dirty|=4;
}

t_std_graphics_Color t_mojo_graphics_Canvas::m_RenderColor(){
  return this->m__0renderColor;
}

void t_mojo_graphics_Canvas::m_PushMatrix(){
  this->m__0matrixStack->m_Push(this->m_Matrix());
}

bbArray<bbGCVar<t_mojo_graphics_Material>>* t_mojo_graphics_Canvas::m_PrimitiveMaterials(){
  return this->m__0materials;
}

void t_mojo_graphics_Canvas::m_PopMatrix(){
  this->m_Matrix(this->m__0matrixStack->m_Pop());
}

void t_mojo_graphics_Canvas::m_ModelMatrix(t_std_geom_Mat4_1f l_modelMatrix){
  this->m_Flush();
  this->m__0modelMatrix=l_modelMatrix;
  this->m__0dirty|=4;
}

t_std_geom_Mat4_1f t_mojo_graphics_Canvas::m_ModelMatrix(){
  return this->m__0modelMatrix;
}

void t_mojo_graphics_Canvas::m_Matrix(t_std_geom_AffineMat3_1f l_matrix){
  this->m__0matrix=l_matrix;
}

t_std_geom_AffineMat3_1f t_mojo_graphics_Canvas::m_Matrix(){
  return this->m__0matrix;
}

void t_mojo_graphics_Canvas::m_Init(t_mojo_graphics_Texture* l_target,t_std_geom_Vec2_1i l_size,t_std_geom_Rect_1i l_viewport){
  if(!g_mojo_graphics_Canvas__0inited){
    g_mojo_graphics_Canvas__0inited=true;
    bbString l_env=g_std_stringio_LoadString(BB_T("asset::mojo/shader_env.glsl"));
    g_mojo_graphics_Canvas__0ambientEnv=bbGCNew<t_mojo_graphics_ShaderEnv>((BB_T("#define RENDERPASS_AMBIENT\n")+l_env));
    g_mojo_graphics_Canvas__0defaultFont=g_mojo_graphics_Font_Load(BB_T("asset::mojo/RobotoMono-Regular.ttf"),16.0f,bbInt(0),((t_mojo_graphics_Shader*)0));
    g_mojo_graphics_Canvas__0nullShader=g_mojo_graphics_Shader_GetShader(BB_T("null"));
  }
  this->m__0target=l_target;
  this->m__0targetSize=l_size;
  this->m__0targetRect=l_viewport;
  this->m__0envParams=bbGCNew<t_mojo_graphics_ParamBuffer>();
  this->m__0device=bbGCNew<t_mojo_graphics_GraphicsDevice>();
  this->m__0viewport=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m__0targetRect.m_Width(),this->m__0targetRect.m_Height());
  this->m__0scissor=this->m__0viewport;
  this->m__0viewMatrix=t_std_geom_Mat4_1f(bbNullCtor);
  this->m__0modelMatrix=t_std_geom_Mat4_1f(bbNullCtor);
  this->m__0ambientLight=g_std_graphics_Color_Black;
  this->m__0filter=true;
  this->m__0renderColor=g_std_graphics_Color_White;
  this->m__0renderMatrix=t_std_geom_AffineMat3_1f(bbNullCtor);
  this->m__0renderBounds=t_std_geom_Rect_1i(bbInt(0),bbInt(0),1073741824,1073741824);
  this->m__0dirty=7;
  this->m_Font(((t_mojo_graphics_Font*)0));
  this->m_Alpha(1.0f);
  this->m_Color(g_std_graphics_Color_White);
  this->m_Matrix(t_std_geom_AffineMat3_1f(bbNullCtor));
  this->m_BlendMode(1);
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<this->m__0materials->length());l_i+=1){
      this->m__0materials->at(l_i)=bbGCNew<t_mojo_graphics_Material>(g_mojo_graphics_Canvas__0nullShader);
    }
  }
}

void t_mojo_graphics_Canvas::m_Font(t_mojo_graphics_Font* l_font){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Font* l_font{};
    f0_t(t_mojo_graphics_Font* l_font):l_font(l_font){
    }
    void gcMark(){
      bbGCMarkPtr(l_font);
    }
  }f0{l_font};
  if(!bbBool(f0.l_font)){
    f0.l_font=g_mojo_graphics_Canvas__0defaultFont;
  }
  this->m__0font=f0.l_font;
}

t_mojo_graphics_Font* t_mojo_graphics_Canvas::m_Font(){
  return this->m__0font;
}

void t_mojo_graphics_Canvas::m_Flush(){
  this->m_Validate();
  this->m_RenderDrawOps();
  this->m_ClearDrawOps();
}

void t_mojo_graphics_Canvas::m_EndRender(){
  this->m_Flush();
  this->m__0renderBounds=this->m__0renderBoundsStack->m_Pop();
  this->m__0renderMatrix=this->m__0renderMatrixStack->m_Pop();
}

void t_mojo_graphics_Canvas::m_DrawTriangle(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1,bbFloat l_x2,bbFloat l_y2){
  this->m_AddDrawOp(this->m__0materials->at(3),3,1);
  this->m_AddVertex(l_x0,l_y0,0.0f,0.0f);
  this->m_AddVertex(l_x1,l_y1,1.0f,0.0f);
  this->m_AddVertex(l_x2,l_y2,1.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawTriangle(t_std_geom_Vec2_1f l_v0,t_std_geom_Vec2_1f l_v1,t_std_geom_Vec2_1f l_v2){
  this->m_AddDrawOp(this->m__0materials->at(3),3,1);
  this->m_AddVertex(l_v0.m_x,l_v0.m_y,.5f,0.0f);
  this->m_AddVertex(l_v1.m_x,l_v1.m_y,1.0f,1.0f);
  this->m_AddVertex(l_v2.m_x,l_v2.m_y,0.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawText(bbString l_text,bbFloat l_tx,bbFloat l_ty,bbFloat l_handleX,bbFloat l_handleY){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Image* l_image{};
    t_mojo_graphics_Texture* t0{};
    t_mojo_graphics_Material* t1{};
    void gcMark(){
      bbGCMarkPtr(l_image);
      bbGCMarkPtr(t0);
      bbGCMarkPtr(t1);
    }
  }f0{};
  l_tx-=(this->m__0font->m_TextWidth(l_text)*l_handleX);
  l_ty-=(this->m__0font->m_Height()*l_handleY);
  f0.l_image=this->m__0font->m_Image();
  bbInt l_sx=f0.l_image->m_Rect().m_min.m_x;
  bbInt l_sy=f0.l_image->m_Rect().m_min.m_y;
  bbInt l_tw=(f0.t0=f0.l_image->m_Texture())->m_Width();
  bbInt l_th=(f0.t0=f0.l_image->m_Texture())->m_Height();
  this->m_AddDrawOp(f0.t1=f0.l_image->m_Material(),4,l_text.length());
  {
    bbInt l_0=bbInt(0);
    bbInt l_1=l_text.length();
    for(;(l_0<l_1);l_0+=1){
      bbInt l_char=l_text[l_0];
      t_mojo_graphics_Glyph l_g=this->m__0font->m_GetGlyph(l_char);
      bbFloat l_s0=(bbFloat((l_g.m_rect.m_min.m_x+l_sx))/bbFloat(l_tw));
      bbFloat l_t0=(bbFloat((l_g.m_rect.m_min.m_y+l_sy))/bbFloat(l_th));
      bbFloat l_s1=(bbFloat((l_g.m_rect.m_max.m_x+l_sx))/bbFloat(l_tw));
      bbFloat l_t1=(bbFloat((l_g.m_rect.m_max.m_y+l_sy))/bbFloat(l_th));
      bbDouble l_x0=std::round(bbDouble((l_tx+l_g.m_offset.m_x)));
      bbDouble l_y0=std::round(bbDouble((l_ty+l_g.m_offset.m_y)));
      bbDouble l_x1=(l_x0+bbDouble(l_g.m_rect.m_Width()));
      bbDouble l_y1=(l_y0+bbDouble(l_g.m_rect.m_Height()));
      this->m_AddVertex(bbFloat(l_x0),bbFloat(l_y0),l_s0,l_t0);
      this->m_AddVertex(bbFloat(l_x1),bbFloat(l_y0),l_s1,l_t0);
      this->m_AddVertex(bbFloat(l_x1),bbFloat(l_y1),l_s1,l_t1);
      this->m_AddVertex(bbFloat(l_x0),bbFloat(l_y1),l_s0,l_t1);
      l_tx+=l_g.m_advance;
    }
  }
}

void t_mojo_graphics_Canvas::m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height,t_mojo_graphics_Image* l_srcImage,bbInt l_srcX,bbInt l_srcY,bbInt l_srcWidth,bbInt l_srcHeight){
  this->m_DrawRect(t_std_geom_Rect_1f(l_x,l_y,(l_x+l_width),(l_y+l_height)),l_srcImage,t_std_geom_Rect_1i(l_srcX,l_srcY,(l_srcX+l_srcWidth),(l_srcY+l_srcHeight)));
}

void t_mojo_graphics_Canvas::m_DrawRect(t_std_geom_Rect_1f l_rect,t_mojo_graphics_Image* l_srcImage,t_std_geom_Rect_1i l_srcRect){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* t0{};
    t_mojo_graphics_Material* t1{};
    void gcMark(){
      bbGCMarkPtr(t0);
      bbGCMarkPtr(t1);
    }
  }f0{};
  bbFloat l_s0=(bbFloat((l_srcImage->m_Rect().m_min.m_x+l_srcRect.m_min.m_x))/bbFloat((f0.t0=l_srcImage->m_Texture())->m_Width()));
  bbFloat l_t0=(bbFloat((l_srcImage->m_Rect().m_min.m_y+l_srcRect.m_min.m_y))/bbFloat((f0.t0=l_srcImage->m_Texture())->m_Height()));
  bbFloat l_s1=(bbFloat((l_srcImage->m_Rect().m_min.m_x+l_srcRect.m_max.m_x))/bbFloat((f0.t0=l_srcImage->m_Texture())->m_Width()));
  bbFloat l_t1=(bbFloat((l_srcImage->m_Rect().m_min.m_y+l_srcRect.m_max.m_y))/bbFloat((f0.t0=l_srcImage->m_Texture())->m_Height()));
  this->m_AddDrawOp(f0.t1=l_srcImage->m_Material(),4,1);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_min.m_y,l_s0,l_t0);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_min.m_y,l_s1,l_t0);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_max.m_y,l_s1,l_t1);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_max.m_y,l_s0,l_t1);
}

void t_mojo_graphics_Canvas::m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height,t_mojo_graphics_Image* l_srcImage){
  this->m_DrawRect(t_std_geom_Rect_1f(l_x,l_y,(l_x+l_width),(l_y+l_height)),l_srcImage);
}

void t_mojo_graphics_Canvas::m_DrawRect(t_std_geom_Rect_1f l_rect,t_mojo_graphics_Image* l_srcImage){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Material* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  t_std_geom_Rect_1f l_tc=l_srcImage->m_TexCoords();
  this->m_AddDrawOp(f0.t0=l_srcImage->m_Material(),4,1);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_min.m_y,l_tc.m_min.m_x,l_tc.m_min.m_y);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_min.m_y,l_tc.m_max.m_x,l_tc.m_min.m_y);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_max.m_y,l_tc.m_max.m_x,l_tc.m_max.m_y);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_max.m_y,l_tc.m_min.m_x,l_tc.m_max.m_y);
}

void t_mojo_graphics_Canvas::m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height){
  this->m_DrawRect(t_std_geom_Rect_1f(l_x,l_y,(l_x+l_width),(l_y+l_height)));
}

void t_mojo_graphics_Canvas::m_DrawRect(t_std_geom_Rect_1f l_rect){
  this->m_AddDrawOp(this->m__0materials->at(4),4,1);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_min.m_y,0.0f,0.0f);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_min.m_y,1.0f,0.0f);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_max.m_y,1.0f,1.0f);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_max.m_y,0.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawQuad(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1,bbFloat l_x2,bbFloat l_y2,bbFloat l_x3,bbFloat l_y3){
  this->m_AddDrawOp(this->m__0materials->at(4),4,1);
  this->m_AddVertex(l_x0,l_y0,0.0f,0.0f);
  this->m_AddVertex(l_x1,l_y1,1.0f,0.0f);
  this->m_AddVertex(l_x2,l_y2,1.0f,1.0f);
  this->m_AddVertex(l_x3,l_y3,0.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawPrimitives(bbInt l_order,bbInt l_count,bbFloat* l_vertices,bbInt l_verticesPitch,bbFloat* l_texCoords,bbInt l_texCoordsPitch,bbInt* l_indices){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Material* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDebugAssert((l_order>bbInt(0)),BB_T("Illegal primtive type"));
  if(!bbBool(l_texCoords)){
    struct f1_t : public bbGCFrame{
      bbArray<bbFloat>* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    static bbGCRootVar<t_std_collections_Stack_1f> g__0texCoords=bbGCNew<t_std_collections_Stack_1f>();
    if((g__0texCoords->m_Length()!=(l_order*2))){
      g__0texCoords->m_Resize((l_order*2));
      {
        bbInt l_i=bbInt(0);
        for(;(((2>bbInt(0))&&(l_i<(l_order*2)))||((2<bbInt(0))&&(l_i>(l_order*2))));l_i+=2){
          g__0texCoords->m__idxeq(l_i,0.0f);
          g__0texCoords->m__idxeq(bbInt((l_i==1)),0.0f);
        }
      }
    }
    l_texCoords=(f1.t0=g__0texCoords->m_Data())->data();
    l_texCoordsPitch=8;
  }
  this->m_AddDrawOp(f0.t0=this->m__0materials->at(g_monkey_math_Min_1i(l_order,5)),l_order,l_count);
  if(bbBool(l_indices)){
    {
      bbInt l_i=bbInt(0);
      for(;(l_i<l_count);l_i+=1){
        {
          bbInt l_j=bbInt(0);
          for(;(l_j<l_order);l_j+=1){
            bbInt l_k=l_indices[l_j];
            bbFloat* l_vp=((bbFloat*)((((bbUByte*)(l_vertices))+(l_k*l_verticesPitch))));
            bbFloat* l_tp=((bbFloat*)((((bbUByte*)(l_texCoords))+(l_k*l_texCoordsPitch))));
            this->m_AddVertex(l_vp[bbInt(0)],l_vp[1],l_tp[bbInt(0)],l_tp[1]);
          }
        }
        l_indices=(l_indices+l_order);
      }
    }
  }else{
    {
      bbInt l_i=bbInt(0);
      for(;(l_i<l_count);l_i+=1){
        {
          bbInt l_j=bbInt(0);
          for(;(l_j<l_order);l_j+=1){
            this->m_AddVertex(l_vertices[bbInt(0)],l_vertices[1],l_texCoords[bbInt(0)],l_texCoords[1]);
            l_vertices=((bbFloat*)((((bbUByte*)(l_vertices))+l_verticesPitch)));
            l_texCoords=((bbFloat*)((((bbUByte*)(l_texCoords))+l_texCoordsPitch)));
          }
        }
      }
    }
  }
}

void t_mojo_graphics_Canvas::m_DrawPoly(bbArray<bbFloat>* l_vertices){
  bbDebugAssert(((l_vertices->length()>=6)&&((l_vertices->length()&1)==bbInt(0))),BB_T("Debug assert failed"));
  bbInt l_n=(l_vertices->length()/2);
  this->m_AddDrawOp(this->m__0materials->at(5),l_n,1);
  {
    bbInt l_i=bbInt(0);
    for(;(((2>bbInt(0))&&(l_i<(l_n*2)))||((2<bbInt(0))&&(l_i>(l_n*2))));l_i+=2){
      this->m_AddVertex(l_vertices->at(l_i),l_vertices->at((l_i+1)),0.0f,0.0f);
    }
  }
}

void t_mojo_graphics_Canvas::m_DrawPoint(bbFloat l_x,bbFloat l_y){
  this->m_AddDrawOp(this->m__0materials->at(1),1,1);
  this->m_AddVertex((l_x+.5f),(l_y+.5f),0.0f,0.0f);
}

void t_mojo_graphics_Canvas::m_DrawPoint(t_std_geom_Vec2_1f l_v){
  this->m_AddDrawOp(this->m__0materials->at(1),1,1);
  this->m_AddVertex((l_v.m_x+.5f),(l_v.m_y+.5f),0.0f,0.0f);
}

void t_mojo_graphics_Canvas::m_DrawOval(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height){
  bbFloat l_xr=(l_width/2.0f);
  bbFloat l_yr=(l_height/2.0f);
  bbFloat l_dx_0x=(l_xr*this->m__0matrix.m_i.m_x);
  bbFloat l_dx_0y=(l_xr*this->m__0matrix.m_i.m_y);
  bbFloat l_dy_0x=(l_yr*this->m__0matrix.m_j.m_x);
  bbFloat l_dy_0y=(l_yr*this->m__0matrix.m_j.m_y);
  bbDouble l_dx=std::sqrt(bbDouble(((l_dx_0x*l_dx_0x)+(l_dx_0y*l_dx_0y))));
  bbDouble l_dy=std::sqrt(bbDouble(((l_dy_0x*l_dy_0x)+(l_dy_0y*l_dy_0y))));
  bbInt l_n=(g_monkey_math_Max_1i(bbInt((l_dx+l_dy)),12)&~3);
  bbFloat l_x0=(l_x+l_xr);
  bbFloat l_y0=(l_y+l_yr);
  this->m_AddDrawOp(this->m__0materials->at(5),l_n,1);
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<l_n);l_i+=1){
      bbDouble l_th=(((bbDouble(l_i)*g_monkey_math_Pi)*2.0)/bbDouble(l_n));
      bbDouble l_px=(bbDouble(l_x0)+(std::cos(l_th)*bbDouble(l_xr)));
      bbDouble l_py=(bbDouble(l_y0)+(std::sin(l_th)*bbDouble(l_yr)));
      this->m_AddVertex(bbFloat(l_px),bbFloat(l_py),0.0f,0.0f);
    }
  }
}

void t_mojo_graphics_Canvas::m_DrawLine(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1){
  this->m_AddDrawOp(this->m__0materials->at(2),2,1);
  this->m_AddVertex((l_x0+.5f),(l_y0+.5f),0.0f,0.0f);
  this->m_AddVertex((l_x1+.5f),(l_y1+.5f),1.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawLine(t_std_geom_Vec2_1f l_v0,t_std_geom_Vec2_1f l_v1){
  this->m_AddDrawOp(this->m__0materials->at(2),2,1);
  this->m_AddVertex((l_v0.m_x+.5f),(l_v0.m_y+.5f),0.0f,0.0f);
  this->m_AddVertex((l_v1.m_x+.5f),(l_v1.m_y+.5f),1.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_tv,bbFloat l_rz,t_std_geom_Vec2_1f l_scale){
  this->m_DrawImage(l_image,l_tv.m_x,l_tv.m_y,l_rz,l_scale.m_x,l_scale.m_y);
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty,bbFloat l_rz,bbFloat l_sx,bbFloat l_sy){
  t_std_geom_AffineMat3_1f l_matrix=this->m__0matrix;
  this->m_Translate(l_tx,l_ty);
  this->m_Rotate(l_rz);
  this->m_Scale(l_sx,l_sy);
  this->m_DrawImage(l_image,0.0f,0.0f);
  this->m__0matrix=l_matrix;
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_translation,bbFloat l_rz){
  this->m_DrawImage(l_image,l_translation.m_x,l_translation.m_y,l_rz);
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty,bbFloat l_rz){
  t_std_geom_AffineMat3_1f l_matrix=this->m__0matrix;
  this->m_Translate(l_tx,l_ty);
  this->m_Rotate(l_rz);
  this->m_DrawImage(l_image,0.0f,0.0f);
  this->m__0matrix=l_matrix;
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_translation){
  this->m_DrawImage(l_image,l_translation.m_x,l_translation.m_y);
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Material* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  t_std_geom_Rect_1f l_vs=l_image->m_Vertices();
  t_std_geom_Rect_1f l_tc=l_image->m_TexCoords();
  this->m_AddDrawOp(f0.t0=l_image->m_Material(),4,1);
  this->m_AddVertex((l_vs.m_min.m_x+l_tx),(l_vs.m_min.m_y+l_ty),l_tc.m_min.m_x,l_tc.m_min.m_y);
  this->m_AddVertex((l_vs.m_max.m_x+l_tx),(l_vs.m_min.m_y+l_ty),l_tc.m_max.m_x,l_tc.m_min.m_y);
  this->m_AddVertex((l_vs.m_max.m_x+l_tx),(l_vs.m_max.m_y+l_ty),l_tc.m_max.m_x,l_tc.m_max.m_y);
  this->m_AddVertex((l_vs.m_min.m_x+l_tx),(l_vs.m_max.m_y+l_ty),l_tc.m_min.m_x,l_tc.m_max.m_y);
}

void t_mojo_graphics_Canvas::m_DrawEllipse(bbFloat l_x,bbFloat l_y,bbFloat l_xRadius,bbFloat l_yRadius){
  this->m_DrawOval((l_x-l_xRadius),(l_y-l_yRadius),(l_xRadius*2.0f),(l_yRadius*2.0f));
}

void t_mojo_graphics_Canvas::m_DrawCircle(bbFloat l_x,bbFloat l_y,bbFloat l_radius){
  this->m_DrawOval((l_x-l_radius),(l_y-l_radius),(l_radius*2.0f),(l_radius*2.0f));
}

t_std_graphics_Pixmap* t_mojo_graphics_Canvas::m_CopyPixmap(t_std_geom_Rect_1i l_rect){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  }f0{};
  this->m_Flush();
  this->m_Validate();
  l_rect=g_std_geom_TransformRecti_1f(l_rect,this->m__0renderMatrix);
  l_rect=l_rect.m__and(this->m__0renderBounds).m__add(this->m__0targetRect.m_Origin());
  f0.l_pixmap=this->m__0device->m_CopyPixmap(l_rect);
  return f0.l_pixmap;
}

void t_mojo_graphics_Canvas::m_Color(t_std_graphics_Color l_color){
  this->m__0color=l_color;
  bbFloat l_a=((this->m__0color.m_a*this->m__0alpha)*255.0f);
  this->m__0pmcolor=((((bbUInt(l_a)<<24)|(bbUInt((this->m__0color.m_b*l_a))<<16))|(bbUInt((this->m__0color.m_g*l_a))<<8))|bbUInt((this->m__0color.m_r*l_a)));
}

t_std_graphics_Color t_mojo_graphics_Canvas::m_Color(){
  return this->m__0color;
}

void t_mojo_graphics_Canvas::m_ClearMatrix(){
  this->m__0matrixStack->m_Clear();
  this->m_Matrix(t_std_geom_AffineMat3_1f(bbNullCtor));
}

void t_mojo_graphics_Canvas::m_ClearDrawOps(){
  this->m__0ops->m_Clear();
  this->m__0vertices->m_Clear();
  this->m__0vertexData=this->m__0vertices->m_Data();
  this->m__0op=bbGCNew<t_mojo_graphics_DrawOp>();
  this->m__0vertex=bbInt(0);
}

void t_mojo_graphics_Canvas::m_Clear(t_std_graphics_Color l_color){
  this->m_Flush();
  this->m_Validate();
  this->m__0device->m_Clear(l_color);
}

void t_mojo_graphics_Canvas::m_BlendMode(bbInt l_blendMode){
  this->m__0blendMode=l_blendMode;
}

bbInt t_mojo_graphics_Canvas::m_BlendMode(){
  return this->m__0blendMode;
}

void t_mojo_graphics_Canvas::m_BeginRender(t_std_geom_Rect_1i l_bounds,t_std_geom_AffineMat3_1f l_matrix){
  this->m_Flush();
  this->m__0device->m_ShaderEnv(g_mojo_graphics_Canvas__0ambientEnv);
  this->m__0renderMatrixStack->m_Push(this->m__0renderMatrix);
  this->m__0renderBoundsStack->m_Push(this->m__0renderBounds);
  this->m__0renderMatrix=this->m__0renderMatrix.m__mul(l_matrix);
  this->m__0renderBounds.m__andeq(g_std_geom_TransformRecti_1f(l_bounds,this->m__0renderMatrix));
  this->m__0dirty|=6;
  this->m_Viewport(l_bounds);
  this->m_Scissor(t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_bounds.m_Size()));
  this->m_TextureFilteringEnabled(true);
  this->m_ClearMatrix();
}

void t_mojo_graphics_Canvas::m_AmbientLight(t_std_graphics_Color l_ambientLight){
  this->m_Flush();
  this->m__0ambientLight=l_ambientLight;
  this->m__0dirty|=4;
}

t_std_graphics_Color t_mojo_graphics_Canvas::m_AmbientLight(){
  return this->m__0ambientLight;
}

void t_mojo_graphics_Canvas::m_Alpha(bbFloat l_alpha){
  this->m__0alpha=l_alpha;
  bbFloat l_a=((this->m__0color.m_a*this->m__0alpha)*255.0f);
  this->m__0pmcolor=((((bbUInt(l_a)<<24)|(bbUInt((this->m__0color.m_b*l_a))<<16))|(bbUInt((this->m__0color.m_g*l_a))<<8))|bbUInt((this->m__0color.m_r*l_a)));
}

bbFloat t_mojo_graphics_Canvas::m_Alpha(){
  return this->m__0alpha;
}

void t_mojo_graphics_Canvas::m_AddVertex(bbFloat l_tx,bbFloat l_ty,bbFloat l_s0,bbFloat l_t0){
  this->m__0vertexData->at(this->m__0vertex).m_x=(((this->m__0matrix.m_i.m_x*l_tx)+(this->m__0matrix.m_j.m_x*l_ty))+this->m__0matrix.m_t.m_x);
  this->m__0vertexData->at(this->m__0vertex).m_y=(((this->m__0matrix.m_i.m_y*l_tx)+(this->m__0matrix.m_j.m_y*l_ty))+this->m__0matrix.m_t.m_y);
  this->m__0vertexData->at(this->m__0vertex).m_s0=l_s0;
  this->m__0vertexData->at(this->m__0vertex).m_t0=l_t0;
  this->m__0vertexData->at(this->m__0vertex).m_ix=this->m__0matrix.m_i.m_x;
  this->m__0vertexData->at(this->m__0vertex).m_iy=this->m__0matrix.m_i.m_y;
  this->m__0vertexData->at(this->m__0vertex).m_color=this->m__0pmcolor;
  this->m__0vertex+=1;
}

void t_mojo_graphics_Canvas::m_AddDrawOp(t_mojo_graphics_Material* l_material,bbInt l_order,bbInt l_count){
  this->m__0vertices->m_Resize((this->m__0vertex+(l_order*l_count)));
  this->m__0vertexData=this->m__0vertices->m_Data();
  if((((this->m__0blendMode==this->m__0op->m_blendMode)&&(l_material==this->m__0op->m_material))&&(l_order==this->m__0op->m_order))){
    this->m__0op->m_count+=l_count;
    return;
  }
  this->m__0op=bbGCNew<t_mojo_graphics_DrawOp>();
  this->m__0op->m_blendMode=this->m__0blendMode;
  this->m__0op->m_material=l_material;
  this->m__0op->m_order=l_order;
  this->m__0op->m_count=l_count;
  this->m__0ops->m_Add(this->m__0op);
}

int bbCompare(const t_mojo_graphics_Canvas_LightInst&x,const t_mojo_graphics_Canvas_LightInst&y){
  if(int t=bbCompare(x.m_position,y.m_position)) return t;
  if(int t=bbCompare(x.m_radius,y.m_radius)) return t;
  if(int t=bbCompare(x.m_color,y.m_color)) return t;
  return 0;
}

void mx2_mojo_graphics_2canvas_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2canvas_init_v("mojo_graphics_2canvas",&mx2_mojo_graphics_2canvas_init);
