
#include "../../desktop_release_pi/mojo_graphics_2image.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_graphics_2material.h"
#include "../../desktop_release_pi/mojo_graphics_2shader.h"
#include "../../desktop_release_pi/mojo_graphics_2texture.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_graphics_2color.h"

extern bbString g_std_filesystem_StripExt(bbString l_path);
extern bbString g_std_filesystem_ExtractExt(bbString l_path);
extern bbFloat g_monkey_math_Max_1f(bbFloat l_x,bbFloat l_y);

// ***** Internal *****

t_mojo_graphics_Image* g_mojo_graphics_Image_Load(bbString l_path,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* l_diffuse{};
    t_mojo_graphics_Image* l_image{};
    t_mojo_graphics_Material* l_material{};
    t_mojo_graphics_Texture* l_normal{};
    t_mojo_graphics_Shader* l_shader{};
    t_mojo_graphics_Texture* l_specular{};
    f0_t(t_mojo_graphics_Shader* l_shader):l_shader(l_shader){
    }
    void gcMark(){
      bbGCMarkPtr(l_diffuse);
      bbGCMarkPtr(l_image);
      bbGCMarkPtr(l_material);
      bbGCMarkPtr(l_normal);
      bbGCMarkPtr(l_shader);
      bbGCMarkPtr(l_specular);
    }
  }f0{l_shader};
  f0.l_diffuse=g_mojo_graphics_Texture_Load(l_path,l_textureFlags);
  if(!bbBool(f0.l_diffuse)){
    return ((t_mojo_graphics_Image*)0);
  }
  bbString l_file=g_std_filesystem_StripExt(l_path);
  bbString l_ext=g_std_filesystem_ExtractExt(l_path);
  f0.l_specular=g_mojo_graphics_Texture_Load(((l_file+BB_T("_SPECULAR"))+l_ext),l_textureFlags);
  f0.l_normal=g_mojo_graphics_Texture_Load(((l_file+BB_T("_NORMALS"))+l_ext),l_textureFlags);
  if((bbBool(f0.l_specular)||bbBool(f0.l_normal))){
    if(!bbBool(f0.l_specular)){
      f0.l_specular=g_mojo_graphics_Texture_ColorTexture(g_std_graphics_Color_Black);
    }
    if(!bbBool(f0.l_normal)){
      f0.l_normal=g_mojo_graphics_Texture_ColorTexture(t_std_graphics_Color(.5f,.5f,.5f,1.0f));
    }
  }
  if(!bbBool(f0.l_shader)){
    if((bbBool(f0.l_specular)||bbBool(f0.l_normal))){
      f0.l_shader=g_mojo_graphics_Shader_GetShader(BB_T("phong"));
    }else{
      f0.l_shader=g_mojo_graphics_Shader_GetShader(BB_T("sprite"));
    }
  }
  f0.l_material=bbGCNew<t_mojo_graphics_Material>(f0.l_shader);
  if(bbBool(f0.l_diffuse)){
    f0.l_material->m_SetTexture(BB_T("DiffuseTexture"),f0.l_diffuse);
  }
  if(bbBool(f0.l_specular)){
    f0.l_material->m_SetTexture(BB_T("SpecularTexture"),f0.l_specular);
  }
  if(bbBool(f0.l_normal)){
    f0.l_material->m_SetTexture(BB_T("NormalTexture"),f0.l_normal);
  }
  f0.l_image=bbGCNew<t_mojo_graphics_Image>(f0.l_material,f0.l_diffuse,f0.l_diffuse->m_Rect());
  struct lambda0 : public bbFunction<void()>::Rep{
    t_mojo_graphics_Texture* l_diffuse;
    t_mojo_graphics_Texture* l_specular;
    t_mojo_graphics_Texture* l_normal;
    lambda0(t_mojo_graphics_Texture* l_diffuse,t_mojo_graphics_Texture* l_specular,t_mojo_graphics_Texture* l_normal):l_diffuse(l_diffuse),l_specular(l_specular),l_normal(l_normal){
    }
    void invoke(){
      if(bbBool(l_diffuse)){
        l_diffuse->m_Discard();
      }
      if(bbBool(l_specular)){
        l_specular->m_Discard();
      }
      if(bbBool(l_normal)){
        l_normal->m_Discard();
      }
    }
    void gcMark(){
      bbGCMarkPtr(l_diffuse);
      bbGCMarkPtr(l_specular);
      bbGCMarkPtr(l_normal);
    }
  };
  f0.l_image->m_OnDiscarded+=bbFunction<void()>(new lambda0(f0.l_diffuse,f0.l_specular,f0.l_normal));
  return f0.l_image;
}

void t_mojo_graphics_Image::init(){
  m__0handle=t_std_geom_Vec2_1f(0.0f,0.0f);
  m__0scale=t_std_geom_Vec2_1f(1.0f,1.0f);
}

void t_mojo_graphics_Image::gcMark(){
  bbGCMark(m_OnDiscarded);
  bbGCMark(m__0material);
  bbGCMark(m__0texture);
}

t_mojo_graphics_Image::t_mojo_graphics_Image(t_mojo_graphics_Material* l_material,t_mojo_graphics_Texture* l_texture,t_std_geom_Rect_1i l_rect){
  init();
  this->m_Init(l_material,l_texture,l_rect,((t_mojo_graphics_Shader*)0));
}

t_mojo_graphics_Image::t_mojo_graphics_Image(t_mojo_graphics_Texture* l_texture,t_mojo_graphics_Shader* l_shader){
  init();
  this->m_Init(((t_mojo_graphics_Material*)0),l_texture,l_texture->m_Rect(),l_shader);
}

t_mojo_graphics_Image::t_mojo_graphics_Image(t_mojo_graphics_Image* l_image,t_std_geom_Rect_1i l_rect){
  init();
  this->m_Init(l_image->m__0material,l_image->m__0texture,l_rect,((t_mojo_graphics_Shader*)0));
}

t_mojo_graphics_Image::t_mojo_graphics_Image(bbInt l_width,bbInt l_height,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader){
  init();
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* l_texture{};
    void gcMark(){
      bbGCMarkPtr(l_texture);
    }
  }f0{};
  bbInt l_textureFormat=5;
  f0.l_texture=bbGCNew<t_mojo_graphics_Texture>(l_width,l_height,l_textureFormat,l_textureFlags);
  this->m_Init(((t_mojo_graphics_Material*)0),f0.l_texture,f0.l_texture->m_Rect(),l_shader);
  struct lambda1 : public bbFunction<void()>::Rep{
    t_mojo_graphics_Image* l_self;
    t_mojo_graphics_Texture* l_texture;
    lambda1(t_mojo_graphics_Image* l_self,t_mojo_graphics_Texture* l_texture):l_self(l_self),l_texture(l_texture){
    }
    void invoke(){
      l_texture->m_Discard();
    }
    void gcMark(){
      bbGCMarkPtr(l_self);
      bbGCMarkPtr(l_texture);
    }
  };
  this->m_OnDiscarded+=bbFunction<void()>(new lambda1(this,f0.l_texture));
}

t_mojo_graphics_Image::t_mojo_graphics_Image(t_std_graphics_Pixmap* l_pixmap,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader){
  init();
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* l_texture{};
    void gcMark(){
      bbGCMarkPtr(l_texture);
    }
  }f0{};
  f0.l_texture=bbGCNew<t_mojo_graphics_Texture>(l_pixmap,l_textureFlags);
  this->m_Init(((t_mojo_graphics_Material*)0),f0.l_texture,f0.l_texture->m_Rect(),l_shader);
  struct lambda2 : public bbFunction<void()>::Rep{
    t_mojo_graphics_Image* l_self;
    t_mojo_graphics_Texture* l_texture;
    lambda2(t_mojo_graphics_Image* l_self,t_mojo_graphics_Texture* l_texture):l_self(l_self),l_texture(l_texture){
    }
    void invoke(){
      l_texture->m_Discard();
    }
    void gcMark(){
      bbGCMarkPtr(l_self);
      bbGCMarkPtr(l_texture);
    }
  };
  this->m_OnDiscarded+=bbFunction<void()>(new lambda2(this,f0.l_texture));
}

bbInt t_mojo_graphics_Image::m_Width(){
  return this->m__0rect.m_Width();
}

t_std_geom_Rect_1f t_mojo_graphics_Image::m_Vertices(){
  return this->m__0vertices;
}

void t_mojo_graphics_Image::m_UpdateVertices(){
  this->m__0vertices.m_min.m_x=((bbFloat(this->m__0rect.m_Width())*(0.0f-this->m__0handle.m_x))*this->m__0scale.m_x);
  this->m__0vertices.m_min.m_y=((bbFloat(this->m__0rect.m_Height())*(0.0f-this->m__0handle.m_y))*this->m__0scale.m_y);
  this->m__0vertices.m_max.m_x=((bbFloat(this->m__0rect.m_Width())*(1.0f-this->m__0handle.m_x))*this->m__0scale.m_x);
  this->m__0vertices.m_max.m_y=((bbFloat(this->m__0rect.m_Height())*(1.0f-this->m__0handle.m_y))*this->m__0scale.m_y);
  this->m__0radius=((this->m__0vertices.m_min.m_x*this->m__0vertices.m_min.m_x)+(this->m__0vertices.m_min.m_y*this->m__0vertices.m_min.m_y));
  this->m__0radius=g_monkey_math_Max_1f(this->m__0radius,((this->m__0vertices.m_max.m_x*this->m__0vertices.m_max.m_x)+(this->m__0vertices.m_min.m_y*this->m__0vertices.m_min.m_y)));
  this->m__0radius=g_monkey_math_Max_1f(this->m__0radius,((this->m__0vertices.m_max.m_x*this->m__0vertices.m_max.m_x)+(this->m__0vertices.m_max.m_y*this->m__0vertices.m_max.m_y)));
  this->m__0radius=g_monkey_math_Max_1f(this->m__0radius,((this->m__0vertices.m_min.m_x*this->m__0vertices.m_min.m_x)+(this->m__0vertices.m_max.m_y*this->m__0vertices.m_max.m_y)));
  this->m__0radius=bbFloat(std::sqrt(bbDouble(this->m__0radius)));
}

void t_mojo_graphics_Image::m_UpdateTexCoords(){
  this->m__0texCoords.m_min.m_x=(bbFloat(this->m__0rect.m_min.m_x)/bbFloat(this->m__0texture->m_Width()));
  this->m__0texCoords.m_min.m_y=(bbFloat(this->m__0rect.m_min.m_y)/bbFloat(this->m__0texture->m_Height()));
  this->m__0texCoords.m_max.m_x=(bbFloat(this->m__0rect.m_max.m_x)/bbFloat(this->m__0texture->m_Width()));
  this->m__0texCoords.m_max.m_y=(bbFloat(this->m__0rect.m_max.m_y)/bbFloat(this->m__0texture->m_Height()));
}

t_mojo_graphics_Texture* t_mojo_graphics_Image::m_Texture(){
  return this->m__0texture;
}

t_std_geom_Rect_1f t_mojo_graphics_Image::m_TexCoords(){
  return this->m__0texCoords;
}

void t_mojo_graphics_Image::m_Scale(t_std_geom_Vec2_1f l_scale){
  this->m__0scale=l_scale;
  this->m_UpdateVertices();
}

t_std_geom_Vec2_1f t_mojo_graphics_Image::m_Scale(){
  return this->m__0scale;
}

t_std_geom_Rect_1i t_mojo_graphics_Image::m_Rect(){
  return this->m__0rect;
}

bbFloat t_mojo_graphics_Image::m_Radius(){
  return this->m__0radius;
}

t_mojo_graphics_Material* t_mojo_graphics_Image::m_Material(){
  return this->m__0material;
}

void t_mojo_graphics_Image::m_Init(t_mojo_graphics_Material* l_material,t_mojo_graphics_Texture* l_texture,t_std_geom_Rect_1i l_rect,t_mojo_graphics_Shader* l_shader){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Material* l_material{};
    t_mojo_graphics_Shader* l_shader{};
    f0_t(t_mojo_graphics_Material* l_material,t_mojo_graphics_Shader* l_shader):l_material(l_material),l_shader(l_shader){
    }
    void gcMark(){
      bbGCMarkPtr(l_material);
      bbGCMarkPtr(l_shader);
    }
  }f0{l_material,l_shader};
  if(!bbBool(f0.l_material)){
    if(!bbBool(f0.l_shader)){
      f0.l_shader=g_mojo_graphics_Shader_GetShader(BB_T("sprite"));
    }
    f0.l_material=bbGCNew<t_mojo_graphics_Material>(f0.l_shader);
    f0.l_material->m_SetTexture(BB_T("DiffuseTexture"),l_texture);
  }
  this->m__0material=f0.l_material;
  this->m__0texture=l_texture;
  this->m__0rect=l_rect;
  this->m_UpdateVertices();
  this->m_UpdateTexCoords();
}

bbInt t_mojo_graphics_Image::m_Height(){
  return this->m__0rect.m_Height();
}

void t_mojo_graphics_Image::m_Handle(t_std_geom_Vec2_1f l_handle){
  this->m__0handle=l_handle;
  this->m_UpdateVertices();
}

t_std_geom_Vec2_1f t_mojo_graphics_Image::m_Handle(){
  return this->m__0handle;
}

void t_mojo_graphics_Image::m_Discard(){
  if(this->m__0discarded){
    return;
  }
  this->m__0discarded=true;
  this->m_OnDiscarded();
}

t_std_geom_Rect_1f t_mojo_graphics_Image::m_Bounds(){
  return this->m__0vertices;
}

void mx2_mojo_graphics_2image_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2image_init_v("mojo_graphics_2image",&mx2_mojo_graphics_2image_init);
