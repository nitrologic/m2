
#include "../../desktop_release_pi/mojo_graphics_2font.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_graphics_2image.h"
#include "../../desktop_release_pi/mojo_graphics_2shader.h"
#include "../../desktop_release_pi/mojo_std_collections_2map.h"

extern bbString g_std_filesystem_RealPath(bbString l_path);
extern t_mojo_graphics_Font* g_mojo_graphics_fontloader_LoadFont(bbString l_path,bbFloat l_fheight,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader);

// ***** Internal *****

bbGCRootVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2> g_mojo_graphics_Font__0openFonts;

t_mojo_graphics_Font* g_mojo_graphics_Font_Open(bbString l_path,bbFloat l_height){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Font* l_font{};
    void gcMark(){
      bbGCMarkPtr(l_font);
    }
  }f0{};
  bbString l_tag=((g_std_filesystem_RealPath(l_path)+BB_T(":"))+bbString(l_height));
  f0.l_font=g_mojo_graphics_Font__0openFonts->m__idx(l_tag);
  if(!bbBool(f0.l_font)){
    f0.l_font=g_mojo_graphics_Font_Load(l_path,l_height,bbInt(0),((t_mojo_graphics_Shader*)0));
    g_mojo_graphics_Font__0openFonts->m__idxeq(l_tag,f0.l_font);
  }
  return f0.l_font;
}

t_mojo_graphics_Font* g_mojo_graphics_Font_Load(bbString l_path,bbFloat l_height,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Font* l_font{};
    t_mojo_graphics_Shader* l_shader{};
    f0_t(t_mojo_graphics_Shader* l_shader):l_shader(l_shader){
    }
    void gcMark(){
      bbGCMarkPtr(l_font);
      bbGCMarkPtr(l_shader);
    }
  }f0{l_shader};
  if(!bbBool(f0.l_shader)){
    f0.l_shader=g_mojo_graphics_Shader_GetShader(BB_T("font"));
  }
  f0.l_font=g_mojo_graphics_fontloader_LoadFont(l_path,l_height,l_textureFlags,f0.l_shader);
  return f0.l_font;
}

void t_mojo_graphics_Font::gcMark(){
  bbGCMark(m__0image);
  bbGCMark(m__0glyphs);
}

t_mojo_graphics_Font::t_mojo_graphics_Font(t_mojo_graphics_Image* l_image,bbFloat l_height,bbInt l_firstChar,bbArray<t_mojo_graphics_Glyph>* l_glyphs){
  this->m__0image=l_image;
  this->m__0height=l_height;
  this->m__0firstChar=l_firstChar;
  this->m__0glyphs=l_glyphs;
}

bbFloat t_mojo_graphics_Font::m_TextWidth(bbString l_text){
  bbFloat l_w=0.0f;
  {
    bbInt l_0=bbInt(0);
    bbInt l_1=l_text.length();
    for(;(l_0<l_1);l_0+=1){
      bbInt l_char=l_text[l_0];
      l_w+=this->m_GetGlyph(l_char).m_advance;
    }
  }
  return l_w;
}

bbInt t_mojo_graphics_Font::m_NumChars(){
  return this->m__0glyphs->length();
}

t_mojo_graphics_Image* t_mojo_graphics_Font::m_Image(){
  return this->m__0image;
}

bbFloat t_mojo_graphics_Font::m_Height(){
  return this->m__0height;
}

bbArray<t_mojo_graphics_Glyph>* t_mojo_graphics_Font::m_Glyphs(){
  return this->m__0glyphs;
}

t_mojo_graphics_Glyph t_mojo_graphics_Font::m_GetGlyph(bbInt l_char){
  if(((l_char>=this->m__0firstChar)&&(l_char<(this->m__0firstChar+this->m__0glyphs->length())))){
    return this->m__0glyphs->at((l_char-this->m__0firstChar));
  }
  return this->m__0glyphs->at(bbInt(0));
}

bbInt t_mojo_graphics_Font::m_FirstChar(){
  return this->m__0firstChar;
}

t_mojo_graphics_Glyph::t_mojo_graphics_Glyph(t_std_geom_Rect_1i l_rect,t_std_geom_Vec2_1f l_offset,bbFloat l_advance){
  (*this).m_rect=l_rect;
  (*this).m_offset=l_offset;
  (*this).m_advance=l_advance;
}

int bbCompare(const t_mojo_graphics_Glyph&x,const t_mojo_graphics_Glyph&y){
  if(int t=bbCompare(x.m_rect,y.m_rect)) return t;
  if(int t=bbCompare(x.m_offset,y.m_offset)) return t;
  if(int t=bbCompare(x.m_advance,y.m_advance)) return t;
  return 0;
}

void mx2_mojo_graphics_2font_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_graphics_Font__0openFonts=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2>();
}

bbInit mx2_mojo_graphics_2font_init_v("mojo_graphics_2font",&mx2_mojo_graphics_2font_init);
