
#include "../../desktop_release_pi/mojo_graphics_2device.h"

// ***** External *****

#include "../../../../gles20/gles20.buildv1.0.0/desktop_release_pi/gles20_gles20.h"
#include "../../../../libc/libc.buildv1.0.0/desktop_release_pi/libc_libc.h"
#include "../../desktop_release_pi/mojo_graphics_2shader.h"
#include "../../desktop_release_pi/mojo_graphics_2texture.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_graphics_2pixmap.h"

extern bbInt g_mojo_graphics_glutil_glGraphicsSeq;

// ***** Internal *****

bbInt g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX;
bbGCRootVar<t_mojo_graphics_GraphicsDevice> g_mojo_graphics_GraphicsDevice__0current;
bbInt g_mojo_graphics_GraphicsDevice__0defaultFbo;
bbGCRootVar<bbArray<bbUShort>> g_mojo_graphics_GraphicsDevice__0qindices;
bbInt g_mojo_graphics_GraphicsDevice__0seq;
bbGCRootVar<bbArray<t_mojo_graphics_Vertex2f>> g_mojo_graphics_GraphicsDevice__0vertices;

void g_mojo_graphics_GraphicsDevice_InitGLState(){
  glGetIntegerv(GL_FRAMEBUFFER_BINDING,&g_mojo_graphics_GraphicsDevice__0defaultFbo);
}

void t_mojo_graphics_GraphicsDevice::gcMark(){
  bbGCMark(m__0target);
  bbGCMark(m__0shaderEnv);
  bbGCMark(m__0envParams);
  bbGCMark(m__0shader);
  bbGCMark(m__0params);
}

t_mojo_graphics_GraphicsDevice::t_mojo_graphics_GraphicsDevice(){
  this->m_RenderTarget(((t_mojo_graphics_Texture*)0));
  this->m_Viewport(t_std_geom_Rect_1i(bbInt(0),bbInt(0),640,480));
  this->m_Scissor(t_std_geom_Rect_1i(bbInt(0),bbInt(0),16384,16384));
  this->m_BlendMode(1);
}

void t_mojo_graphics_GraphicsDevice::m_Viewport(t_std_geom_Rect_1i l_viewport){
  this->m_FlushTarget();
  this->m__0viewport=l_viewport;
  this->m__0dirty|=6;
}

t_std_geom_Rect_1i t_mojo_graphics_GraphicsDevice::m_Viewport(){
  return this->m__0viewport;
}

void t_mojo_graphics_GraphicsDevice::m_Validate(){
  if((g_mojo_graphics_GraphicsDevice__0seq!=g_mojo_graphics_glutil_glGraphicsSeq)){
    g_mojo_graphics_GraphicsDevice__0seq=g_mojo_graphics_glutil_glGraphicsSeq;
    g_mojo_graphics_GraphicsDevice__0current=((t_mojo_graphics_GraphicsDevice*)0);
    g_mojo_graphics_GraphicsDevice_InitGLState();
  }
  if((g_mojo_graphics_GraphicsDevice__0current==this)){
    if(!bbBool(this->m__0dirty)){
      return;
    }
  }else{
    if(bbBool(g_mojo_graphics_GraphicsDevice__0current)){
      g_mojo_graphics_GraphicsDevice__0current->m_FlushTarget();
    }
    g_mojo_graphics_GraphicsDevice__0current=this;
    this->m__0dirty=127;
  }
  if(bbBool((this->m__0dirty&1))){
    if(bbBool(this->m__0target)){
      glBindFramebuffer(GL_FRAMEBUFFER,this->m__0target->m_GLFramebuffer());
    }else{
      glBindFramebuffer(GL_FRAMEBUFFER,bbUInt(g_mojo_graphics_GraphicsDevice__0defaultFbo));
    }
  }
  if(bbBool((this->m__0dirty&2))){
    glViewport(this->m__0viewport.m_X(),this->m__0viewport.m_Y(),this->m__0viewport.m_Width(),this->m__0viewport.m_Height());
  }
  if(bbBool((this->m__0dirty&4))){
    this->m__0rscissor=this->m__0scissor.m__and(this->m__0viewport);
    if((bbCompare(this->m__0rscissor,this->m__0viewport)!=0)){
      glEnable(GL_SCISSOR_TEST);
      glScissor(this->m__0rscissor.m_X(),this->m__0rscissor.m_Y(),this->m__0rscissor.m_Width(),this->m__0rscissor.m_Height());
    }else{
      glDisable(GL_SCISSOR_TEST);
    }
  }
  if(bbBool((this->m__0dirty&8))){
    if(this->m__0blendMode==0){
      glDisable(GL_BLEND);
    }else if(this->m__0blendMode==1){
      glEnable(GL_BLEND);
      glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
    }else if(this->m__0blendMode==2){
      glEnable(GL_BLEND);
      glBlendFunc(GL_ONE,GL_ONE);
    }else if(this->m__0blendMode==3){
      glEnable(GL_BLEND);
      glBlendFunc(GL_DST_COLOR,GL_ONE_MINUS_SRC_ALPHA);
    }
  }
  if((((bbBool(this->m__0shader)&&bbBool(this->m__0shaderEnv))&&bbBool(this->m__0envParams))&&bbBool(this->m__0params))){
    if(bbBool((this->m__0dirty&16))){
      this->m__0shader->m_Bind(this->m__0shaderEnv);
    }
    if(bbBool((this->m__0dirty&32))){
      this->m__0shader->m_BindEnvParams(this->m__0envParams);
    }
    if(bbBool((this->m__0dirty&64))){
      this->m__0shader->m_BindParams(this->m__0params,this->m__0filter);
    }
  }
  this->m__0dirty=bbInt(0);
}

void t_mojo_graphics_GraphicsDevice::m_ShaderEnv(t_mojo_graphics_ShaderEnv* l_shaderEnv){
  this->m__0shaderEnv=l_shaderEnv;
  this->m__0dirty|=112;
}

t_mojo_graphics_ShaderEnv* t_mojo_graphics_GraphicsDevice::m_ShaderEnv(){
  return this->m__0shaderEnv;
}

void t_mojo_graphics_GraphicsDevice::m_Shader(t_mojo_graphics_Shader* l_shader){
  this->m__0shader=l_shader;
  this->m__0dirty|=112;
}

t_mojo_graphics_Shader* t_mojo_graphics_GraphicsDevice::m_Shader(){
  return this->m__0shader;
}

void t_mojo_graphics_GraphicsDevice::m_Scissor(t_std_geom_Rect_1i l_scissor){
  this->m_FlushTarget();
  this->m__0scissor=l_scissor;
  this->m__0dirty|=4;
}

t_std_geom_Rect_1i t_mojo_graphics_GraphicsDevice::m_Scissor(){
  return this->m__0scissor;
}

void t_mojo_graphics_GraphicsDevice::m_RenderTarget(t_mojo_graphics_Texture* l_renderTarget){
  this->m_FlushTarget();
  this->m__0target=l_renderTarget;
  this->m__0dirty|=1;
}

t_mojo_graphics_Texture* t_mojo_graphics_GraphicsDevice::m_RenderTarget(){
  return this->m__0target;
}

void t_mojo_graphics_GraphicsDevice::m_Render(t_mojo_graphics_Vertex2f* l_vertices,bbInt l_order,bbInt l_count){
  this->m_Validate();
  bbInt l_n=(l_order*l_count);
  if((l_n>g_mojo_graphics_GraphicsDevice__0vertices->length())){
    g_mojo_graphics_GraphicsDevice__0vertices=bbArray<t_mojo_graphics_Vertex2f>::create(l_n);
    bbUByte* l_p=((bbUByte*)(g_mojo_graphics_GraphicsDevice__0vertices->data()));
    glEnableVertexAttribArray(bbUInt(0));
    glVertexAttribPointer(bbUInt(0),2,GL_FLOAT,false,g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX,((void*)(l_p)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1,2,GL_FLOAT,false,g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX,((void*)((l_p+8))));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2,2,GL_FLOAT,false,g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX,((void*)((l_p+16))));
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3,4,GL_UNSIGNED_BYTE,true,g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX,((void*)((l_p+24))));
  }
  memcpy(((void*)(g_mojo_graphics_GraphicsDevice__0vertices->data())),((void*)(l_vertices)),(l_n*g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX));
  if(l_order==1){
    glDrawArrays(GL_POINTS,bbInt(0),l_n);
  }else if(l_order==2){
    glDrawArrays(GL_LINES,bbInt(0),l_n);
  }else if(l_order==3){
    glDrawArrays(GL_TRIANGLES,bbInt(0),l_n);
  }else if(l_order==4){
    bbInt l_n=(l_count*6);
    if((l_n>g_mojo_graphics_GraphicsDevice__0qindices->length())){
      g_mojo_graphics_GraphicsDevice__0qindices=bbArray<bbUShort>::create(l_n);
      {
        bbInt l_i=bbInt(0);
        for(;(l_i<l_count);l_i+=1){
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+bbInt(0)))=bbUShort((l_i*4));
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+1))=bbUShort(((l_i*4)+1));
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+2))=bbUShort(((l_i*4)+2));
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+3))=bbUShort((l_i*4));
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+4))=bbUShort(((l_i*4)+2));
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+5))=bbUShort(((l_i*4)+3));
        }
      }
    }
    glDrawElements(GL_TRIANGLES,l_n,GL_UNSIGNED_SHORT,((void*)(g_mojo_graphics_GraphicsDevice__0qindices->data())));
  }else{
    {
      bbInt l_i=bbInt(0);
      for(;(l_i<l_count);l_i+=1){
        glDrawArrays(GL_TRIANGLE_FAN,(l_i*l_order),l_order);
      }
    }
  }
  this->m__0modified=true;
}

void t_mojo_graphics_GraphicsDevice::m_Params(t_mojo_graphics_ParamBuffer* l_params){
  this->m__0params=l_params;
  this->m__0dirty|=64;
}

t_mojo_graphics_ParamBuffer* t_mojo_graphics_GraphicsDevice::m_Params(){
  return this->m__0params;
}

void t_mojo_graphics_GraphicsDevice::m_FlushTarget(){
  if(!this->m__0modified){
    return;
  }
  if(bbBool(this->m__0target)){
    this->m__0target->m_Modified(this);
  }
  this->m__0modified=false;
}

void t_mojo_graphics_GraphicsDevice::m_FilteringEnabled(bbBool l_filteringEnabled){
  if((l_filteringEnabled==this->m__0filter)){
    return;
  }
  this->m__0filter=l_filteringEnabled;
  this->m__0dirty|=64;
}

bbBool t_mojo_graphics_GraphicsDevice::m_FilteringEnabled(){
  return this->m__0filter;
}

void t_mojo_graphics_GraphicsDevice::m_EnvParams(t_mojo_graphics_ParamBuffer* l_envParams){
  this->m__0envParams=l_envParams;
  this->m__0dirty|=32;
}

t_mojo_graphics_ParamBuffer* t_mojo_graphics_GraphicsDevice::m_EnvParams(){
  return this->m__0envParams;
}

t_std_graphics_Pixmap* t_mojo_graphics_GraphicsDevice::m_CopyPixmap(t_std_geom_Rect_1i l_rect){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  }f0{};
  this->m_Validate();
  f0.l_pixmap=bbGCNew<t_std_graphics_Pixmap>(l_rect.m_Width(),l_rect.m_Height(),5);
  glReadPixels(l_rect.m_X(),l_rect.m_Y(),l_rect.m_Width(),l_rect.m_Height(),GL_RGBA,GL_UNSIGNED_BYTE,((void*)(f0.l_pixmap->m_Data())));
  return f0.l_pixmap;
}

void t_mojo_graphics_GraphicsDevice::m_Clear(t_std_graphics_Color l_color){
  this->m_Validate();
  if((bbCompare(this->m__0rscissor,this->m__0windowRect)!=0)){
    glEnable(GL_SCISSOR_TEST);
    glScissor(this->m__0rscissor.m_X(),this->m__0rscissor.m_Y(),this->m__0rscissor.m_Width(),this->m__0rscissor.m_Height());
  }else{
    glDisable(GL_SCISSOR_TEST);
  }
  glClearColor(l_color.m_r,l_color.m_g,l_color.m_b,l_color.m_a);
  glClear(GL_COLOR_BUFFER_BIT);
  if((bbCompare(this->m__0rscissor,this->m__0viewport)!=0)){
    glEnable(GL_SCISSOR_TEST);
    glScissor(this->m__0rscissor.m_X(),this->m__0rscissor.m_Y(),this->m__0rscissor.m_Width(),this->m__0rscissor.m_Height());
  }else{
    glDisable(GL_SCISSOR_TEST);
  }
  this->m__0modified=true;
}

void t_mojo_graphics_GraphicsDevice::m_BlendMode(bbInt l_blendMode){
  this->m__0blendMode=l_blendMode;
  this->m__0dirty|=8;
}

bbInt t_mojo_graphics_GraphicsDevice::m_BlendMode(){
  return this->m__0blendMode;
}

void mx2_mojo_graphics_2device_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX=28;
}

bbInit mx2_mojo_graphics_2device_init_v("mojo_graphics_2device",&mx2_mojo_graphics_2device_init);
