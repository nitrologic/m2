
#include "../../desktop_release_pi/mojo_app_2skin.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_graphics_2canvas.h"
#include "../../desktop_release_pi/mojo_graphics_2image.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_geom_2vec2.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_graphics_2pixmap.h"

// ***** Internal *****

t_mojo_app_Skin* g_mojo_app_Skin_Load(bbString l_path){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  }f0{};
  f0.l_pixmap=g_std_graphics_Pixmap_Load(l_path,0);
  if(!bbBool(f0.l_pixmap)){
    return ((t_mojo_app_Skin*)0);
  }
  f0.l_pixmap->m_PremultiplyAlpha();
  return bbGCNew<t_mojo_app_Skin>(f0.l_pixmap);
}

void t_mojo_app_Skin::gcMark(){
  bbGCMark(m__0image);
}

t_mojo_app_Skin::t_mojo_app_Skin(t_std_graphics_Pixmap* l_pixmap){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    f0_t(t_std_graphics_Pixmap* l_pixmap):l_pixmap(l_pixmap){
    }
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  }f0{l_pixmap};
  t_std_geom_Rect_1i l__0scale{};
  t_std_geom_Rect_1i l__0fill{};
  {
    bbInt l_x=1;
    for(;(l_x<(f0.l_pixmap->m_Width()-1));l_x+=1){
      bbUInt l_p=f0.l_pixmap->m_GetPixelARGB(l_x,bbInt(0));
      if((l_p==4278190080)){
        if(!bbBool(l__0scale.m_min.m_x)){
          l__0scale.m_min.m_x=l_x;
        }
        l__0scale.m_max.m_x=(l_x+1);
      }
      l_p=f0.l_pixmap->m_GetPixelARGB(l_x,(f0.l_pixmap->m_Height()-1));
      if((l_p==4278190080)){
        if(!bbBool(l__0fill.m_min.m_x)){
          l__0fill.m_min.m_x=l_x;
        }
        l__0fill.m_max.m_x=(l_x+1);
      }
    }
  }
  {
    bbInt l_y=1;
    for(;(l_y<(f0.l_pixmap->m_Height()-1));l_y+=1){
      bbUInt l_p=f0.l_pixmap->m_GetPixelARGB(bbInt(0),l_y);
      if((l_p==4278190080)){
        if(!bbBool(l__0scale.m_min.m_y)){
          l__0scale.m_min.m_y=l_y;
        }
        l__0scale.m_max.m_y=(l_y+1);
      }
      l_p=f0.l_pixmap->m_GetPixelARGB((f0.l_pixmap->m_Width()-1),l_y);
      if((l_p==4278190080)){
        if(!bbBool(l__0fill.m_min.m_y)){
          l__0fill.m_min.m_y=l_y;
        }
        l__0fill.m_max.m_y=(l_y+1);
      }
    }
  }
  if((bbBool(l__0scale.m_min.m_x)&&bbBool(l__0scale.m_min.m_y))){
    f0.l_pixmap=f0.l_pixmap->m_Window(1,1,(f0.l_pixmap->m_Width()-2),(f0.l_pixmap->m_Height()-2));
    if((!bbBool(l__0fill.m_min.m_x)||!bbBool(l__0fill.m_min.m_y))){
      l__0fill=l__0scale;
    }
    l__0scale.m__subeq(t_std_geom_Vec2_1i(1,1));
    l__0fill.m__subeq(t_std_geom_Vec2_1i(1,1));
  }else{
    l__0scale=t_std_geom_Rect_1i((f0.l_pixmap->m_Width()/3),(f0.l_pixmap->m_Height()/3),((f0.l_pixmap->m_Width()*2)/3),((f0.l_pixmap->m_Height()*2)/3));
    l__0fill=l__0scale;
  }
  this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),f0.l_pixmap->m_Width(),f0.l_pixmap->m_Height());
  this->m__0x0=bbInt(0);
  this->m__0x1=l__0scale.m_min.m_x;
  this->m__0x2=l__0scale.m_max.m_x;
  this->m__0x3=this->m__0rect.m_max.m_x;
  this->m__0y0=bbInt(0);
  this->m__0y1=l__0scale.m_min.m_y;
  this->m__0y2=l__0scale.m_max.m_y;
  this->m__0y3=this->m__0rect.m_max.m_y;
  this->m__0image=bbGCNew<t_mojo_graphics_Image>(f0.l_pixmap,3,((t_mojo_graphics_Shader*)0));
  this->m__0bounds=t_std_geom_Rect_1i(l__0fill.m_min.m__sub(),this->m__0rect.m_max.m__sub(l__0fill.m_max));
}

t_mojo_graphics_Image* t_mojo_app_Skin::m_Image(){
  return this->m__0image;
}

void t_mojo_app_Skin::m_Draw(t_mojo_graphics_Canvas* l_canvas,t_std_geom_Rect_1i l_rect){
  bbInt l_x0=l_rect.m_Left();
  bbInt l_x1=(l_rect.m_Left()+this->m__0x1);
  bbInt l_x2=(l_rect.m_Right()-(this->m__0x3-this->m__0x2));
  bbInt l_x3=l_rect.m_Right();
  bbInt l_y0=l_rect.m_Top();
  bbInt l_y1=(l_rect.m_Top()+this->m__0y1);
  bbInt l_y2=(l_rect.m_Bottom()-(this->m__0y3-this->m__0y2));
  bbInt l_y3=l_rect.m_Bottom();
  l_canvas->m_DrawRect(bbFloat(l_x0),bbFloat(l_y0),bbFloat((l_x1-l_x0)),bbFloat((l_y1-l_y0)),this->m__0image,this->m__0x0,this->m__0y0,(this->m__0x1-this->m__0x0),(this->m__0y1-this->m__0y0));
  l_canvas->m_DrawRect(bbFloat(l_x1),bbFloat(l_y0),bbFloat((l_x2-l_x1)),bbFloat((l_y1-l_y0)),this->m__0image,this->m__0x1,this->m__0y0,(this->m__0x2-this->m__0x1),(this->m__0y1-this->m__0y0));
  l_canvas->m_DrawRect(bbFloat(l_x2),bbFloat(l_y0),bbFloat((l_x3-l_x2)),bbFloat((l_y1-l_y0)),this->m__0image,this->m__0x2,this->m__0y0,(this->m__0x3-this->m__0x2),(this->m__0y1-this->m__0y0));
  l_canvas->m_DrawRect(bbFloat(l_x0),bbFloat(l_y1),bbFloat((l_x1-l_x0)),bbFloat((l_y2-l_y1)),this->m__0image,this->m__0x0,this->m__0y1,(this->m__0x1-this->m__0x0),(this->m__0y2-this->m__0y1));
  l_canvas->m_DrawRect(bbFloat(l_x1),bbFloat(l_y1),bbFloat((l_x2-l_x1)),bbFloat((l_y2-l_y1)),this->m__0image,this->m__0x1,this->m__0y1,(this->m__0x2-this->m__0x1),(this->m__0y2-this->m__0y1));
  l_canvas->m_DrawRect(bbFloat(l_x2),bbFloat(l_y1),bbFloat((l_x3-l_x2)),bbFloat((l_y2-l_y1)),this->m__0image,this->m__0x2,this->m__0y1,(this->m__0x3-this->m__0x2),(this->m__0y2-this->m__0y1));
  l_canvas->m_DrawRect(bbFloat(l_x0),bbFloat(l_y2),bbFloat((l_x1-l_x0)),bbFloat((l_y3-l_y2)),this->m__0image,this->m__0x0,this->m__0y2,(this->m__0x1-this->m__0x0),(this->m__0y3-this->m__0y2));
  l_canvas->m_DrawRect(bbFloat(l_x1),bbFloat(l_y2),bbFloat((l_x2-l_x1)),bbFloat((l_y3-l_y2)),this->m__0image,this->m__0x1,this->m__0y2,(this->m__0x2-this->m__0x1),(this->m__0y3-this->m__0y2));
  l_canvas->m_DrawRect(bbFloat(l_x2),bbFloat(l_y2),bbFloat((l_x3-l_x2)),bbFloat((l_y3-l_y2)),this->m__0image,this->m__0x2,this->m__0y2,(this->m__0x3-this->m__0x2),(this->m__0y3-this->m__0y2));
}

t_std_geom_Rect_1i t_mojo_app_Skin::m_Bounds(){
  return this->m__0bounds;
}

void mx2_mojo_app_2skin_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_app_2skin_init_v("mojo_app_2skin",&mx2_mojo_app_2skin_init);
