
#include "../../desktop_release_pi/mojo_app_2window.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_app_2app.h"
#include "../../desktop_release_pi/mojo_app_2event.h"
#include "../../desktop_release_pi/mojo_graphics_2canvas.h"
#include "../../desktop_release_pi/mojo_std_collections_2map.h"
#include "../../desktop_release_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_types.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_geom_2affinemat3.h"

// ***** Internal *****

bbGCRootVar<t_std_collections_Stack_1Tt_mojo_app_Window_2> g_mojo_app_Window__0allWindows;
bbGCRootVar<t_std_collections_Stack_1Tt_mojo_app_Window_2> g_mojo_app_Window__0visibleWindows;
bbGCRootVar<t_std_collections_Map_1jTt_mojo_app_Window_2> g_mojo_app_Window__0windowsByID;

t_mojo_app_Window* g_mojo_app_Window_WindowForID(bbUInt l_id){
  return g_mojo_app_Window__0windowsByID->m__idx(l_id);
}

bbArray<bbGCVar<t_mojo_app_Window>>* g_mojo_app_Window_VisibleWindows(){
  return g_mojo_app_Window__0visibleWindows->m_ToArray();
}

bbArray<bbGCVar<t_mojo_app_Window>>* g_mojo_app_Window_AllWindows(){
  return g_mojo_app_Window__0allWindows->m_ToArray();
}

void t_mojo_app_Window::gcMark(){
  t_mojo_app_View::gcMark();
  bbGCMark(m__0canvas);
  bbGCMark(m__0keyView);
}

t_mojo_app_Window::t_mojo_app_Window(bbString l_title,t_std_geom_Rect_1i l_rect,bbInt l_flags){
  this->m_Init(l_title,l_rect,l_flags);
}

t_mojo_app_Window::t_mojo_app_Window(bbString l_title,bbInt l_width,bbInt l_height,bbInt l_flags){
  this->m_Init(l_title,t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_width,l_height),(l_flags|3));
}

t_mojo_app_Window::t_mojo_app_Window(){
  this->m_Init(BB_T("Window"),t_std_geom_Rect_1i(bbInt(0),bbInt(0),640,480),3);
}

void t_mojo_app_Window::m_Update(){
  if((bbCompare(this->m_MinSize(),this->m__0minSize)!=0)){
    SDL_SetWindowMinimumSize(this->m__0sdlWindow,this->m_MinSize().m_x,this->m_MinSize().m_y);
    this->m__0minSize=this->m_GetMinSize();
    this->m_MinSize(this->m__0minSize);
  }
  if((bbCompare(this->m_MaxSize(),this->m__0maxSize)!=0)){
    SDL_SetWindowMaximumSize(this->m__0sdlWindow,this->m_MaxSize().m_x,this->m_MaxSize().m_y);
    this->m__0maxSize=this->m_GetMaxSize();
    this->m_MaxSize(this->m__0maxSize);
  }
  if((bbCompare(this->m_Frame(),this->m__0frame)!=0)){
    SDL_SetWindowPosition(this->m__0sdlWindow,this->m_Frame().m_X(),this->m_Frame().m_Y());
    SDL_SetWindowSize(this->m__0sdlWindow,this->m_Frame().m_Width(),this->m_Frame().m_Height());
    this->m__0frame=this->m_GetFrame();
    this->m_Frame(this->m__0frame);
    this->m__0weirdHack=true;
  }
  this->m_Measure();
  this->m_UpdateLayout();
}

void t_mojo_app_Window::m_Title(bbString l_title){
  SDL_SetWindowTitle(this->m__0sdlWindow,bbUtf8String(l_title));
}

bbString t_mojo_app_Window::m_Title(){
  return bbString::fromUtf8String(((void*)(SDL_GetWindowTitle(this->m__0sdlWindow))));
}

void t_mojo_app_Window::m_SwapInterval(bbInt l_swapInterval){
  this->m__0swapInterval=l_swapInterval;
}

bbInt t_mojo_app_Window::m_SwapInterval(){
  return this->m__0swapInterval;
}

void t_mojo_app_Window::m_SendWindowEvent(t_mojo_app_WindowEvent* l_event){
  bbInt l_0=l_event->m_Type();
  if(l_0==11||l_0==12){
    this->m__0frame=this->m_GetFrame();
    this->m_Frame(this->m__0frame);
    this->m__0weirdHack=true;
  }
  this->m_OnWindowEvent(l_event);
}

void t_mojo_app_Window::m_Render(){
  SDL_GL_MakeCurrent(this->m__0sdlWindow,this->m__0sdlGLContext);
  SDL_GL_SetSwapInterval(this->m__0swapInterval);
  t_std_geom_Rect_1i l_bounds=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m_Frame().m_Size());
  this->m__0canvas->m_Resize(l_bounds.m_Size());
  this->m__0canvas->m_BeginRender(l_bounds,t_std_geom_AffineMat3_1f(bbNullCtor));
  this->m__0canvas->m_Clear(this->m__0clearColor);
  this->m_Render(this->m__0canvas);
  this->m__0canvas->m_EndRender();
  SDL_GL_SwapWindow(this->m__0sdlWindow);
}

void t_mojo_app_Window::m_OnWindowEvent(t_mojo_app_WindowEvent* l_event){
  bbInt l_0=l_event->m_Type();
  if(l_0==10){
    g_mojo_app_App->m_Terminate();
  }else if(l_0==11){
  }else if(l_0==12){
    g_mojo_app_App->m_RequestRender();
  }else if(l_0==13){
  }else if(l_0==14){
  }
}

SDL_Window* t_mojo_app_Window::m_NativeWindow(){
  return this->m__0sdlWindow;
}

void t_mojo_app_Window::m_KeyView(t_mojo_app_View* l_keyView){
  this->m__0keyView=l_keyView;
}

t_mojo_app_View* t_mojo_app_Window::m_KeyView(){
  return this->m__0keyView;
}

void t_mojo_app_Window::m_Init(bbString l_title,t_std_geom_Rect_1i l_rect,bbInt l_flags){
  this->m_Layout(BB_T("fill"));
  bbInt l_x=(bbBool((l_flags&1)) ? SDL_WINDOWPOS_CENTERED : l_rect.m_X());
  bbInt l_y=(bbBool((l_flags&2)) ? SDL_WINDOWPOS_CENTERED : l_rect.m_Y());
  SDL_WindowFlags l_sdlFlags=SDL_WINDOW_OPENGL;
  if(bbBool((l_flags&4))){
    l_sdlFlags=SDL_WindowFlags(l_sdlFlags|SDL_WINDOW_HIDDEN);
  }
  if(bbBool((l_flags&8))){
    l_sdlFlags=SDL_WindowFlags(l_sdlFlags|SDL_WINDOW_RESIZABLE);
  }
  if(bbBool((l_flags&16))){
    l_sdlFlags=SDL_WindowFlags(l_sdlFlags|SDL_WINDOW_BORDERLESS);
  }
  if(bbBool((l_flags&32))){
    this->m__0fullscreen=true;
    l_sdlFlags=SDL_WindowFlags(l_sdlFlags|SDL_WINDOW_FULLSCREEN);
  }
  this->m__0flags=l_flags;
  this->m__0sdlWindow=SDL_CreateWindow(bbUtf8String(l_title),l_x,l_y,l_rect.m_Width(),l_rect.m_Height(),bbInt(l_sdlFlags));
  bbAssert(bbBool(this->m__0sdlWindow),BB_T("Failed to create SDL_Window"));
  g_mojo_app_Window__0allWindows->m_Push(this);
  g_mojo_app_Window__0windowsByID->m__idxeq(bbUInt(SDL_GetWindowID(this->m__0sdlWindow)),this);
  if(!bbBool((l_flags&4))){
    g_mojo_app_Window__0visibleWindows->m_Push(this);
  }
  this->m__0minSize=this->m_GetMinSize();
  this->m_MinSize(this->m__0minSize);
  this->m__0maxSize=this->m_GetMaxSize();
  this->m_MaxSize(this->m__0maxSize);
  this->m__0frame=this->m_GetFrame();
  this->m_Frame(this->m__0frame);
  this->m__0sdlGLContext=SDL_GL_CreateContext(this->m__0sdlWindow);
  SDL_GL_MakeCurrent(this->m__0sdlWindow,this->m__0sdlGLContext);
  this->m__0canvas=bbGCNew<t_mojo_graphics_Canvas>(this->m__0frame.m_Width(),this->m__0frame.m_Height());
  this->m_Update();
}

t_std_geom_Vec2_1i t_mojo_app_Window::m_GetMinSize(){
  bbInt l_w{};
  bbInt l_h{};
  SDL_GetWindowMinimumSize(this->m__0sdlWindow,&l_w,&l_h);
  return t_std_geom_Vec2_1i(l_w,l_h);
}

t_std_geom_Vec2_1i t_mojo_app_Window::m_GetMaxSize(){
  bbInt l_w{};
  bbInt l_h{};
  SDL_GetWindowMaximumSize(this->m__0sdlWindow,&l_w,&l_h);
  return t_std_geom_Vec2_1i(l_w,l_h);
}

t_std_geom_Rect_1i t_mojo_app_Window::m_GetFrame(){
  bbInt l_x{};
  bbInt l_y{};
  bbInt l_w{};
  bbInt l_h{};
  SDL_GetWindowPosition(this->m__0sdlWindow,&l_x,&l_y);
  SDL_GetWindowSize(this->m__0sdlWindow,&l_w,&l_h);
  return t_std_geom_Rect_1i(l_x,l_y,(l_x+l_w),(l_y+l_h));
}

void t_mojo_app_Window::m_Fullscreen(bbBool l_fullscreen){
  if((l_fullscreen==this->m__0fullscreen)){
    return;
  }
  this->m__0fullscreen=l_fullscreen;
  if(this->m__0fullscreen){
    SDL_DisplayMode l_mode{};
    l_mode.w=this->m_Width();
    l_mode.h=this->m_Height();
    SDL_SetWindowDisplayMode(this->m__0sdlWindow,&l_mode);
    SDL_SetWindowFullscreen(this->m__0sdlWindow,bbInt(SDL_WINDOW_FULLSCREEN));
  }else{
    SDL_SetWindowFullscreen(this->m__0sdlWindow,bbInt(0));
  }
}

bbBool t_mojo_app_Window::m_Fullscreen(){
  return this->m__0fullscreen;
}

t_mojo_app_Window* t_mojo_app_Window::m_FindWindow(){
  return this;
}

void t_mojo_app_Window::m_ClearColor(t_std_graphics_Color l_clearColor){
  this->m__0clearColor=l_clearColor;
}

t_std_graphics_Color t_mojo_app_Window::m_ClearColor(){
  return this->m__0clearColor;
}

void mx2_mojo_app_2window_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_app_Window__0allWindows=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_Window_2>();
  g_mojo_app_Window__0visibleWindows=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_Window_2>();
  g_mojo_app_Window__0windowsByID=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2>();
}

bbInit mx2_mojo_app_2window_init_v("mojo_app_2window",&mx2_mojo_app_2window_init);
