
#include "../../desktop_release_pi/mojo_app_2style.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_app_2skin.h"
#include "../../desktop_release_pi/mojo_graphics_2canvas.h"
#include "../../desktop_release_pi/mojo_graphics_2font.h"
#include "../../desktop_release_pi/mojo_std_collections_2map.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_geom_2vec2.h"

// ***** Internal *****

bbGCRootVar<t_mojo_app_Style> g_mojo_app_Style__0defaultStyle;
bbGCRootVar<t_std_collections_Map_1sTt_mojo_app_Style_2> g_mojo_app_Style__0styles;

t_mojo_app_Style* g_mojo_app_Style_GetStyle(bbString l_name){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    void gcMark(){
      bbGCMarkPtr(l_style);
    }
  }f0{};
  f0.l_style=g_mojo_app_Style__0styles->m__idx(l_name);
  if(bbBool(f0.l_style)){
    return f0.l_style;
  }
  bbInt l_i=l_name.find(BB_T(":"),bbInt(0));
  if((l_i!=-1)){
    return g_mojo_app_Style_GetStyle(l_name.slice(bbInt(0),l_i));
  }
  if(!bbBool(g_mojo_app_Style__0defaultStyle)){
    g_mojo_app_Style__0defaultStyle=bbGCNew<t_mojo_app_Style>();
  }
  return g_mojo_app_Style__0defaultStyle;
}

void t_mojo_app_Style::init(){
  m__0states=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2>();
  m__0images=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2>();
}

void t_mojo_app_Style::gcMark(){
  bbGCMark(m__0states);
  bbGCMark(m__0skin);
  bbGCMark(m__0font);
  bbGCMark(m__0images);
}

t_mojo_app_Style::t_mojo_app_Style(bbString l_name,t_mojo_app_Style* l_style){
  init();
  this->m_Init(l_name,l_style,true);
}

t_mojo_app_Style::t_mojo_app_Style(bbString l_name){
  init();
  this->m_Init(l_name,((t_mojo_app_Style*)0),false);
}

t_mojo_app_Style::t_mojo_app_Style(t_mojo_app_Style* l_style){
  init();
  this->m_Init(bbString{},l_style,true);
}

t_mojo_app_Style::t_mojo_app_Style(){
  init();
  this->m_Init(bbString{},((t_mojo_app_Style*)0),false);
}

void t_mojo_app_Style::m_SkinColor(t_std_graphics_Color l_skinColor){
  this->m__0skcolor=l_skinColor;
}

t_std_graphics_Color t_mojo_app_Style::m_SkinColor(){
  return this->m__0skcolor;
}

void t_mojo_app_Style::m_Skin(t_mojo_app_Skin* l_skin){
  this->m__0skin=l_skin;
}

t_mojo_app_Skin* t_mojo_app_Style::m_Skin(){
  return this->m__0skin;
}

void t_mojo_app_Style::m_SetImage(bbString l_name,t_mojo_graphics_Image* l_image){
  this->m__0images->m__idxeq(l_name,l_image);
}

void t_mojo_app_Style::m_Render(t_mojo_graphics_Canvas* l_canvas,t_std_geom_Rect_1i l_bounds){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Font* l_font{};
    t_mojo_app_Skin* l_skin{};
    void gcMark(){
      bbGCMarkPtr(l_font);
      bbGCMarkPtr(l_skin);
    }
  }f0{};
  l_canvas->m_BlendMode(1);
  l_bounds.m__subeq(this->m_Margin());
  t_std_geom_Rect_1i l_border=this->m_Border();
  t_std_graphics_Color l_bdcolor=this->m_BorderColor();
  if(((bbBool(l_border.m_Width())||bbBool(l_border.m_Height()))&&bbBool(l_bdcolor.m_a))){
    l_canvas->m_Color(l_bdcolor);
    bbInt l_x=l_bounds.m_X();
    bbInt l_y=l_bounds.m_Y();
    bbInt l_w=l_bounds.m_Width();
    bbInt l_h=l_bounds.m_Height();
    bbInt l_l=-l_border.m_min.m_x;
    bbInt l_r=l_border.m_max.m_x;
    bbInt l_t=-l_border.m_min.m_y;
    bbInt l_b=l_border.m_max.m_y;
    l_canvas->m_DrawRect(bbFloat(l_x),bbFloat(l_y),bbFloat(l_l),bbFloat((l_h-l_b)));
    l_canvas->m_DrawRect(bbFloat((l_x+l_l)),bbFloat(l_y),bbFloat((l_w-l_l)),bbFloat(l_t));
    l_canvas->m_DrawRect(bbFloat(((l_x+l_w)-l_r)),bbFloat((l_y+l_t)),bbFloat(l_r),bbFloat((l_h-l_t)));
    l_canvas->m_DrawRect(bbFloat(l_x),bbFloat(((l_y+l_h)-l_b)),bbFloat((l_w-l_r)),bbFloat(l_b));
  }
  l_bounds.m__subeq(l_border);
  t_std_graphics_Color l_bgcolor=this->m_BackgroundColor();
  if(bbBool(l_bgcolor.m_a)){
    l_canvas->m_Color(l_bgcolor);
    l_canvas->m_DrawRect(bbFloat(l_bounds.m_X()),bbFloat(l_bounds.m_Y()),bbFloat(l_bounds.m_Width()),bbFloat(l_bounds.m_Height()));
  }
  f0.l_skin=this->m_Skin();
  t_std_graphics_Color l_skcolor=this->m_SkinColor();
  if((bbBool(f0.l_skin)&&bbBool(l_skcolor.m_a))){
    l_canvas->m_Color(l_skcolor);
    f0.l_skin->m_Draw(l_canvas,l_bounds);
  }
  f0.l_font=this->m_DefaultFont();
  t_std_graphics_Color l_color=this->m_DefaultColor();
  l_canvas->m_Font(f0.l_font);
  l_canvas->m_Color(l_color);
}

void t_mojo_app_Style::m_Padding(t_std_geom_Rect_1i l_padding){
  this->m__0padding=l_padding;
}

t_std_geom_Rect_1i t_mojo_app_Style::m_Padding(){
  return this->m__0padding;
}

void t_mojo_app_Style::m_Margin(t_std_geom_Rect_1i l_margin){
  this->m__0margin=l_margin;
}

t_std_geom_Rect_1i t_mojo_app_Style::m_Margin(){
  return this->m__0margin;
}

void t_mojo_app_Style::m_Init(bbString l_name,t_mojo_app_Style* l_style,bbBool l_copyStates){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    f0_t(t_mojo_app_Style* l_style):l_style(l_style){
    }
    void gcMark(){
      bbGCMarkPtr(l_style);
    }
  }f0{l_style};
  if(!bbBool(f0.l_style)){
    f0.l_style=g_mojo_app_Style__0defaultStyle;
  }
  if(bbBool(f0.l_style)){
    this->m__0bgcolor=f0.l_style->m__0bgcolor;
    this->m__0padding=f0.l_style->m__0padding;
    this->m__0skin=f0.l_style->m__0skin;
    this->m__0skcolor=f0.l_style->m__0skcolor;
    this->m__0border=f0.l_style->m__0border;
    this->m__0bdcolor=f0.l_style->m__0bdcolor;
    this->m__0margin=f0.l_style->m__0margin;
    this->m__0color=f0.l_style->m__0color;
    this->m__0font=f0.l_style->m__0font;
    this->m__0images=f0.l_style->m__0images->m_Copy();
    if(l_copyStates){
      {
        struct f3_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator l_0{};
          void gcMark(){
            bbGCMark(l_0);
          }
        }f3{};
        f3.l_0=f0.l_style->m__0states->m_All();
        for(;f3.l_0.m_Valid();f3.l_0.m_Bump()){
          struct f4_t : public bbGCFrame{
            t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_it{};
            t_mojo_app_Style* t0{};
            t_mojo_app_Style* t1{};
            void gcMark(){
              bbGCMarkPtr(l_it);
              bbGCMarkPtr(t0);
              bbGCMarkPtr(t1);
            }
          }f4{};
          f4.l_it=f3.l_0.m_Current();
          this->m__0states->m__idxeq(f4.l_it->m_Key(),f4.t1=bbGCNew<t_mojo_app_Style>(f4.t0=f4.l_it->m_Value()));
        }
      }
    }
  }
  if(bbBool(l_name)){
    g_mojo_app_Style__0styles->m__idxeq(l_name,this);
  }
}

t_mojo_app_Style* t_mojo_app_Style::m_GetState(bbString l_state){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    void gcMark(){
      bbGCMarkPtr(l_style);
    }
  }f0{};
  f0.l_style=this->m__0states->m__idx(l_state);
  if(bbBool(f0.l_style)){
    return f0.l_style;
  }
  return this;
}

t_mojo_graphics_Image* t_mojo_app_Style::m_GetImage(bbString l_name){
  return this->m__0images->m__idx(l_name);
}

void t_mojo_app_Style::m_DefaultFont(t_mojo_graphics_Font* l_font){
  this->m__0font=l_font;
}

t_mojo_graphics_Font* t_mojo_app_Style::m_DefaultFont(){
  return this->m__0font;
}

void t_mojo_app_Style::m_DefaultColor(t_std_graphics_Color l_color){
  this->m__0color=l_color;
}

t_std_graphics_Color t_mojo_app_Style::m_DefaultColor(){
  return this->m__0color;
}

t_std_geom_Rect_1i t_mojo_app_Style::m_Bounds(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Skin* l_skin{};
    void gcMark(){
      bbGCMarkPtr(l_skin);
    }
  }f0{};
  t_std_geom_Rect_1i l_bounds=this->m_Padding();
  f0.l_skin=this->m_Skin();
  if(bbBool(f0.l_skin)){
    struct f1_t : public bbGCFrame{
      t_mojo_app_Skin* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    l_bounds.m__addeq((f1.t0=this->m_Skin())->m_Bounds());
  }
  l_bounds.m__addeq(this->m_Border());
  l_bounds.m__addeq(this->m_Margin());
  return l_bounds;
}

void t_mojo_app_Style::m_BorderColor(t_std_graphics_Color l_borderColor){
  this->m__0bdcolor=l_borderColor;
}

t_std_graphics_Color t_mojo_app_Style::m_BorderColor(){
  return this->m__0bdcolor;
}

void t_mojo_app_Style::m_Border(t_std_geom_Rect_1i l_border){
  this->m__0border=l_border;
}

t_std_geom_Rect_1i t_mojo_app_Style::m_Border(){
  return this->m__0border;
}

void t_mojo_app_Style::m_BackgroundColor(t_std_graphics_Color l_backgroundColor){
  this->m__0bgcolor=l_backgroundColor;
}

t_std_graphics_Color t_mojo_app_Style::m_BackgroundColor(){
  return this->m__0bgcolor;
}

t_mojo_app_Style* t_mojo_app_Style::m_AddState(bbString l_state,bbString l_srcState){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    t_mojo_app_Style* t0{};
    void gcMark(){
      bbGCMarkPtr(l_style);
      bbGCMarkPtr(t0);
    }
  }f0{};
  f0.l_style=bbGCNew<t_mojo_app_Style>();
  f0.l_style->m_Init(bbString{},f0.t0=this->m_GetState(l_srcState),false);
  this->m__0states->m__idxeq(l_state,f0.l_style);
  return f0.l_style;
}

void mx2_mojo_app_2style_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_app_Style__0styles=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2>();
}

bbInit mx2_mojo_app_2style_init_v("mojo_app_2style",&mx2_mojo_app_2style_init);
