
#include "../../desktop_release_pi/mojo_graphics_2vertex.h"

// ***** External *****

// ***** Internal *****

t_mojo_graphics_Vertex2f::t_mojo_graphics_Vertex2f(bbFloat l_x,bbFloat l_y,bbFloat l_s0,bbFloat l_t0,bbFloat l_ix,bbFloat l_iy,bbUInt l_colorARGB){
  (*this).m_x=l_x;
  (*this).m_y=l_y;
  (*this).m_s0=l_s0;
  (*this).m_t0=l_t0;
  (*this).m_ix=l_ix;
  (*this).m_iy=l_iy;
  (*this).m_color=l_colorARGB;
}

t_mojo_graphics_Vertex2f::t_mojo_graphics_Vertex2f(t_std_geom_Vec2_1f l_position,t_std_geom_Vec2_1f l_texCoord0,t_std_geom_Vec2_1f l_tangent,bbUInt l_colorARGB){
  (*this).m_Position(l_position);
  (*this).m_TexCoord0(l_texCoord0);
  (*this).m_Tangent(l_tangent);
  (*this).m_ColorARGB(l_colorARGB);
}

t_mojo_graphics_Vertex2f::t_mojo_graphics_Vertex2f(bbNullCtor_t){
}

void t_mojo_graphics_Vertex2f::m_TexCoord0(t_std_geom_Vec2_1f l_texCoord0){
  (*this).m_s0=l_texCoord0.m_x;
  (*this).m_t0=l_texCoord0.m_y;
}

t_std_geom_Vec2_1f t_mojo_graphics_Vertex2f::m_TexCoord0(){
  return t_std_geom_Vec2_1f((*this).m_s0,(*this).m_t0);
}

void t_mojo_graphics_Vertex2f::m_Tangent(t_std_geom_Vec2_1f l_tangent){
  (*this).m_ix=l_tangent.m_x;
  (*this).m_iy=l_tangent.m_y;
}

t_std_geom_Vec2_1f t_mojo_graphics_Vertex2f::m_Tangent(){
  return t_std_geom_Vec2_1f((*this).m_ix,(*this).m_iy);
}

void t_mojo_graphics_Vertex2f::m_Position(t_std_geom_Vec2_1f l_position){
  (*this).m_x=l_position.m_x;
  (*this).m_y=l_position.m_y;
}

t_std_geom_Vec2_1f t_mojo_graphics_Vertex2f::m_Position(){
  return t_std_geom_Vec2_1f((*this).m_x,(*this).m_y);
}

void t_mojo_graphics_Vertex2f::m_ColorARGB(bbUInt l_colorARGB){
  (*this).m_color=l_colorARGB;
}

bbUInt t_mojo_graphics_Vertex2f::m_ColorARGB(){
  return (*this).m_color;
}

int bbCompare(const t_mojo_graphics_Vertex2f&x,const t_mojo_graphics_Vertex2f&y){
  if(int t=bbCompare(x.m_x,y.m_x)) return t;
  if(int t=bbCompare(x.m_y,y.m_y)) return t;
  if(int t=bbCompare(x.m_s0,y.m_s0)) return t;
  if(int t=bbCompare(x.m_t0,y.m_t0)) return t;
  if(int t=bbCompare(x.m_ix,y.m_ix)) return t;
  if(int t=bbCompare(x.m_iy,y.m_iy)) return t;
  if(int t=bbCompare(x.m_color,y.m_color)) return t;
  return 0;
}

void mx2_mojo_graphics_2vertex_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2vertex_init_v("mojo_graphics_2vertex",&mx2_mojo_graphics_2vertex_init);
