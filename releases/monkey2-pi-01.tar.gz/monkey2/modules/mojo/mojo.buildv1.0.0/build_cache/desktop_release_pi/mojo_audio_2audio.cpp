
#include "../../desktop_release_pi/mojo_audio_2audio.h"

// ***** External *****

#include "../../../../sdl2/sdl2.buildv1.0.0/desktop_release_pi/sdl2_sdl2.h"
#include "../../../../std/std.buildv1.0.0/desktop_release_pi/std_memory_2databuffer.h"

extern bbFloat g_monkey_math_Clamp_1f(bbFloat l_value,bbFloat l_min,bbFloat l_max);

// ***** Internal *****

bbGCRootVar<bbArray<bbInt>> g_mojo_audio__0alloced;
bbGCRootVar<t_mojo_audio_AudioDevice> g_mojo_audio_Audio;

t_mojo_audio_Sound* g_mojo_audio_Sound_Load(bbString l_path){
  struct f0_t : public bbGCFrame{
    t_std_memory_DataBuffer* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  f0.l_data=g_std_memory_DataBuffer_Load(l_path);
  if(!bbBool(f0.l_data)){
    return ((t_mojo_audio_Sound*)0);
  }
  SDL_RWops* l_rwops=SDL_RWFromMem(((void*)(f0.l_data->m_Data())),f0.l_data->m_Length());
  Mix_Chunk* l_chunk=Mix_LoadWAV_RW(l_rwops,1);
  if(!bbBool(l_chunk)){
    return ((t_mojo_audio_Sound*)0);
  }
  return bbGCNew<t_mojo_audio_Sound>(l_chunk);
}

void t_mojo_audio_AudioDevice::m_Init(){
  Mix_Init(bbInt(0));
  Mix_OpenAudio(44100,bbUShort(MIX_DEFAULT_FORMAT),2,1024);
  Mix_AllocateChannels(32);
  g_mojo_audio__0alloced=bbArray<bbInt>::create(32);
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<32);l_i+=1){
      g_mojo_audio__0alloced->at(l_i)=(l_i+32);
    }
  }
}

t_mojo_audio_Sound::t_mojo_audio_Sound(Mix_Chunk* l_chunk){
  this->m__0chunk=l_chunk;
}

t_mojo_audio_Channel* t_mojo_audio_Sound::m_Play(bbInt l_loops){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_channel{};
    void gcMark(){
      bbGCMarkPtr(l_channel);
    }
  }f0{};
  f0.l_channel=bbGCNew<t_mojo_audio_Channel>();
  if(!f0.l_channel->m_Play(this,l_loops)){
    return ((t_mojo_audio_Channel*)0);
  }
  return f0.l_channel;
}

t_mojo_audio_Channel::t_mojo_audio_Channel(){
}

void t_mojo_audio_Channel::m_Volume(bbFloat l_volume){
  if(this->m_Invalid()){
    return;
  }
  this->m__0volume=g_monkey_math_Clamp_1f(l_volume,0.0f,1.0f);
  Mix_Volume((this->m__0id&31),bbInt((this->m__0volume*128.0f)));
}

bbFloat t_mojo_audio_Channel::m_Volume(){
  if(this->m_Invalid()){
    return 0.0f;
  }
  return this->m__0volume;
}

void t_mojo_audio_Channel::m_Stop(){
  if(this->m_Invalid()){
    return;
  }
  Mix_HaltChannel(this->m__0id);
}

void t_mojo_audio_Channel::m_Rate(bbFloat l_rate){
}

bbFloat t_mojo_audio_Channel::m_Rate(){
  return 1.0f;
}

bbBool t_mojo_audio_Channel::m_Playing(){
  if(this->m_Invalid()){
    return false;
  }
  return bbBool(Mix_Playing((this->m__0id&31)));
}

bbBool t_mojo_audio_Channel::m_Play(t_mojo_audio_Sound* l_sound,bbInt l_loops){
  bbInt l_id=(this->m__0id&31);
  if((g_mojo_audio__0alloced->at(l_id)!=this->m__0id)){
    l_id=-1;
  }
  l_id=Mix_PlayChannel(l_id,l_sound->m__0chunk,l_loops);
  if((l_id<bbInt(0))){
    return false;
  }
  g_mojo_audio__0alloced->at(l_id)+=32;
  this->m__0id=g_mojo_audio__0alloced->at(l_id);
  this->m__0volume=1.0f;
  return true;
}

void t_mojo_audio_Channel::m_Paused(bbBool l_paused){
  if(this->m_Invalid()){
    return;
  }
  Mix_Pause((this->m__0id&31));
}

bbBool t_mojo_audio_Channel::m_Paused(){
  if(this->m_Invalid()){
    return false;
  }
  return bbBool(Mix_Paused((this->m__0id&31)));
}

void t_mojo_audio_Channel::m_Pan(bbFloat l_pan){
}

bbFloat t_mojo_audio_Channel::m_Pan(){
  return 0.0f;
}

bbBool t_mojo_audio_Channel::m_Invalid(){
  return (g_mojo_audio__0alloced->at((this->m__0id&31))!=this->m__0id);
}

void mx2_mojo_audio_2audio_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_audio_Audio=bbGCNew<t_mojo_audio_AudioDevice>();
}

bbInit mx2_mojo_audio_2audio_init_v("mojo_audio_2audio",&mx2_mojo_audio_2audio_init);
