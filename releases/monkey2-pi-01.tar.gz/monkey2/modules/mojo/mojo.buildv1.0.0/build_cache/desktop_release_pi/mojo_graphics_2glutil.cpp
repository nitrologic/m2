
#include "../../desktop_release_pi/mojo_graphics_2glutil.h"

// ***** External *****

#include "../../../../gles20/gles20.buildv1.0.0/desktop_release_pi/gles20_gles20.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_types.h"

// ***** Internal *****

bbInt g_mojo_graphics_glutil_tmpi;
bbInt g_mojo_graphics_glutil_glGraphicsSeq;

void g_mojo_graphics_glutil_glLink(bbInt l_program){
  glLinkProgram(bbUInt(l_program));
  glGetProgramiv(bbUInt(l_program),GL_LINK_STATUS,&g_mojo_graphics_glutil_tmpi);
  if(!bbBool(g_mojo_graphics_glutil_tmpi)){
    bbAssert(false,(BB_T("Failed to link program:")+g_gles20_glGetProgramInfoLogEx(bbUInt(l_program))));
  }
}

bbInt g_mojo_graphics_glutil_glCompile(bbInt l_type,bbString l_source){
  bbUInt l_shader=glCreateShader(l_type);
  g_gles20_glShaderSourceEx(l_shader,l_source);
  glCompileShader(l_shader);
  glGetShaderiv(l_shader,GL_COMPILE_STATUS,&g_mojo_graphics_glutil_tmpi);
  if(!bbBool(g_mojo_graphics_glutil_tmpi)){
    struct f1_t : public bbGCFrame{
      bbArray<bbString>* l_lines{};
      void gcMark(){
        bbGCMarkPtr(l_lines);
      }
    }f1{};
    puts((BB_T("Failed to compile fragment shader:")+g_gles20_glGetShaderInfoLogEx(l_shader)).c_str());fflush( stdout );
    f1.l_lines=l_source.split(BB_T("\n"));
    {
      bbInt l_i=bbInt(0);
      for(;(l_i<f1.l_lines->length());l_i+=1){
        puts(((bbString((l_i+1))+BB_T(":\t"))+f1.l_lines->at(l_i)).c_str());fflush( stdout );
      }
    }
    bbAssert(false,BB_T("Compile fragment shader failed"));
  }
  return bbInt(l_shader);
}

void g_mojo_graphics_glutil_glPopFramebuffer(){
  glBindFramebuffer(GL_FRAMEBUFFER,bbUInt(g_mojo_graphics_glutil_tmpi));
}

void g_mojo_graphics_glutil_glPushFramebuffer(bbInt l_framebuf){
  glGetIntegerv(GL_FRAMEBUFFER_BINDING,&g_mojo_graphics_glutil_tmpi);
  glBindFramebuffer(GL_FRAMEBUFFER,bbUInt(l_framebuf));
}

void g_mojo_graphics_glutil_glPopTexture2d(){
  glBindTexture(GL_TEXTURE_2D,bbUInt(g_mojo_graphics_glutil_tmpi));
}

void g_mojo_graphics_glutil_glPushTexture2d(bbInt l_tex){
  glGetIntegerv(GL_TEXTURE_BINDING_2D,&g_mojo_graphics_glutil_tmpi);
  glBindTexture(GL_TEXTURE_2D,bbUInt(l_tex));
}

bbInt g_mojo_graphics_glutil_glFormat(bbInt l_format){
  if(l_format==2){
    return GL_ALPHA;
  }else if(l_format==1){
    return GL_LUMINANCE;
  }else if(l_format==3){
    return GL_LUMINANCE_ALPHA;
  }else if(l_format==4){
    return GL_RGB;
  }else if(l_format==5){
    return GL_RGBA;
  }
  bbAssert(false,BB_T("Invalidate PixelFormat"));
  return GL_RGBA;
}

void g_mojo_graphics_glutil_glCheck(){
  bbInt l_err=glGetError();
  if((l_err==GL_NO_ERROR)){
    return;
  }
  bbAssert(false,(BB_T("GL ERROR! err=")+bbString(l_err)));
}

void mx2_mojo_graphics_2glutil_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_graphics_glutil_glGraphicsSeq=1;
}

bbInit mx2_mojo_graphics_2glutil_init_v("mojo_graphics_2glutil",&mx2_mojo_graphics_2glutil_init);
