
#include "../../desktop_release_pi/mojo_input_2mouse.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_app_2app.h"
#include "../../desktop_release_pi/mojo_app_2view.h"
#include "../../desktop_release_pi/mojo_app_2window.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_debug.h"
#include "../../../../sdl2/sdl2.buildv1.0.0/desktop_release_pi/sdl2_sdl2.h"

// ***** Internal *****

bbGCRootVar<t_mojo_input_MouseDevice> g_mojo_input_Mouse;

void t_mojo_input_MouseDevice::init(){
  m__0buttons=bbArray<bbBool>::create(4);
  m__0pressed=bbArray<bbBool>::create(4);
  m__0released=bbArray<bbBool>::create(4);
}

void t_mojo_input_MouseDevice::gcMark(){
  t_mojo_input_InputDevice::gcMark();
  bbGCMark(m__0buttons);
  bbGCMark(m__0pressed);
  bbGCMark(m__0released);
}

t_mojo_input_MouseDevice::t_mojo_input_MouseDevice(){
  init();
}

bbInt t_mojo_input_MouseDevice::m_Y(){
  return this->m_Location().m_y;
}

bbInt t_mojo_input_MouseDevice::m_X(){
  return this->m_Location().m_x;
}

void t_mojo_input_MouseDevice::m_Reset(){
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<4);l_i+=1){
      this->m__0pressed->at(l_i)=true;
      this->m__0released->at(l_i)=true;
    }
  }
}

void t_mojo_input_MouseDevice::m_Poll(){
  bbInt l_mask=SDL_GetMouseState(&this->m__0location.m_x,&this->m__0location.m_y);
  if(bbBool(g_mojo_app_App->m_ActiveWindow())){
    struct f1_t : public bbGCFrame{
      t_mojo_app_Window* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    this->m__0location=(f1.t0=g_mojo_app_App->m_ActiveWindow())->m_TransformPointFromView(this->m__0location,((t_mojo_app_View*)0));
  }
  this->m__0buttons->at(bbInt(1))=bbBool((l_mask&1));
  this->m__0buttons->at(bbInt(2))=bbBool((l_mask&2));
  this->m__0buttons->at(bbInt(3))=bbBool((l_mask&4));
  g_mojo_app_App->m_Idle+=bbMethod((t_mojo_input_MouseDevice*)(this),&t_mojo_input_MouseDevice::m_Poll);
}

void t_mojo_input_MouseDevice::m_PointerVisible(bbBool l_pointerVisible){
  SDL_ShowCursor((l_pointerVisible ? SDL_ENABLE : SDL_DISABLE));
}

bbBool t_mojo_input_MouseDevice::m_PointerVisible(){
  return (SDL_ShowCursor(-1)==SDL_ENABLE);
}

t_std_geom_Vec2_1i t_mojo_input_MouseDevice::m_Location(){
  return this->m__0location;
}

void t_mojo_input_MouseDevice::m_Init(){
  if(this->m__0init){
    return;
  }
  g_mojo_app_App->m_Idle+=bbMethod((t_mojo_input_MouseDevice*)(this),&t_mojo_input_MouseDevice::m_Poll);
  this->m__0init=true;
  this->m_Reset();
}

bbBool t_mojo_input_MouseDevice::m_ButtonReleased(bbInt l_button){
  bbDebugAssert(((bbInt(l_button)>=bbInt(0))&&(bbInt(l_button)<4)),BB_T("Mouse buttton out of range"));
  if(!this->m__0buttons->at(bbInt(l_button))){
    if(this->m__0released->at(bbInt(l_button))){
      return false;
    }
    this->m__0released->at(bbInt(l_button))=true;
    return true;
  }
  this->m__0released->at(bbInt(l_button))=false;
  return false;
}

bbBool t_mojo_input_MouseDevice::m_ButtonPressed(bbInt l_button){
  bbDebugAssert(((bbInt(l_button)>=bbInt(0))&&(bbInt(l_button)<4)),BB_T("Mouse buttton out of range"));
  if(this->m__0buttons->at(bbInt(l_button))){
    if(this->m__0pressed->at(bbInt(l_button))){
      return false;
    }
    this->m__0pressed->at(bbInt(l_button))=true;
    return true;
  }
  this->m__0pressed->at(bbInt(l_button))=false;
  return false;
}

bbBool t_mojo_input_MouseDevice::m_ButtonHit(bbInt l_button){
  return this->m_ButtonPressed(l_button);
}

bbBool t_mojo_input_MouseDevice::m_ButtonDown(bbInt l_button){
  bbDebugAssert(((bbInt(l_button)>=bbInt(0))&&(bbInt(l_button)<4)),BB_T("Mouse buttton out of range"));
  return this->m__0buttons->at(bbInt(l_button));
}

void mx2_mojo_input_2mouse_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_input_Mouse=bbGCNew<t_mojo_input_MouseDevice>();
}

bbInit mx2_mojo_input_2mouse_init_v("mojo_input_2mouse",&mx2_mojo_input_2mouse_init);
