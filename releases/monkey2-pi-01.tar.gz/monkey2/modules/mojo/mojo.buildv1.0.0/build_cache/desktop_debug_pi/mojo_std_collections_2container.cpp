
#include "../../desktop_debug_pi/mojo_std_collections_2container.h"

// ***** External *****

// ***** Internal *****

bbString bbDBType(t_std_collections_IContainer_1Tt_std_geom_AffineMat3_1f_2**){
  return "std.collections.IContainer<AffineMat3f:std.geom.AffineMat3<Float>>";
}
bbString bbDBValue(t_std_collections_IContainer_1Tt_std_geom_AffineMat3_1f_2**p){
  return bbDBInterfaceValue(*p);
}

bbString bbDBType(t_std_collections_IContainer_1Tt_mojo_graphics_DrawOp_2**){
  return "std.collections.IContainer<mojo.graphics.DrawOp>";
}
bbString bbDBValue(t_std_collections_IContainer_1Tt_mojo_graphics_DrawOp_2**p){
  return bbDBInterfaceValue(*p);
}

bbString bbDBType(t_std_collections_IContainer_1Tt_std_geom_Rect_1i_2**){
  return "std.collections.IContainer<Recti:std.geom.Rect<Int>>";
}
bbString bbDBValue(t_std_collections_IContainer_1Tt_std_geom_Rect_1i_2**p){
  return bbDBInterfaceValue(*p);
}

bbString bbDBType(t_std_collections_IContainer_1Tt_mojo_graphics_Vertex2f_2**){
  return "std.collections.IContainer<mojo.graphics.Vertex2f>";
}
bbString bbDBValue(t_std_collections_IContainer_1Tt_mojo_graphics_Vertex2f_2**p){
  return bbDBInterfaceValue(*p);
}

bbString bbDBType(t_std_collections_IContainer_1Tt_mojo_app_View_2**){
  return "std.collections.IContainer<mojo.app.View>";
}
bbString bbDBValue(t_std_collections_IContainer_1Tt_mojo_app_View_2**p){
  return bbDBInterfaceValue(*p);
}

bbString bbDBType(t_std_collections_IContainer_1Tt_mojo_app_Window_2**){
  return "std.collections.IContainer<mojo.app.Window>";
}
bbString bbDBValue(t_std_collections_IContainer_1Tt_mojo_app_Window_2**p){
  return bbDBInterfaceValue(*p);
}

bbString bbDBType(t_std_collections_IContainer_1Tt_mojo_graphics_Uniform_2**){
  return "std.collections.IContainer<mojo.graphics.Uniform>";
}
bbString bbDBValue(t_std_collections_IContainer_1Tt_mojo_graphics_Uniform_2**p){
  return bbDBInterfaceValue(*p);
}

void mx2_mojo_std_collections_2container_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_collections_2container_init_v("mojo_std_collections_2container",&mx2_mojo_std_collections_2container_init);
