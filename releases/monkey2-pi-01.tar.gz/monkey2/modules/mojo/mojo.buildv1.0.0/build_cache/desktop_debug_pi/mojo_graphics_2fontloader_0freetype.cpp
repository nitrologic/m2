
#include "../../desktop_debug_pi/mojo_graphics_2fontloader_0freetype.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_graphics_2font.h"
#include "../../desktop_debug_pi/mojo_graphics_2image.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2rect.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec2.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_graphics_2color.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_graphics_2pixmap.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_memory_2databuffer.h"

extern bbInt g_monkey_math_Max_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

FT_LibraryRec_* g_mojo_graphics_fontloader_FreeType;

t_mojo_graphics_Font* g_mojo_graphics_fontloader_LoadFont(bbString l_path,bbFloat l_fheight,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader){
  struct f0_t : public bbGCFrame{
    t_std_memory_DataBuffer* l_data{};
    t_mojo_graphics_Font* l_font{};
    bbArray<t_mojo_graphics_Glyph>* l_glyphs{};
    t_mojo_graphics_Image* l_image{};
    t_std_graphics_Pixmap* l_pixmap{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_font);
      bbGCMarkPtr(l_glyphs);
      bbGCMarkPtr(l_image);
      bbGCMarkPtr(l_pixmap);
    }
  }f0{};
  bbDBFrame db_f{"LoadFont:mojo.graphics.Font(path:String,fheight:Float,textureFlags:mojo.graphics.TextureFlags,shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/fontloader_freetype.monkey2"};
  bbDBLocal("path",&l_path);
  bbDBLocal("fheight",&l_fheight);
  bbDBLocal("textureFlags",&l_textureFlags);
  bbDBLocal("shader",&l_shader);
  bbDBStmt(73729);
  if((!bbBool(g_mojo_graphics_fontloader_FreeType)&&bbBool(FT_Init_FreeType(&g_mojo_graphics_fontloader_FreeType)))){
    bbDBBlock db_blk;
    bbDBStmt(73785);
    return ((t_mojo_graphics_Font*)0);
  }
  bbDBStmt(81927);
  f0.l_data=g_std_memory_DataBuffer_Load(l_path);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(86017);
  if(!bbBool(f0.l_data)){
    bbDBBlock db_blk;
    bbDBStmt(86029);
    return ((t_mojo_graphics_Font*)0);
  }
  bbDBStmt(94215);
  FT_FaceRec_* l_face{};
  bbDBLocal("face",&l_face);
  bbDBStmt(102401);
  if(bbBool(FT_New_Memory_Face(g_mojo_graphics_fontloader_FreeType,f0.l_data->m_Data(),f0.l_data->m_Length(),bbInt(0),&l_face))){
    bbDBBlock db_blk;
    bbDBStmt(106498);
    f0.l_data->m_Discard();
    bbDBStmt(110594);
    return ((t_mojo_graphics_Font*)0);
  }
  bbDBStmt(122887);
  FT_Size_RequestRec_ l_size_0req{};
  bbDBLocal("size_req",&l_size_0req);
  bbDBStmt(131073);
  l_size_0req.type=FT_SIZE_REQUEST_TYPE_REAL_DIM;
  bbDBStmt(135169);
  l_size_0req.width=bbInt(0);
  bbDBStmt(139265);
  l_size_0req.height=bbInt((l_fheight*64.0f));
  bbDBStmt(143361);
  l_size_0req.horiResolution=bbUInt(0);
  bbDBStmt(147457);
  l_size_0req.vertResolution=bbUInt(0);
  bbDBStmt(155649);
  if(bbBool(FT_Request_Size(l_face,&l_size_0req))){
    bbDBBlock db_blk;
    bbDBStmt(159746);
    f0.l_data->m_Discard();
    bbDBStmt(163842);
    return ((t_mojo_graphics_Font*)0);
  }
  bbDBStmt(176135);
  bbInt l_height=((l_face[bbInt(0)].size[bbInt(0)].metrics.height+32)>>6);
  bbDBLocal("height",&l_height);
  bbDBStmt(180231);
  bbInt l_ascent=((l_face[bbInt(0)].size[bbInt(0)].metrics.ascender+32)>>6);
  bbDBLocal("ascent",&l_ascent);
  bbDBStmt(204807);
  bbInt l_firstChar=32;
  bbDBLocal("firstChar",&l_firstChar);
  bbDBStmt(204821);
  bbInt l_numChars=96;
  bbDBLocal("numChars",&l_numChars);
  bbDBStmt(212999);
  f0.l_glyphs=bbArray<t_mojo_graphics_Glyph>::create(l_numChars);
  bbDBLocal("glyphs",&f0.l_glyphs);
  bbDBStmt(217095);
  f0.l_pixmap=bbGCNew<t_std_graphics_Pixmap>(512,512,2);
  bbDBLocal("pixmap",&f0.l_pixmap);
  bbDBStmt(221185);
  f0.l_pixmap->m_Clear(g_std_graphics_Color_None);
  bbDBStmt(229383);
  FT_GlyphSlotRec_* l_slot=l_face[bbInt(0)].glyph;
  bbDBLocal("slot",&l_slot);
  bbDBStmt(237575);
  bbInt l_x=bbInt(0);
  bbDBLocal("x",&l_x);
  bbDBStmt(237580);
  bbInt l_y=bbInt(0);
  bbDBLocal("y",&l_y);
  bbDBStmt(237585);
  bbInt l_h=bbInt(0);
  bbDBLocal("h",&l_h);
  bbDBStmt(245761);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(245761);
    for(;(l_i<l_numChars);l_i+=1){
      struct f2_t : public bbGCFrame{
        t_std_graphics_Pixmap* l_tmp{};
        void gcMark(){
          bbGCMarkPtr(l_tmp);
        }
      }f2{};
      bbDBBlock db_blk;
      bbDBStmt(274434);
      if(bbBool(FT_Load_Char(l_face,bbULong((l_firstChar+l_i)),(FT_LOAD_RENDER|FT_LOAD_FORCE_AUTOHINT)))){
        bbDBBlock db_blk;
        bbDBStmt(278531);
        continue;
      }
      bbDBStmt(315400);
      bbUInt l_gw=l_slot[bbInt(0)].bitmap.width;
      bbDBLocal("gw",&l_gw);
      bbDBStmt(319496);
      bbUInt l_gh=l_slot[bbInt(0)].bitmap.rows;
      bbDBLocal("gh",&l_gh);
      bbDBStmt(327682);
      if((((bbUInt(l_x)+l_gw)+1)>bbUInt(f0.l_pixmap->m_Width()))){
        bbDBBlock db_blk;
        bbDBStmt(331779);
        l_y+=l_h;
        bbDBStmt(335875);
        l_h=bbInt(0);
        bbDBStmt(339971);
        l_x=bbInt(0);
      }
      bbDBStmt(352264);
      f2.l_tmp=bbGCNew<t_std_graphics_Pixmap>(bbInt(l_gw),bbInt(l_gh),2,l_slot[bbInt(0)].bitmap.buffer,l_slot[bbInt(0)].bitmap.pitch);
      bbDBLocal("tmp",&f2.l_tmp);
      bbDBStmt(360450);
      f0.l_pixmap->m_Paste(f2.l_tmp,l_x,l_y);
      bbDBStmt(368642);
      f0.l_glyphs->at(l_i)=t_mojo_graphics_Glyph(t_std_geom_Rect_1i(l_x,l_y,bbInt((bbUInt(l_x)+l_gw)),bbInt((bbUInt(l_y)+l_gh))),t_std_geom_Vec2_1f(bbFloat(l_slot[bbInt(0)].bitmap_left),bbFloat((l_ascent-l_slot[bbInt(0)].bitmap_top))),bbFloat((l_slot[bbInt(0)].advance.x>>6)));
      bbDBStmt(376834);
      l_h=g_monkey_math_Max_1i(l_h,(bbInt(l_gh)+1));
      bbDBStmt(380930);
      l_x+=bbInt((l_gw+1));
    }
  }
  bbDBStmt(393217);
  FT_Done_Face(l_face);
  bbDBStmt(401409);
  f0.l_data->m_Discard();
  bbDBStmt(409607);
  f0.l_image=bbGCNew<t_mojo_graphics_Image>(f0.l_pixmap,l_textureFlags,l_shader);
  bbDBLocal("image",&f0.l_image);
  bbDBStmt(417799);
  f0.l_font=bbGCNew<t_mojo_graphics_Font>(f0.l_image,bbFloat(l_height),l_firstChar,f0.l_glyphs);
  bbDBLocal("font",&f0.l_font);
  bbDBStmt(425985);
  return f0.l_font;
}

void mx2_mojo_graphics_2fontloader_0freetype_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2fontloader_0freetype_init_v("mojo_graphics_2fontloader_0freetype",&mx2_mojo_graphics_2fontloader_0freetype_init);
