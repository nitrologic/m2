
#include "../../desktop_debug_pi/mojo_input_2device.h"

// ***** External *****

// ***** Internal *****

void t_mojo_input_InputDevice::dbEmit(){
}
bbString bbDBType(t_mojo_input_InputDevice**){
  return "mojo.input.InputDevice";
}
bbString bbDBValue(t_mojo_input_InputDevice**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_input_2device_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_input_2device_init_v("mojo_input_2device",&mx2_mojo_input_2device_init);
