
#include "../../desktop_debug_pi/mojo_input_2joystick.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"

extern bbInt g_monkey_math_Min_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

bbGCRootVar<bbArray<bbGCVar<t_mojo_input_JoystickDevice>>> g_mojo_input_JoystickDevice__0joysticks;

void g_mojo_input_JoystickDevice_UpdateJoysticks(){
  bbDBFrame db_f{"UpdateJoysticks:Void()","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  bbDBStmt(487426);
  SDL_JoystickUpdate();
}

t_mojo_input_JoystickDevice* g_mojo_input_JoystickDevice_Open(bbInt l_index){
  struct f0_t : public bbGCFrame{
    t_mojo_input_JoystickDevice* l_joystick{};
    void gcMark(){
      bbGCMarkPtr(l_joystick);
    }
  }f0{};
  bbDBFrame db_f{"Open:mojo.input.JoystickDevice(index:Int)","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  bbDBLocal("index",&l_index);
  bbDBStmt(524290);
  bbAssert(((l_index>=bbInt(0))&&(l_index<8)),BB_T("Assert failed"));
  bbDBStmt(528392);
  f0.l_joystick=g_mojo_input_JoystickDevice__0joysticks->at(l_index);
  bbDBLocal("joystick",&f0.l_joystick);
  bbDBStmt(532482);
  if(!bbBool(f0.l_joystick)){
    bbDBBlock db_blk;
    bbDBStmt(536585);
    SDL_Joystick* l_sdlJoystick=SDL_JoystickOpen(l_index);
    bbDBLocal("sdlJoystick",&l_sdlJoystick);
    bbDBStmt(540675);
    if(!bbBool(l_sdlJoystick)){
      bbDBBlock db_blk;
      bbDBStmt(540694);
      return ((t_mojo_input_JoystickDevice*)0);
    }
    bbDBStmt(544771);
    f0.l_joystick=bbGCNew<t_mojo_input_JoystickDevice>(l_sdlJoystick);
    bbDBStmt(548867);
    g_mojo_input_JoystickDevice__0joysticks->at(l_index)=f0.l_joystick;
  }
  bbDBStmt(557058);
  return f0.l_joystick;
}

bbInt g_mojo_input_JoystickDevice_NumJoysticks(){
  bbDBFrame db_f{"NumJoysticks:Int()","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  bbDBStmt(462850);
  return g_monkey_math_Min_1i(SDL_NumJoysticks(),8);
}

void t_mojo_input_JoystickDevice::init(){
  m__0hits=bbArray<bbBool>::create(32);
}

void t_mojo_input_JoystickDevice::gcMark(){
  t_mojo_input_InputDevice::gcMark();
  bbGCMark(m__0hits);
}

void t_mojo_input_JoystickDevice::dbEmit(){
  t_mojo_input_InputDevice::dbEmit();
  bbDBEmit("_joystick",&m__0joystick);
  bbDBEmit("_name",&m__0name);
  bbDBEmit("_guid",&m__0guid);
  bbDBEmit("_numAxes",&m__0numAxes);
  bbDBEmit("_numBalls",&m__0numBalls);
  bbDBEmit("_numButtons",&m__0numButtons);
  bbDBEmit("_numHats",&m__0numHats);
  bbDBEmit("_hits",&m__0hits);
}

t_mojo_input_JoystickDevice::t_mojo_input_JoystickDevice(SDL_Joystick* l_joystick){
  init();
  struct f0_t : public bbGCFrame{
    bbArray<bbByte>* l_buf{};
    void gcMark(){
      bbGCMarkPtr(l_buf);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(joystick:sdl2.SDL_Joystick Ptr)","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  bbDBLocal("joystick",&l_joystick);
  bbDBStmt(626690);
  this->m__0joystick=l_joystick;
  bbDBStmt(630786);
  this->m__0name=bbString::fromCString(((void*)(SDL_JoystickName(this->m__0joystick))));
  bbDBStmt(634882);
  this->m__0numAxes=SDL_JoystickNumAxes(this->m__0joystick);
  bbDBStmt(638978);
  this->m__0numBalls=SDL_JoystickNumBalls(this->m__0joystick);
  bbDBStmt(643074);
  this->m__0numButtons=SDL_JoystickNumButtons(this->m__0joystick);
  bbDBStmt(647170);
  this->m__0numHats=SDL_JoystickNumHats(this->m__0joystick);
  bbDBStmt(655368);
  f0.l_buf=bbArray<bbByte>::create(64);
  bbDBLocal("buf",&f0.l_buf);
  bbDBStmt(659464);
  SDL_JoystickGUID l_guid=SDL_JoystickGetGUID(this->m__0joystick);
  bbDBLocal("guid",&l_guid);
  bbDBStmt(663554);
  SDL_JoystickGetGUIDString(l_guid,((char*)(f0.l_buf->data())),f0.l_buf->length());
  bbDBStmt(667650);
  f0.l_buf->at((f0.l_buf->length()-1))=bbByte(0);
  bbDBStmt(671746);
  this->m__0guid=bbString::fromCString(((void*)(f0.l_buf->data())));
}

bbInt t_mojo_input_JoystickDevice::m_NumHats(){
  bbDBFrame db_f{"NumHats:Int()","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(282626);
  return this->m__0numHats;
}

bbInt t_mojo_input_JoystickDevice::m_NumButtons(){
  bbDBFrame db_f{"NumButtons:Int()","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(258050);
  return this->m__0numButtons;
}

bbInt t_mojo_input_JoystickDevice::m_NumBalls(){
  bbDBFrame db_f{"NumBalls:Int()","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(233474);
  return this->m__0numBalls;
}

bbInt t_mojo_input_JoystickDevice::m_NumAxes(){
  bbDBFrame db_f{"NumAxes:Int()","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(204802);
  return this->m__0numAxes;
}

bbString t_mojo_input_JoystickDevice::m_Name(){
  bbDBFrame db_f{"Name:String()","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(155650);
  return this->m__0name;
}

bbInt t_mojo_input_JoystickDevice::m_GetHat(bbInt l_hat){
  bbDBFrame db_f{"GetHat:mojo.input.JoystickHat(hat:Int)","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("hat",&l_hat);
  bbDBStmt(364546);
  return ((bbInt)(SDL_JoystickGetHat(this->m__0joystick,l_hat)));
}

t_std_geom_Vec2_1i t_mojo_input_JoystickDevice::m_GetBall(bbInt l_ball){
  bbDBFrame db_f{"GetBall:Vec2i:std.geom.Vec2<Int>(ball:Int)","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ball",&l_ball);
  bbDBStmt(331784);
  bbInt l_x{};
  bbDBLocal("x",&l_x);
  bbDBStmt(331790);
  bbInt l_y{};
  bbDBLocal("y",&l_y);
  bbDBStmt(335874);
  SDL_JoystickGetBall(this->m__0joystick,l_ball,&l_x,&l_y);
  bbDBStmt(339970);
  return t_std_geom_Vec2_1i(l_x,l_y);
}

bbFloat t_mojo_input_JoystickDevice::m_GetAxis(bbInt l_axis){
  bbDBFrame db_f{"GetAxis:Float(axis:Int)","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("axis",&l_axis);
  bbDBStmt(307202);
  return (((bbFloat(SDL_JoystickGetAxis(this->m__0joystick,l_axis))+32768.0f)/32767.5f)-1.0f);
}

bbString t_mojo_input_JoystickDevice::m_GUID(){
  bbDBFrame db_f{"GUID:String()","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(180226);
  return this->m__0guid;
}

bbBool t_mojo_input_JoystickDevice::m_ButtonPressed(bbInt l_button){
  bbDBFrame db_f{"ButtonPressed:Bool(button:Int)","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("button",&l_button);
  bbDBStmt(413698);
  if(this->m_ButtonDown(l_button)){
    bbDBBlock db_blk;
    bbDBStmt(417795);
    if(this->m__0hits->at(l_button)){
      bbDBBlock db_blk;
      bbDBStmt(417812);
      return false;
    }
    bbDBStmt(421891);
    this->m__0hits->at(l_button)=true;
    bbDBStmt(425987);
    return true;
  }
  bbDBStmt(434178);
  this->m__0hits->at(l_button)=false;
  bbDBStmt(438274);
  return false;
}

bbBool t_mojo_input_JoystickDevice::m_ButtonDown(bbInt l_button){
  bbDBFrame db_f{"ButtonDown:Bool(button:Int)","/home/pi/monkey2/modules/mojo/input/joystick.monkey2"};
  t_mojo_input_JoystickDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("button",&l_button);
  bbDBStmt(389122);
  return bbBool(SDL_JoystickGetButton(this->m__0joystick,l_button));
}
bbString bbDBType(t_mojo_input_JoystickDevice**){
  return "mojo.input.JoystickDevice";
}
bbString bbDBValue(t_mojo_input_JoystickDevice**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_input_2joystick_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_input_JoystickDevice__0joysticks=bbArray<bbGCVar<t_mojo_input_JoystickDevice>>::create(8);
}

bbInit mx2_mojo_input_2joystick_init_v("mojo_input_2joystick",&mx2_mojo_input_2joystick_init);
