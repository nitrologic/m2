
#include "../../desktop_debug_pi/mojo_timer_2timer.h"

// ***** External *****

// ***** Internal *****

void mx2_mojo_timer_2timer_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_timer_2timer_init_v("mojo_timer_2timer",&mx2_mojo_timer_2timer_init);
