
#include "../../desktop_debug_pi/mojo_app_2skin.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_graphics_2canvas.h"
#include "../../desktop_debug_pi/mojo_graphics_2image.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2vec2.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_graphics_2pixmap.h"

// ***** Internal *****

t_mojo_app_Skin* g_mojo_app_Skin_Load(bbString l_path){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  }f0{};
  bbDBFrame db_f{"Load:mojo.app.Skin(path:String)","/home/pi/monkey2/modules/mojo/app/skin.monkey2"};
  bbDBLocal("path",&l_path);
  bbDBStmt(180232);
  f0.l_pixmap=g_std_graphics_Pixmap_Load(l_path,0);
  bbDBLocal("pixmap",&f0.l_pixmap);
  bbDBStmt(184322);
  if(!bbBool(f0.l_pixmap)){
    bbDBBlock db_blk;
    bbDBStmt(184336);
    return ((t_mojo_app_Skin*)0);
  }
  bbDBStmt(192514);
  f0.l_pixmap->m_PremultiplyAlpha();
  bbDBStmt(200706);
  return bbGCNew<t_mojo_app_Skin>(f0.l_pixmap);
}

void t_mojo_app_Skin::gcMark(){
  bbGCMark(m__0image);
}

void t_mojo_app_Skin::dbEmit(){
  bbDBEmit("_image",&m__0image);
  bbDBEmit("_bounds",&m__0bounds);
  bbDBEmit("_rect",&m__0rect);
  bbDBEmit("_x0",&m__0x0);
  bbDBEmit("_x1",&m__0x1);
  bbDBEmit("_x2",&m__0x2);
  bbDBEmit("_x3",&m__0x3);
  bbDBEmit("_y0",&m__0y0);
  bbDBEmit("_y1",&m__0y1);
  bbDBEmit("_y2",&m__0y2);
  bbDBEmit("_y3",&m__0y3);
}

t_mojo_app_Skin::t_mojo_app_Skin(t_std_graphics_Pixmap* l_pixmap){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    f0_t(t_std_graphics_Pixmap* l_pixmap):l_pixmap(l_pixmap){
    }
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  }f0{l_pixmap};
  bbDBFrame db_f{"new:Void(pixmap:std.graphics.Pixmap)","/home/pi/monkey2/modules/mojo/app/skin.monkey2"};
  bbDBLocal("pixmap",&f0.l_pixmap);
  bbDBStmt(258056);
  t_std_geom_Rect_1i l__0scale{};
  bbDBLocal("_scale",&l__0scale);
  bbDBStmt(262152);
  t_std_geom_Rect_1i l__0fill{};
  bbDBLocal("_fill",&l__0fill);
  bbDBStmt(270338);
  {
    bbDBLoop db_loop;
    bbInt l_x=1;
    bbDBLocal("x",&l_x);
    bbDBStmt(270338);
    for(;(l_x<(f0.l_pixmap->m_Width()-1));l_x+=1){
      bbDBBlock db_blk;
      bbDBStmt(274441);
      bbUInt l_p=f0.l_pixmap->m_GetPixelARGB(l_x,bbInt(0));
      bbDBLocal("p",&l_p);
      bbDBStmt(278531);
      if((l_p==4278190080)){
        bbDBBlock db_blk;
        bbDBStmt(282628);
        if(!bbBool(l__0scale.m_min.m_x)){
          bbDBBlock db_blk;
          bbDBStmt(282648);
          l__0scale.m_min.m_x=l_x;
        }
        bbDBStmt(286724);
        l__0scale.m_max.m_x=(l_x+1);
      }
      bbDBStmt(294915);
      l_p=f0.l_pixmap->m_GetPixelARGB(l_x,(f0.l_pixmap->m_Height()-1));
      bbDBStmt(299011);
      if((l_p==4278190080)){
        bbDBBlock db_blk;
        bbDBStmt(303108);
        if(!bbBool(l__0fill.m_min.m_x)){
          bbDBBlock db_blk;
          bbDBStmt(303127);
          l__0fill.m_min.m_x=l_x;
        }
        bbDBStmt(307204);
        l__0fill.m_max.m_x=(l_x+1);
      }
    }
  }
  bbDBStmt(323586);
  {
    bbDBLoop db_loop;
    bbInt l_y=1;
    bbDBLocal("y",&l_y);
    bbDBStmt(323586);
    for(;(l_y<(f0.l_pixmap->m_Height()-1));l_y+=1){
      bbDBBlock db_blk;
      bbDBStmt(327689);
      bbUInt l_p=f0.l_pixmap->m_GetPixelARGB(bbInt(0),l_y);
      bbDBLocal("p",&l_p);
      bbDBStmt(331779);
      if((l_p==4278190080)){
        bbDBBlock db_blk;
        bbDBStmt(335876);
        if(!bbBool(l__0scale.m_min.m_y)){
          bbDBBlock db_blk;
          bbDBStmt(335896);
          l__0scale.m_min.m_y=l_y;
        }
        bbDBStmt(339972);
        l__0scale.m_max.m_y=(l_y+1);
      }
      bbDBStmt(348163);
      l_p=f0.l_pixmap->m_GetPixelARGB((f0.l_pixmap->m_Width()-1),l_y);
      bbDBStmt(352259);
      if((l_p==4278190080)){
        bbDBBlock db_blk;
        bbDBStmt(356356);
        if(!bbBool(l__0fill.m_min.m_y)){
          bbDBBlock db_blk;
          bbDBStmt(356375);
          l__0fill.m_min.m_y=l_y;
        }
        bbDBStmt(360452);
        l__0fill.m_max.m_y=(l_y+1);
      }
    }
  }
  bbDBStmt(376834);
  if((bbBool(l__0scale.m_min.m_x)&&bbBool(l__0scale.m_min.m_y))){
    bbDBBlock db_blk;
    bbDBStmt(380931);
    f0.l_pixmap=f0.l_pixmap->m_Window(1,1,(f0.l_pixmap->m_Width()-2),(f0.l_pixmap->m_Height()-2));
    bbDBStmt(385027);
    if((!bbBool(l__0fill.m_min.m_x)||!bbBool(l__0fill.m_min.m_y))){
      bbDBBlock db_blk;
      bbDBStmt(385065);
      l__0fill=l__0scale;
    }
    bbDBStmt(389123);
    l__0scale.m__subeq(t_std_geom_Vec2_1i(1,1));
    bbDBStmt(393219);
    l__0fill.m__subeq(t_std_geom_Vec2_1i(1,1));
  }else{
    bbDBStmt(397314);
    bbDBBlock db_blk;
    bbDBStmt(401411);
    l__0scale=t_std_geom_Rect_1i((f0.l_pixmap->m_Width()/3),(f0.l_pixmap->m_Height()/3),((f0.l_pixmap->m_Width()*2)/3),((f0.l_pixmap->m_Height()*2)/3));
    bbDBStmt(405507);
    l__0fill=l__0scale;
  }
  bbDBStmt(417794);
  this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),f0.l_pixmap->m_Width(),f0.l_pixmap->m_Height());
  bbDBStmt(425986);
  this->m__0x0=bbInt(0);
  bbDBStmt(430082);
  this->m__0x1=l__0scale.m_min.m_x;
  bbDBStmt(434178);
  this->m__0x2=l__0scale.m_max.m_x;
  bbDBStmt(438274);
  this->m__0x3=this->m__0rect.m_max.m_x;
  bbDBStmt(446466);
  this->m__0y0=bbInt(0);
  bbDBStmt(450562);
  this->m__0y1=l__0scale.m_min.m_y;
  bbDBStmt(454658);
  this->m__0y2=l__0scale.m_max.m_y;
  bbDBStmt(458754);
  this->m__0y3=this->m__0rect.m_max.m_y;
  bbDBStmt(466946);
  this->m__0image=bbGCNew<t_mojo_graphics_Image>(f0.l_pixmap,3,((t_mojo_graphics_Shader*)0));
  bbDBStmt(471042);
  this->m__0bounds=t_std_geom_Rect_1i(l__0fill.m_min.m__sub(),this->m__0rect.m_max.m__sub(l__0fill.m_max));
}

t_mojo_graphics_Image* t_mojo_app_Skin::m_Image(){
  bbDBFrame db_f{"Image:mojo.graphics.Image()","/home/pi/monkey2/modules/mojo/app/skin.monkey2"};
  t_mojo_app_Skin*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(36866);
  return this->m__0image;
}

void t_mojo_app_Skin::m_Draw(t_mojo_graphics_Canvas* l_canvas,t_std_geom_Rect_1i l_rect){
  bbDBFrame db_f{"Draw:Void(canvas:mojo.graphics.Canvas,rect:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/app/skin.monkey2"};
  t_mojo_app_Skin*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
  bbDBLocal("rect",&l_rect);
  bbDBStmt(73736);
  bbInt l_x0=l_rect.m_Left();
  bbDBLocal("x0",&l_x0);
  bbDBStmt(77832);
  bbInt l_x1=(l_rect.m_Left()+this->m__0x1);
  bbDBLocal("x1",&l_x1);
  bbDBStmt(81928);
  bbInt l_x2=(l_rect.m_Right()-(this->m__0x3-this->m__0x2));
  bbDBLocal("x2",&l_x2);
  bbDBStmt(86024);
  bbInt l_x3=l_rect.m_Right();
  bbDBLocal("x3",&l_x3);
  bbDBStmt(94216);
  bbInt l_y0=l_rect.m_Top();
  bbDBLocal("y0",&l_y0);
  bbDBStmt(98312);
  bbInt l_y1=(l_rect.m_Top()+this->m__0y1);
  bbDBLocal("y1",&l_y1);
  bbDBStmt(102408);
  bbInt l_y2=(l_rect.m_Bottom()-(this->m__0y3-this->m__0y2));
  bbDBLocal("y2",&l_y2);
  bbDBStmt(106504);
  bbInt l_y3=l_rect.m_Bottom();
  bbDBLocal("y3",&l_y3);
  bbDBStmt(114690);
  l_canvas->m_DrawRect(bbFloat(l_x0),bbFloat(l_y0),bbFloat((l_x1-l_x0)),bbFloat((l_y1-l_y0)),this->m__0image,this->m__0x0,this->m__0y0,(this->m__0x1-this->m__0x0),(this->m__0y1-this->m__0y0));
  bbDBStmt(118786);
  l_canvas->m_DrawRect(bbFloat(l_x1),bbFloat(l_y0),bbFloat((l_x2-l_x1)),bbFloat((l_y1-l_y0)),this->m__0image,this->m__0x1,this->m__0y0,(this->m__0x2-this->m__0x1),(this->m__0y1-this->m__0y0));
  bbDBStmt(122882);
  l_canvas->m_DrawRect(bbFloat(l_x2),bbFloat(l_y0),bbFloat((l_x3-l_x2)),bbFloat((l_y1-l_y0)),this->m__0image,this->m__0x2,this->m__0y0,(this->m__0x3-this->m__0x2),(this->m__0y1-this->m__0y0));
  bbDBStmt(131074);
  l_canvas->m_DrawRect(bbFloat(l_x0),bbFloat(l_y1),bbFloat((l_x1-l_x0)),bbFloat((l_y2-l_y1)),this->m__0image,this->m__0x0,this->m__0y1,(this->m__0x1-this->m__0x0),(this->m__0y2-this->m__0y1));
  bbDBStmt(135170);
  l_canvas->m_DrawRect(bbFloat(l_x1),bbFloat(l_y1),bbFloat((l_x2-l_x1)),bbFloat((l_y2-l_y1)),this->m__0image,this->m__0x1,this->m__0y1,(this->m__0x2-this->m__0x1),(this->m__0y2-this->m__0y1));
  bbDBStmt(139266);
  l_canvas->m_DrawRect(bbFloat(l_x2),bbFloat(l_y1),bbFloat((l_x3-l_x2)),bbFloat((l_y2-l_y1)),this->m__0image,this->m__0x2,this->m__0y1,(this->m__0x3-this->m__0x2),(this->m__0y2-this->m__0y1));
  bbDBStmt(147458);
  l_canvas->m_DrawRect(bbFloat(l_x0),bbFloat(l_y2),bbFloat((l_x1-l_x0)),bbFloat((l_y3-l_y2)),this->m__0image,this->m__0x0,this->m__0y2,(this->m__0x1-this->m__0x0),(this->m__0y3-this->m__0y2));
  bbDBStmt(151554);
  l_canvas->m_DrawRect(bbFloat(l_x1),bbFloat(l_y2),bbFloat((l_x2-l_x1)),bbFloat((l_y3-l_y2)),this->m__0image,this->m__0x1,this->m__0y2,(this->m__0x2-this->m__0x1),(this->m__0y3-this->m__0y2));
  bbDBStmt(155650);
  l_canvas->m_DrawRect(bbFloat(l_x2),bbFloat(l_y2),bbFloat((l_x3-l_x2)),bbFloat((l_y3-l_y2)),this->m__0image,this->m__0x2,this->m__0y2,(this->m__0x3-this->m__0x2),(this->m__0y3-this->m__0y2));
}

t_std_geom_Rect_1i t_mojo_app_Skin::m_Bounds(){
  bbDBFrame db_f{"Bounds:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/skin.monkey2"};
  t_mojo_app_Skin*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(53250);
  return this->m__0bounds;
}
bbString bbDBType(t_mojo_app_Skin**){
  return "mojo.app.Skin";
}
bbString bbDBValue(t_mojo_app_Skin**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_app_2skin_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_app_2skin_init_v("mojo_app_2skin",&mx2_mojo_app_2skin_init);
