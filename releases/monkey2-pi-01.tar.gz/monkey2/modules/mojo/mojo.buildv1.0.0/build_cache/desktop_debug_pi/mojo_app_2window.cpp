
#include "../../desktop_debug_pi/mojo_app_2window.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2app.h"
#include "../../desktop_debug_pi/mojo_app_2event.h"
#include "../../desktop_debug_pi/mojo_graphics_2canvas.h"
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_geom_2affinemat3.h"

// ***** Internal *****

bbGCRootVar<t_std_collections_Stack_1Tt_mojo_app_Window_2> g_mojo_app_Window__0allWindows;
bbGCRootVar<t_std_collections_Stack_1Tt_mojo_app_Window_2> g_mojo_app_Window__0visibleWindows;
bbGCRootVar<t_std_collections_Map_1jTt_mojo_app_Window_2> g_mojo_app_Window__0windowsByID;

t_mojo_app_Window* g_mojo_app_Window_WindowForID(bbUInt l_id){
  bbDBFrame db_f{"WindowForID:mojo.app.Window(id:Uint)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBLocal("id",&l_id);
  bbDBStmt(827394);
  return g_mojo_app_Window__0windowsByID->m__idx(l_id);
}

bbArray<bbGCVar<t_mojo_app_Window>>* g_mojo_app_Window_VisibleWindows(){
  bbDBFrame db_f{"VisibleWindows:mojo.app.Window[]()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBStmt(798722);
  return g_mojo_app_Window__0visibleWindows->m_ToArray();
}

bbArray<bbGCVar<t_mojo_app_Window>>* g_mojo_app_Window_AllWindows(){
  bbDBFrame db_f{"AllWindows:mojo.app.Window[]()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBStmt(770050);
  return g_mojo_app_Window__0allWindows->m_ToArray();
}

void t_mojo_app_Window::gcMark(){
  t_mojo_app_View::gcMark();
  bbGCMark(m__0canvas);
  bbGCMark(m__0keyView);
}

void t_mojo_app_Window::dbEmit(){
  t_mojo_app_View::dbEmit();
  bbDBEmit("_flags",&m__0flags);
  bbDBEmit("_fullscreen",&m__0fullscreen);
  bbDBEmit("_sdlWindow",&m__0sdlWindow);
  bbDBEmit("_sdlGLContext",&m__0sdlGLContext);
  bbDBEmit("_swapInterval",&m__0swapInterval);
  bbDBEmit("_canvas",&m__0canvas);
  bbDBEmit("_clearColor",&m__0clearColor);
  bbDBEmit("_keyView",&m__0keyView);
  bbDBEmit("_minSize",&m__0minSize);
  bbDBEmit("_maxSize",&m__0maxSize);
  bbDBEmit("_frame",&m__0frame);
  bbDBEmit("_weirdHack",&m__0weirdHack);
}

t_mojo_app_Window::t_mojo_app_Window(bbString l_title,t_std_geom_Rect_1i l_rect,bbInt l_flags){
  bbDBFrame db_f{"new:Void(title:String,rect:Recti:std.geom.Rect<Int>,flags:mojo.app.WindowFlags)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBLocal("title",&l_title);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(159746);
  this->m_Init(l_title,l_rect,l_flags);
}

t_mojo_app_Window::t_mojo_app_Window(bbString l_title,bbInt l_width,bbInt l_height,bbInt l_flags){
  bbDBFrame db_f{"new:Void(title:String,width:Int,height:Int,flags:mojo.app.WindowFlags)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBLocal("title",&l_title);
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(143362);
  this->m_Init(l_title,t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_width,l_height),(l_flags|3));
}

t_mojo_app_Window::t_mojo_app_Window(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBStmt(126978);
  this->m_Init(BB_T("Window"),t_std_geom_Rect_1i(bbInt(0),bbInt(0),640,480),3);
}

void t_mojo_app_Window::m_Update(){
  bbDBFrame db_f{"Update:Void()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(466946);
  if((bbCompare(this->m_MinSize(),this->m__0minSize)!=0)){
    bbDBBlock db_blk;
    bbDBStmt(471043);
    SDL_SetWindowMinimumSize(this->m__0sdlWindow,this->m_MinSize().m_x,this->m_MinSize().m_y);
    bbDBStmt(475139);
    this->m__0minSize=this->m_GetMinSize();
    bbDBStmt(479235);
    this->m_MinSize(this->m__0minSize);
  }
  bbDBStmt(491522);
  if((bbCompare(this->m_MaxSize(),this->m__0maxSize)!=0)){
    bbDBBlock db_blk;
    bbDBStmt(495619);
    SDL_SetWindowMaximumSize(this->m__0sdlWindow,this->m_MaxSize().m_x,this->m_MaxSize().m_y);
    bbDBStmt(499715);
    this->m__0maxSize=this->m_GetMaxSize();
    bbDBStmt(503811);
    this->m_MaxSize(this->m__0maxSize);
  }
  bbDBStmt(516098);
  if((bbCompare(this->m_Frame(),this->m__0frame)!=0)){
    bbDBBlock db_blk;
    bbDBStmt(520195);
    SDL_SetWindowPosition(this->m__0sdlWindow,this->m_Frame().m_X(),this->m_Frame().m_Y());
    bbDBStmt(524291);
    SDL_SetWindowSize(this->m__0sdlWindow,this->m_Frame().m_Width(),this->m_Frame().m_Height());
    bbDBStmt(528387);
    this->m__0frame=this->m_GetFrame();
    bbDBStmt(532483);
    this->m_Frame(this->m__0frame);
    bbDBStmt(536579);
    this->m__0weirdHack=true;
  }
  bbDBStmt(552962);
  this->m_Measure();
  bbDBStmt(561154);
  this->m_UpdateLayout();
}

void t_mojo_app_Window::m_Title(bbString l_title){
  bbDBFrame db_f{"Title:Void(title:String)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("title",&l_title);
  bbDBStmt(204802);
  SDL_SetWindowTitle(this->m__0sdlWindow,bbUtf8String(l_title));
}

bbString t_mojo_app_Window::m_Title(){
  bbDBFrame db_f{"Title:String()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(188418);
  return bbString::fromUtf8String(((void*)(SDL_GetWindowTitle(this->m__0sdlWindow))));
}

void t_mojo_app_Window::m_SwapInterval(bbInt l_swapInterval){
  bbDBFrame db_f{"SwapInterval:Void(swapInterval:Int)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("swapInterval",&l_swapInterval);
  bbDBStmt(294914);
  this->m__0swapInterval=l_swapInterval;
}

bbInt t_mojo_app_Window::m_SwapInterval(){
  bbDBFrame db_f{"SwapInterval:Int()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(278530);
  return this->m__0swapInterval;
}

void t_mojo_app_Window::m_SendWindowEvent(t_mojo_app_WindowEvent* l_event){
  bbDBFrame db_f{"SendWindowEvent:Void(event:mojo.app.WindowEvent)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbInt l_0=l_event->m_Type();
  bbDBLocal("0",&l_0);
  bbDBStmt(864258);
  if(l_0==11||l_0==12){
    bbDBBlock db_blk;
    bbDBStmt(872451);
    this->m__0frame=this->m_GetFrame();
    bbDBStmt(876547);
    this->m_Frame(this->m__0frame);
    bbDBStmt(880643);
    this->m__0weirdHack=true;
  }
  bbDBStmt(892930);
  this->m_OnWindowEvent(l_event);
}

void t_mojo_app_Window::m_Render(){
  bbDBFrame db_f{"Render:Void()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(589826);
  SDL_GL_MakeCurrent(this->m__0sdlWindow,this->m__0sdlGLContext);
  bbDBStmt(598018);
  SDL_GL_SetSwapInterval(this->m__0swapInterval);
  bbDBStmt(634888);
  t_std_geom_Rect_1i l_bounds=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m_Frame().m_Size());
  bbDBLocal("bounds",&l_bounds);
  bbDBStmt(643074);
  this->m__0canvas->m_Resize(l_bounds.m_Size());
  bbDBStmt(651266);
  this->m__0canvas->m_BeginRender(l_bounds,t_std_geom_AffineMat3_1f(bbNullCtor));
  bbDBStmt(659458);
  this->m__0canvas->m_Clear(this->m__0clearColor);
  bbDBStmt(667650);
  this->m_Render(this->m__0canvas);
  bbDBStmt(675842);
  this->m__0canvas->m_EndRender();
  bbDBStmt(684034);
  SDL_GL_SwapWindow(this->m__0sdlWindow);
}

void t_mojo_app_Window::m_OnWindowEvent(t_mojo_app_WindowEvent* l_event){
  bbDBFrame db_f{"OnWindowEvent:Void(event:mojo.app.WindowEvent)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbInt l_0=l_event->m_Type();
  bbDBLocal("0",&l_0);
  bbDBStmt(987138);
  if(l_0==10){
    bbDBBlock db_blk;
    bbDBStmt(999427);
    g_mojo_app_App->m_Terminate();
  }else if(l_0==11){
    bbDBBlock db_blk;
  }else if(l_0==12){
    bbDBBlock db_blk;
    bbDBStmt(1024003);
    g_mojo_app_App->m_RequestRender();
  }else if(l_0==13){
    bbDBBlock db_blk;
  }else if(l_0==14){
    bbDBBlock db_blk;
  }
}

SDL_Window* t_mojo_app_Window::m_NativeWindow(){
  bbDBFrame db_f{"NativeWindow:sdl2.SDL_Window Ptr()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(741378);
  return this->m__0sdlWindow;
}

void t_mojo_app_Window::m_KeyView(t_mojo_app_View* l_keyView){
  bbDBFrame db_f{"KeyView:Void(keyView:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("keyView",&l_keyView);
  bbDBStmt(937986);
  this->m__0keyView=l_keyView;
}

t_mojo_app_View* t_mojo_app_Window::m_KeyView(){
  bbDBFrame db_f{"KeyView:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(921602);
  return this->m__0keyView;
}

void t_mojo_app_Window::m_Init(bbString l_title,t_std_geom_Rect_1i l_rect,bbInt l_flags){
  bbDBFrame db_f{"Init:Void(title:String,rect:Recti:std.geom.Rect<Int>,flags:mojo.app.WindowFlags)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("title",&l_title);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(1249282);
  this->m_Layout(BB_T("fill"));
  bbDBStmt(1257480);
  bbInt l_x=(bbBool((l_flags&1)) ? SDL_WINDOWPOS_CENTERED : l_rect.m_X());
  bbDBLocal("x",&l_x);
  bbDBStmt(1261576);
  bbInt l_y=(bbBool((l_flags&2)) ? SDL_WINDOWPOS_CENTERED : l_rect.m_Y());
  bbDBLocal("y",&l_y);
  bbDBStmt(1269768);
  SDL_WindowFlags l_sdlFlags=SDL_WINDOW_OPENGL;
  bbDBLocal("sdlFlags",&l_sdlFlags);
  bbDBStmt(1277954);
  if(bbBool((l_flags&4))){
    bbDBBlock db_blk;
    bbDBStmt(1277984);
    l_sdlFlags=SDL_WindowFlags(l_sdlFlags|SDL_WINDOW_HIDDEN);
  }
  bbDBStmt(1282050);
  if(bbBool((l_flags&8))){
    bbDBBlock db_blk;
    bbDBStmt(1282083);
    l_sdlFlags=SDL_WindowFlags(l_sdlFlags|SDL_WINDOW_RESIZABLE);
  }
  bbDBStmt(1286146);
  if(bbBool((l_flags&16))){
    bbDBBlock db_blk;
    bbDBStmt(1286180);
    l_sdlFlags=SDL_WindowFlags(l_sdlFlags|SDL_WINDOW_BORDERLESS);
  }
  bbDBStmt(1290242);
  if(bbBool((l_flags&32))){
    bbDBBlock db_blk;
    bbDBStmt(1290276);
    this->m__0fullscreen=true;
    bbDBStmt(1290295);
    l_sdlFlags=SDL_WindowFlags(l_sdlFlags|SDL_WINDOW_FULLSCREEN);
  }
  bbDBStmt(1298434);
  this->m__0flags=l_flags;
  bbDBStmt(1306626);
  this->m__0sdlWindow=SDL_CreateWindow(bbUtf8String(l_title),l_x,l_y,l_rect.m_Width(),l_rect.m_Height(),bbInt(l_sdlFlags));
  bbDBStmt(1310722);
  bbAssert(bbBool(this->m__0sdlWindow),BB_T("Failed to create SDL_Window"));
  bbDBStmt(1318914);
  g_mojo_app_Window__0allWindows->m_Push(this);
  bbDBStmt(1323010);
  g_mojo_app_Window__0windowsByID->m__idxeq(bbUInt(SDL_GetWindowID(this->m__0sdlWindow)),this);
  bbDBStmt(1327106);
  if(!bbBool((l_flags&4))){
    bbDBBlock db_blk;
    bbDBStmt(1327142);
    g_mojo_app_Window__0visibleWindows->m_Push(this);
  }
  bbDBStmt(1335298);
  this->m__0minSize=this->m_GetMinSize();
  bbDBStmt(1339394);
  this->m_MinSize(this->m__0minSize);
  bbDBStmt(1347586);
  this->m__0maxSize=this->m_GetMaxSize();
  bbDBStmt(1351682);
  this->m_MaxSize(this->m__0maxSize);
  bbDBStmt(1359874);
  this->m__0frame=this->m_GetFrame();
  bbDBStmt(1363970);
  this->m_Frame(this->m__0frame);
  bbDBStmt(1380354);
  this->m__0sdlGLContext=SDL_GL_CreateContext(this->m__0sdlWindow);
  bbDBStmt(1384450);
  SDL_GL_MakeCurrent(this->m__0sdlWindow,this->m__0sdlGLContext);
  bbDBStmt(1392642);
  this->m__0canvas=bbGCNew<t_mojo_graphics_Canvas>(this->m__0frame.m_Width(),this->m__0frame.m_Height());
  bbDBStmt(1400834);
  this->m_Update();
}

t_std_geom_Vec2_1i t_mojo_app_Window::m_GetMinSize(){
  bbDBFrame db_f{"GetMinSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1167368);
  bbInt l_w{};
  bbDBLocal("w",&l_w);
  bbDBStmt(1167374);
  bbInt l_h{};
  bbDBLocal("h",&l_h);
  bbDBStmt(1171458);
  SDL_GetWindowMinimumSize(this->m__0sdlWindow,&l_w,&l_h);
  bbDBStmt(1175554);
  return t_std_geom_Vec2_1i(l_w,l_h);
}

t_std_geom_Vec2_1i t_mojo_app_Window::m_GetMaxSize(){
  bbDBFrame db_f{"GetMaxSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191944);
  bbInt l_w{};
  bbDBLocal("w",&l_w);
  bbDBStmt(1191950);
  bbInt l_h{};
  bbDBLocal("h",&l_h);
  bbDBStmt(1196034);
  SDL_GetWindowMaximumSize(this->m__0sdlWindow,&l_w,&l_h);
  bbDBStmt(1200130);
  return t_std_geom_Vec2_1i(l_w,l_h);
}

t_std_geom_Rect_1i t_mojo_app_Window::m_GetFrame(){
  bbDBFrame db_f{"GetFrame:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1216520);
  bbInt l_x{};
  bbDBLocal("x",&l_x);
  bbDBStmt(1216526);
  bbInt l_y{};
  bbDBLocal("y",&l_y);
  bbDBStmt(1216532);
  bbInt l_w{};
  bbDBLocal("w",&l_w);
  bbDBStmt(1216538);
  bbInt l_h{};
  bbDBLocal("h",&l_h);
  bbDBStmt(1220610);
  SDL_GetWindowPosition(this->m__0sdlWindow,&l_x,&l_y);
  bbDBStmt(1224706);
  SDL_GetWindowSize(this->m__0sdlWindow,&l_w,&l_h);
  bbDBStmt(1228802);
  return t_std_geom_Rect_1i(l_x,l_y,(l_x+l_w),(l_y+l_h));
}

void t_mojo_app_Window::m_Fullscreen(bbBool l_fullscreen){
  bbDBFrame db_f{"Fullscreen:Void(fullscreen:Bool)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("fullscreen",&l_fullscreen);
  bbDBStmt(339970);
  if((l_fullscreen==this->m__0fullscreen)){
    bbDBBlock db_blk;
    bbDBStmt(339996);
    return;
  }
  bbDBStmt(348162);
  this->m__0fullscreen=l_fullscreen;
  bbDBStmt(356354);
  if(this->m__0fullscreen){
    bbDBBlock db_blk;
    bbDBStmt(360457);
    SDL_DisplayMode l_mode{};
    bbDBLocal("mode",&l_mode);
    bbDBStmt(364547);
    l_mode.w=this->m_Width();
    bbDBStmt(368643);
    l_mode.h=this->m_Height();
    bbDBStmt(372739);
    SDL_SetWindowDisplayMode(this->m__0sdlWindow,&l_mode);
    bbDBStmt(376835);
    SDL_SetWindowFullscreen(this->m__0sdlWindow,bbInt(SDL_WINDOW_FULLSCREEN));
  }else{
    bbDBStmt(380930);
    bbDBBlock db_blk;
    bbDBStmt(385027);
    SDL_SetWindowFullscreen(this->m__0sdlWindow,bbInt(0));
  }
}

bbBool t_mojo_app_Window::m_Fullscreen(){
  bbDBFrame db_f{"Fullscreen:Bool()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323586);
  return this->m__0fullscreen;
}

t_mojo_app_Window* t_mojo_app_Window::m_FindWindow(){
  bbDBFrame db_f{"FindWindow:mojo.app.Window()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(712706);
  return this;
}

void t_mojo_app_Window::m_ClearColor(t_std_graphics_Color l_clearColor){
  bbDBFrame db_f{"ClearColor:Void(clearColor:std.graphics.Color)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("clearColor",&l_clearColor);
  bbDBStmt(249858);
  this->m__0clearColor=l_clearColor;
}

t_std_graphics_Color t_mojo_app_Window::m_ClearColor(){
  bbDBFrame db_f{"ClearColor:std.graphics.Color()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(233474);
  return this->m__0clearColor;
}
bbString bbDBType(t_mojo_app_Window**){
  return "mojo.app.Window";
}
bbString bbDBValue(t_mojo_app_Window**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_app_2window_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_app_Window__0allWindows=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_Window_2>();
  g_mojo_app_Window__0visibleWindows=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_Window_2>();
  g_mojo_app_Window__0windowsByID=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2>();
}

bbInit mx2_mojo_app_2window_init_v("mojo_app_2window",&mx2_mojo_app_2window_init);
