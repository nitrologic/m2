
#include "../../desktop_debug_pi/mojo_graphics_2material.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_graphics_2shader.h"

// ***** Internal *****

void t_mojo_graphics_Material::init(){
  m__0params=bbGCNew<t_mojo_graphics_ParamBuffer>();
}

void t_mojo_graphics_Material::gcMark(){
  bbGCMark(m__0shader);
  bbGCMark(m__0params);
}

void t_mojo_graphics_Material::dbEmit(){
  bbDBEmit("_shader",&m__0shader);
  bbDBEmit("_params",&m__0params);
}

t_mojo_graphics_Material::t_mojo_graphics_Material(t_mojo_graphics_Shader* l_shader){
  init();
  bbDBFrame db_f{"new:Void(shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/material.monkey2"};
  bbDBLocal("shader",&l_shader);
  bbDBStmt(40962);
  this->m__0shader=l_shader;
}

t_mojo_graphics_Shader* t_mojo_graphics_Material::m_Shader(){
  bbDBFrame db_f{"Shader:mojo.graphics.Shader()","/home/pi/monkey2/modules/mojo/graphics/material.monkey2"};
  t_mojo_graphics_Material*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(61442);
  return this->m__0shader;
}

void t_mojo_graphics_Material::m_SetVector(bbString l_name,t_std_geom_Vec4_1f l_value){
  bbDBFrame db_f{"SetVector:Void(name:String,value:Vec4f:std.geom.Vec4<Float>)","/home/pi/monkey2/modules/mojo/graphics/material.monkey2"};
  t_mojo_graphics_Material*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("value",&l_value);
  bbDBStmt(110594);
  this->m__0params->m_SetVector(l_name,l_value);
}

void t_mojo_graphics_Material::m_SetTexture(bbString l_name,t_mojo_graphics_Texture* l_value){
  bbDBFrame db_f{"SetTexture:Void(name:String,value:mojo.graphics.Texture)","/home/pi/monkey2/modules/mojo/graphics/material.monkey2"};
  t_mojo_graphics_Material*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("value",&l_value);
  bbDBStmt(151554);
  this->m__0params->m_SetTexture(l_name,l_value);
}

void t_mojo_graphics_Material::m_SetMatrix(bbString l_name,t_std_geom_Mat4_1f l_value){
  bbDBFrame db_f{"SetMatrix:Void(name:String,value:Mat4f:std.geom.Mat4<Float>)","/home/pi/monkey2/modules/mojo/graphics/material.monkey2"};
  t_mojo_graphics_Material*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("value",&l_value);
  bbDBStmt(131074);
  this->m__0params->m_SetMatrix(l_name,l_value);
}

void t_mojo_graphics_Material::m_SetColor(bbString l_name,t_std_graphics_Color l_value){
  bbDBFrame db_f{"SetColor:Void(name:String,value:std.graphics.Color)","/home/pi/monkey2/modules/mojo/graphics/material.monkey2"};
  t_mojo_graphics_Material*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("value",&l_value);
  bbDBStmt(172034);
  this->m__0params->m_SetColor(l_name,l_value);
}

t_mojo_graphics_ParamBuffer* t_mojo_graphics_Material::m_Params(){
  bbDBFrame db_f{"Params:mojo.graphics.ParamBuffer()","/home/pi/monkey2/modules/mojo/graphics/material.monkey2"};
  t_mojo_graphics_Material*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(90114);
  return this->m__0params;
}
bbString bbDBType(t_mojo_graphics_Material**){
  return "mojo.graphics.Material";
}
bbString bbDBValue(t_mojo_graphics_Material**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_graphics_2material_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2material_init_v("mojo_graphics_2material",&mx2_mojo_graphics_2material_init);
