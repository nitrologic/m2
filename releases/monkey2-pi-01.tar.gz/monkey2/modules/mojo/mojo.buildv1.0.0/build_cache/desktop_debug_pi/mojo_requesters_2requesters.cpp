
#include "../../desktop_debug_pi/mojo_requesters_2requesters.h"

// ***** External *****

// ***** Internal *****

void mx2_mojo_requesters_2requesters_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_requesters_2requesters_init_v("mojo_requesters_2requesters",&mx2_mojo_requesters_2requesters_init);
