
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2style.h"
#include "../../desktop_debug_pi/mojo_app_2window.h"
#include "../../desktop_debug_pi/mojo_graphics_2font.h"
#include "../../desktop_debug_pi/mojo_graphics_2image.h"
#include "../../desktop_debug_pi/mojo_graphics_2shader.h"
#include "../../desktop_debug_pi/mojo_graphics_2texture.h"

// ***** Internal *****

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value,bbInt l_color,t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:std.graphics.Color,value:mojo.graphics.Texture,color:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node.Color,parent:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

t_mojo_graphics_Texture* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.graphics.Texture()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

t_std_graphics_Color t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_Key(){
  bbDBFrame db_f{"Key:std.graphics.Color()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node::m_Copy(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node(parent:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node**){
  return "std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node";
}
bbString bbDBValue(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::dbEmit(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator*){
  return "std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::dbEmit(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

t_std_graphics_Color t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:std.graphics.Color()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator*){
  return "std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys::dbEmit(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys*){
  return "std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::dbEmit(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

t_mojo_graphics_Texture* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Texture()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator*){
  return "std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues::dbEmit(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues*){
  return "std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m__idxeq(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value){
  bbDBFrame db_f{"[]=:Void(key:std.graphics.Color,value:mojo.graphics.Texture)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

t_mojo_graphics_Texture* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m__idx(t_std_graphics_Color l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:mojo.graphics.Texture(key:std.graphics.Color)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return ((t_mojo_graphics_Texture*)0);
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues(this);
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Update(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:std.graphics.Color,value:mojo.graphics.Texture)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Set(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:std.graphics.Color,value:mojo.graphics.Texture)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(l_key,l_value,0,((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_RotateRight(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_RotateLeft(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_RemoveNode(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_child{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Remove(t_std_graphics_Color l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:std.graphics.Color)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys(this);
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_InsertFixup(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    f0_t(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

t_mojo_graphics_Texture* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Get(t_std_graphics_Color l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:mojo.graphics.Texture(key:std.graphics.Color)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return ((t_mojo_graphics_Texture*)0);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_FindNode(t_std_graphics_Color l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node(key:std.graphics.Color)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0);
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_DeleteFixup(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node,t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node,t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node,parent:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2>(f0.l_root);
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Contains(t_std_graphics_Color l_key){
  bbDBFrame db_f{"Contains:Bool(key:std.graphics.Color)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
}

void t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0);
}

t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<std.graphics.Color,mojo.graphics.Texture>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2::m_Add(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node{};
    t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:std.graphics.Color,value:mojo.graphics.Texture)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(l_key,l_value,0,((t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2**){
  return "std.collections.Map<std.graphics.Color,mojo.graphics.Texture>";
}
bbString bbDBValue(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1si_Node::gcMark(){
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1si_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1si_Node::t_std_collections_Map_1si_Node(bbString l_key,bbInt l_value,bbInt l_color,t_std_collections_Map_1si_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:String,value:Int,color:std.collections.Map<String,Int>.Node.Color,parent:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

bbInt t_std_collections_Map_1si_Node::m_Value(){
  bbDBFrame db_f{"Value:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<String,Int>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1si_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<String,Int>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1si_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

bbString t_std_collections_Map_1si_Node::m_Key(){
  bbDBFrame db_f{"Key:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1si_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si_Node::m_Copy(t_std_collections_Map_1si_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,Int>.Node(parent:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1si_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1si_Node**){
  return "std.collections.Map<String,Int>.Node";
}
bbString bbDBValue(t_std_collections_Map_1si_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1si_Iterator::dbEmit(t_std_collections_Map_1si_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1si_Iterator::t_std_collections_Map_1si_Iterator(t_std_collections_Map_1si_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1si_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<String,Int>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1si_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1si_Iterator*){
  return "std.collections.Map<String,Int>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1si_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1si_Iterator&x,const t_std_collections_Map_1si_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1si_KeyIterator::dbEmit(t_std_collections_Map_1si_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1si_KeyIterator::t_std_collections_Map_1si_KeyIterator(t_std_collections_Map_1si_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1si_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1si_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1si_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1si_KeyIterator*){
  return "std.collections.Map<String,Int>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1si_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1si_KeyIterator&x,const t_std_collections_Map_1si_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1si_MapKeys::dbEmit(t_std_collections_Map_1si_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1si_MapKeys::t_std_collections_Map_1si_MapKeys(t_std_collections_Map_1si* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,Int>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1si_KeyIterator t_std_collections_Map_1si_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,Int>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1si_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1si_MapKeys*){
  return "std.collections.Map<String,Int>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1si_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1si_MapKeys&x,const t_std_collections_Map_1si_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1si_ValueIterator::dbEmit(t_std_collections_Map_1si_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1si_ValueIterator::t_std_collections_Map_1si_ValueIterator(t_std_collections_Map_1si_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1si_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

bbInt t_std_collections_Map_1si_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1si_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1si_ValueIterator*){
  return "std.collections.Map<String,Int>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1si_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1si_ValueIterator&x,const t_std_collections_Map_1si_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1si_MapValues::dbEmit(t_std_collections_Map_1si_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1si_MapValues::t_std_collections_Map_1si_MapValues(t_std_collections_Map_1si* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,Int>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1si_ValueIterator t_std_collections_Map_1si_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,Int>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1si_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1si_MapValues*){
  return "std.collections.Map<String,Int>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1si_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1si_MapValues&x,const t_std_collections_Map_1si_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1si_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1si::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1si::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1si::t_std_collections_Map_1si(t_std_collections_Map_1si_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1si::t_std_collections_Map_1si(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1si::m__idxeq(bbString l_key,bbInt l_value){
  bbDBFrame db_f{"[]=:Void(key:String,value:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

bbInt t_std_collections_Map_1si::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:Int(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return 0;
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1si_MapValues t_std_collections_Map_1si::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<String,Int>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1si_MapValues(this);
}

bbBool t_std_collections_Map_1si::m_Update(bbString l_key,bbInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:String,value:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1si::m_Set(bbString l_key,bbInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:String,value:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1si_Node>(l_key,l_value,0,((t_std_collections_Map_1si_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1si_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1si::m_RotateRight(t_std_collections_Map_1si_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1si::m_RotateLeft(t_std_collections_Map_1si_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1si::m_RemoveNode(t_std_collections_Map_1si_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_child{};
    t_std_collections_Map_1si_Node* l_parent{};
    t_std_collections_Map_1si_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1si::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<String,Int>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1si_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1si_MapKeys t_std_collections_Map_1si::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<String,Int>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1si_MapKeys(this);
}

void t_std_collections_Map_1si::m_InsertFixup(t_std_collections_Map_1si_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    f0_t(t_std_collections_Map_1si_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1si_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1si_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

bbInt t_std_collections_Map_1si::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:Int(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return 0;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<String,Int>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1si_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1si_Node* t_std_collections_Map_1si::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<String,Int>.Node(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1si_Node*)0);
}

bbBool t_std_collections_Map_1si::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1si_Node*)0));
}

void t_std_collections_Map_1si::m_DeleteFixup(t_std_collections_Map_1si_Node* l_node,t_std_collections_Map_1si_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    f0_t(t_std_collections_Map_1si_Node* l_node,t_std_collections_Map_1si_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<String,Int>.Node,parent:std.collections.Map<String,Int>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1si_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1si_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1si::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1si* t_std_collections_Map_1si::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,Int>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1si_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1si>(f0.l_root);
}

bbBool t_std_collections_Map_1si::m_Contains(bbString l_key){
  bbDBFrame db_f{"Contains:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1si_Node*)0));
}

void t_std_collections_Map_1si::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1si_Node*)0);
}

t_std_collections_Map_1si_Iterator t_std_collections_Map_1si::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,Int>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1si_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1si::m_Add(bbString l_key,bbInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1si_Node* l_node{};
    t_std_collections_Map_1si_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:String,value:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1si*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1si_Node>(l_key,l_value,0,((t_std_collections_Map_1si_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1si_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1si**){
  return "std.collections.Map<String,Int>";
}
bbString bbDBValue(t_std_collections_Map_1si**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node(bbString l_key,t_mojo_graphics_Shader* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:String,value:mojo.graphics.Shader,color:std.collections.Map<String,mojo.graphics.Shader>.Node.Color,parent:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

t_mojo_graphics_Shader* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.graphics.Shader()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<String,mojo.graphics.Shader>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<String,mojo.graphics.Shader>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_Key(){
  bbDBFrame db_f{"Key:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node::m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,mojo.graphics.Shader>.Node(parent:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node**){
  return "std.collections.Map<String,mojo.graphics.Shader>.Node";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<String,mojo.graphics.Shader>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator*){
  return "std.collections.Map<String,mojo.graphics.Shader>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator*){
  return "std.collections.Map<String,mojo.graphics.Shader>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Shader_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,mojo.graphics.Shader>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Shader>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys*){
  return "std.collections.Map<String,mojo.graphics.Shader>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

t_mojo_graphics_Shader* t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Shader()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator*){
  return "std.collections.Map<String,mojo.graphics.Shader>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues::t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Shader_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,mojo.graphics.Shader>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Shader>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues*){
  return "std.collections.Map<String,mojo.graphics.Shader>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2::t_std_collections_Map_1sTt_mojo_graphics_Shader_2(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2::t_std_collections_Map_1sTt_mojo_graphics_Shader_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m__idxeq(bbString l_key,t_mojo_graphics_Shader* l_value){
  bbDBFrame db_f{"[]=:Void(key:String,value:mojo.graphics.Shader)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

t_mojo_graphics_Shader* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:mojo.graphics.Shader(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return ((t_mojo_graphics_Shader*)0);
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<String,mojo.graphics.Shader>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues(this);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Update(bbString l_key,t_mojo_graphics_Shader* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:String,value:mojo.graphics.Shader)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Set(bbString l_key,t_mojo_graphics_Shader* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:String,value:mojo.graphics.Shader)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_child{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<String,mojo.graphics.Shader>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<String,mojo.graphics.Shader>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys(this);
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

t_mojo_graphics_Shader* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:mojo.graphics.Shader(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return ((t_mojo_graphics_Shader*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<String,mojo.graphics.Shader>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<String,mojo.graphics.Shader>.Node(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<String,mojo.graphics.Shader>.Node,parent:std.collections.Map<String,mojo.graphics.Shader>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2* t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,mojo.graphics.Shader>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2>(f0.l_root);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Contains(bbString l_key){
  bbDBFrame db_f{"Contains:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Shader>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Shader_2::m_Add(bbString l_key,t_mojo_graphics_Shader* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:String,value:mojo.graphics.Shader)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Shader_2**){
  return "std.collections.Map<String,mojo.graphics.Shader>";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Shader_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node(bbString l_key,t_mojo_graphics_Font* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:String,value:mojo.graphics.Font,color:std.collections.Map<String,mojo.graphics.Font>.Node.Color,parent:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

t_mojo_graphics_Font* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.graphics.Font()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<String,mojo.graphics.Font>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<String,mojo.graphics.Font>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_Key(){
  bbDBFrame db_f{"Key:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node::m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,mojo.graphics.Font>.Node(parent:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node**){
  return "std.collections.Map<String,mojo.graphics.Font>.Node";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<String,mojo.graphics.Font>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator*){
  return "std.collections.Map<String,mojo.graphics.Font>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator*){
  return "std.collections.Map<String,mojo.graphics.Font>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys::t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Font_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,mojo.graphics.Font>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Font>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys*){
  return "std.collections.Map<String,mojo.graphics.Font>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

t_mojo_graphics_Font* t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Font()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator*){
  return "std.collections.Map<String,mojo.graphics.Font>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues::t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Font_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,mojo.graphics.Font>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Font>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues*){
  return "std.collections.Map<String,mojo.graphics.Font>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2::t_std_collections_Map_1sTt_mojo_graphics_Font_2(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2::t_std_collections_Map_1sTt_mojo_graphics_Font_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m__idxeq(bbString l_key,t_mojo_graphics_Font* l_value){
  bbDBFrame db_f{"[]=:Void(key:String,value:mojo.graphics.Font)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

t_mojo_graphics_Font* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:mojo.graphics.Font(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return ((t_mojo_graphics_Font*)0);
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<String,mojo.graphics.Font>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues(this);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Update(bbString l_key,t_mojo_graphics_Font* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:String,value:mojo.graphics.Font)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Set(bbString l_key,t_mojo_graphics_Font* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:String,value:mojo.graphics.Font)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_child{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<String,mojo.graphics.Font>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<String,mojo.graphics.Font>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys(this);
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

t_mojo_graphics_Font* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:mojo.graphics.Font(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return ((t_mojo_graphics_Font*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<String,mojo.graphics.Font>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<String,mojo.graphics.Font>.Node(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<String,mojo.graphics.Font>.Node,parent:std.collections.Map<String,mojo.graphics.Font>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2* t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,mojo.graphics.Font>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2>(f0.l_root);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Contains(bbString l_key){
  bbDBFrame db_f{"Contains:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Font>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Font_2::m_Add(bbString l_key,t_mojo_graphics_Font* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:String,value:mojo.graphics.Font)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Font_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Font_2**){
  return "std.collections.Map<String,mojo.graphics.Font>";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Font_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node::t_std_collections_Map_1jTt_mojo_app_Window_2_Node(bbUInt l_key,t_mojo_app_Window* l_value,bbInt l_color,t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:Uint,value:mojo.app.Window,color:std.collections.Map<Uint,mojo.app.Window>.Node.Color,parent:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

t_mojo_app_Window* t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<Uint,mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<Uint,mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

bbUInt t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_Key(){
  bbDBFrame db_f{"Key:Uint()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2_Node::m_Copy(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<Uint,mojo.app.Window>.Node(parent:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1jTt_mojo_app_Window_2_Node**){
  return "std.collections.Map<Uint,mojo.app.Window>.Node";
}
bbString bbDBValue(t_std_collections_Map_1jTt_mojo_app_Window_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::dbEmit(t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<Uint,mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator*){
  return "std.collections.Map<Uint,mojo.app.Window>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::dbEmit(t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

bbUInt t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:Uint()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator*){
  return "std.collections.Map<Uint,mojo.app.Window>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys::dbEmit(t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys::t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys(t_std_collections_Map_1jTt_mojo_app_Window_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<Uint,mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Uint,mojo.app.Window>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys*){
  return "std.collections.Map<Uint,mojo.app.Window>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::dbEmit(t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

t_mojo_app_Window* t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator*){
  return "std.collections.Map<Uint,mojo.app.Window>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues::dbEmit(t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues::t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues(t_std_collections_Map_1jTt_mojo_app_Window_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<Uint,mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Uint,mojo.app.Window>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues*){
  return "std.collections.Map<Uint,mojo.app.Window>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1jTt_mojo_app_Window_2::t_std_collections_Map_1jTt_mojo_app_Window_2(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1jTt_mojo_app_Window_2::t_std_collections_Map_1jTt_mojo_app_Window_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m__idxeq(bbUInt l_key,t_mojo_app_Window* l_value){
  bbDBFrame db_f{"[]=:Void(key:Uint,value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

t_mojo_app_Window* t_std_collections_Map_1jTt_mojo_app_Window_2::m__idx(bbUInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:mojo.app.Window(key:Uint)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return ((t_mojo_app_Window*)0);
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues t_std_collections_Map_1jTt_mojo_app_Window_2::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<Uint,mojo.app.Window>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues(this);
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Update(bbUInt l_key,t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:Uint,value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Set(bbUInt l_key,t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:Uint,value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(l_key,l_value,0,((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_RotateRight(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_RotateLeft(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_RemoveNode(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_child{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Remove(bbUInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:Uint)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<Uint,mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys t_std_collections_Map_1jTt_mojo_app_Window_2::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<Uint,mojo.app.Window>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys(this);
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_InsertFixup(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    f0_t(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

t_mojo_app_Window* t_std_collections_Map_1jTt_mojo_app_Window_2::m_Get(bbUInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:mojo.app.Window(key:Uint)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return ((t_mojo_app_Window*)0);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<Uint,mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t_std_collections_Map_1jTt_mojo_app_Window_2::m_FindNode(bbUInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<Uint,mojo.app.Window>.Node(key:Uint)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0);
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_DeleteFixup(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node,t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node,t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<Uint,mojo.app.Window>.Node,parent:std.collections.Map<Uint,mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1jTt_mojo_app_Window_2::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1jTt_mojo_app_Window_2* t_std_collections_Map_1jTt_mojo_app_Window_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<Uint,mojo.app.Window>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2>(f0.l_root);
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Contains(bbUInt l_key){
  bbDBFrame db_f{"Contains:Bool(key:Uint)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
}

void t_std_collections_Map_1jTt_mojo_app_Window_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0);
}

t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator t_std_collections_Map_1jTt_mojo_app_Window_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Uint,mojo.app.Window>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1jTt_mojo_app_Window_2::m_Add(bbUInt l_key,t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node{};
    t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:Uint,value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1jTt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(l_key,l_value,0,((t_std_collections_Map_1jTt_mojo_app_Window_2_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1jTt_mojo_app_Window_2**){
  return "std.collections.Map<Uint,mojo.app.Window>";
}
bbString bbDBValue(t_std_collections_Map_1jTt_mojo_app_Window_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node(bbString l_key,t_mojo_graphics_Image* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:String,value:mojo.graphics.Image,color:std.collections.Map<String,mojo.graphics.Image>.Node.Color,parent:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

t_mojo_graphics_Image* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.graphics.Image()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<String,mojo.graphics.Image>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<String,mojo.graphics.Image>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_Key(){
  bbDBFrame db_f{"Key:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node::m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,mojo.graphics.Image>.Node(parent:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node**){
  return "std.collections.Map<String,mojo.graphics.Image>.Node";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<String,mojo.graphics.Image>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator*){
  return "std.collections.Map<String,mojo.graphics.Image>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator*){
  return "std.collections.Map<String,mojo.graphics.Image>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys::t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Image_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,mojo.graphics.Image>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Image>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys*){
  return "std.collections.Map<String,mojo.graphics.Image>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

t_mojo_graphics_Image* t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Image()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator*){
  return "std.collections.Map<String,mojo.graphics.Image>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues::dbEmit(t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues::t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Image_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,mojo.graphics.Image>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Image>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues*){
  return "std.collections.Map<String,mojo.graphics.Image>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2::t_std_collections_Map_1sTt_mojo_graphics_Image_2(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2::t_std_collections_Map_1sTt_mojo_graphics_Image_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m__idxeq(bbString l_key,t_mojo_graphics_Image* l_value){
  bbDBFrame db_f{"[]=:Void(key:String,value:mojo.graphics.Image)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

t_mojo_graphics_Image* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:mojo.graphics.Image(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return ((t_mojo_graphics_Image*)0);
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<String,mojo.graphics.Image>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues(this);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Update(bbString l_key,t_mojo_graphics_Image* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:String,value:mojo.graphics.Image)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Set(bbString l_key,t_mojo_graphics_Image* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:String,value:mojo.graphics.Image)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_child{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<String,mojo.graphics.Image>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<String,mojo.graphics.Image>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys(this);
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

t_mojo_graphics_Image* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:mojo.graphics.Image(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return ((t_mojo_graphics_Image*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<String,mojo.graphics.Image>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<String,mojo.graphics.Image>.Node(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<String,mojo.graphics.Image>.Node,parent:std.collections.Map<String,mojo.graphics.Image>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2* t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,mojo.graphics.Image>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2>(f0.l_root);
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Contains(bbString l_key){
  bbDBFrame db_f{"Contains:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0);
}

t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.graphics.Image>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1sTt_mojo_graphics_Image_2::m_Add(bbString l_key,t_mojo_graphics_Image* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:String,value:mojo.graphics.Image)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_graphics_Image_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Image_2**){
  return "std.collections.Map<String,mojo.graphics.Image>";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Image_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node::t_std_collections_Map_1sTt_mojo_app_Style_2_Node(bbString l_key,t_mojo_app_Style* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:String,value:mojo.app.Style,color:std.collections.Map<String,mojo.app.Style>.Node.Color,parent:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

t_mojo_app_Style* t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.app.Style()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<String,mojo.app.Style>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<String,mojo.app.Style>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

bbString t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_Key(){
  bbDBFrame db_f{"Key:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2_Node::m_Copy(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,mojo.app.Style>.Node(parent:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_app_Style_2_Node**){
  return "std.collections.Map<String,mojo.app.Style>.Node";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_app_Style_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::dbEmit(t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<String,mojo.app.Style>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator*){
  return "std.collections.Map<String,mojo.app.Style>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::dbEmit(t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

bbString t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:String()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator*){
  return "std.collections.Map<String,mojo.app.Style>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys::dbEmit(t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys::t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys(t_std_collections_Map_1sTt_mojo_app_Style_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,mojo.app.Style>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.app.Style>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys*){
  return "std.collections.Map<String,mojo.app.Style>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::dbEmit(t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

t_mojo_app_Style* t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.Style()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator*){
  return "std.collections.Map<String,mojo.app.Style>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues::dbEmit(t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues::t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues(t_std_collections_Map_1sTt_mojo_app_Style_2* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<String,mojo.app.Style>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.app.Style>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues*){
  return "std.collections.Map<String,mojo.app.Style>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1sTt_mojo_app_Style_2::t_std_collections_Map_1sTt_mojo_app_Style_2(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1sTt_mojo_app_Style_2::t_std_collections_Map_1sTt_mojo_app_Style_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m__idxeq(bbString l_key,t_mojo_app_Style* l_value){
  bbDBFrame db_f{"[]=:Void(key:String,value:mojo.app.Style)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

t_mojo_app_Style* t_std_collections_Map_1sTt_mojo_app_Style_2::m__idx(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:mojo.app.Style(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return ((t_mojo_app_Style*)0);
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues t_std_collections_Map_1sTt_mojo_app_Style_2::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<String,mojo.app.Style>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues(this);
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Update(bbString l_key,t_mojo_app_Style* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:String,value:mojo.app.Style)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Set(bbString l_key,t_mojo_app_Style* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:String,value:mojo.app.Style)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_RotateRight(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_RotateLeft(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_RemoveNode(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_child{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Remove(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<String,mojo.app.Style>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys t_std_collections_Map_1sTt_mojo_app_Style_2::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<String,mojo.app.Style>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys(this);
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_InsertFixup(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    f0_t(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

t_mojo_app_Style* t_std_collections_Map_1sTt_mojo_app_Style_2::m_Get(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:mojo.app.Style(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return ((t_mojo_app_Style*)0);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<String,mojo.app.Style>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t_std_collections_Map_1sTt_mojo_app_Style_2::m_FindNode(bbString l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<String,mojo.app.Style>.Node(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0);
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_DeleteFixup(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node,t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    f0_t(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node,t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<String,mojo.app.Style>.Node,parent:std.collections.Map<String,mojo.app.Style>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1sTt_mojo_app_Style_2::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1sTt_mojo_app_Style_2* t_std_collections_Map_1sTt_mojo_app_Style_2::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<String,mojo.app.Style>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2>(f0.l_root);
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Contains(bbString l_key){
  bbDBFrame db_f{"Contains:Bool(key:String)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
}

void t_std_collections_Map_1sTt_mojo_app_Style_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0);
}

t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator t_std_collections_Map_1sTt_mojo_app_Style_2::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<String,mojo.app.Style>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1sTt_mojo_app_Style_2::m_Add(bbString l_key,t_mojo_app_Style* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node{};
    t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:String,value:mojo.app.Style)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1sTt_mojo_app_Style_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(l_key,l_value,0,((t_std_collections_Map_1sTt_mojo_app_Style_2_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1sTt_mojo_app_Style_2**){
  return "std.collections.Map<String,mojo.app.Style>";
}
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_app_Style_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1iFvE_Node::gcMark(){
  bbGCMark(m__0value);
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1iFvE_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1iFvE_Node::t_std_collections_Map_1iFvE_Node(bbInt l_key,bbFunction<void()> l_value,bbInt l_color,t_std_collections_Map_1iFvE_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:Int,value:Void(),color:std.collections.Map<Int,Void()>.Node.Color,parent:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

bbFunction<void()> t_std_collections_Map_1iFvE_Node::m_Value(){
  bbDBFrame db_f{"Value:Void()()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<Int,Void()>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1iFvE_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<Int,Void()>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1iFvE_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

bbInt t_std_collections_Map_1iFvE_Node::m_Key(){
  bbDBFrame db_f{"Key:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1iFvE_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE_Node::m_Copy(t_std_collections_Map_1iFvE_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<Int,Void()>.Node(parent:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1iFvE_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1iFvE_Node**){
  return "std.collections.Map<Int,Void()>.Node";
}
bbString bbDBValue(t_std_collections_Map_1iFvE_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1iFvE_Iterator::dbEmit(t_std_collections_Map_1iFvE_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1iFvE_Iterator::t_std_collections_Map_1iFvE_Iterator(t_std_collections_Map_1iFvE_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iFvE_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<Int,Void()>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1iFvE_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1iFvE_Iterator*){
  return "std.collections.Map<Int,Void()>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1iFvE_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iFvE_Iterator&x,const t_std_collections_Map_1iFvE_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1iFvE_KeyIterator::dbEmit(t_std_collections_Map_1iFvE_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1iFvE_KeyIterator::t_std_collections_Map_1iFvE_KeyIterator(t_std_collections_Map_1iFvE_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iFvE_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

bbInt t_std_collections_Map_1iFvE_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1iFvE_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1iFvE_KeyIterator*){
  return "std.collections.Map<Int,Void()>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1iFvE_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iFvE_KeyIterator&x,const t_std_collections_Map_1iFvE_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1iFvE_MapKeys::dbEmit(t_std_collections_Map_1iFvE_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1iFvE_MapKeys::t_std_collections_Map_1iFvE_MapKeys(t_std_collections_Map_1iFvE* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<Int,Void()>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1iFvE_KeyIterator t_std_collections_Map_1iFvE_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Int,Void()>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1iFvE_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1iFvE_MapKeys*){
  return "std.collections.Map<Int,Void()>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1iFvE_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iFvE_MapKeys&x,const t_std_collections_Map_1iFvE_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1iFvE_ValueIterator::dbEmit(t_std_collections_Map_1iFvE_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1iFvE_ValueIterator::t_std_collections_Map_1iFvE_ValueIterator(t_std_collections_Map_1iFvE_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iFvE_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

bbFunction<void()> t_std_collections_Map_1iFvE_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:Void()()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1iFvE_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1iFvE_ValueIterator*){
  return "std.collections.Map<Int,Void()>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1iFvE_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iFvE_ValueIterator&x,const t_std_collections_Map_1iFvE_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1iFvE_MapValues::dbEmit(t_std_collections_Map_1iFvE_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1iFvE_MapValues::t_std_collections_Map_1iFvE_MapValues(t_std_collections_Map_1iFvE* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<Int,Void()>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1iFvE_ValueIterator t_std_collections_Map_1iFvE_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Int,Void()>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1iFvE_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1iFvE_MapValues*){
  return "std.collections.Map<Int,Void()>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1iFvE_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iFvE_MapValues&x,const t_std_collections_Map_1iFvE_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iFvE_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1iFvE::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1iFvE::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1iFvE::t_std_collections_Map_1iFvE(t_std_collections_Map_1iFvE_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1iFvE::t_std_collections_Map_1iFvE(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1iFvE::m__idxeq(bbInt l_key,bbFunction<void()> l_value){
  bbDBFrame db_f{"[]=:Void(key:Int,value:Void())","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

bbFunction<void()> t_std_collections_Map_1iFvE::m__idx(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:Void()(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return bbFunction<void()>{};
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1iFvE_MapValues t_std_collections_Map_1iFvE::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<Int,Void()>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1iFvE_MapValues(this);
}

bbBool t_std_collections_Map_1iFvE::m_Update(bbInt l_key,bbFunction<void()> l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:Int,value:Void())","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1iFvE::m_Set(bbInt l_key,bbFunction<void()> l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:Int,value:Void())","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1iFvE_Node>(l_key,l_value,0,((t_std_collections_Map_1iFvE_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1iFvE_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1iFvE::m_RotateRight(t_std_collections_Map_1iFvE_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1iFvE::m_RotateLeft(t_std_collections_Map_1iFvE_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1iFvE::m_RemoveNode(t_std_collections_Map_1iFvE_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_child{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    t_std_collections_Map_1iFvE_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1iFvE::m_Remove(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<Int,Void()>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1iFvE_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1iFvE_MapKeys t_std_collections_Map_1iFvE::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<Int,Void()>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1iFvE_MapKeys(this);
}

void t_std_collections_Map_1iFvE::m_InsertFixup(t_std_collections_Map_1iFvE_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    f0_t(t_std_collections_Map_1iFvE_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1iFvE_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1iFvE_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

bbFunction<void()> t_std_collections_Map_1iFvE::m_Get(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:Void()(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return bbFunction<void()>{};
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<Int,Void()>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1iFvE_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1iFvE_Node* t_std_collections_Map_1iFvE::m_FindNode(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<Int,Void()>.Node(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1iFvE_Node*)0);
}

bbBool t_std_collections_Map_1iFvE::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1iFvE_Node*)0));
}

void t_std_collections_Map_1iFvE::m_DeleteFixup(t_std_collections_Map_1iFvE_Node* l_node,t_std_collections_Map_1iFvE_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    f0_t(t_std_collections_Map_1iFvE_Node* l_node,t_std_collections_Map_1iFvE_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<Int,Void()>.Node,parent:std.collections.Map<Int,Void()>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1iFvE_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1iFvE_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1iFvE::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1iFvE* t_std_collections_Map_1iFvE::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<Int,Void()>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1iFvE_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1iFvE>(f0.l_root);
}

bbBool t_std_collections_Map_1iFvE::m_Contains(bbInt l_key){
  bbDBFrame db_f{"Contains:Bool(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1iFvE_Node*)0));
}

void t_std_collections_Map_1iFvE::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1iFvE_Node*)0);
}

t_std_collections_Map_1iFvE_Iterator t_std_collections_Map_1iFvE::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Int,Void()>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1iFvE_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1iFvE::m_Add(bbInt l_key,bbFunction<void()> l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iFvE_Node* l_node{};
    t_std_collections_Map_1iFvE_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:Int,value:Void())","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iFvE*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1iFvE_Node>(l_key,l_value,0,((t_std_collections_Map_1iFvE_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1iFvE_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1iFvE**){
  return "std.collections.Map<Int,Void()>";
}
bbString bbDBValue(t_std_collections_Map_1iFvE**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1iz_Node::gcMark(){
  bbGCMark(m__0left);
  bbGCMark(m__0right);
  bbGCMark(m__0parent);
}

void t_std_collections_Map_1iz_Node::dbEmit(){
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_value",&m__0value);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_left",&m__0left);
  bbDBEmit("_right",&m__0right);
  bbDBEmit("_parent",&m__0parent);
}

t_std_collections_Map_1iz_Node::t_std_collections_Map_1iz_Node(bbInt l_key,bbBool l_value,bbInt l_color,t_std_collections_Map_1iz_Node* l_parent){
  bbDBFrame db_f{"new:Void(key:Int,value:Bool,color:std.collections.Map<Int,Bool>.Node.Color,parent:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBLocal("color",&l_color);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(270339);
  this->m__0key=l_key;
  bbDBStmt(274435);
  this->m__0value=l_value;
  bbDBStmt(278531);
  this->m__0color=l_color;
  bbDBStmt(282627);
  this->m__0parent=l_parent;
}

bbBool t_std_collections_Map_1iz_Node::m_Value(){
  bbDBFrame db_f{"Value:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(196611);
  return this->m__0value;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz_Node::m_PrevNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"PrevNode:std.collections.Map<Int,Bool>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(389123);
  if(bbBool(this->m__0left)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1iz_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(393226);
    f1.l_node=this->m__0left;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(397316);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(401413);
        f1.l_node=f1.l_node->m__0right;
      }
    }
    bbDBStmt(409604);
    return f1.l_node;
  }
  bbDBStmt(417801);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(417812);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(421891);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0left))){
      bbDBBlock db_blk;
      bbDBStmt(425988);
      f0.l_node=f0.l_parent;
      bbDBStmt(430084);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(438275);
  return f0.l_parent;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz_Node::m_NextNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"NextNode:std.collections.Map<Int,Bool>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323587);
  if(bbBool(this->m__0right)){
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1iz_Node* l_node{};
      void gcMark(){
        bbGCMarkPtr(l_node);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(327690);
    f1.l_node=this->m__0right;
    bbDBLocal("node",&f1.l_node);
    bbDBStmt(331780);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_node->m__0left)){
        bbDBBlock db_blk;
        bbDBStmt(335877);
        f1.l_node=f1.l_node->m__0left;
      }
    }
    bbDBStmt(344068);
    return f1.l_node;
  }
  bbDBStmt(352265);
  f0.l_node=this;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(352276);
  f0.l_parent=this->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(356355);
  {
    bbDBLoop db_loop;
    while((bbBool(f0.l_parent)&&(f0.l_node==f0.l_parent->m__0right))){
      bbDBBlock db_blk;
      bbDBStmt(360452);
      f0.l_node=f0.l_parent;
      bbDBStmt(364548);
      f0.l_parent=f0.l_parent->m__0parent;
    }
  }
  bbDBStmt(372739);
  return f0.l_parent;
}

bbInt t_std_collections_Map_1iz_Node::m_Key(){
  bbDBFrame db_f{"Key:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(159747);
  return this->m__0key;
}

bbInt t_std_collections_Map_1iz_Node::m_Count(bbInt l_n){
  bbDBFrame db_f{"Count:Int(n:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("n",&l_n);
  bbDBStmt(299011);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(299020);
    l_n=this->m__0left->m_Count(l_n);
  }
  bbDBStmt(303107);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(303117);
    l_n=this->m__0right->m_Count(l_n);
  }
  bbDBStmt(307203);
  return (l_n+1);
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz_Node::m_Copy(t_std_collections_Map_1iz_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<Int,Bool>.Node(parent:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("parent",&l_parent);
  bbDBStmt(454665);
  f0.l_node=bbGCNew<t_std_collections_Map_1iz_Node>(this->m__0key,this->m__0value,this->m__0color,l_parent);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(458755);
  if(bbBool(this->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(458764);
    f0.l_node->m__0left=this->m__0left->m_Copy(f0.l_node);
  }
  bbDBStmt(462851);
  if(bbBool(this->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(462861);
    f0.l_node->m__0right=this->m__0right->m_Copy(f0.l_node);
  }
  bbDBStmt(466947);
  return f0.l_node;
}
bbString bbDBType(t_std_collections_Map_1iz_Node**){
  return "std.collections.Map<Int,Bool>.Node";
}
bbString bbDBValue(t_std_collections_Map_1iz_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Map_1iz_Iterator::dbEmit(t_std_collections_Map_1iz_Iterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1iz_Iterator::t_std_collections_Map_1iz_Iterator(t_std_collections_Map_1iz_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(565251);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iz_Iterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  return bbBool((*this).m__0node);
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz_Iterator::m_Current(){
  bbDBFrame db_f{"Current:std.collections.Map<Int,Bool>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(516099);
  return (*this).m__0node;
}

void t_std_collections_Map_1iz_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(532483);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1iz_Iterator*){
  return "std.collections.Map<Int,Bool>.Iterator";
}
bbString bbDBValue(t_std_collections_Map_1iz_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iz_Iterator&x,const t_std_collections_Map_1iz_Iterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_Iterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1iz_KeyIterator::dbEmit(t_std_collections_Map_1iz_KeyIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1iz_KeyIterator::t_std_collections_Map_1iz_KeyIterator(t_std_collections_Map_1iz_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(663555);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iz_KeyIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(598019);
  return bbBool((*this).m__0node);
}

bbInt t_std_collections_Map_1iz_KeyIterator::m_Current(){
  bbDBFrame db_f{"Current:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(614403);
  return (*this).m__0node->m__0key;
}

void t_std_collections_Map_1iz_KeyIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_KeyIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(630787);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1iz_KeyIterator*){
  return "std.collections.Map<Int,Bool>.KeyIterator";
}
bbString bbDBValue(t_std_collections_Map_1iz_KeyIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iz_KeyIterator&x,const t_std_collections_Map_1iz_KeyIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_KeyIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1iz_MapKeys::dbEmit(t_std_collections_Map_1iz_MapKeys*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1iz_MapKeys::t_std_collections_Map_1iz_MapKeys(t_std_collections_Map_1iz* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<Int,Bool>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(827395);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1iz_KeyIterator t_std_collections_Map_1iz_MapKeys::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Int,Bool>.KeyIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_MapKeys*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(794627);
  return t_std_collections_Map_1iz_KeyIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1iz_MapKeys*){
  return "std.collections.Map<Int,Bool>.MapKeys";
}
bbString bbDBValue(t_std_collections_Map_1iz_MapKeys*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iz_MapKeys&x,const t_std_collections_Map_1iz_MapKeys&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_MapKeys&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1iz_ValueIterator::dbEmit(t_std_collections_Map_1iz_ValueIterator*p){
  bbDBEmit("_node",&p->m__0node);
}

t_std_collections_Map_1iz_ValueIterator::t_std_collections_Map_1iz_ValueIterator(t_std_collections_Map_1iz_Node* l_node){
  bbDBFrame db_f{"new:Void(node:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("node",&l_node);
  bbDBStmt(761859);
  (*this).m__0node=l_node;
}

bbBool t_std_collections_Map_1iz_ValueIterator::m_Valid(){
  bbDBFrame db_f{"Valid:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(696323);
  return bbBool((*this).m__0node);
}

bbBool t_std_collections_Map_1iz_ValueIterator::m_Current(){
  bbDBFrame db_f{"Current:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(712707);
  return (*this).m__0node->m__0value;
}

void t_std_collections_Map_1iz_ValueIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_ValueIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m__0node=(*this).m__0node->m_NextNode();
}
bbString bbDBType(t_std_collections_Map_1iz_ValueIterator*){
  return "std.collections.Map<Int,Bool>.ValueIterator";
}
bbString bbDBValue(t_std_collections_Map_1iz_ValueIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iz_ValueIterator&x,const t_std_collections_Map_1iz_ValueIterator&y){
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_ValueIterator&t){
  bbGCMark(t.m__0node);
}

void t_std_collections_Map_1iz_MapValues::dbEmit(t_std_collections_Map_1iz_MapValues*p){
  bbDBEmit("_map",&p->m__0map);
}

t_std_collections_Map_1iz_MapValues::t_std_collections_Map_1iz_MapValues(t_std_collections_Map_1iz* l_map){
  bbDBFrame db_f{"new:Void(map:std.collections.Map<Int,Bool>)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("map",&l_map);
  bbDBStmt(892931);
  (*this).m__0map=l_map;
}

t_std_collections_Map_1iz_ValueIterator t_std_collections_Map_1iz_MapValues::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Int,Bool>.ValueIterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz_MapValues*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(860163);
  return t_std_collections_Map_1iz_ValueIterator(f0.t0=(*this).m__0map->m_FirstNode());
}
bbString bbDBType(t_std_collections_Map_1iz_MapValues*){
  return "std.collections.Map<Int,Bool>.MapValues";
}
bbString bbDBValue(t_std_collections_Map_1iz_MapValues*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Map_1iz_MapValues&x,const t_std_collections_Map_1iz_MapValues&y){
  if(int t=bbCompare(x.m__0map,y.m__0map)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Map_1iz_MapValues&t){
  bbGCMark(t.m__0map);
}

void t_std_collections_Map_1iz::gcMark(){
  bbGCMark(m__0root);
}

void t_std_collections_Map_1iz::dbEmit(){
  bbDBEmit("_root",&m__0root);
}

t_std_collections_Map_1iz::t_std_collections_Map_1iz(t_std_collections_Map_1iz_Node* l_root){
  bbDBFrame db_f{"new:Void(root:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  bbDBLocal("root",&l_root);
  bbDBStmt(1941506);
  this->m__0root=l_root;
}

t_std_collections_Map_1iz::t_std_collections_Map_1iz(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
}

void t_std_collections_Map_1iz::m__idxeq(bbInt l_key,bbBool l_value){
  bbDBFrame db_f{"[]=:Void(key:Int,value:Bool)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1314818);
  this->m_Set(l_key,l_value);
}

bbBool t_std_collections_Map_1iz::m__idx(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"[]:Bool(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1359880);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1363970);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1363982);
    return false;
  }
  bbDBStmt(1368066);
  return f0.l_node->m__0value;
}

t_std_collections_Map_1iz_MapValues t_std_collections_Map_1iz::m_Values(){
  bbDBFrame db_f{"Values:std.collections.Map<Int,Bool>.MapValues()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return t_std_collections_Map_1iz_MapValues(this);
}

bbBool t_std_collections_Map_1iz::m_Update(bbInt l_key,bbBool l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Update:Bool(key:Int,value:Bool)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1785864);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1789954);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1789966);
    return false;
  }
  bbDBStmt(1794050);
  f0.l_node->m__0value=l_value;
  bbDBStmt(1798146);
  return true;
}

bbBool t_std_collections_Map_1iz::m_Set(bbInt l_key,bbBool l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Set:Bool(key:Int,value:Bool)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1437698);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0root=bbGCNew<t_std_collections_Map_1iz_Node>(l_key,l_value,0,((t_std_collections_Map_1iz_Node*)0));
    bbDBStmt(1445891);
    return true;
  }
  bbDBStmt(1458184);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1458196);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1458208);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1466370);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1470467);
      f0.l_parent=f0.l_node;
      bbDBStmt(1474563);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1478659);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1482756);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1486851),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1490948);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1495043);
        bbDBBlock db_blk;
        bbDBStmt(1499140);
        f0.l_node->m__0value=l_value;
        bbDBStmt(1503236);
        return false;
      }
    }
  }
  bbDBStmt(1519618);
  f0.l_node=bbGCNew<t_std_collections_Map_1iz_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1527810);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1527819);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1527838);
    bbDBBlock db_blk;
    bbDBStmt(1527843);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1536002);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1544194);
  return true;
}

void t_std_collections_Map_1iz::m_RotateRight(t_std_collections_Map_1iz_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateRight:Void(node:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2351112);
  f0.l_child=l_node->m__0left;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2355202);
  l_node->m__0left=f0.l_child->m__0right;
  bbDBStmt(2359298);
  if(bbBool(f0.l_child->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2363395);
    f0.l_child->m__0right->m__0parent=l_node;
  }
  bbDBStmt(2371586);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2375682);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    if((l_node==l_node->m__0parent->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2383876);
      l_node->m__0parent->m__0right=f0.l_child;
    }else{
      bbDBStmt(2387971);
      bbDBBlock db_blk;
      bbDBStmt(2392068);
      l_node->m__0parent->m__0left=f0.l_child;
    }
  }else{
    bbDBStmt(2400258);
    bbDBBlock db_blk;
    bbDBStmt(2404355);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2412546);
  f0.l_child->m__0right=l_node;
  bbDBStmt(2416642);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1iz::m_RotateLeft(t_std_collections_Map_1iz_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_child{};
    void gcMark(){
      bbGCMarkPtr(l_child);
    }
  }f0{};
  bbDBFrame db_f{"RotateLeft:Void(node:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2269192);
  f0.l_child=l_node->m__0right;
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2273282);
  l_node->m__0right=f0.l_child->m__0left;
  bbDBStmt(2277378);
  if(bbBool(f0.l_child->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2281475);
    f0.l_child->m__0left->m__0parent=l_node;
  }
  bbDBStmt(2289666);
  f0.l_child->m__0parent=l_node->m__0parent;
  bbDBStmt(2293762);
  if(bbBool(l_node->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2297859);
    if((l_node==l_node->m__0parent->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(2301956);
      l_node->m__0parent->m__0left=f0.l_child;
    }else{
      bbDBStmt(2306051);
      bbDBBlock db_blk;
      bbDBStmt(2310148);
      l_node->m__0parent->m__0right=f0.l_child;
    }
  }else{
    bbDBStmt(2318338);
    bbDBBlock db_blk;
    bbDBStmt(2322435);
    this->m__0root=f0.l_child;
  }
  bbDBStmt(2330626);
  f0.l_child->m__0left=l_node;
  bbDBStmt(2334722);
  l_node->m__0parent=f0.l_child;
}

void t_std_collections_Map_1iz::m_RemoveNode(t_std_collections_Map_1iz_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_child{};
    t_std_collections_Map_1iz_Node* l_parent{};
    t_std_collections_Map_1iz_Node* l_splice{};
    void gcMark(){
      bbGCMarkPtr(l_child);
      bbGCMarkPtr(l_parent);
      bbGCMarkPtr(l_splice);
    }
  }f0{};
  bbDBFrame db_f{"RemoveNode:Void(node:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(2101256);
  bbDBLocal("splice",&f0.l_splice);
  bbDBStmt(2101268);
  bbDBLocal("child",&f0.l_child);
  bbDBStmt(2109442);
  if(!bbBool(l_node->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2113539);
    f0.l_splice=l_node;
    bbDBStmt(2117635);
    f0.l_child=l_node->m__0right;
  }else if(bbDBStmt(2121730),!bbBool(l_node->m__0right)){
    bbDBBlock db_blk;
    bbDBStmt(2125827);
    f0.l_splice=l_node;
    bbDBStmt(2129923);
    f0.l_child=l_node->m__0left;
  }else{
    bbDBStmt(2134018);
    bbDBBlock db_blk;
    bbDBStmt(2138115);
    f0.l_splice=l_node->m__0left;
    bbDBStmt(2142211);
    {
      bbDBLoop db_loop;
      while(bbBool(f0.l_splice->m__0right)){
        bbDBBlock db_blk;
        bbDBStmt(2146308);
        f0.l_splice=f0.l_splice->m__0right;
      }
    }
    bbDBStmt(2154499);
    f0.l_child=f0.l_splice->m__0left;
    bbDBStmt(2158595);
    l_node->m__0key=f0.l_splice->m__0key;
    bbDBStmt(2162691);
    l_node->m__0value=f0.l_splice->m__0value;
  }
  bbDBStmt(2174984);
  f0.l_parent=f0.l_splice->m__0parent;
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2183170);
  if(bbBool(f0.l_child)){
    bbDBBlock db_blk;
    bbDBStmt(2187267);
    f0.l_child->m__0parent=f0.l_parent;
  }
  bbDBStmt(2199554);
  if(!bbBool(f0.l_parent)){
    bbDBBlock db_blk;
    bbDBStmt(2203651);
    this->m__0root=f0.l_child;
    bbDBStmt(2207747);
    return;
  }
  bbDBStmt(2220034);
  if((f0.l_splice==f0.l_parent->m__0left)){
    bbDBBlock db_blk;
    bbDBStmt(2224131);
    f0.l_parent->m__0left=f0.l_child;
  }else{
    bbDBStmt(2228226);
    bbDBBlock db_blk;
    bbDBStmt(2232323);
    f0.l_parent->m__0right=f0.l_child;
  }
  bbDBStmt(2244610);
  if((f0.l_splice->m__0color==1)){
    bbDBBlock db_blk;
    bbDBStmt(2248707);
    this->m_DeleteFixup(f0.l_child,f0.l_parent);
  }
}

bbBool t_std_collections_Map_1iz::m_Remove(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1896456);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1900546);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1900558);
    return false;
  }
  bbDBStmt(1904642);
  this->m_RemoveNode(f0.l_node);
  bbDBStmt(1908738);
  return true;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz::m_LastNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"LastNode:std.collections.Map<Int,Bool>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1998863);
    return ((t_std_collections_Map_1iz_Node*)0);
  }
  bbDBStmt(2007048);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2011138);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0right)){
      bbDBBlock db_blk;
      bbDBStmt(2015235);
      f0.l_node=f0.l_node->m__0right;
    }
  }
  bbDBStmt(2023426);
  return f0.l_node;
}

t_std_collections_Map_1iz_MapKeys t_std_collections_Map_1iz::m_Keys(){
  bbDBFrame db_f{"Keys:std.collections.Map<Int,Bool>.MapKeys()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return t_std_collections_Map_1iz_MapKeys(this);
}

void t_std_collections_Map_1iz::m_InsertFixup(t_std_collections_Map_1iz_Node* l_node){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    f0_t(t_std_collections_Map_1iz_Node* l_node):l_node(l_node){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{l_node};
  bbDBFrame db_f{"InsertFixup:Void(node:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2433026);
  {
    bbDBLoop db_loop;
    while(((bbBool(f0.l_node->m__0parent)&&(f0.l_node->m__0parent->m__0color==0))&&bbBool(f0.l_node->m__0parent->m__0parent))){
      bbDBBlock db_blk;
      bbDBStmt(2437123);
      if((f0.l_node->m__0parent==f0.l_node->m__0parent->m__0parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1iz_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2441226);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0right;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2445316);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2449413);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2453509);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2457605);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2461701);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2465796);
          bbDBBlock db_blk;
          bbDBStmt(2469893);
          if((f0.l_node==f0.l_node->m__0parent->m__0right)){
            bbDBBlock db_blk;
            bbDBStmt(2473990);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2478086);
            this->m_RotateLeft(f0.l_node);
          }
          bbDBStmt(2486277);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2490373);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2494469);
          this->m_RotateRight(f0.l_node->m__0parent->m__0parent);
        }
      }else{
        bbDBStmt(2502659);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1iz_Node* l_uncle{};
          void gcMark(){
            bbGCMarkPtr(l_uncle);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2506762);
        f2.l_uncle=f0.l_node->m__0parent->m__0parent->m__0left;
        bbDBLocal("uncle",&f2.l_uncle);
        bbDBStmt(2510852);
        if((bbBool(f2.l_uncle)&&(f2.l_uncle->m__0color==0))){
          bbDBBlock db_blk;
          bbDBStmt(2514949);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2519045);
          f2.l_uncle->m__0color=1;
          bbDBStmt(2523141);
          f2.l_uncle->m__0parent->m__0color=0;
          bbDBStmt(2527237);
          f0.l_node=f2.l_uncle->m__0parent;
        }else{
          bbDBStmt(2531332);
          bbDBBlock db_blk;
          bbDBStmt(2535429);
          if((f0.l_node==f0.l_node->m__0parent->m__0left)){
            bbDBBlock db_blk;
            bbDBStmt(2539526);
            f0.l_node=f0.l_node->m__0parent;
            bbDBStmt(2543622);
            this->m_RotateRight(f0.l_node);
          }
          bbDBStmt(2551813);
          f0.l_node->m__0parent->m__0color=1;
          bbDBStmt(2555909);
          f0.l_node->m__0parent->m__0parent->m__0color=0;
          bbDBStmt(2560005);
          this->m_RotateLeft(f0.l_node->m__0parent->m__0parent);
        }
      }
    }
  }
  bbDBStmt(2576386);
  this->m__0root->m__0color=1;
}

bbBool t_std_collections_Map_1iz::m_Get(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Get:Bool(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1843208);
  f0.l_node=this->m_FindNode(l_key);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1847298);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1847306);
    return f0.l_node->m__0value;
  }
  bbDBStmt(1851394);
  return false;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz::m_FirstNode(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FirstNode:std.collections.Map<Int,Bool>.Node()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1957890);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1957903);
    return ((t_std_collections_Map_1iz_Node*)0);
  }
  bbDBStmt(1966088);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node->m__0left)){
      bbDBBlock db_blk;
      bbDBStmt(1974275);
      f0.l_node=f0.l_node->m__0left;
    }
  }
  bbDBStmt(1982466);
  return f0.l_node;
}

t_std_collections_Map_1iz_Node* t_std_collections_Map_1iz::m_FindNode(bbInt l_key){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.Map<Int,Bool>.Node(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(2039816);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2043906);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(2048009);
      bbInt l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBLocal("cmp",&l_cmp);
      bbDBStmt(2052099);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(2060291),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(2064388);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(2068483);
        bbDBBlock db_blk;
        bbDBStmt(2072580);
        return f0.l_node;
      }
    }
  }
  bbDBStmt(2084866);
  return ((t_std_collections_Map_1iz_Node*)0);
}

bbBool t_std_collections_Map_1iz::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1191938);
  return (this->m__0root==((t_std_collections_Map_1iz_Node*)0));
}

void t_std_collections_Map_1iz::m_DeleteFixup(t_std_collections_Map_1iz_Node* l_node,t_std_collections_Map_1iz_Node* l_parent){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    f0_t(t_std_collections_Map_1iz_Node* l_node,t_std_collections_Map_1iz_Node* l_parent):l_node(l_node),l_parent(l_parent){
    }
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{l_node,l_parent};
  bbDBFrame db_f{"DeleteFixup:Void(node:std.collections.Map<Int,Bool>.Node,parent:std.collections.Map<Int,Bool>.Node)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&f0.l_node);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(2596866);
  {
    bbDBLoop db_loop;
    while(((f0.l_node!=this->m__0root)&&(!bbBool(f0.l_node)||(f0.l_node->m__0color==1)))){
      bbDBBlock db_blk;
      bbDBStmt(2605059);
      if((f0.l_node==f0.l_parent->m__0left)){
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1iz_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2613258);
        f2.l_sib=f0.l_parent->m__0right;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2621444);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2625541);
          f2.l_sib->m__0color=1;
          bbDBStmt(2629637);
          f0.l_parent->m__0color=0;
          bbDBStmt(2633733);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2637829);
          f2.l_sib=f0.l_parent->m__0right;
        }
        bbDBStmt(2650116);
        if(((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))&&(!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2654213);
          f2.l_sib->m__0color=0;
          bbDBStmt(2658309);
          f0.l_node=f0.l_parent;
          bbDBStmt(2662405);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2666500);
          bbDBBlock db_blk;
          bbDBStmt(2670597);
          if((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2674694);
            f2.l_sib->m__0left->m__0color=1;
            bbDBStmt(2678790);
            f2.l_sib->m__0color=0;
            bbDBStmt(2682886);
            this->m_RotateRight(f2.l_sib);
            bbDBStmt(2686982);
            f2.l_sib=f0.l_parent->m__0right;
          }
          bbDBStmt(2695173);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2699269);
          f0.l_parent->m__0color=1;
          bbDBStmt(2703365);
          f2.l_sib->m__0right->m__0color=1;
          bbDBStmt(2707461);
          this->m_RotateLeft(f0.l_parent);
          bbDBStmt(2711557);
          f0.l_node=this->m__0root;
        }
      }else{
        bbDBStmt(2719747);
        struct f2_t : public bbGCFrame{
          t_std_collections_Map_1iz_Node* l_sib{};
          void gcMark(){
            bbGCMarkPtr(l_sib);
          }
        }f2{};
        bbDBBlock db_blk;
        bbDBStmt(2723850);
        f2.l_sib=f0.l_parent->m__0left;
        bbDBLocal("sib",&f2.l_sib);
        bbDBStmt(2732036);
        if((f2.l_sib->m__0color==0)){
          bbDBBlock db_blk;
          bbDBStmt(2736133);
          f2.l_sib->m__0color=1;
          bbDBStmt(2740229);
          f0.l_parent->m__0color=0;
          bbDBStmt(2744325);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2748421);
          f2.l_sib=f0.l_parent->m__0left;
        }
        bbDBStmt(2760708);
        if(((!bbBool(f2.l_sib->m__0right)||(f2.l_sib->m__0right->m__0color==1))&&(!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1)))){
          bbDBBlock db_blk;
          bbDBStmt(2764805);
          f2.l_sib->m__0color=0;
          bbDBStmt(2768901);
          f0.l_node=f0.l_parent;
          bbDBStmt(2772997);
          f0.l_parent=f0.l_parent->m__0parent;
        }else{
          bbDBStmt(2777092);
          bbDBBlock db_blk;
          bbDBStmt(2781189);
          if((!bbBool(f2.l_sib->m__0left)||(f2.l_sib->m__0left->m__0color==1))){
            bbDBBlock db_blk;
            bbDBStmt(2785286);
            f2.l_sib->m__0right->m__0color=1;
            bbDBStmt(2789382);
            f2.l_sib->m__0color=0;
            bbDBStmt(2793478);
            this->m_RotateLeft(f2.l_sib);
            bbDBStmt(2797574);
            f2.l_sib=f0.l_parent->m__0left;
          }
          bbDBStmt(2805765);
          f2.l_sib->m__0color=f0.l_parent->m__0color;
          bbDBStmt(2809861);
          f0.l_parent->m__0color=1;
          bbDBStmt(2813957);
          f2.l_sib->m__0left->m__0color=1;
          bbDBStmt(2818053);
          this->m_RotateRight(f0.l_parent);
          bbDBStmt(2822149);
          f0.l_node=this->m__0root;
        }
      }
    }
  }
  bbDBStmt(2838530);
  if(bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(2838538);
    f0.l_node->m__0color=1;
  }
}

bbInt t_std_collections_Map_1iz::m_Count(){
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1150991);
    return bbInt(0);
  }
  bbDBStmt(1155074);
  return this->m__0root->m_Count(bbInt(0));
}

t_std_collections_Map_1iz* t_std_collections_Map_1iz::m_Copy(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_root{};
    void gcMark(){
      bbGCMarkPtr(l_root);
    }
  }f0{};
  bbDBFrame db_f{"Copy:std.collections.Map<Int,Bool>()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1081352);
  bbDBLocal("root",&f0.l_root);
  bbDBStmt(1085442);
  if(bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1085451);
    f0.l_root=this->m__0root->m_Copy(((t_std_collections_Map_1iz_Node*)0));
  }
  bbDBStmt(1089538);
  return bbGCNew<t_std_collections_Map_1iz>(f0.l_root);
}

bbBool t_std_collections_Map_1iz::m_Contains(bbInt l_key){
  bbDBFrame db_f{"Contains:Bool(key:Int)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(1236994);
  return (this->m_FindNode(l_key)!=((t_std_collections_Map_1iz_Node*)0));
}

void t_std_collections_Map_1iz::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1114114);
  this->m__0root=((t_std_collections_Map_1iz_Node*)0);
}

t_std_collections_Map_1iz_Iterator t_std_collections_Map_1iz::m_All(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"All:std.collections.Map<Int,Bool>.Iterator()","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  return t_std_collections_Map_1iz_Iterator(f0.t0=this->m_FirstNode());
}

bbBool t_std_collections_Map_1iz::m_Add(bbInt l_key,bbBool l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1iz_Node* l_node{};
    t_std_collections_Map_1iz_Node* l_parent{};
    void gcMark(){
      bbGCMarkPtr(l_node);
      bbGCMarkPtr(l_parent);
    }
  }f0{};
  bbDBFrame db_f{"Add:Bool(key:Int,value:Bool)","/home/pi/monkey2/modules/std/collections/map.monkey2"};
  t_std_collections_Map_1iz*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBLocal("value",&l_value);
  bbDBStmt(1613826);
  if(!bbBool(this->m__0root)){
    bbDBBlock db_blk;
    bbDBStmt(1617923);
    this->m__0root=bbGCNew<t_std_collections_Map_1iz_Node>(l_key,l_value,0,((t_std_collections_Map_1iz_Node*)0));
    bbDBStmt(1622019);
    return true;
  }
  bbDBStmt(1634312);
  f0.l_node=this->m__0root;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1634324);
  bbDBLocal("parent",&f0.l_parent);
  bbDBStmt(1634336);
  bbInt l_cmp{};
  bbDBLocal("cmp",&l_cmp);
  bbDBStmt(1642498);
  {
    bbDBLoop db_loop;
    while(bbBool(f0.l_node)){
      bbDBBlock db_blk;
      bbDBStmt(1646595);
      f0.l_parent=f0.l_node;
      bbDBStmt(1650691);
      l_cmp=bbCompare(l_key,f0.l_node->m__0key);
      bbDBStmt(1654787);
      if((l_cmp>bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1658884);
        f0.l_node=f0.l_node->m__0right;
      }else if(bbDBStmt(1662979),(l_cmp<bbInt(0))){
        bbDBBlock db_blk;
        bbDBStmt(1667076);
        f0.l_node=f0.l_node->m__0left;
      }else{
        bbDBStmt(1671171);
        bbDBBlock db_blk;
        bbDBStmt(1675268);
        return false;
      }
    }
  }
  bbDBStmt(1691650);
  f0.l_node=bbGCNew<t_std_collections_Map_1iz_Node>(l_key,l_value,0,f0.l_parent);
  bbDBStmt(1699842);
  if((l_cmp>bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(1699851);
    f0.l_parent->m__0right=f0.l_node;
  }else{
    bbDBStmt(1699870);
    bbDBBlock db_blk;
    bbDBStmt(1699875);
    f0.l_parent->m__0left=f0.l_node;
  }
  bbDBStmt(1708034);
  this->m_InsertFixup(f0.l_node);
  bbDBStmt(1716226);
  return true;
}
bbString bbDBType(t_std_collections_Map_1iz**){
  return "std.collections.Map<Int,Bool>";
}
bbString bbDBValue(t_std_collections_Map_1iz**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_std_collections_2map_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_collections_2map_init_v("mojo_std_collections_2map",&mx2_mojo_std_collections_2map_init);
