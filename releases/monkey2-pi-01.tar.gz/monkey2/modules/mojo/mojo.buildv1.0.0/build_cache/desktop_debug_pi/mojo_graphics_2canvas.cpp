
#include "../../desktop_debug_pi/mojo_graphics_2canvas.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_graphics_2device.h"
#include "../../desktop_debug_pi/mojo_graphics_2font.h"
#include "../../desktop_debug_pi/mojo_graphics_2image.h"
#include "../../desktop_debug_pi/mojo_graphics_2material.h"
#include "../../desktop_debug_pi/mojo_graphics_2shader.h"
#include "../../desktop_debug_pi/mojo_graphics_2texture.h"
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_collections_2stack.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_graphics_2pixmap.h"

extern t_std_geom_Rect_1i g_std_geom_TransformRecti_1f(t_std_geom_Rect_1i l_rect,t_std_geom_AffineMat3_1f l_matrix);
extern bbString g_std_stringio_LoadString(bbString l_path);
extern bbInt g_monkey_math_Min_1i(bbInt l_x,bbInt l_y);
extern bbInt g_monkey_math_Max_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

bbGCRootVar<t_mojo_graphics_ShaderEnv> g_mojo_graphics_Canvas__0ambientEnv;
bbGCRootVar<t_mojo_graphics_Font> g_mojo_graphics_Canvas__0defaultFont;
bbBool g_mojo_graphics_Canvas__0inited;
bbGCRootVar<t_mojo_graphics_Shader> g_mojo_graphics_Canvas__0nullShader;

void t_mojo_graphics_DrawOp::gcMark(){
  bbGCMark(m_material);
}

void t_mojo_graphics_DrawOp::dbEmit(){
  bbDBEmit("blendMode",&m_blendMode);
  bbDBEmit("material",&m_material);
  bbDBEmit("order",&m_order);
  bbDBEmit("count",&m_count);
}
bbString bbDBType(t_mojo_graphics_DrawOp**){
  return "mojo.graphics.DrawOp";
}
bbString bbDBValue(t_mojo_graphics_DrawOp**p){
  return bbDBObjectValue(*p);
}

void t_mojo_graphics_Canvas::init(){
  m__0renderMatrixStack=bbGCNew<t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2>();
  m__0renderBoundsStack=bbGCNew<t_std_collections_Stack_1Tt_std_geom_Rect_1i_2>();
  m__0matrixStack=bbGCNew<t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2>();
  m__0ops=bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2>();
  m__0op=bbGCNew<t_mojo_graphics_DrawOp>();
  m__0vertices=bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2>();
  m__0materials=bbArray<bbGCVar<t_mojo_graphics_Material>>::create(6);
}

void t_mojo_graphics_Canvas::gcMark(){
  bbGCMark(m__0target);
  bbGCMark(m__0envParams);
  bbGCMark(m__0device);
  bbGCMark(m__0renderMatrixStack);
  bbGCMark(m__0renderBoundsStack);
  bbGCMark(m__0font);
  bbGCMark(m__0matrixStack);
  bbGCMark(m__0ops);
  bbGCMark(m__0op);
  bbGCMark(m__0vertices);
  bbGCMark(m__0vertexData);
  bbGCMark(m__0materials);
}

void t_mojo_graphics_Canvas::dbEmit(){
  bbDBEmit("_dirty",&m__0dirty);
  bbDBEmit("_target",&m__0target);
  bbDBEmit("_targetSize",&m__0targetSize);
  bbDBEmit("_targetRect",&m__0targetRect);
  bbDBEmit("_envParams",&m__0envParams);
  bbDBEmit("_device",&m__0device);
  bbDBEmit("_viewport",&m__0viewport);
  bbDBEmit("_scissor",&m__0scissor);
  bbDBEmit("_viewMatrix",&m__0viewMatrix);
  bbDBEmit("_modelMatrix",&m__0modelMatrix);
  bbDBEmit("_ambientLight",&m__0ambientLight);
  bbDBEmit("_filter",&m__0filter);
  bbDBEmit("_renderColor",&m__0renderColor);
  bbDBEmit("_renderMatrix",&m__0renderMatrix);
  bbDBEmit("_renderMatrixStack",&m__0renderMatrixStack);
  bbDBEmit("_renderBounds",&m__0renderBounds);
  bbDBEmit("_renderBoundsStack",&m__0renderBoundsStack);
  bbDBEmit("_font",&m__0font);
  bbDBEmit("_alpha",&m__0alpha);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_pmcolor",&m__0pmcolor);
  bbDBEmit("_matrix",&m__0matrix);
  bbDBEmit("_blendMode",&m__0blendMode);
  bbDBEmit("_matrixStack",&m__0matrixStack);
  bbDBEmit("_ops",&m__0ops);
  bbDBEmit("_op",&m__0op);
  bbDBEmit("_vertices",&m__0vertices);
  bbDBEmit("_vertexData",&m__0vertexData);
  bbDBEmit("_vertex",&m__0vertex);
  bbDBEmit("_materials",&m__0materials);
}

t_mojo_graphics_Canvas::t_mojo_graphics_Canvas(bbInt l_width,bbInt l_height){
  init();
  bbDBFrame db_f{"new:Void(width:Int,height:Int)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBStmt(274434);
  this->m_Init(((t_mojo_graphics_Texture*)0),t_std_geom_Vec2_1i(l_width,l_height),t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_width,l_height));
}

t_mojo_graphics_Canvas::t_mojo_graphics_Canvas(t_mojo_graphics_Texture* l_texture){
  init();
  bbDBFrame db_f{"new:Void(texture:mojo.graphics.Texture)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  bbDBLocal("texture",&l_texture);
  bbDBStmt(237570);
  this->m_Init(l_texture,l_texture->m_Rect().m_Size(),l_texture->m_Rect());
  bbDBStmt(245762);
  this->m_BeginRender(l_texture->m_Rect(),t_std_geom_AffineMat3_1f(bbNullCtor));
}

t_mojo_graphics_Canvas::t_mojo_graphics_Canvas(t_mojo_graphics_Image* l_image){
  init();
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* t0{};
    t_mojo_graphics_Texture* t1{};
    void gcMark(){
      bbGCMarkPtr(t0);
      bbGCMarkPtr(t1);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(image:mojo.graphics.Image)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  bbDBLocal("image",&l_image);
  bbDBStmt(200706);
  this->m_Init(f0.t0=l_image->m_Texture(),(f0.t1=l_image->m_Texture())->m_Rect().m_Size(),l_image->m_Rect());
  bbDBStmt(208898);
  this->m_BeginRender(t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_image->m_Rect().m_Size()),t_std_geom_AffineMat3_1f(bbNullCtor));
}

void t_mojo_graphics_Canvas::m_Viewport(t_std_geom_Rect_1i l_viewport){
  bbDBFrame db_f{"Viewport:Void(viewport:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("viewport",&l_viewport);
  bbDBStmt(339970);
  this->m_Flush();
  bbDBStmt(348162);
  this->m__0viewport=l_viewport;
  bbDBStmt(356354);
  this->m__0dirty|=6;
}

t_std_geom_Rect_1i t_mojo_graphics_Canvas::m_Viewport(){
  bbDBFrame db_f{"Viewport:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323586);
  return this->m__0viewport;
}

void t_mojo_graphics_Canvas::m_ViewMatrix(t_std_geom_Mat4_1f l_viewMatrix){
  bbDBFrame db_f{"ViewMatrix:Void(viewMatrix:Mat4f:std.geom.Mat4<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("viewMatrix",&l_viewMatrix);
  bbDBStmt(483330);
  this->m_Flush();
  bbDBStmt(491522);
  this->m__0viewMatrix=l_viewMatrix;
  bbDBStmt(499714);
  this->m__0dirty|=4;
}

t_std_geom_Mat4_1f t_mojo_graphics_Canvas::m_ViewMatrix(){
  bbDBFrame db_f{"ViewMatrix:Mat4f:std.geom.Mat4<Float>()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(466946);
  return this->m__0viewMatrix;
}

void t_mojo_graphics_Canvas::m_Validate(){
  bbDBFrame db_f{"Validate:Void()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3862530);
  if(!bbBool(this->m__0dirty)){
    bbDBBlock db_blk;
    bbDBStmt(3862544);
    return;
  }
  bbDBStmt(3870722);
  if(bbBool((this->m__0dirty&1))){
    bbDBBlock db_blk;
    bbDBStmt(3878921);
    t_std_geom_Mat4_1f l_projMatrix{};
    bbDBLocal("projMatrix",&l_projMatrix);
    bbDBStmt(3883017);
    t_std_geom_Rect_1i l_viewport=this->m__0targetRect;
    bbDBLocal("viewport",&l_viewport);
    bbDBStmt(3891203);
    if(bbBool(this->m__0target)){
      bbDBBlock db_blk;
      bbDBStmt(3895300);
      l_projMatrix=g_std_geom_Mat4_1f_Ortho(0.0f,bbFloat(l_viewport.m_Width()),0.0f,bbFloat(l_viewport.m_Height()),bbFloat(-1),1.0f);
    }else{
      bbDBStmt(3899395);
      bbDBBlock db_blk;
      bbDBStmt(3903492);
      l_viewport.m_min.m_y=(this->m__0targetSize.m_y-l_viewport.m_max.m_y);
      bbDBStmt(3907588);
      l_viewport.m_max.m_y=(l_viewport.m_min.m_y+l_viewport.m_Height());
      bbDBStmt(3911684);
      l_projMatrix=g_std_geom_Mat4_1f_Ortho(0.0f,bbFloat(l_viewport.m_Width()),bbFloat(l_viewport.m_Height()),0.0f,bbFloat(-1),1.0f);
    }
    bbDBStmt(3923971);
    this->m__0device->m_RenderTarget(this->m__0target);
    bbDBStmt(3928067);
    this->m__0device->m_Viewport(this->m__0targetRect);
    bbDBStmt(3932163);
    this->m__0envParams->m_SetMatrix(BB_T("mx2_ProjectionMatrix"),l_projMatrix);
    bbDBStmt(3940355);
    this->m__0dirty|=4;
  }
  bbDBStmt(3956738);
  if(bbBool((this->m__0dirty&4))){
    bbDBBlock db_blk;
    bbDBStmt(3964937);
    t_std_geom_AffineMat3_1f l_renderMatrix=this->m__0renderMatrix.m_Translate(t_std_geom_Vec2_1f(bbFloat(this->m__0viewport.m_X()),bbFloat(this->m__0viewport.m_Y())));
    bbDBLocal("renderMatrix",&l_renderMatrix);
    bbDBStmt(3973129);
    t_std_geom_Mat4_1f l_modelViewMatrix=this->m__0viewMatrix.m__mul(this->m__0modelMatrix).m__mul(t_std_geom_Mat4_1f(l_renderMatrix));
    bbDBLocal("modelViewMatrix",&l_modelViewMatrix);
    bbDBStmt(3981315);
    this->m__0envParams->m_SetMatrix(BB_T("mx2_ModelViewMatrix"),l_modelViewMatrix);
    bbDBStmt(3985411);
    this->m__0envParams->m_SetColor(BB_T("mx2_AmbientLight"),this->m__0ambientLight);
    bbDBStmt(3989507);
    this->m__0envParams->m_SetColor(BB_T("mx2_RenderColor"),this->m__0renderColor);
    bbDBStmt(3997699);
    this->m__0device->m_EnvParams(this->m__0envParams);
  }
  bbDBStmt(4014082);
  if(bbBool((this->m__0dirty&2))){
    bbDBBlock db_blk;
    bbDBStmt(4022281);
    t_std_geom_Rect_1i l_scissor=g_std_geom_TransformRecti_1f(this->m__0viewport.m__and(this->m__0scissor.m__add(this->m__0viewport.m_Origin())),this->m__0renderMatrix);
    bbDBLocal("scissor",&l_scissor);
    bbDBStmt(4030467);
    l_scissor=l_scissor.m__and(this->m__0renderBounds).m__add(this->m__0targetRect.m_Origin());
    bbDBStmt(4038659);
    if(!bbBool(this->m__0target)){
      bbDBBlock db_blk;
      bbDBStmt(4042762);
      bbInt l_h=l_scissor.m_Height();
      bbDBLocal("h",&l_h);
      bbDBStmt(4046852);
      l_scissor.m_min.m_y=(this->m__0targetSize.m_y-l_scissor.m_max.m_y);
      bbDBStmt(4050948);
      l_scissor.m_max.m_y=(l_scissor.m_min.m_y+l_h);
    }
    bbDBStmt(4063235);
    this->m__0device->m_Scissor(l_scissor);
  }
  bbDBStmt(4075522);
  this->m__0dirty=bbInt(0);
}

void t_mojo_graphics_Canvas::m_Translate(bbFloat l_tx,bbFloat l_ty){
  bbDBFrame db_f{"Translate:Void(tx:Float,ty:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("tx",&l_tx);
  bbDBLocal("ty",&l_ty);
  bbDBStmt(1638402);
  this->m_Matrix(this->m_Matrix().m_Translate(l_tx,l_ty));
}

void t_mojo_graphics_Canvas::m_TextureFilteringEnabled(bbBool l_enabled){
  bbDBFrame db_f{"TextureFilteringEnabled:Void(enabled:Bool)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("enabled",&l_enabled);
  bbDBStmt(741378);
  this->m_Flush();
  bbDBStmt(749570);
  this->m__0filter=l_enabled;
}

bbBool t_mojo_graphics_Canvas::m_TextureFilteringEnabled(){
  bbDBFrame db_f{"TextureFilteringEnabled:Bool()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(724994);
  return this->m__0filter;
}

void t_mojo_graphics_Canvas::m_Scissor(t_std_geom_Rect_1i l_scissor){
  bbDBFrame db_f{"Scissor:Void(scissor:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("scissor",&l_scissor);
  bbDBStmt(421890);
  this->m_Flush();
  bbDBStmt(430082);
  this->m__0scissor=l_scissor;
  bbDBStmt(438274);
  this->m__0dirty|=2;
}

t_std_geom_Rect_1i t_mojo_graphics_Canvas::m_Scissor(){
  bbDBFrame db_f{"Scissor:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(405506);
  return this->m__0scissor;
}

void t_mojo_graphics_Canvas::m_Scale(bbFloat l_sx,bbFloat l_sy){
  bbDBFrame db_f{"Scale:Void(sx:Float,sy:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("sx",&l_sx);
  bbDBLocal("sy",&l_sy);
  bbDBStmt(1744898);
  this->m_Matrix(this->m_Matrix().m_Scale(l_sx,l_sy));
}

void t_mojo_graphics_Canvas::m_Rotate(bbFloat l_rz){
  bbDBFrame db_f{"Rotate:Void(rz:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rz",&l_rz);
  bbDBStmt(1687554);
  this->m_Matrix(this->m_Matrix().m_Rotate(bbDouble(l_rz)));
}

void t_mojo_graphics_Canvas::m_Resize(t_std_geom_Vec2_1i l_size){
  bbDBFrame db_f{"Resize:Void(size:Vec2i:std.geom.Vec2<Int>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("size",&l_size);
  bbDBStmt(778242);
  this->m_Flush();
  bbDBStmt(786434);
  this->m__0targetSize=l_size;
  bbDBStmt(790530);
  this->m__0targetRect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_size);
  bbDBStmt(798722);
  this->m__0dirty|=1;
}

void t_mojo_graphics_Canvas::m_RenderDrawOps(){
  bbDBFrame db_f{"RenderDrawOps:Void()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(4096008);
  t_mojo_graphics_Vertex2f* l_p=this->m__0vertexData->data();
  bbDBLocal("p",&l_p);
  bbDBStmt(4104194);
  this->m__0device->m_FilteringEnabled(this->m__0filter);
  bbDBStmt(4112386);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=this->m__0ops->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_DrawOp* l_op{};
        t_mojo_graphics_Shader* t0{};
        t_mojo_graphics_ParamBuffer* t1{};
        void gcMark(){
          bbGCMarkPtr(l_op);
          bbGCMarkPtr(t0);
          bbGCMarkPtr(t1);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_op=f1.l_0.m_Current();
      bbDBLocal("op",&f2.l_op);
      bbDBStmt(4116483);
      this->m__0device->m_BlendMode(f2.l_op->m_blendMode);
      bbDBStmt(4120579);
      this->m__0device->m_Shader(f2.t0=f2.l_op->m_material->m_Shader());
      bbDBStmt(4124675);
      this->m__0device->m_Params(f2.t1=f2.l_op->m_material->m_Params());
      bbDBStmt(4128771);
      this->m__0device->m_Render(l_p,f2.l_op->m_order,f2.l_op->m_count);
      bbDBStmt(4132867);
      l_p=(l_p+(f2.l_op->m_order*f2.l_op->m_count));
    }
  }
}

void t_mojo_graphics_Canvas::m_RenderColor(t_std_graphics_Color l_renderColor){
  bbDBFrame db_f{"RenderColor:Void(renderColor:std.graphics.Color)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("renderColor",&l_renderColor);
  bbDBStmt(667650);
  this->m_Flush();
  bbDBStmt(675842);
  this->m__0renderColor=l_renderColor;
  bbDBStmt(684034);
  this->m__0dirty|=4;
}

t_std_graphics_Color t_mojo_graphics_Canvas::m_RenderColor(){
  bbDBFrame db_f{"RenderColor:std.graphics.Color()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(651266);
  return this->m__0renderColor;
}

void t_mojo_graphics_Canvas::m_PushMatrix(){
  bbDBFrame db_f{"PushMatrix:Void()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1519618);
  this->m__0matrixStack->m_Push(this->m_Matrix());
}

bbArray<bbGCVar<t_mojo_graphics_Material>>* t_mojo_graphics_Canvas::m_PrimitiveMaterials(){
  bbDBFrame db_f{"PrimitiveMaterials:mojo.graphics.Material[]()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1486850);
  return this->m__0materials;
}

void t_mojo_graphics_Canvas::m_PopMatrix(){
  bbDBFrame db_f{"PopMatrix:Void()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1552386);
  this->m_Matrix(this->m__0matrixStack->m_Pop());
}

void t_mojo_graphics_Canvas::m_ModelMatrix(t_std_geom_Mat4_1f l_modelMatrix){
  bbDBFrame db_f{"ModelMatrix:Void(modelMatrix:Mat4f:std.geom.Mat4<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("modelMatrix",&l_modelMatrix);
  bbDBStmt(544770);
  this->m_Flush();
  bbDBStmt(552962);
  this->m__0modelMatrix=l_modelMatrix;
  bbDBStmt(561154);
  this->m__0dirty|=4;
}

t_std_geom_Mat4_1f t_mojo_graphics_Canvas::m_ModelMatrix(){
  bbDBFrame db_f{"ModelMatrix:Mat4f:std.geom.Mat4<Float>()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(528386);
  return this->m__0modelMatrix;
}

void t_mojo_graphics_Canvas::m_Matrix(t_std_geom_AffineMat3_1f l_matrix){
  bbDBFrame db_f{"Matrix:Void(matrix:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("matrix",&l_matrix);
  bbDBStmt(1409026);
  this->m__0matrix=l_matrix;
}

t_std_geom_AffineMat3_1f t_mojo_graphics_Canvas::m_Matrix(){
  bbDBFrame db_f{"Matrix:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1392642);
  return this->m__0matrix;
}

void t_mojo_graphics_Canvas::m_Init(t_mojo_graphics_Texture* l_target,t_std_geom_Vec2_1i l_size,t_std_geom_Rect_1i l_viewport){
  bbDBFrame db_f{"Init:Void(target:mojo.graphics.Texture,size:Vec2i:std.geom.Vec2<Int>,viewport:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("target",&l_target);
  bbDBLocal("size",&l_size);
  bbDBLocal("viewport",&l_viewport);
  bbDBStmt(3694594);
  if(!g_mojo_graphics_Canvas__0inited){
    bbDBBlock db_blk;
    bbDBStmt(3698691);
    g_mojo_graphics_Canvas__0inited=true;
    bbDBStmt(3702793);
    bbString l_env=g_std_stringio_LoadString(BB_T("asset::mojo/shader_env.glsl"));
    bbDBLocal("env",&l_env);
    bbDBStmt(3706883);
    g_mojo_graphics_Canvas__0ambientEnv=bbGCNew<t_mojo_graphics_ShaderEnv>((BB_T("#define RENDERPASS_AMBIENT\n")+l_env));
    bbDBStmt(3715075);
    g_mojo_graphics_Canvas__0defaultFont=g_mojo_graphics_Font_Load(BB_T("asset::mojo/RobotoMono-Regular.ttf"),16.0f,bbInt(0),((t_mojo_graphics_Shader*)0));
    bbDBStmt(3719171);
    g_mojo_graphics_Canvas__0nullShader=g_mojo_graphics_Shader_GetShader(BB_T("null"));
  }
  bbDBStmt(3731458);
  this->m__0target=l_target;
  bbDBStmt(3735554);
  this->m__0targetSize=l_size;
  bbDBStmt(3739650);
  this->m__0targetRect=l_viewport;
  bbDBStmt(3747842);
  this->m__0envParams=bbGCNew<t_mojo_graphics_ParamBuffer>();
  bbDBStmt(3751938);
  this->m__0device=bbGCNew<t_mojo_graphics_GraphicsDevice>();
  bbDBStmt(3760130);
  this->m__0viewport=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m__0targetRect.m_Width(),this->m__0targetRect.m_Height());
  bbDBStmt(3764226);
  this->m__0scissor=this->m__0viewport;
  bbDBStmt(3768322);
  this->m__0viewMatrix=t_std_geom_Mat4_1f(bbNullCtor);
  bbDBStmt(3772418);
  this->m__0modelMatrix=t_std_geom_Mat4_1f(bbNullCtor);
  bbDBStmt(3776514);
  this->m__0ambientLight=g_std_graphics_Color_Black;
  bbDBStmt(3780610);
  this->m__0filter=true;
  bbDBStmt(3788802);
  this->m__0renderColor=g_std_graphics_Color_White;
  bbDBStmt(3792898);
  this->m__0renderMatrix=t_std_geom_AffineMat3_1f(bbNullCtor);
  bbDBStmt(3796994);
  this->m__0renderBounds=t_std_geom_Rect_1i(bbInt(0),bbInt(0),1073741824,1073741824);
  bbDBStmt(3805186);
  this->m__0dirty=7;
  bbDBStmt(3813378);
  this->m_Font(((t_mojo_graphics_Font*)0));
  bbDBStmt(3817474);
  this->m_Alpha(1.0f);
  bbDBStmt(3821570);
  this->m_Color(g_std_graphics_Color_White);
  bbDBStmt(3825666);
  this->m_Matrix(t_std_geom_AffineMat3_1f(bbNullCtor));
  bbDBStmt(3829762);
  this->m_BlendMode(1);
  bbDBStmt(3833858);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(3833858);
    for(;(l_i<this->m__0materials->length());l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(3837955);
      this->m__0materials->at(l_i)=bbGCNew<t_mojo_graphics_Material>(g_mojo_graphics_Canvas__0nullShader);
    }
  }
}

void t_mojo_graphics_Canvas::m_Font(t_mojo_graphics_Font* l_font){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Font* l_font{};
    f0_t(t_mojo_graphics_Font* l_font):l_font(l_font){
    }
    void gcMark(){
      bbGCMarkPtr(l_font);
    }
  }f0{l_font};
  bbDBFrame db_f{"Font:Void(font:mojo.graphics.Font)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("font",&f0.l_font);
  bbDBStmt(1204226);
  if(!bbBool(f0.l_font)){
    bbDBBlock db_blk;
    bbDBStmt(1204238);
    f0.l_font=g_mojo_graphics_Canvas__0defaultFont;
  }
  bbDBStmt(1212418);
  this->m__0font=f0.l_font;
}

t_mojo_graphics_Font* t_mojo_graphics_Canvas::m_Font(){
  bbDBFrame db_f{"Font:mojo.graphics.Font()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0font;
}

void t_mojo_graphics_Canvas::m_Flush(){
  bbDBFrame db_f{"Flush:Void()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1122306);
  this->m_Validate();
  bbDBStmt(1130498);
  this->m_RenderDrawOps();
  bbDBStmt(1138690);
  this->m_ClearDrawOps();
}

void t_mojo_graphics_Canvas::m_EndRender(){
  bbDBFrame db_f{"EndRender:Void()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1064962);
  this->m_Flush();
  bbDBStmt(1073154);
  this->m__0renderBounds=this->m__0renderBoundsStack->m_Pop();
  bbDBStmt(1077250);
  this->m__0renderMatrix=this->m__0renderMatrixStack->m_Pop();
}

void t_mojo_graphics_Canvas::m_DrawTriangle(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1,bbFloat l_x2,bbFloat l_y2){
  bbDBFrame db_f{"DrawTriangle:Void(x0:Float,y0:Float,x1:Float,y1:Float,x2:Float,y2:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x0",&l_x0);
  bbDBLocal("y0",&l_y0);
  bbDBLocal("x1",&l_x1);
  bbDBLocal("y1",&l_y1);
  bbDBLocal("x2",&l_x2);
  bbDBLocal("y2",&l_y2);
  bbDBStmt(2048002);
  this->m_AddDrawOp(this->m__0materials->at(3),3,1);
  bbDBStmt(2052098);
  this->m_AddVertex(l_x0,l_y0,0.0f,0.0f);
  bbDBStmt(2056194);
  this->m_AddVertex(l_x1,l_y1,1.0f,0.0f);
  bbDBStmt(2060290);
  this->m_AddVertex(l_x2,l_y2,1.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawTriangle(t_std_geom_Vec2_1f l_v0,t_std_geom_Vec2_1f l_v1,t_std_geom_Vec2_1f l_v2){
  bbDBFrame db_f{"DrawTriangle:Void(v0:Vec2f:std.geom.Vec2<Float>,v1:Vec2f:std.geom.Vec2<Float>,v2:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("v0",&l_v0);
  bbDBLocal("v1",&l_v1);
  bbDBLocal("v2",&l_v2);
  bbDBStmt(2019330);
  this->m_AddDrawOp(this->m__0materials->at(3),3,1);
  bbDBStmt(2023426);
  this->m_AddVertex(l_v0.m_x,l_v0.m_y,.5f,0.0f);
  bbDBStmt(2027522);
  this->m_AddVertex(l_v1.m_x,l_v1.m_y,1.0f,1.0f);
  bbDBStmt(2031618);
  this->m_AddVertex(l_v2.m_x,l_v2.m_y,0.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawText(bbString l_text,bbFloat l_tx,bbFloat l_ty,bbFloat l_handleX,bbFloat l_handleY){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Image* l_image{};
    t_mojo_graphics_Texture* t0{};
    t_mojo_graphics_Material* t1{};
    void gcMark(){
      bbGCMarkPtr(l_image);
      bbGCMarkPtr(t0);
      bbGCMarkPtr(t1);
    }
  }f0{};
  bbDBFrame db_f{"DrawText:Void(text:String,tx:Float,ty:Float,handleX:Float,handleY:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("text",&l_text);
  bbDBLocal("tx",&l_tx);
  bbDBLocal("ty",&l_ty);
  bbDBLocal("handleX",&l_handleX);
  bbDBLocal("handleY",&l_handleY);
  bbDBStmt(3268610);
  l_tx-=(this->m__0font->m_TextWidth(l_text)*l_handleX);
  bbDBStmt(3272706);
  l_ty-=(this->m__0font->m_Height()*l_handleY);
  bbDBStmt(3280904);
  f0.l_image=this->m__0font->m_Image();
  bbDBLocal("image",&f0.l_image);
  bbDBStmt(3285000);
  bbInt l_sx=f0.l_image->m_Rect().m_min.m_x;
  bbDBLocal("sx",&l_sx);
  bbDBStmt(3285021);
  bbInt l_sy=f0.l_image->m_Rect().m_min.m_y;
  bbDBLocal("sy",&l_sy);
  bbDBStmt(3289096);
  bbInt l_tw=(f0.t0=f0.l_image->m_Texture())->m_Width();
  bbDBLocal("tw",&l_tw);
  bbDBStmt(3289120);
  bbInt l_th=(f0.t0=f0.l_image->m_Texture())->m_Height();
  bbDBLocal("th",&l_th);
  bbDBStmt(3297282);
  this->m_AddDrawOp(f0.t1=f0.l_image->m_Material(),4,l_text.length());
  bbDBStmt(3305474);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_text.length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      bbDBBlock db_blk;
      bbInt l_char=l_text[l_0];
      bbDBLocal("char",&l_char);
      bbDBStmt(3313673);
      t_mojo_graphics_Glyph l_g=this->m__0font->m_GetGlyph(l_char);
      bbDBLocal("g",&l_g);
      bbDBStmt(3321865);
      bbFloat l_s0=(bbFloat((l_g.m_rect.m_min.m_x+l_sx))/bbFloat(l_tw));
      bbDBLocal("s0",&l_s0);
      bbDBStmt(3325961);
      bbFloat l_t0=(bbFloat((l_g.m_rect.m_min.m_y+l_sy))/bbFloat(l_th));
      bbDBLocal("t0",&l_t0);
      bbDBStmt(3330057);
      bbFloat l_s1=(bbFloat((l_g.m_rect.m_max.m_x+l_sx))/bbFloat(l_tw));
      bbDBLocal("s1",&l_s1);
      bbDBStmt(3334153);
      bbFloat l_t1=(bbFloat((l_g.m_rect.m_max.m_y+l_sy))/bbFloat(l_th));
      bbDBLocal("t1",&l_t1);
      bbDBStmt(3342345);
      bbDouble l_x0=std::round(bbDouble((l_tx+l_g.m_offset.m_x)));
      bbDBLocal("x0",&l_x0);
      bbDBStmt(3346441);
      bbDouble l_y0=std::round(bbDouble((l_ty+l_g.m_offset.m_y)));
      bbDBLocal("y0",&l_y0);
      bbDBStmt(3350537);
      bbDouble l_x1=(l_x0+bbDouble(l_g.m_rect.m_Width()));
      bbDBLocal("x1",&l_x1);
      bbDBStmt(3354633);
      bbDouble l_y1=(l_y0+bbDouble(l_g.m_rect.m_Height()));
      bbDBLocal("y1",&l_y1);
      bbDBStmt(3362819);
      this->m_AddVertex(bbFloat(l_x0),bbFloat(l_y0),l_s0,l_t0);
      bbDBStmt(3366915);
      this->m_AddVertex(bbFloat(l_x1),bbFloat(l_y0),l_s1,l_t0);
      bbDBStmt(3371011);
      this->m_AddVertex(bbFloat(l_x1),bbFloat(l_y1),l_s1,l_t1);
      bbDBStmt(3375107);
      this->m_AddVertex(bbFloat(l_x0),bbFloat(l_y1),l_s0,l_t1);
      bbDBStmt(3383299);
      l_tx+=l_g.m_advance;
    }
  }
}

void t_mojo_graphics_Canvas::m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height,t_mojo_graphics_Image* l_srcImage,bbInt l_srcX,bbInt l_srcY,bbInt l_srcWidth,bbInt l_srcHeight){
  bbDBFrame db_f{"DrawRect:Void(x:Float,y:Float,width:Float,height:Float,srcImage:mojo.graphics.Image,srcX:Int,srcY:Int,srcWidth:Int,srcHeight:Int)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBLocal("srcImage",&l_srcImage);
  bbDBLocal("srcX",&l_srcX);
  bbDBLocal("srcY",&l_srcY);
  bbDBLocal("srcWidth",&l_srcWidth);
  bbDBLocal("srcHeight",&l_srcHeight);
  bbDBStmt(2322434);
  this->m_DrawRect(t_std_geom_Rect_1f(l_x,l_y,(l_x+l_width),(l_y+l_height)),l_srcImage,t_std_geom_Rect_1i(l_srcX,l_srcY,(l_srcX+l_srcWidth),(l_srcY+l_srcHeight)));
}

void t_mojo_graphics_Canvas::m_DrawRect(t_std_geom_Rect_1f l_rect,t_mojo_graphics_Image* l_srcImage,t_std_geom_Rect_1i l_srcRect){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* t0{};
    t_mojo_graphics_Material* t1{};
    void gcMark(){
      bbGCMarkPtr(t0);
      bbGCMarkPtr(t1);
    }
  }f0{};
  bbDBFrame db_f{"DrawRect:Void(rect:Rectf:std.geom.Rect<Float>,srcImage:mojo.graphics.Image,srcRect:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("srcImage",&l_srcImage);
  bbDBLocal("srcRect",&l_srcRect);
  bbDBStmt(2269192);
  bbFloat l_s0=(bbFloat((l_srcImage->m_Rect().m_min.m_x+l_srcRect.m_min.m_x))/bbFloat((f0.t0=l_srcImage->m_Texture())->m_Width()));
  bbDBLocal("s0",&l_s0);
  bbDBStmt(2273288);
  bbFloat l_t0=(bbFloat((l_srcImage->m_Rect().m_min.m_y+l_srcRect.m_min.m_y))/bbFloat((f0.t0=l_srcImage->m_Texture())->m_Height()));
  bbDBLocal("t0",&l_t0);
  bbDBStmt(2277384);
  bbFloat l_s1=(bbFloat((l_srcImage->m_Rect().m_min.m_x+l_srcRect.m_max.m_x))/bbFloat((f0.t0=l_srcImage->m_Texture())->m_Width()));
  bbDBLocal("s1",&l_s1);
  bbDBStmt(2281480);
  bbFloat l_t1=(bbFloat((l_srcImage->m_Rect().m_min.m_y+l_srcRect.m_max.m_y))/bbFloat((f0.t0=l_srcImage->m_Texture())->m_Height()));
  bbDBLocal("t1",&l_t1);
  bbDBStmt(2285570);
  this->m_AddDrawOp(f0.t1=l_srcImage->m_Material(),4,1);
  bbDBStmt(2289666);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_min.m_y,l_s0,l_t0);
  bbDBStmt(2293762);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_min.m_y,l_s1,l_t0);
  bbDBStmt(2297858);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_max.m_y,l_s1,l_t1);
  bbDBStmt(2301954);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_max.m_y,l_s0,l_t1);
}

void t_mojo_graphics_Canvas::m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height,t_mojo_graphics_Image* l_srcImage){
  bbDBFrame db_f{"DrawRect:Void(x:Float,y:Float,width:Float,height:Float,srcImage:mojo.graphics.Image)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBLocal("srcImage",&l_srcImage);
  bbDBStmt(2252802);
  this->m_DrawRect(t_std_geom_Rect_1f(l_x,l_y,(l_x+l_width),(l_y+l_height)),l_srcImage);
}

void t_mojo_graphics_Canvas::m_DrawRect(t_std_geom_Rect_1f l_rect,t_mojo_graphics_Image* l_srcImage){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Material* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"DrawRect:Void(rect:Rectf:std.geom.Rect<Float>,srcImage:mojo.graphics.Image)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("srcImage",&l_srcImage);
  bbDBStmt(2215944);
  t_std_geom_Rect_1f l_tc=l_srcImage->m_TexCoords();
  bbDBLocal("tc",&l_tc);
  bbDBStmt(2220034);
  this->m_AddDrawOp(f0.t0=l_srcImage->m_Material(),4,1);
  bbDBStmt(2224130);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_min.m_y,l_tc.m_min.m_x,l_tc.m_min.m_y);
  bbDBStmt(2228226);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_min.m_y,l_tc.m_max.m_x,l_tc.m_min.m_y);
  bbDBStmt(2232322);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_max.m_y,l_tc.m_max.m_x,l_tc.m_max.m_y);
  bbDBStmt(2236418);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_max.m_y,l_tc.m_min.m_x,l_tc.m_max.m_y);
}

void t_mojo_graphics_Canvas::m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height){
  bbDBFrame db_f{"DrawRect:Void(x:Float,y:Float,width:Float,height:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBStmt(2199554);
  this->m_DrawRect(t_std_geom_Rect_1f(l_x,l_y,(l_x+l_width),(l_y+l_height)));
}

void t_mojo_graphics_Canvas::m_DrawRect(t_std_geom_Rect_1f l_rect){
  bbDBFrame db_f{"DrawRect:Void(rect:Rectf:std.geom.Rect<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rect",&l_rect);
  bbDBStmt(2166786);
  this->m_AddDrawOp(this->m__0materials->at(4),4,1);
  bbDBStmt(2170882);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_min.m_y,0.0f,0.0f);
  bbDBStmt(2174978);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_min.m_y,1.0f,0.0f);
  bbDBStmt(2179074);
  this->m_AddVertex(l_rect.m_max.m_x,l_rect.m_max.m_y,1.0f,1.0f);
  bbDBStmt(2183170);
  this->m_AddVertex(l_rect.m_min.m_x,l_rect.m_max.m_y,0.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawQuad(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1,bbFloat l_x2,bbFloat l_y2,bbFloat l_x3,bbFloat l_y3){
  bbDBFrame db_f{"DrawQuad:Void(x0:Float,y0:Float,x1:Float,y1:Float,x2:Float,y2:Float,x3:Float,y3:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x0",&l_x0);
  bbDBLocal("y0",&l_y0);
  bbDBLocal("x1",&l_x1);
  bbDBLocal("y1",&l_y1);
  bbDBLocal("x2",&l_x2);
  bbDBLocal("y2",&l_y2);
  bbDBLocal("x3",&l_x3);
  bbDBLocal("y3",&l_y3);
  bbDBStmt(2105346);
  this->m_AddDrawOp(this->m__0materials->at(4),4,1);
  bbDBStmt(2109442);
  this->m_AddVertex(l_x0,l_y0,0.0f,0.0f);
  bbDBStmt(2113538);
  this->m_AddVertex(l_x1,l_y1,1.0f,0.0f);
  bbDBStmt(2117634);
  this->m_AddVertex(l_x2,l_y2,1.0f,1.0f);
  bbDBStmt(2121730);
  this->m_AddVertex(l_x3,l_y3,0.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawPrimitives(bbInt l_order,bbInt l_count,bbFloat* l_vertices,bbInt l_verticesPitch,bbFloat* l_texCoords,bbInt l_texCoordsPitch,bbInt* l_indices){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Material* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"DrawPrimitives:Void(order:Int,count:Int,vertices:Float Ptr,verticesPitch:Int,texCoords:Float Ptr,texCoordsPitch:Int,indices:Int Ptr)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("order",&l_order);
  bbDBLocal("count",&l_count);
  bbDBLocal("vertices",&l_vertices);
  bbDBLocal("verticesPitch",&l_verticesPitch);
  bbDBLocal("texCoords",&l_texCoords);
  bbDBLocal("texCoordsPitch",&l_texCoordsPitch);
  bbDBLocal("indices",&l_indices);
  bbDBStmt(2793474);
  bbDebugAssert((l_order>bbInt(0)),BB_T("Illegal primtive type"));
  bbDBStmt(2801666);
  if(!bbBool(l_texCoords)){
    struct f1_t : public bbGCFrame{
      bbArray<bbFloat>* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(2805770);
    static bbGCRootVar<t_std_collections_Stack_1f> g__0texCoords=bbGCNew<t_std_collections_Stack_1f>();
    bbDBStmt(2809859);
    if((g__0texCoords->m_Length()!=(l_order*2))){
      bbDBBlock db_blk;
      bbDBStmt(2813956);
      g__0texCoords->m_Resize((l_order*2));
      bbDBStmt(2818052);
      {
        bbDBLoop db_loop;
        bbInt l_i=bbInt(0);
        bbDBLocal("i",&l_i);
        bbDBStmt(2818052);
        for(;(((2>bbInt(0))&&(l_i<(l_order*2)))||((2<bbInt(0))&&(l_i>(l_order*2))));l_i+=2){
          bbDBBlock db_blk;
          bbDBStmt(2822149);
          g__0texCoords->m__idxeq(l_i,0.0f);
          bbDBStmt(2826245);
          g__0texCoords->m__idxeq(bbInt((l_i==1)),0.0f);
        }
      }
    }
    bbDBStmt(2838531);
    l_texCoords=(f1.t0=g__0texCoords->m_Data())->data();
    bbDBStmt(2842627);
    l_texCoordsPitch=8;
  }
  bbDBStmt(2854914);
  this->m_AddDrawOp(f0.t0=this->m__0materials->at(g_monkey_math_Min_1i(l_order,5)),l_order,l_count);
  bbDBStmt(2863106);
  if(bbBool(l_indices)){
    bbDBBlock db_blk;
    bbDBStmt(2871299);
    {
      bbDBLoop db_loop;
      bbInt l_i=bbInt(0);
      bbDBLocal("i",&l_i);
      bbDBStmt(2871299);
      for(;(l_i<l_count);l_i+=1){
        bbDBBlock db_blk;
        bbDBStmt(2875396);
        {
          bbDBLoop db_loop;
          bbInt l_j=bbInt(0);
          bbDBLocal("j",&l_j);
          bbDBStmt(2875396);
          for(;(l_j<l_order);l_j+=1){
            bbDBBlock db_blk;
            bbDBStmt(2879499);
            bbInt l_k=l_indices[l_j];
            bbDBLocal("k",&l_k);
            bbDBStmt(2883595);
            bbFloat* l_vp=((bbFloat*)((((bbUByte*)(l_vertices))+(l_k*l_verticesPitch))));
            bbDBLocal("vp",&l_vp);
            bbDBStmt(2887691);
            bbFloat* l_tp=((bbFloat*)((((bbUByte*)(l_texCoords))+(l_k*l_texCoordsPitch))));
            bbDBLocal("tp",&l_tp);
            bbDBStmt(2891781);
            this->m_AddVertex(l_vp[bbInt(0)],l_vp[1],l_tp[bbInt(0)],l_tp[1]);
          }
        }
        bbDBStmt(2899972);
        l_indices=(l_indices+l_order);
      }
    }
  }else{
    bbDBStmt(2912258);
    bbDBBlock db_blk;
    bbDBStmt(2920451);
    {
      bbDBLoop db_loop;
      bbInt l_i=bbInt(0);
      bbDBLocal("i",&l_i);
      bbDBStmt(2920451);
      for(;(l_i<l_count);l_i+=1){
        bbDBBlock db_blk;
        bbDBStmt(2924548);
        {
          bbDBLoop db_loop;
          bbInt l_j=bbInt(0);
          bbDBLocal("j",&l_j);
          bbDBStmt(2924548);
          for(;(l_j<l_order);l_j+=1){
            bbDBBlock db_blk;
            bbDBStmt(2928645);
            this->m_AddVertex(l_vertices[bbInt(0)],l_vertices[1],l_texCoords[bbInt(0)],l_texCoords[1]);
            bbDBStmt(2932741);
            l_vertices=((bbFloat*)((((bbUByte*)(l_vertices))+l_verticesPitch)));
            bbDBStmt(2936837);
            l_texCoords=((bbFloat*)((((bbUByte*)(l_texCoords))+l_texCoordsPitch)));
          }
        }
      }
    }
  }
}

void t_mojo_graphics_Canvas::m_DrawPoly(bbArray<bbFloat>* l_vertices){
  bbDBFrame db_f{"DrawPoly:Void(vertices:Float[])","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("vertices",&l_vertices);
  bbDBStmt(2666498);
  bbDebugAssert(((l_vertices->length()>=6)&&((l_vertices->length()&1)==bbInt(0))),BB_T("Debug assert failed"));
  bbDBStmt(2674696);
  bbInt l_n=(l_vertices->length()/2);
  bbDBLocal("n",&l_n);
  bbDBStmt(2682882);
  this->m_AddDrawOp(this->m__0materials->at(5),l_n,1);
  bbDBStmt(2691074);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(2691074);
    for(;(((2>bbInt(0))&&(l_i<(l_n*2)))||((2<bbInt(0))&&(l_i>(l_n*2))));l_i+=2){
      bbDBBlock db_blk;
      bbDBStmt(2695171);
      this->m_AddVertex(l_vertices->at(l_i),l_vertices->at((l_i+1)),0.0f,0.0f);
    }
  }
}

void t_mojo_graphics_Canvas::m_DrawPoint(bbFloat l_x,bbFloat l_y){
  bbDBFrame db_f{"DrawPoint:Void(x:Float,y:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBStmt(1843202);
  this->m_AddDrawOp(this->m__0materials->at(1),1,1);
  bbDBStmt(1847298);
  this->m_AddVertex((l_x+.5f),(l_y+.5f),0.0f,0.0f);
}

void t_mojo_graphics_Canvas::m_DrawPoint(t_std_geom_Vec2_1f l_v){
  bbDBFrame db_f{"DrawPoint:Void(v:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("v",&l_v);
  bbDBStmt(1822722);
  this->m_AddDrawOp(this->m__0materials->at(1),1,1);
  bbDBStmt(1826818);
  this->m_AddVertex((l_v.m_x+.5f),(l_v.m_y+.5f),0.0f,0.0f);
}

void t_mojo_graphics_Canvas::m_DrawOval(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height){
  bbDBFrame db_f{"DrawOval:Void(x:Float,y:Float,width:Float,height:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBStmt(2400264);
  bbFloat l_xr=(l_width/2.0f);
  bbDBLocal("xr",&l_xr);
  bbDBStmt(2400278);
  bbFloat l_yr=(l_height/2.0f);
  bbDBLocal("yr",&l_yr);
  bbDBStmt(2408456);
  bbFloat l_dx_0x=(l_xr*this->m__0matrix.m_i.m_x);
  bbDBLocal("dx_x",&l_dx_0x);
  bbDBStmt(2412552);
  bbFloat l_dx_0y=(l_xr*this->m__0matrix.m_i.m_y);
  bbDBLocal("dx_y",&l_dx_0y);
  bbDBStmt(2416648);
  bbFloat l_dy_0x=(l_yr*this->m__0matrix.m_j.m_x);
  bbDBLocal("dy_x",&l_dy_0x);
  bbDBStmt(2420744);
  bbFloat l_dy_0y=(l_yr*this->m__0matrix.m_j.m_y);
  bbDBLocal("dy_y",&l_dy_0y);
  bbDBStmt(2424840);
  bbDouble l_dx=std::sqrt(bbDouble(((l_dx_0x*l_dx_0x)+(l_dx_0y*l_dx_0y))));
  bbDBLocal("dx",&l_dx);
  bbDBStmt(2428936);
  bbDouble l_dy=std::sqrt(bbDouble(((l_dy_0x*l_dy_0x)+(l_dy_0y*l_dy_0y))));
  bbDBLocal("dy",&l_dy);
  bbDBStmt(2437128);
  bbInt l_n=(g_monkey_math_Max_1i(bbInt((l_dx+l_dy)),12)&~3);
  bbDBLocal("n",&l_n);
  bbDBStmt(2445320);
  bbFloat l_x0=(l_x+l_xr);
  bbDBLocal("x0",&l_x0);
  bbDBStmt(2445329);
  bbFloat l_y0=(l_y+l_yr);
  bbDBLocal("y0",&l_y0);
  bbDBStmt(2453506);
  this->m_AddDrawOp(this->m__0materials->at(5),l_n,1);
  bbDBStmt(2461698);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(2461698);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(2465801);
      bbDouble l_th=(((bbDouble(l_i)*g_monkey_math_Pi)*2.0)/bbDouble(l_n));
      bbDBLocal("th",&l_th);
      bbDBStmt(2469897);
      bbDouble l_px=(bbDouble(l_x0)+(std::cos(l_th)*bbDouble(l_xr)));
      bbDBLocal("px",&l_px);
      bbDBStmt(2473993);
      bbDouble l_py=(bbDouble(l_y0)+(std::sin(l_th)*bbDouble(l_yr)));
      bbDBLocal("py",&l_py);
      bbDBStmt(2478083);
      this->m_AddVertex(bbFloat(l_px),bbFloat(l_py),0.0f,0.0f);
    }
  }
}

void t_mojo_graphics_Canvas::m_DrawLine(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1){
  bbDBFrame db_f{"DrawLine:Void(x0:Float,y0:Float,x1:Float,y1:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x0",&l_x0);
  bbDBLocal("y0",&l_y0);
  bbDBLocal("x1",&l_x1);
  bbDBLocal("y1",&l_y1);
  bbDBStmt(1966082);
  this->m_AddDrawOp(this->m__0materials->at(2),2,1);
  bbDBStmt(1970178);
  this->m_AddVertex((l_x0+.5f),(l_y0+.5f),0.0f,0.0f);
  bbDBStmt(1974274);
  this->m_AddVertex((l_x1+.5f),(l_y1+.5f),1.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawLine(t_std_geom_Vec2_1f l_v0,t_std_geom_Vec2_1f l_v1){
  bbDBFrame db_f{"DrawLine:Void(v0:Vec2f:std.geom.Vec2<Float>,v1:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("v0",&l_v0);
  bbDBLocal("v1",&l_v1);
  bbDBStmt(1941506);
  this->m_AddDrawOp(this->m__0materials->at(2),2,1);
  bbDBStmt(1945602);
  this->m_AddVertex((l_v0.m_x+.5f),(l_v0.m_y+.5f),0.0f,0.0f);
  bbDBStmt(1949698);
  this->m_AddVertex((l_v1.m_x+.5f),(l_v1.m_y+.5f),1.0f,1.0f);
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_tv,bbFloat l_rz,t_std_geom_Vec2_1f l_scale){
  bbDBFrame db_f{"DrawImage:Void(image:mojo.graphics.Image,tv:Vec2f:std.geom.Vec2<Float>,rz:Float,scale:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("image",&l_image);
  bbDBLocal("tv",&l_tv);
  bbDBLocal("rz",&l_rz);
  bbDBLocal("scale",&l_scale);
  bbDBStmt(3186690);
  this->m_DrawImage(l_image,l_tv.m_x,l_tv.m_y,l_rz,l_scale.m_x,l_scale.m_y);
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty,bbFloat l_rz,bbFloat l_sx,bbFloat l_sy){
  bbDBFrame db_f{"DrawImage:Void(image:mojo.graphics.Image,tx:Float,ty:Float,rz:Float,sx:Float,sy:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("image",&l_image);
  bbDBLocal("tx",&l_tx);
  bbDBLocal("ty",&l_ty);
  bbDBLocal("rz",&l_rz);
  bbDBLocal("sx",&l_sx);
  bbDBLocal("sy",&l_sy);
  bbDBStmt(3149832);
  t_std_geom_AffineMat3_1f l_matrix=this->m__0matrix;
  bbDBLocal("matrix",&l_matrix);
  bbDBStmt(3153922);
  this->m_Translate(l_tx,l_ty);
  bbDBStmt(3158018);
  this->m_Rotate(l_rz);
  bbDBStmt(3162114);
  this->m_Scale(l_sx,l_sy);
  bbDBStmt(3166210);
  this->m_DrawImage(l_image,0.0f,0.0f);
  bbDBStmt(3170306);
  this->m__0matrix=l_matrix;
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_translation,bbFloat l_rz){
  bbDBFrame db_f{"DrawImage:Void(image:mojo.graphics.Image,translation:Vec2f:std.geom.Vec2<Float>,rz:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("image",&l_image);
  bbDBLocal("translation",&l_translation);
  bbDBLocal("rz",&l_rz);
  bbDBStmt(3133442);
  this->m_DrawImage(l_image,l_translation.m_x,l_translation.m_y,l_rz);
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty,bbFloat l_rz){
  bbDBFrame db_f{"DrawImage:Void(image:mojo.graphics.Image,tx:Float,ty:Float,rz:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("image",&l_image);
  bbDBLocal("tx",&l_tx);
  bbDBLocal("ty",&l_ty);
  bbDBLocal("rz",&l_rz);
  bbDBStmt(3100680);
  t_std_geom_AffineMat3_1f l_matrix=this->m__0matrix;
  bbDBLocal("matrix",&l_matrix);
  bbDBStmt(3104770);
  this->m_Translate(l_tx,l_ty);
  bbDBStmt(3108866);
  this->m_Rotate(l_rz);
  bbDBStmt(3112962);
  this->m_DrawImage(l_image,0.0f,0.0f);
  bbDBStmt(3117058);
  this->m__0matrix=l_matrix;
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_translation){
  bbDBFrame db_f{"DrawImage:Void(image:mojo.graphics.Image,translation:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("image",&l_image);
  bbDBLocal("translation",&l_translation);
  bbDBStmt(3084290);
  this->m_DrawImage(l_image,l_translation.m_x,l_translation.m_y);
}

void t_mojo_graphics_Canvas::m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Material* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"DrawImage:Void(image:mojo.graphics.Image,tx:Float,ty:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("image",&l_image);
  bbDBLocal("tx",&l_tx);
  bbDBLocal("ty",&l_ty);
  bbDBStmt(3043336);
  t_std_geom_Rect_1f l_vs=l_image->m_Vertices();
  bbDBLocal("vs",&l_vs);
  bbDBStmt(3047432);
  t_std_geom_Rect_1f l_tc=l_image->m_TexCoords();
  bbDBLocal("tc",&l_tc);
  bbDBStmt(3051522);
  this->m_AddDrawOp(f0.t0=l_image->m_Material(),4,1);
  bbDBStmt(3055618);
  this->m_AddVertex((l_vs.m_min.m_x+l_tx),(l_vs.m_min.m_y+l_ty),l_tc.m_min.m_x,l_tc.m_min.m_y);
  bbDBStmt(3059714);
  this->m_AddVertex((l_vs.m_max.m_x+l_tx),(l_vs.m_min.m_y+l_ty),l_tc.m_max.m_x,l_tc.m_min.m_y);
  bbDBStmt(3063810);
  this->m_AddVertex((l_vs.m_max.m_x+l_tx),(l_vs.m_max.m_y+l_ty),l_tc.m_max.m_x,l_tc.m_max.m_y);
  bbDBStmt(3067906);
  this->m_AddVertex((l_vs.m_min.m_x+l_tx),(l_vs.m_max.m_y+l_ty),l_tc.m_min.m_x,l_tc.m_max.m_y);
}

void t_mojo_graphics_Canvas::m_DrawEllipse(bbFloat l_x,bbFloat l_y,bbFloat l_xRadius,bbFloat l_yRadius){
  bbDBFrame db_f{"DrawEllipse:Void(x:Float,y:Float,xRadius:Float,yRadius:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBLocal("xRadius",&l_xRadius);
  bbDBLocal("yRadius",&l_yRadius);
  bbDBStmt(2560002);
  this->m_DrawOval((l_x-l_xRadius),(l_y-l_yRadius),(l_xRadius*2.0f),(l_yRadius*2.0f));
}

void t_mojo_graphics_Canvas::m_DrawCircle(bbFloat l_x,bbFloat l_y,bbFloat l_radius){
  bbDBFrame db_f{"DrawCircle:Void(x:Float,y:Float,radius:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBLocal("radius",&l_radius);
  bbDBStmt(2621442);
  this->m_DrawOval((l_x-l_radius),(l_y-l_radius),(l_radius*2.0f),(l_radius*2.0f));
}

t_std_graphics_Pixmap* t_mojo_graphics_Canvas::m_CopyPixmap(t_std_geom_Rect_1i l_rect){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  }f0{};
  bbDBFrame db_f{"CopyPixmap:std.graphics.Pixmap(rect:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rect",&l_rect);
  bbDBStmt(905218);
  this->m_Flush();
  bbDBStmt(913410);
  this->m_Validate();
  bbDBStmt(921602);
  l_rect=g_std_geom_TransformRecti_1f(l_rect,this->m__0renderMatrix);
  bbDBStmt(929794);
  l_rect=l_rect.m__and(this->m__0renderBounds).m__add(this->m__0targetRect.m_Origin());
  bbDBStmt(937992);
  f0.l_pixmap=this->m__0device->m_CopyPixmap(l_rect);
  bbDBLocal("pixmap",&f0.l_pixmap);
  bbDBStmt(946178);
  return f0.l_pixmap;
}

void t_mojo_graphics_Canvas::m_Color(t_std_graphics_Color l_color){
  bbDBFrame db_f{"Color:Void(color:std.graphics.Color)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("color",&l_color);
  bbDBStmt(1339394);
  this->m__0color=l_color;
  bbDBStmt(1347592);
  bbFloat l_a=((this->m__0color.m_a*this->m__0alpha)*255.0f);
  bbDBLocal("a",&l_a);
  bbDBStmt(1351682);
  this->m__0pmcolor=((((bbUInt(l_a)<<24)|(bbUInt((this->m__0color.m_b*l_a))<<16))|(bbUInt((this->m__0color.m_g*l_a))<<8))|bbUInt((this->m__0color.m_r*l_a)));
}

t_std_graphics_Color t_mojo_graphics_Canvas::m_Color(){
  bbDBFrame db_f{"Color:std.graphics.Color()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1323010);
  return this->m__0color;
}

void t_mojo_graphics_Canvas::m_ClearMatrix(){
  bbDBFrame db_f{"ClearMatrix:Void()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1589250);
  this->m__0matrixStack->m_Clear();
  bbDBStmt(1597442);
  this->m_Matrix(t_std_geom_AffineMat3_1f(bbNullCtor));
}

void t_mojo_graphics_Canvas::m_ClearDrawOps(){
  bbDBFrame db_f{"ClearDrawOps:Void()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(4157442);
  this->m__0ops->m_Clear();
  bbDBStmt(4161538);
  this->m__0vertices->m_Clear();
  bbDBStmt(4165634);
  this->m__0vertexData=this->m__0vertices->m_Data();
  bbDBStmt(4169730);
  this->m__0op=bbGCNew<t_mojo_graphics_DrawOp>();
  bbDBStmt(4173826);
  this->m__0vertex=bbInt(0);
}

void t_mojo_graphics_Canvas::m_Clear(t_std_graphics_Color l_color){
  bbDBFrame db_f{"Clear:Void(color:std.graphics.Color)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("color",&l_color);
  bbDBStmt(847874);
  this->m_Flush();
  bbDBStmt(856066);
  this->m_Validate();
  bbDBStmt(864258);
  this->m__0device->m_Clear(l_color);
}

void t_mojo_graphics_Canvas::m_BlendMode(bbInt l_blendMode){
  bbDBFrame db_f{"BlendMode:Void(blendMode:mojo.graphics.BlendMode)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("blendMode",&l_blendMode);
  bbDBStmt(1458178);
  this->m__0blendMode=l_blendMode;
}

bbInt t_mojo_graphics_Canvas::m_BlendMode(){
  bbDBFrame db_f{"BlendMode:mojo.graphics.BlendMode()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return this->m__0blendMode;
}

void t_mojo_graphics_Canvas::m_BeginRender(t_std_geom_Rect_1i l_bounds,t_std_geom_AffineMat3_1f l_matrix){
  bbDBFrame db_f{"BeginRender:Void(bounds:Recti:std.geom.Rect<Int>,matrix:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("bounds",&l_bounds);
  bbDBLocal("matrix",&l_matrix);
  bbDBStmt(974850);
  this->m_Flush();
  bbDBStmt(983042);
  this->m__0device->m_ShaderEnv(g_mojo_graphics_Canvas__0ambientEnv);
  bbDBStmt(991234);
  this->m__0renderMatrixStack->m_Push(this->m__0renderMatrix);
  bbDBStmt(995330);
  this->m__0renderBoundsStack->m_Push(this->m__0renderBounds);
  bbDBStmt(1003522);
  this->m__0renderMatrix=this->m__0renderMatrix.m__mul(l_matrix);
  bbDBStmt(1007618);
  this->m__0renderBounds.m__andeq(g_std_geom_TransformRecti_1f(l_bounds,this->m__0renderMatrix));
  bbDBStmt(1015810);
  this->m__0dirty|=6;
  bbDBStmt(1024002);
  this->m_Viewport(l_bounds);
  bbDBStmt(1028098);
  this->m_Scissor(t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_bounds.m_Size()));
  bbDBStmt(1032194);
  this->m_TextureFilteringEnabled(true);
  bbDBStmt(1036290);
  this->m_ClearMatrix();
}

void t_mojo_graphics_Canvas::m_AmbientLight(t_std_graphics_Color l_ambientLight){
  bbDBFrame db_f{"AmbientLight:Void(ambientLight:std.graphics.Color)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ambientLight",&l_ambientLight);
  bbDBStmt(606210);
  this->m_Flush();
  bbDBStmt(614402);
  this->m__0ambientLight=l_ambientLight;
  bbDBStmt(622594);
  this->m__0dirty|=4;
}

t_std_graphics_Color t_mojo_graphics_Canvas::m_AmbientLight(){
  bbDBFrame db_f{"AmbientLight:std.graphics.Color()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(589826);
  return this->m__0ambientLight;
}

void t_mojo_graphics_Canvas::m_Alpha(bbFloat l_alpha){
  bbDBFrame db_f{"Alpha:Void(alpha:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("alpha",&l_alpha);
  bbDBStmt(1269762);
  this->m__0alpha=l_alpha;
  bbDBStmt(1277960);
  bbFloat l_a=((this->m__0color.m_a*this->m__0alpha)*255.0f);
  bbDBLocal("a",&l_a);
  bbDBStmt(1282050);
  this->m__0pmcolor=((((bbUInt(l_a)<<24)|(bbUInt((this->m__0color.m_b*l_a))<<16))|(bbUInt((this->m__0color.m_g*l_a))<<8))|bbUInt((this->m__0color.m_r*l_a)));
}

bbFloat t_mojo_graphics_Canvas::m_Alpha(){
  bbDBFrame db_f{"Alpha:Float()","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0alpha;
}

void t_mojo_graphics_Canvas::m_AddVertex(bbFloat l_tx,bbFloat l_ty,bbFloat l_s0,bbFloat l_t0){
  bbDBFrame db_f{"AddVertex:Void(tx:Float,ty:Float,s0:Float,t0:Float)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("tx",&l_tx);
  bbDBLocal("ty",&l_ty);
  bbDBLocal("s0",&l_s0);
  bbDBLocal("t0",&l_t0);
  bbDBStmt(4268034);
  this->m__0vertexData->at(this->m__0vertex).m_x=(((this->m__0matrix.m_i.m_x*l_tx)+(this->m__0matrix.m_j.m_x*l_ty))+this->m__0matrix.m_t.m_x);
  bbDBStmt(4272130);
  this->m__0vertexData->at(this->m__0vertex).m_y=(((this->m__0matrix.m_i.m_y*l_tx)+(this->m__0matrix.m_j.m_y*l_ty))+this->m__0matrix.m_t.m_y);
  bbDBStmt(4276226);
  this->m__0vertexData->at(this->m__0vertex).m_s0=l_s0;
  bbDBStmt(4280322);
  this->m__0vertexData->at(this->m__0vertex).m_t0=l_t0;
  bbDBStmt(4284418);
  this->m__0vertexData->at(this->m__0vertex).m_ix=this->m__0matrix.m_i.m_x;
  bbDBStmt(4288514);
  this->m__0vertexData->at(this->m__0vertex).m_iy=this->m__0matrix.m_i.m_y;
  bbDBStmt(4292610);
  this->m__0vertexData->at(this->m__0vertex).m_color=this->m__0pmcolor;
  bbDBStmt(4300802);
  this->m__0vertex+=1;
}

void t_mojo_graphics_Canvas::m_AddDrawOp(t_mojo_graphics_Material* l_material,bbInt l_order,bbInt l_count){
  bbDBFrame db_f{"AddDrawOp:Void(material:mojo.graphics.Material,order:Int,count:Int)","/home/pi/monkey2/modules/mojo/graphics/canvas.monkey2"};
  t_mojo_graphics_Canvas*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("material",&l_material);
  bbDBLocal("order",&l_order);
  bbDBLocal("count",&l_count);
  bbDBStmt(4194306);
  this->m__0vertices->m_Resize((this->m__0vertex+(l_order*l_count)));
  bbDBStmt(4198402);
  this->m__0vertexData=this->m__0vertices->m_Data();
  bbDBStmt(4206594);
  if((((this->m__0blendMode==this->m__0op->m_blendMode)&&(l_material==this->m__0op->m_material))&&(l_order==this->m__0op->m_order))){
    bbDBBlock db_blk;
    bbDBStmt(4210691);
    this->m__0op->m_count+=l_count;
    bbDBStmt(4214787);
    return;
  }
  bbDBStmt(4227074);
  this->m__0op=bbGCNew<t_mojo_graphics_DrawOp>();
  bbDBStmt(4231170);
  this->m__0op->m_blendMode=this->m__0blendMode;
  bbDBStmt(4235266);
  this->m__0op->m_material=l_material;
  bbDBStmt(4239362);
  this->m__0op->m_order=l_order;
  bbDBStmt(4243458);
  this->m__0op->m_count=l_count;
  bbDBStmt(4247554);
  this->m__0ops->m_Add(this->m__0op);
}
bbString bbDBType(t_mojo_graphics_Canvas**){
  return "mojo.graphics.Canvas";
}
bbString bbDBValue(t_mojo_graphics_Canvas**p){
  return bbDBObjectValue(*p);
}

void t_mojo_graphics_Canvas_LightInst::dbEmit(t_mojo_graphics_Canvas_LightInst*p){
  bbDBEmit("position",&p->m_position);
  bbDBEmit("radius",&p->m_radius);
  bbDBEmit("color",&p->m_color);
}
bbString bbDBType(t_mojo_graphics_Canvas_LightInst*){
  return "mojo.graphics.Canvas.LightInst";
}
bbString bbDBValue(t_mojo_graphics_Canvas_LightInst*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_mojo_graphics_Canvas_LightInst&x,const t_mojo_graphics_Canvas_LightInst&y){
  if(int t=bbCompare(x.m_position,y.m_position)) return t;
  if(int t=bbCompare(x.m_radius,y.m_radius)) return t;
  if(int t=bbCompare(x.m_color,y.m_color)) return t;
  return 0;
}

void mx2_mojo_graphics_2canvas_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2canvas_init_v("mojo_graphics_2canvas",&mx2_mojo_graphics_2canvas_init);
