
#include "../../desktop_debug_pi/mojo_audio_2audio.h"

// ***** External *****

#include "../../../../sdl2/sdl2.buildv1.0.0/desktop_debug_pi/sdl2_sdl2.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_memory_2databuffer.h"

extern bbFloat g_monkey_math_Clamp_1f(bbFloat l_value,bbFloat l_min,bbFloat l_max);

// ***** Internal *****

bbGCRootVar<bbArray<bbInt>> g_mojo_audio__0alloced;
bbGCRootVar<t_mojo_audio_AudioDevice> g_mojo_audio_Audio;

t_mojo_audio_Sound* g_mojo_audio_Sound_Load(bbString l_path){
  struct f0_t : public bbGCFrame{
    t_std_memory_DataBuffer* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Load:mojo.audio.Sound(path:String)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  bbDBLocal("path",&l_path);
  bbDBStmt(229384);
  f0.l_data=g_std_memory_DataBuffer_Load(l_path);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(233474);
  if(!bbBool(f0.l_data)){
    bbDBBlock db_blk;
    bbDBStmt(233486);
    return ((t_mojo_audio_Sound*)0);
  }
  bbDBStmt(241672);
  SDL_RWops* l_rwops=SDL_RWFromMem(((void*)(f0.l_data->m_Data())),f0.l_data->m_Length());
  bbDBLocal("rwops",&l_rwops);
  bbDBStmt(245768);
  Mix_Chunk* l_chunk=Mix_LoadWAV_RW(l_rwops,1);
  bbDBLocal("chunk",&l_chunk);
  bbDBStmt(249858);
  if(!bbBool(l_chunk)){
    bbDBBlock db_blk;
    bbDBStmt(249871);
    return ((t_mojo_audio_Sound*)0);
  }
  bbDBStmt(258050);
  return bbGCNew<t_mojo_audio_Sound>(l_chunk);
}

void t_mojo_audio_AudioDevice::dbEmit(){
}

void t_mojo_audio_AudioDevice::m_Init(){
  bbDBFrame db_f{"Init:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_AudioDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(98306);
  Mix_Init(bbInt(0));
  bbDBStmt(106498);
  Mix_OpenAudio(44100,bbUShort(MIX_DEFAULT_FORMAT),2,1024);
  bbDBStmt(114690);
  Mix_AllocateChannels(32);
  bbDBStmt(122882);
  g_mojo_audio__0alloced=bbArray<bbInt>::create(32);
  bbDBStmt(126978);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(126978);
    for(;(l_i<32);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(131075);
      g_mojo_audio__0alloced->at(l_i)=(l_i+32);
    }
  }
}
bbString bbDBType(t_mojo_audio_AudioDevice**){
  return "mojo.audio.AudioDevice";
}
bbString bbDBValue(t_mojo_audio_AudioDevice**p){
  return bbDBObjectValue(*p);
}

void t_mojo_audio_Sound::dbEmit(){
  bbDBEmit("_chunk",&m__0chunk);
}

t_mojo_audio_Sound::t_mojo_audio_Sound(Mix_Chunk* l_chunk){
  bbDBFrame db_f{"new:Void(chunk:sdl2.mixer.Mix_Chunk Ptr)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  bbDBLocal("chunk",&l_chunk);
  bbDBStmt(290818);
  this->m__0chunk=l_chunk;
}

t_mojo_audio_Channel* t_mojo_audio_Sound::m_Play(bbInt l_loops){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_channel{};
    void gcMark(){
      bbGCMarkPtr(l_channel);
    }
  }f0{};
  bbDBFrame db_f{"Play:mojo.audio.Channel(loops:Int)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Sound*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("loops",&l_loops);
  bbDBStmt(188424);
  f0.l_channel=bbGCNew<t_mojo_audio_Channel>();
  bbDBLocal("channel",&f0.l_channel);
  bbDBStmt(192514);
  if(!f0.l_channel->m_Play(this,l_loops)){
    bbDBBlock db_blk;
    bbDBStmt(192548);
    return ((t_mojo_audio_Channel*)0);
  }
  bbDBStmt(200706);
  return f0.l_channel;
}
bbString bbDBType(t_mojo_audio_Sound**){
  return "mojo.audio.Sound";
}
bbString bbDBValue(t_mojo_audio_Sound**p){
  return bbDBObjectValue(*p);
}

void t_mojo_audio_Channel::dbEmit(){
  bbDBEmit("_id",&m__0id);
  bbDBEmit("_volume",&m__0volume);
}

t_mojo_audio_Channel::t_mojo_audio_Channel(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
}

void t_mojo_audio_Channel::m_Volume(bbFloat l_volume){
  bbDBFrame db_f{"Volume:Void(volume:Float)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("volume",&l_volume);
  bbDBStmt(413698);
  if(this->m_Invalid()){
    bbDBBlock db_blk;
    bbDBStmt(413709);
    return;
  }
  bbDBStmt(417794);
  this->m__0volume=g_monkey_math_Clamp_1f(l_volume,0.0f,1.0f);
  bbDBStmt(421890);
  Mix_Volume((this->m__0id&31),bbInt((this->m__0volume*128.0f)));
}

bbFloat t_mojo_audio_Channel::m_Volume(){
  bbDBFrame db_f{"Volume:Float()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(401410);
  if(this->m_Invalid()){
    bbDBBlock db_blk;
    bbDBStmt(401421);
    return 0.0f;
  }
  bbDBStmt(405506);
  return this->m__0volume;
}

void t_mojo_audio_Channel::m_Stop(){
  bbDBFrame db_f{"Stop:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(618498);
  if(this->m_Invalid()){
    bbDBBlock db_blk;
    bbDBStmt(618509);
    return;
  }
  bbDBStmt(622594);
  Mix_HaltChannel(this->m__0id);
}

void t_mojo_audio_Channel::m_Rate(bbFloat l_rate){
  bbDBFrame db_f{"Rate:Void(rate:Float)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rate",&l_rate);
}

bbFloat t_mojo_audio_Channel::m_Rate(){
  bbDBFrame db_f{"Rate:Float()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(446466);
  return 1.0f;
}

bbBool t_mojo_audio_Channel::m_Playing(){
  bbDBFrame db_f{"Playing:Bool()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(372738);
  if(this->m_Invalid()){
    bbDBBlock db_blk;
    bbDBStmt(372749);
    return false;
  }
  bbDBStmt(376834);
  return bbBool(Mix_Playing((this->m__0id&31)));
}

bbBool t_mojo_audio_Channel::m_Play(t_mojo_audio_Sound* l_sound,bbInt l_loops){
  bbDBFrame db_f{"Play:Bool(sound:mojo.audio.Sound,loops:Int)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("sound",&l_sound);
  bbDBLocal("loops",&l_loops);
  bbDBStmt(548872);
  bbInt l_id=(this->m__0id&31);
  bbDBLocal("id",&l_id);
  bbDBStmt(552962);
  if((g_mojo_audio__0alloced->at(l_id)!=this->m__0id)){
    bbDBBlock db_blk;
    bbDBStmt(552983);
    l_id=-1;
  }
  bbDBStmt(561154);
  l_id=Mix_PlayChannel(l_id,l_sound->m__0chunk,l_loops);
  bbDBStmt(565250);
  if((l_id<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(565258);
    return false;
  }
  bbDBStmt(573442);
  g_mojo_audio__0alloced->at(l_id)+=32;
  bbDBStmt(577538);
  this->m__0id=g_mojo_audio__0alloced->at(l_id);
  bbDBStmt(585730);
  this->m__0volume=1.0f;
  bbDBStmt(593922);
  return true;
}

void t_mojo_audio_Channel::m_Paused(bbBool l_paused){
  bbDBFrame db_f{"Paused:Void(paused:Bool)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("paused",&l_paused);
  bbDBStmt(516098);
  if(this->m_Invalid()){
    bbDBBlock db_blk;
    bbDBStmt(516109);
    return;
  }
  bbDBStmt(520194);
  Mix_Pause((this->m__0id&31));
}

bbBool t_mojo_audio_Channel::m_Paused(){
  bbDBFrame db_f{"Paused:Bool()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503810);
  if(this->m_Invalid()){
    bbDBBlock db_blk;
    bbDBStmt(503821);
    return false;
  }
  bbDBStmt(507906);
  return bbBool(Mix_Paused((this->m__0id&31)));
}

void t_mojo_audio_Channel::m_Pan(bbFloat l_pan){
  bbDBFrame db_f{"Pan:Void(pan:Float)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("pan",&l_pan);
}

bbFloat t_mojo_audio_Channel::m_Pan(){
  bbDBFrame db_f{"Pan:Float()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(475138);
  return 0.0f;
}

bbBool t_mojo_audio_Channel::m_Invalid(){
  bbDBFrame db_f{"Invalid:Bool()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(659458);
  return (g_mojo_audio__0alloced->at((this->m__0id&31))!=this->m__0id);
}
bbString bbDBType(t_mojo_audio_Channel**){
  return "mojo.audio.Channel";
}
bbString bbDBValue(t_mojo_audio_Channel**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_audio_2audio_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_audio_Audio=bbGCNew<t_mojo_audio_AudioDevice>();
}

bbInit mx2_mojo_audio_2audio_init_v("mojo_audio_2audio",&mx2_mojo_audio_2audio_init);
