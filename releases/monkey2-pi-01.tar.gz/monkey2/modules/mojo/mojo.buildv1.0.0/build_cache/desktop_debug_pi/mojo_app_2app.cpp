
#include "../../desktop_debug_pi/mojo_app_2app.h"

// ***** External *****

#include "../../../../libc/libc.buildv1.0.0/desktop_debug_pi/libc_libc.h"
#include "../../desktop_debug_pi/mojo_app_2event.h"
#include "../../desktop_debug_pi/mojo_app_2style.h"
#include "../../desktop_debug_pi/mojo_app_2view.h"
#include "../../desktop_debug_pi/mojo_app_2window.h"
#include "../../desktop_debug_pi/mojo_audio_2audio.h"
#include "../../desktop_debug_pi/mojo_graphics_2font.h"
#include "../../desktop_debug_pi/mojo_input_2keyboard.h"
#include "../../desktop_debug_pi/mojo_input_2mouse.h"
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.0/desktop_debug_pi/std_graphics_2color.h"

// ***** Internal *****

bbGCRootVar<t_mojo_app_AppInstance> g_mojo_app_App;
bbGCRootVar<t_std_collections_Map_1iFvE> g_mojo_app_AppInstance__0asyncCallbacks;
bbGCRootVar<t_std_collections_Map_1iz> g_mojo_app_AppInstance__0disabledCallbacks;
bbInt g_mojo_app_AppInstance__0nextCallbackId;

bbInt g_mojo_app_AppInstance__0EventFilter(void* l_userData,SDL_Event* l_event){
  bbDBFrame db_f{"_EventFilter:Int(userData:Void Ptr,event:sdl2.SDL_Event Ptr)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("userData",&l_userData);
  bbDBLocal("event",&l_event);
  bbDBStmt(2732034);
  return g_mojo_app_App->m_EventFilter(l_userData,l_event);
}

void g_mojo_app_AppInstance_RemoveAsyncCallback(bbInt l_id){
  bbDBFrame db_f{"RemoveAsyncCallback:Void(id:Int)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("id",&l_id);
  bbDBStmt(2973698);
  g_mojo_app_AppInstance__0disabledCallbacks->m_Remove(l_id);
  bbDBStmt(2977794);
  g_mojo_app_AppInstance__0asyncCallbacks->m_Remove(l_id);
}

void g_mojo_app_AppInstance_EnableAsyncCallback(bbInt l_id){
  bbDBFrame db_f{"EnableAsyncCallback:Void(id:Int)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("id",&l_id);
  bbDBStmt(2994178);
  g_mojo_app_AppInstance__0disabledCallbacks->m_Remove(l_id);
}

void g_mojo_app_AppInstance_EmscriptenMainLoop(){
  bbDBFrame db_f{"EmscriptenMainLoop:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBStmt(1310722);
  g_mojo_app_App->m__0requestRender=true;
  bbDBStmt(1318914);
  g_mojo_app_App->m_MainLoop();
}

void g_mojo_app_AppInstance_DisableAsyncCallback(bbInt l_id){
  bbDBFrame db_f{"DisableAsyncCallback:Void(id:Int)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("id",&l_id);
  bbDBStmt(3010562);
  if(g_mojo_app_AppInstance__0asyncCallbacks->m_Contains(l_id)){
    bbDBBlock db_blk;
    bbDBStmt(3010596);
    g_mojo_app_AppInstance__0disabledCallbacks->m__idxeq(l_id,true);
  }
}

bbInt g_mojo_app_AppInstance_AddAsyncCallback(bbFunction<void()> l_func){
  bbDBFrame db_f{"AddAsyncCallback:Int(func:Void())","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("func",&l_func);
  bbDBStmt(2945026);
  g_mojo_app_AppInstance__0nextCallbackId+=1;
  bbDBStmt(2949128);
  bbInt l_id=g_mojo_app_AppInstance__0nextCallbackId;
  bbDBLocal("id",&l_id);
  bbDBStmt(2953218);
  g_mojo_app_AppInstance__0asyncCallbacks->m__idxeq(l_id,l_func);
  bbDBStmt(2957314);
  return l_id;
}

void t_mojo_app_AppInstance::init(){
  m__0modalStack=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_View_2>();
}

void t_mojo_app_AppInstance::gcMark(){
  bbGCMark(m_Idle);
  bbGCMark(m_NextIdle);
  bbGCMark(m_KeyEventFilter);
  bbGCMark(m_MouseEventFilter);
  bbGCMark(m__0defaultFont);
  bbGCMark(m__0defaultMonoFont);
  bbGCMark(m__0hoverView);
  bbGCMark(m__0mouseView);
  bbGCMark(m__0window);
  bbGCMark(m__0modalView);
  bbGCMark(m__0modalStack);
}

void t_mojo_app_AppInstance::dbEmit(){
  bbDBEmit("Idle",&m_Idle);
  bbDBEmit("NextIdle",&m_NextIdle);
  bbDBEmit("KeyEventFilter",&m_KeyEventFilter);
  bbDBEmit("MouseEventFilter",&m_MouseEventFilter);
  bbDBEmit("_sdlThread",&m__0sdlThread);
  bbDBEmit("_glWindow",&m__0glWindow);
  bbDBEmit("_glContext",&m__0glContext);
  bbDBEmit("_defaultFont",&m__0defaultFont);
  bbDBEmit("_defaultMonoFont",&m__0defaultMonoFont);
  bbDBEmit("_requestRender",&m__0requestRender);
  bbDBEmit("_hoverView",&m__0hoverView);
  bbDBEmit("_mouseView",&m__0mouseView);
  bbDBEmit("_fps",&m__0fps);
  bbDBEmit("_fpsFrames",&m__0fpsFrames);
  bbDBEmit("_fpsMillis",&m__0fpsMillis);
  bbDBEmit("_window",&m__0window);
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_rawKey",&m__0rawKey);
  bbDBEmit("_keyChar",&m__0keyChar);
  bbDBEmit("_modifiers",&m__0modifiers);
  bbDBEmit("_mouseButton",&m__0mouseButton);
  bbDBEmit("_mouseLocation",&m__0mouseLocation);
  bbDBEmit("_mouseWheel",&m__0mouseWheel);
  bbDBEmit("_modalView",&m__0modalView);
  bbDBEmit("_modalStack",&m__0modalStack);
  bbDBEmit("_polling",&m__0polling);
}

t_mojo_app_AppInstance::t_mojo_app_AppInstance(){
  init();
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    void gcMark(){
      bbGCMarkPtr(l_style);
    }
  }f0{};
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBStmt(253954);
  g_mojo_app_App=this;
  bbDBStmt(262146);
  SDL_Init(SDL_INIT_EVERYTHING);
  bbDBStmt(270338);
  this->m__0sdlThread=SDL_ThreadID();
  bbDBStmt(278530);
  g_mojo_input_Keyboard->m_Init();
  bbDBStmt(286722);
  g_mojo_input_Mouse->m_Init();
  bbDBStmt(294914);
  g_mojo_audio_Audio->m_Init();
  bbDBStmt(311298);
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER,1);
  bbDBStmt(319490);
  this->m__0glWindow=SDL_CreateWindow(bbUtf8String(BB_T("<hidden>")),bbInt(0),bbInt(0),bbInt(0),bbInt(0),bbInt(SDL_WindowFlags(SDL_WINDOW_HIDDEN|SDL_WINDOW_OPENGL)));
  bbDBStmt(327682);
  this->m__0glContext=SDL_GL_CreateContext(this->m__0glWindow);
  bbDBStmt(335874);
  SDL_GL_MakeCurrent(this->m__0glWindow,this->m__0glContext);
  bbDBStmt(344066);
  SDL_GL_SetAttribute(SDL_GL_SHARE_WITH_CURRENT_CONTEXT,1);
  bbDBStmt(356354);
  this->m__0defaultFont=g_mojo_graphics_Font_Open(this->m_DefaultFontName(),16.0f);
  bbDBStmt(364546);
  this->m__0defaultMonoFont=g_mojo_graphics_Font_Open(this->m_DefaultMonoFontName(),16.0f);
  bbDBStmt(372744);
  f0.l_style=g_mojo_app_Style_GetStyle(bbString{});
  bbDBLocal("style",&f0.l_style);
  bbDBStmt(376834);
  f0.l_style->m_DefaultFont(this->m__0defaultFont);
  bbDBStmt(380930);
  f0.l_style->m_DefaultColor(g_std_graphics_Color_White);
}

void t_mojo_app_AppInstance::m_UpdateFPS(){
  bbDBFrame db_f{"UpdateFPS:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1576962);
  this->m__0fpsFrames+=1;
  bbDBStmt(1585160);
  bbInt l_elapsed=(g_mojo_app_App->m_Millisecs()-this->m__0fpsMillis);
  bbDBLocal("elapsed",&l_elapsed);
  bbDBStmt(1593346);
  if((l_elapsed>=250)){
    bbDBBlock db_blk;
    bbDBStmt(1597443);
    this->m__0fps=bbFloat(std::round(bbDouble((bbFloat(this->m__0fpsFrames)/(bbFloat(l_elapsed)/1000.0f)))));
    bbDBStmt(1601539);
    this->m__0fpsMillis+=l_elapsed;
    bbDBStmt(1605635);
    this->m__0fpsFrames=bbInt(0);
  }
}

void t_mojo_app_AppInstance::m_UpdateEvents(){
  struct f0_t : public bbGCFrame{
    bbFunction<void()> l_idle{};
    void gcMark(){
      bbGCMark(l_idle);
    }
  }f0{};
  bbDBFrame db_f{"UpdateEvents:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1634312);
  SDL_Event l_event{};
  bbDBLocal("event",&l_event);
  bbDBStmt(1642498);
  this->m__0polling=true;
  bbDBStmt(1650690);
  {
    bbDBLoop db_loop;
    while(bbBool(SDL_PollEvent(&l_event))){
      bbDBBlock db_blk;
      bbDBStmt(1658883);
      this->m_DispatchEvent(&l_event);
    }
  }
  bbDBStmt(1675266);
  this->m__0polling=false;
  bbDBStmt(1683464);
  f0.l_idle=this->m_Idle;
  bbDBLocal("idle",&f0.l_idle);
  bbDBStmt(1687554);
  this->m_Idle=this->m_NextIdle;
  bbDBStmt(1691650);
  this->m_NextIdle=bbFunction<void()>{};
  bbDBStmt(1695746);
  f0.l_idle();
  bbDBStmt(1703938);
  {
    struct f1_t : public bbGCFrame{
      bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
      void gcMark(){
        bbGCMarkPtr(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=g_mojo_app_Window_VisibleWindows();
    bbDBLocal("0",&f1.l_0);
    bbInt l_1=bbInt(0);
    bbDBLocal("1",&l_1);
    bbInt l_2=f1.l_0->length();
    bbDBLocal("2",&l_2);
    for(;(l_1<l_2);l_1+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_window{};
        void gcMark(){
          bbGCMarkPtr(l_window);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_window=f1.l_0->at(l_1);
      bbDBLocal("window",&f2.l_window);
    }
  }
}

void t_mojo_app_AppInstance::m_Terminate(){
  bbDBFrame db_f{"Terminate:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  exit(bbInt(0));
}

void t_mojo_app_AppInstance::m_SendWindowEvent(bbInt l_type){
  struct f0_t : public bbGCFrame{
    t_mojo_app_WindowEvent* l_event{};
    void gcMark(){
      bbGCMarkPtr(l_event);
    }
  }f0{};
  bbDBFrame db_f{"SendWindowEvent:Void(type:mojo.app.EventType)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("type",&l_type);
  bbDBStmt(1880072);
  f0.l_event=bbGCNew<t_mojo_app_WindowEvent>(l_type,this->m__0window);
  bbDBLocal("event",&f0.l_event);
  bbDBStmt(1888258);
  this->m__0window->m_SendWindowEvent(f0.l_event);
}

void t_mojo_app_AppInstance::m_SendMouseEvent(bbInt l_type,t_mojo_app_View* l_view){
  struct f0_t : public bbGCFrame{
    t_mojo_app_MouseEvent* l_event{};
    void gcMark(){
      bbGCMarkPtr(l_event);
    }
  }f0{};
  bbDBFrame db_f{"SendMouseEvent:Void(type:mojo.app.EventType,view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("type",&l_type);
  bbDBLocal("view",&l_view);
  bbDBStmt(1818632);
  t_std_geom_Vec2_1i l_location=l_view->m_TransformWindowPointToView(this->m__0mouseLocation);
  bbDBLocal("location",&l_location);
  bbDBStmt(1826824);
  f0.l_event=bbGCNew<t_mojo_app_MouseEvent>(l_type,l_view,l_location,this->m__0mouseButton,this->m__0mouseWheel,this->m__0modifiers);
  bbDBLocal("event",&f0.l_event);
  bbDBStmt(1835010);
  this->m_MouseEventFilter(f0.l_event);
  bbDBStmt(1843202);
  if(f0.l_event->m_Eaten()){
    bbDBBlock db_blk;
    bbDBStmt(1843217);
    return;
  }
  bbDBStmt(1851394);
  if((bbBool(this->m__0modalView)&&!l_view->m_IsChildOf(this->m__0modalView))){
    bbDBBlock db_blk;
    bbDBStmt(1851445);
    return;
  }
  bbDBStmt(1859586);
  l_view->m_SendMouseEvent(f0.l_event);
}

void t_mojo_app_AppInstance::m_SendKeyEvent(bbInt l_type){
  struct f0_t : public bbGCFrame{
    t_mojo_app_KeyEvent* l_event{};
    t_mojo_app_View* l_view{};
    void gcMark(){
      bbGCMarkPtr(l_event);
      bbGCMarkPtr(l_view);
    }
  }f0{};
  bbDBFrame db_f{"SendKeyEvent:Void(type:mojo.app.EventType)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("type",&l_type);
  bbDBStmt(1736712);
  f0.l_view=this->m_KeyView();
  bbDBLocal("view",&f0.l_view);
  bbDBStmt(1740802);
  if((bbBool(f0.l_view)&&!f0.l_view->m_ReallyEnabled())){
    bbDBBlock db_blk;
    bbDBStmt(1740837);
    f0.l_view=((t_mojo_app_View*)0);
  }
  bbDBStmt(1749000);
  f0.l_event=bbGCNew<t_mojo_app_KeyEvent>(l_type,f0.l_view,this->m__0key,this->m__0rawKey,this->m__0modifiers,this->m__0keyChar);
  bbDBLocal("event",&f0.l_event);
  bbDBStmt(1757186);
  this->m_KeyEventFilter(f0.l_event);
  bbDBStmt(1765378);
  if(f0.l_event->m_Eaten()){
    bbDBBlock db_blk;
    bbDBStmt(1765393);
    return;
  }
  bbDBStmt(1773570);
  if((bbBool(this->m__0modalView)&&!f0.l_view->m_IsChildOf(this->m__0modalView))){
    bbDBBlock db_blk;
    bbDBStmt(1773621);
    return;
  }
  bbDBStmt(1781762);
  if(bbBool(f0.l_view)){
    bbDBBlock db_blk;
    bbDBStmt(1785859);
    f0.l_view->m_SendKeyEvent(f0.l_event);
  }else if(bbDBStmt(1789954),bbBool(this->m_ActiveWindow())){
    struct f1_t : public bbGCFrame{
      t_mojo_app_Window* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(1794051);
    (f1.t0=this->m_ActiveWindow())->m_SendKeyEvent(f0.l_event);
  }
}

void t_mojo_app_AppInstance::m_Run(){
  bbDBFrame db_f{"Run:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1347586);
  SDL_AddEventWatch(g_mojo_app_AppInstance__0EventFilter,((void*)0));
  bbDBStmt(1355778);
  this->m_RequestRender();
  bbDBStmt(1384450);
  {
    bbDBLoop db_loop;
    for(;;){
      bbDBBlock db_blk;
      bbDBStmt(1392643);
      this->m_MainLoop();
    }
  }
}

void t_mojo_app_AppInstance::m_RequestRender(){
  bbDBFrame db_f{"RequestRender:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1179650);
  this->m__0requestRender=true;
}

t_mojo_app_View* t_mojo_app_AppInstance::m_MouseView(){
  bbDBFrame db_f{"MouseView:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(733186);
  return this->m__0mouseView;
}

t_std_geom_Vec2_1i t_mojo_app_AppInstance::m_MouseLocation(){
  bbDBFrame db_f{"MouseLocation:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(999426);
  return this->m__0mouseLocation;
}

bbInt t_mojo_app_AppInstance::m_Millisecs(){
  bbDBFrame db_f{"Millisecs:Int()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(958466);
  return SDL_GetTicks();
}

void t_mojo_app_AppInstance::m_MainLoop(){
  bbDBFrame db_f{"MainLoop:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1208322);
  if(!this->m__0requestRender){
    bbDBBlock db_blk;
    bbDBStmt(1216515);
    SDL_WaitEvent(((SDL_Event*)0));
  }
  bbDBStmt(1232898);
  this->m_UpdateEvents();
  bbDBStmt(1241090);
  if(!this->m__0requestRender){
    bbDBBlock db_blk;
    bbDBStmt(1241112);
    return;
  }
  bbDBStmt(1249282);
  this->m__0requestRender=false;
  bbDBStmt(1257474);
  this->m_UpdateFPS();
  bbDBStmt(1265666);
  {
    struct f1_t : public bbGCFrame{
      bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
      void gcMark(){
        bbGCMarkPtr(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=g_mojo_app_Window_VisibleWindows();
    bbDBLocal("0",&f1.l_0);
    bbInt l_1=bbInt(0);
    bbDBLocal("1",&l_1);
    bbInt l_2=f1.l_0->length();
    bbDBLocal("2",&l_2);
    for(;(l_1<l_2);l_1+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_window{};
        void gcMark(){
          bbGCMarkPtr(l_window);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_window=f1.l_0->at(l_1);
      bbDBLocal("window",&f2.l_window);
      bbDBStmt(1269763);
      f2.l_window->m_Update();
      bbDBStmt(1273859);
      f2.l_window->m_Render();
    }
  }
}

void t_mojo_app_AppInstance::m_KeyView(t_mojo_app_View* l_keyView){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_window{};
    void gcMark(){
      bbGCMarkPtr(l_window);
    }
  }f0{};
  bbDBFrame db_f{"KeyView:Void(keyView:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("keyView",&l_keyView);
  bbDBStmt(684040);
  f0.l_window=this->m_ActiveWindow();
  bbDBLocal("window",&f0.l_window);
  bbDBStmt(688130);
  if(bbBool(f0.l_window)){
    bbDBBlock db_blk;
    bbDBStmt(688140);
    f0.l_window->m_KeyView(l_keyView);
  }
}

t_mojo_app_View* t_mojo_app_AppInstance::m_KeyView(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_window{};
    void gcMark(){
      bbGCMarkPtr(l_window);
    }
  }f0{};
  bbDBFrame db_f{"KeyView:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(655368);
  f0.l_window=this->m_ActiveWindow();
  bbDBLocal("window",&f0.l_window);
  bbDBStmt(659458);
  if(bbBool(f0.l_window)){
    bbDBBlock db_blk;
    bbDBStmt(659468);
    return f0.l_window->m_KeyView();
  }
  bbDBStmt(667650);
  return ((t_mojo_app_View*)0);
}

t_mojo_app_View* t_mojo_app_AppInstance::m_HoverView(){
  bbDBFrame db_f{"HoverView:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(774146);
  return this->m__0hoverView;
}

bbArray<t_mojo_app_DisplayMode>* t_mojo_app_AppInstance::m_GetDisplayModes(){
  struct f0_t : public bbGCFrame{
    bbArray<t_mojo_app_DisplayMode>* l_modes{};
    void gcMark(){
      bbGCMarkPtr(l_modes);
    }
  }f0{};
  bbDBFrame db_f{"GetDisplayModes:mojo.app.DisplayMode[]()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1028104);
  bbInt l_n=SDL_GetNumDisplayModes(bbInt(0));
  bbDBLocal("n",&l_n);
  bbDBStmt(1032200);
  f0.l_modes=bbArray<t_mojo_app_DisplayMode>::create(l_n);
  bbDBLocal("modes",&f0.l_modes);
  bbDBStmt(1036290);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1036290);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1040393);
      SDL_DisplayMode l_mode{};
      bbDBLocal("mode",&l_mode);
      bbDBStmt(1044483);
      SDL_GetDisplayMode(bbInt(0),l_i,&l_mode);
      bbDBStmt(1048579);
      f0.l_modes->at(l_i).m_width=l_mode.w;
      bbDBStmt(1052675);
      f0.l_modes->at(l_i).m_height=l_mode.h;
      bbDBStmt(1056771);
      f0.l_modes->at(l_i).m_hertz=l_mode.refresh_rate;
    }
  }
  bbDBStmt(1069058);
  return f0.l_modes;
}

bbFloat t_mojo_app_AppInstance::m_FPS(){
  bbDBFrame db_f{"FPS:Float()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(917506);
  return this->m__0fps;
}

bbInt t_mojo_app_AppInstance::m_EventFilter(void* l_userData,SDL_Event* l_event){
  bbDBFrame db_f{"EventFilter:Int(userData:Void Ptr,event:sdl2.SDL_Event Ptr)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("userData",&l_userData);
  bbDBLocal("event",&l_event);
  bbDBStmt(2781186);
  if(l_event[bbInt(0)].type==bbInt(SDL_WINDOWEVENT)){
    bbDBBlock db_blk;
    bbDBStmt(2793481);
    SDL_WindowEvent* l_wevent=((SDL_WindowEvent*)(l_event));
    bbDBLocal("wevent",&l_wevent);
    bbDBStmt(2801667);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_wevent[bbInt(0)].windowID));
    bbDBStmt(2805763);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2805778);
      return 1;
    }
    bbDBStmt(2813955);
    if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_MOVED)){
      bbDBBlock db_blk;
      bbDBStmt(2830340);
      this->m_SendWindowEvent(11);
      bbDBStmt(2838532);
      return bbInt(0);
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_RESIZED)){
      bbDBBlock db_blk;
      bbDBStmt(2854916);
      this->m_SendWindowEvent(12);
      bbDBStmt(2863108);
      if(this->m__0requestRender){
        bbDBBlock db_blk;
        bbDBStmt(2871301);
        this->m__0requestRender=false;
        bbDBStmt(2879493);
        {
          struct f4_t : public bbGCFrame{
            bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
            void gcMark(){
              bbGCMarkPtr(l_0);
            }
          }f4{};
          bbDBLoop db_loop;
          f4.l_0=g_mojo_app_Window_VisibleWindows();
          bbDBLocal("0",&f4.l_0);
          bbInt l_1=bbInt(0);
          bbDBLocal("1",&l_1);
          bbInt l_2=f4.l_0->length();
          bbDBLocal("2",&l_2);
          for(;(l_1<l_2);l_1+=1){
            struct f5_t : public bbGCFrame{
              t_mojo_app_Window* l_window{};
              void gcMark(){
                bbGCMarkPtr(l_window);
              }
            }f5{};
            bbDBBlock db_blk;
            f5.l_window=f4.l_0->at(l_1);
            bbDBLocal("window",&f5.l_window);
            bbDBStmt(2883590);
            f5.l_window->m_Update();
            bbDBStmt(2887686);
            f5.l_window->m_Render();
          }
        }
      }
      bbDBStmt(2908164);
      return bbInt(0);
    }
  }
  bbDBStmt(2928642);
  return 1;
}

void t_mojo_app_AppInstance::m_EndModal(){
  bbDBFrame db_f{"EndModal:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1122306);
  this->m__0modalView=this->m__0modalStack->m_Pop();
}

void t_mojo_app_AppInstance::m_DispatchEvent(SDL_Event* l_event){
  bbDBFrame db_f{"DispatchEvent:Void(event:sdl2.SDL_Event Ptr)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbDBStmt(1908738);
  if(l_event[bbInt(0)].type==bbInt(SDL_KEYDOWN)){
    bbDBBlock db_blk;
    bbDBStmt(1925129);
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    bbDBLocal("kevent",&l_kevent);
    bbDBStmt(1933315);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_kevent[bbInt(0)].windowID));
    bbDBStmt(1937411);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(1937426);
      return;
    }
    bbDBStmt(1945603);
    this->m__0key=g_mojo_input_Keyboard->m_KeyCodeToKey(l_kevent[bbInt(0)].keysym.sym);
    bbDBStmt(1949699);
    this->m__0rawKey=g_mojo_input_Keyboard->m_ScanCodeToRawKey(bbInt(l_kevent[bbInt(0)].keysym.scancode));
    bbDBStmt(1957891);
    this->m__0keyChar=g_mojo_input_Keyboard->m_KeyName(this->m__0key);
    bbDBStmt(1966083);
    if(bbBool(l_kevent[bbInt(0)].repeat)){
      bbDBBlock db_blk;
      bbDBStmt(1970180);
      this->m_SendKeyEvent(1);
    }else{
      bbDBStmt(1974275);
      bbDBBlock db_blk;
      bbDBStmt(1978372);
      this->m_SendKeyEvent(0);
    }
    bbDBStmt(1990659);
    this->m__0modifiers=g_mojo_input_Keyboard->m_Modifiers();
  }else if(l_event[bbInt(0)].type==bbInt(SDL_KEYUP)){
    bbDBBlock db_blk;
    bbDBStmt(2007049);
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    bbDBLocal("kevent",&l_kevent);
    bbDBStmt(2015235);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_kevent[bbInt(0)].windowID));
    bbDBStmt(2019331);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2019346);
      return;
    }
    bbDBStmt(2027523);
    this->m__0key=g_mojo_input_Keyboard->m_KeyCodeToKey(l_kevent[bbInt(0)].keysym.sym);
    bbDBStmt(2031619);
    this->m__0rawKey=g_mojo_input_Keyboard->m_ScanCodeToRawKey(bbInt(l_kevent[bbInt(0)].keysym.scancode));
    bbDBStmt(2039811);
    this->m__0keyChar=g_mojo_input_Keyboard->m_KeyName(this->m__0key);
    bbDBStmt(2048003);
    this->m_SendKeyEvent(2);
    bbDBStmt(2056195);
    this->m__0modifiers=g_mojo_input_Keyboard->m_Modifiers();
  }else if(l_event[bbInt(0)].type==bbInt(SDL_TEXTINPUT)){
    bbDBBlock db_blk;
    bbDBStmt(2072585);
    SDL_TextInputEvent* l_tevent=((SDL_TextInputEvent*)(l_event));
    bbDBLocal("tevent",&l_tevent);
    bbDBStmt(2080771);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_tevent[bbInt(0)].windowID));
    bbDBStmt(2084867);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2084882);
      return;
    }
    bbDBStmt(2093059);
    this->m__0keyChar=bbString::fromChar(bbInt(l_tevent[bbInt(0)].text[bbInt(0)]));
    bbDBStmt(2101251);
    this->m_SendKeyEvent(3);
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEBUTTONDOWN)){
    bbDBBlock db_blk;
    bbDBStmt(2117641);
    SDL_MouseButtonEvent* l_mevent=((SDL_MouseButtonEvent*)(l_event));
    bbDBLocal("mevent",&l_mevent);
    bbDBStmt(2125827);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    bbDBStmt(2129923);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2129938);
      return;
    }
    bbDBStmt(2138115);
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    bbDBStmt(2142211);
    this->m__0mouseButton=((bbInt)(l_mevent[bbInt(0)].button));
    bbDBStmt(2150403);
    if(!bbBool(this->m__0mouseView)){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      bbDBBlock db_blk;
      bbDBStmt(2158602);
      f2.l_view=this->m__0window->m_FindViewAtWindowPoint(this->m__0mouseLocation);
      bbDBLocal("view",&f2.l_view);
      bbDBStmt(2162692);
      if(bbBool(f2.l_view)){
        bbDBBlock db_blk;
        bbDBStmt(2170885);
        SDL_CaptureMouse(SDL_TRUE);
        bbDBStmt(2179077);
        this->m__0mouseView=f2.l_view;
      }
    }
    bbDBStmt(2195459);
    if(bbBool(this->m__0mouseView)){
      bbDBBlock db_blk;
      bbDBStmt(2195473);
      this->m_SendMouseEvent(4,this->m__0mouseView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEBUTTONUP)){
    bbDBBlock db_blk;
    bbDBStmt(2211849);
    SDL_MouseButtonEvent* l_mevent=((SDL_MouseButtonEvent*)(l_event));
    bbDBLocal("mevent",&l_mevent);
    bbDBStmt(2220035);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    bbDBStmt(2224131);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2224146);
      return;
    }
    bbDBStmt(2232323);
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    bbDBStmt(2236419);
    this->m__0mouseButton=((bbInt)(l_mevent[bbInt(0)].button));
    bbDBStmt(2244611);
    if(bbBool(this->m__0mouseView)){
      bbDBBlock db_blk;
      bbDBStmt(2252804);
      this->m_SendMouseEvent(5,this->m__0mouseView);
      bbDBStmt(2260996);
      SDL_CaptureMouse(SDL_FALSE);
      bbDBStmt(2269188);
      this->m__0mouseView=((t_mojo_app_View*)0);
      bbDBStmt(2277380);
      this->m__0mouseButton=bbInt(0);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEMOTION)){
    struct f1_t : public bbGCFrame{
      t_mojo_app_View* l_view{};
      void gcMark(){
        bbGCMarkPtr(l_view);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(2297865);
    SDL_MouseMotionEvent* l_mevent=((SDL_MouseMotionEvent*)(l_event));
    bbDBLocal("mevent",&l_mevent);
    bbDBStmt(2306051);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    bbDBStmt(2310147);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2310162);
      return;
    }
    bbDBStmt(2318339);
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    bbDBStmt(2326537);
    f1.l_view=this->m__0window->m_FindViewAtWindowPoint(this->m__0mouseLocation);
    bbDBLocal("view",&f1.l_view);
    bbDBStmt(2334723);
    if((bbBool(this->m__0mouseView)&&(f1.l_view!=this->m__0mouseView))){
      bbDBBlock db_blk;
      bbDBStmt(2334758);
      f1.l_view=((t_mojo_app_View*)0);
    }
    bbDBStmt(2342915);
    if((f1.l_view!=this->m__0hoverView)){
      bbDBBlock db_blk;
      bbDBStmt(2351108);
      if(bbBool(this->m__0hoverView)){
        bbDBBlock db_blk;
        bbDBStmt(2351122);
        this->m_SendMouseEvent(9,this->m__0hoverView);
      }
      bbDBStmt(2359300);
      this->m__0hoverView=f1.l_view;
      bbDBStmt(2367492);
      if(bbBool(this->m__0hoverView)){
        bbDBBlock db_blk;
        bbDBStmt(2367506);
        this->m_SendMouseEvent(8,this->m__0hoverView);
      }
    }
    bbDBStmt(2379779);
    if(bbBool(this->m__0mouseView)){
      bbDBBlock db_blk;
      bbDBStmt(2387972);
      this->m_SendMouseEvent(6,this->m__0mouseView);
    }else if(bbDBStmt(2396163),bbBool(this->m__0hoverView)){
      bbDBBlock db_blk;
      bbDBStmt(2404356);
      this->m_SendMouseEvent(6,this->m__0hoverView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEWHEEL)){
    bbDBBlock db_blk;
    bbDBStmt(2428937);
    SDL_MouseWheelEvent* l_mevent=((SDL_MouseWheelEvent*)(l_event));
    bbDBLocal("mevent",&l_mevent);
    bbDBStmt(2437123);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    bbDBStmt(2441219);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2441234);
      return;
    }
    bbDBStmt(2449411);
    this->m__0mouseWheel=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    bbDBStmt(2457603);
    if(bbBool(this->m__0mouseView)){
      bbDBBlock db_blk;
      bbDBStmt(2465796);
      this->m_SendMouseEvent(7,this->m__0mouseView);
    }else if(bbDBStmt(2473987),bbBool(this->m__0hoverView)){
      bbDBBlock db_blk;
      bbDBStmt(2482180);
      this->m_SendMouseEvent(7,this->m__0hoverView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_WINDOWEVENT)){
    bbDBBlock db_blk;
    bbDBStmt(2506761);
    SDL_WindowEvent* l_wevent=((SDL_WindowEvent*)(l_event));
    bbDBLocal("wevent",&l_wevent);
    bbDBStmt(2514947);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_wevent[bbInt(0)].windowID));
    bbDBStmt(2519043);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2519058);
      return;
    }
    bbDBStmt(2527235);
    if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_CLOSE)){
      bbDBBlock db_blk;
      bbDBStmt(2543620);
      this->m_SendWindowEvent(10);
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_MOVED)){
      bbDBBlock db_blk;
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_RESIZED)){
      bbDBBlock db_blk;
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_SIZE_CHANGED)){
      bbDBBlock db_blk;
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_FOCUS_GAINED)){
      bbDBBlock db_blk;
      bbDBStmt(2584580);
      this->m_SendWindowEvent(13);
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_FOCUS_LOST)){
      bbDBBlock db_blk;
      bbDBStmt(2600964);
      this->m_SendWindowEvent(14);
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_LEAVE)){
      bbDBBlock db_blk;
      bbDBStmt(2617348);
      if(bbBool(this->m__0hoverView)){
        bbDBBlock db_blk;
        bbDBStmt(2621445);
        this->m_SendMouseEvent(9,this->m__0hoverView);
        bbDBStmt(2625541);
        this->m__0hoverView=((t_mojo_app_View*)0);
      }
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_USEREVENT)){
    bbDBBlock db_blk;
    bbDBStmt(2654217);
    SDL_UserEvent* l_t=((SDL_UserEvent*)(l_event));
    bbDBLocal("t",&l_t);
    bbDBStmt(2662409);
    bbInt l_code=l_t[bbInt(0)].code;
    bbDBLocal("code",&l_code);
    bbDBStmt(2666505);
    bbInt l_id=(l_code&1073741823);
    bbDBLocal("id",&l_id);
    bbDBStmt(2674691);
    if(bbBool((l_code&1073741824))){
      struct f2_t : public bbGCFrame{
        bbFunction<void()> l_func{};
        void gcMark(){
          bbGCMark(l_func);
        }
      }f2{};
      bbDBBlock db_blk;
      bbDBStmt(2678794);
      f2.l_func=g_mojo_app_AppInstance__0asyncCallbacks->m__idx(l_id);
      bbDBLocal("func",&f2.l_func);
      bbDBStmt(2682884);
      if(bbBool((l_code&2147483648))){
        bbDBBlock db_blk;
        bbDBStmt(2682904);
        g_mojo_app_AppInstance_RemoveAsyncCallback(l_id);
      }
      bbDBStmt(2686980);
      if(!g_mojo_app_AppInstance__0disabledCallbacks->m__idx(l_id)){
        bbDBBlock db_blk;
        bbDBStmt(2687010);
        f2.l_func();
      }
    }else if(bbDBStmt(2691075),bbBool((l_code&2147483648))){
      bbDBBlock db_blk;
      bbDBStmt(2695172);
      g_mojo_app_AppInstance_RemoveAsyncCallback(l_id);
    }
  }
}

t_std_geom_Vec2_1i t_mojo_app_AppInstance::m_DesktopSize(){
  bbDBFrame db_f{"DesktopSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(823304);
  SDL_DisplayMode l_dm{};
  bbDBLocal("dm",&l_dm);
  bbDBStmt(831490);
  if(bbBool(SDL_GetDesktopDisplayMode(bbInt(0),&l_dm))){
    bbDBBlock db_blk;
    bbDBStmt(831534);
    return t_std_geom_Vec2_1i(bbNullCtor);
  }
  bbDBStmt(839682);
  return t_std_geom_Vec2_1i(l_dm.w,l_dm.h);
}

bbString t_mojo_app_AppInstance::m_DefaultMonoFontName(){
  bbDBFrame db_f{"DefaultMonoFontName:String()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(430082);
  return BB_T("asset::mojo/RobotoMono-Regular.ttf");
}

t_mojo_graphics_Font* t_mojo_app_AppInstance::m_DefaultMonoFont(){
  bbDBFrame db_f{"DefaultMonoFont:mojo.graphics.Font()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(479234);
  return this->m__0defaultMonoFont;
}

bbString t_mojo_app_AppInstance::m_DefaultFontName(){
  bbDBFrame db_f{"DefaultFontName:String()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(405506);
  return BB_T("asset::mojo/Roboto-Regular.ttf");
}

t_mojo_graphics_Font* t_mojo_app_AppInstance::m_DefaultFont(){
  bbDBFrame db_f{"DefaultFont:mojo.graphics.Font()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(454658);
  return this->m__0defaultFont;
}

bbBool t_mojo_app_AppInstance::m_ClipboardTextEmpty(){
  bbDBFrame db_f{"ClipboardTextEmpty:Bool()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(520194);
  return (SDL_HasClipboardText()==SDL_FALSE);
}

void t_mojo_app_AppInstance::m_ClipboardText(bbString l_text){
  bbDBFrame db_f{"ClipboardText:Void(text:String)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("text",&l_text);
  bbDBStmt(614402);
  SDL_SetClipboardText(bbUtf8String(l_text));
}

bbString t_mojo_app_AppInstance::m_ClipboardText(){
  bbDBFrame db_f{"ClipboardText:String()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(548866);
  if((SDL_HasClipboardText()==SDL_FALSE)){
    bbDBBlock db_blk;
    bbDBStmt(548902);
    return bbString{};
  }
  bbDBStmt(557064);
  char* l_p=SDL_GetClipboardText();
  bbDBLocal("p",&l_p);
  bbDBStmt(565256);
  bbString l_str=bbString::fromUtf8String(((void*)(l_p)));
  bbDBLocal("str",&l_str);
  bbDBStmt(577538);
  l_str=l_str.replace(BB_T("\r\n"),BB_T("\n"));
  bbDBStmt(581634);
  l_str=l_str.replace(BB_T("\r"),BB_T("\n"));
  bbDBStmt(589826);
  SDL_free(((void*)(l_p)));
  bbDBStmt(598018);
  return l_str;
}

void t_mojo_app_AppInstance::m_BeginModal(t_mojo_app_View* l_view){
  bbDBFrame db_f{"BeginModal:Void(view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("view",&l_view);
  bbDBStmt(1093634);
  this->m__0modalStack->m_Push(this->m__0modalView);
  bbDBStmt(1097730);
  this->m__0modalView=l_view;
}

t_mojo_app_Window* t_mojo_app_AppInstance::m_ActiveWindow(){
  bbDBFrame db_f{"ActiveWindow:mojo.app.Window()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(888834);
  return g_mojo_app_Window_VisibleWindows()->at(bbInt(0));
}
bbString bbDBType(t_mojo_app_AppInstance**){
  return "mojo.app.AppInstance";
}
bbString bbDBValue(t_mojo_app_AppInstance**p){
  return bbDBObjectValue(*p);
}

void t_mojo_app_DisplayMode::dbEmit(t_mojo_app_DisplayMode*p){
  bbDBEmit("width",&p->m_width);
  bbDBEmit("height",&p->m_height);
  bbDBEmit("hertz",&p->m_hertz);
}
bbString bbDBType(t_mojo_app_DisplayMode*){
  return "mojo.app.DisplayMode";
}
bbString bbDBValue(t_mojo_app_DisplayMode*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_mojo_app_DisplayMode&x,const t_mojo_app_DisplayMode&y){
  if(int t=bbCompare(x.m_width,y.m_width)) return t;
  if(int t=bbCompare(x.m_height,y.m_height)) return t;
  if(int t=bbCompare(x.m_hertz,y.m_hertz)) return t;
  return 0;
}

void mx2_mojo_app_2app_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_app_AppInstance__0asyncCallbacks=bbGCNew<t_std_collections_Map_1iFvE>();
  g_mojo_app_AppInstance__0disabledCallbacks=bbGCNew<t_std_collections_Map_1iz>();
}

bbInit mx2_mojo_app_2app_init_v("mojo_app_2app",&mx2_mojo_app_2app_init);
