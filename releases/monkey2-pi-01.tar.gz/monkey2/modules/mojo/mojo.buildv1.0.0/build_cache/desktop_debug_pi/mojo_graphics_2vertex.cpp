
#include "../../desktop_debug_pi/mojo_graphics_2vertex.h"

// ***** External *****

// ***** Internal *****

void t_mojo_graphics_Vertex2f::dbEmit(t_mojo_graphics_Vertex2f*p){
  bbDBEmit("x",&p->m_x);
  bbDBEmit("y",&p->m_y);
  bbDBEmit("s0",&p->m_s0);
  bbDBEmit("t0",&p->m_t0);
  bbDBEmit("ix",&p->m_ix);
  bbDBEmit("iy",&p->m_iy);
  bbDBEmit("color",&p->m_color);
}

t_mojo_graphics_Vertex2f::t_mojo_graphics_Vertex2f(bbFloat l_x,bbFloat l_y,bbFloat l_s0,bbFloat l_t0,bbFloat l_ix,bbFloat l_iy,bbUInt l_colorARGB){
  bbDBFrame db_f{"new:Void(x:Float,y:Float,s0:Float,t0:Float,ix:Float,iy:Float,colorARGB:Uint)","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBLocal("s0",&l_s0);
  bbDBLocal("t0",&l_t0);
  bbDBLocal("ix",&l_ix);
  bbDBLocal("iy",&l_iy);
  bbDBLocal("colorARGB",&l_colorARGB);
  bbDBStmt(98306);
  (*this).m_x=l_x;
  bbDBStmt(98315);
  (*this).m_y=l_y;
  bbDBStmt(102402);
  (*this).m_s0=l_s0;
  bbDBStmt(102413);
  (*this).m_t0=l_t0;
  bbDBStmt(106498);
  (*this).m_ix=l_ix;
  bbDBStmt(106509);
  (*this).m_iy=l_iy;
  bbDBStmt(110594);
  (*this).m_color=l_colorARGB;
}

t_mojo_graphics_Vertex2f::t_mojo_graphics_Vertex2f(t_std_geom_Vec2_1f l_position,t_std_geom_Vec2_1f l_texCoord0,t_std_geom_Vec2_1f l_tangent,bbUInt l_colorARGB){
  bbDBFrame db_f{"new:Void(position:Vec2f:std.geom.Vec2<Float>,texCoord0:Vec2f:std.geom.Vec2<Float>,tangent:Vec2f:std.geom.Vec2<Float>,colorARGB:Uint)","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  bbDBLocal("position",&l_position);
  bbDBLocal("texCoord0",&l_texCoord0);
  bbDBLocal("tangent",&l_tangent);
  bbDBLocal("colorARGB",&l_colorARGB);
  bbDBStmt(69634);
  (*this).m_Position(l_position);
  bbDBStmt(73730);
  (*this).m_TexCoord0(l_texCoord0);
  bbDBStmt(77826);
  (*this).m_Tangent(l_tangent);
  bbDBStmt(81922);
  (*this).m_ColorARGB(l_colorARGB);
}

t_mojo_graphics_Vertex2f::t_mojo_graphics_Vertex2f(bbNullCtor_t){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
}

void t_mojo_graphics_Vertex2f::m_TexCoord0(t_std_geom_Vec2_1f l_texCoord0){
  bbDBFrame db_f{"TexCoord0:Void(texCoord0:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  t_mojo_graphics_Vertex2f*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("texCoord0",&l_texCoord0);
  bbDBStmt(163842);
  (*this).m_s0=l_texCoord0.m_x;
  bbDBStmt(167938);
  (*this).m_t0=l_texCoord0.m_y;
}

t_std_geom_Vec2_1f t_mojo_graphics_Vertex2f::m_TexCoord0(){
  bbDBFrame db_f{"TexCoord0:Vec2f:std.geom.Vec2<Float>()","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  t_mojo_graphics_Vertex2f*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(155650);
  return t_std_geom_Vec2_1f((*this).m_s0,(*this).m_t0);
}

void t_mojo_graphics_Vertex2f::m_Tangent(t_std_geom_Vec2_1f l_tangent){
  bbDBFrame db_f{"Tangent:Void(tangent:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  t_mojo_graphics_Vertex2f*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("tangent",&l_tangent);
  bbDBStmt(192514);
  (*this).m_ix=l_tangent.m_x;
  bbDBStmt(196610);
  (*this).m_iy=l_tangent.m_y;
}

t_std_geom_Vec2_1f t_mojo_graphics_Vertex2f::m_Tangent(){
  bbDBFrame db_f{"Tangent:Vec2f:std.geom.Vec2<Float>()","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  t_mojo_graphics_Vertex2f*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(184322);
  return t_std_geom_Vec2_1f((*this).m_ix,(*this).m_iy);
}

void t_mojo_graphics_Vertex2f::m_Position(t_std_geom_Vec2_1f l_position){
  bbDBFrame db_f{"Position:Void(position:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  t_mojo_graphics_Vertex2f*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("position",&l_position);
  bbDBStmt(135170);
  (*this).m_x=l_position.m_x;
  bbDBStmt(139266);
  (*this).m_y=l_position.m_y;
}

t_std_geom_Vec2_1f t_mojo_graphics_Vertex2f::m_Position(){
  bbDBFrame db_f{"Position:Vec2f:std.geom.Vec2<Float>()","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  t_mojo_graphics_Vertex2f*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(126978);
  return t_std_geom_Vec2_1f((*this).m_x,(*this).m_y);
}

void t_mojo_graphics_Vertex2f::m_ColorARGB(bbUInt l_colorARGB){
  bbDBFrame db_f{"ColorARGB:Void(colorARGB:Uint)","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  t_mojo_graphics_Vertex2f*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("colorARGB",&l_colorARGB);
  bbDBStmt(221186);
  (*this).m_color=l_colorARGB;
}

bbUInt t_mojo_graphics_Vertex2f::m_ColorARGB(){
  bbDBFrame db_f{"ColorARGB:Uint()","/home/pi/monkey2/modules/mojo/graphics/vertex.monkey2"};
  t_mojo_graphics_Vertex2f*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(212994);
  return (*this).m_color;
}
bbString bbDBType(t_mojo_graphics_Vertex2f*){
  return "mojo.graphics.Vertex2f";
}
bbString bbDBValue(t_mojo_graphics_Vertex2f*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_mojo_graphics_Vertex2f&x,const t_mojo_graphics_Vertex2f&y){
  if(int t=bbCompare(x.m_x,y.m_x)) return t;
  if(int t=bbCompare(x.m_y,y.m_y)) return t;
  if(int t=bbCompare(x.m_s0,y.m_s0)) return t;
  if(int t=bbCompare(x.m_t0,y.m_t0)) return t;
  if(int t=bbCompare(x.m_ix,y.m_ix)) return t;
  if(int t=bbCompare(x.m_iy,y.m_iy)) return t;
  if(int t=bbCompare(x.m_color,y.m_color)) return t;
  return 0;
}

void mx2_mojo_graphics_2vertex_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2vertex_init_v("mojo_graphics_2vertex",&mx2_mojo_graphics_2vertex_init);
