
#include "../../desktop_debug_pi/mojo_input_2keycodes.h"

// ***** External *****

// ***** Internal *****

void mx2_mojo_input_2keycodes_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_input_2keycodes_init_v("mojo_input_2keycodes",&mx2_mojo_input_2keycodes_init);
