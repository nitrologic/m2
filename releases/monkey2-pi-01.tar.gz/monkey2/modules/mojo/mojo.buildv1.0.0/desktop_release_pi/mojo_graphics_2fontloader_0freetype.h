
#ifndef MX2_MOJO_GRAPHICS_2FONTLOADER_0FREETYPE_H
#define MX2_MOJO_GRAPHICS_2FONTLOADER_0FREETYPE_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../freetype/freetype.buildv1.0.0/desktop_release_pi/freetype_freetype.h"

struct t_mojo_graphics_Font;
struct t_mojo_graphics_Shader;

// ***** Internal *****

extern FT_LibraryRec_* g_mojo_graphics_fontloader_FreeType;

extern t_mojo_graphics_Font* g_mojo_graphics_fontloader_LoadFont(bbString l_path,bbFloat l_fheight,bbInt l_textureFlags,t_mojo_graphics_Shader* l_shader);

#endif
