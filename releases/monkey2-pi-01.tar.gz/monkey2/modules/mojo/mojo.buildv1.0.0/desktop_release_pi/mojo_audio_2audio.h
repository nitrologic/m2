
#ifndef MX2_MOJO_AUDIO_2AUDIO_H
#define MX2_MOJO_AUDIO_2AUDIO_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_types.h"
#include "../../../sdl2-mixer/sdl2-mixer.buildv1.0.0/desktop_release_pi/sdl2_5mixer_sdl2_5mixer.h"

// ***** Internal *****

struct t_mojo_audio_AudioDevice;
struct t_mojo_audio_Sound;
struct t_mojo_audio_Channel;

extern bbGCRootVar<bbArray<bbInt>> g_mojo_audio__0alloced;
extern bbGCRootVar<t_mojo_audio_AudioDevice> g_mojo_audio_Audio;

extern t_mojo_audio_Sound* g_mojo_audio_Sound_Load(bbString l_path);

struct t_mojo_audio_AudioDevice : public bbObject{

  const char *typeName()const{return "t_mojo_audio_AudioDevice";}

  void m_Init();

  t_mojo_audio_AudioDevice(){
  }
};

struct t_mojo_audio_Sound : public bbObject{

  const char *typeName()const{return "t_mojo_audio_Sound";}

  Mix_Chunk* m__0chunk{};

  t_mojo_audio_Sound(Mix_Chunk* l_chunk);

  t_mojo_audio_Channel* m_Play(bbInt l_loops);

  t_mojo_audio_Sound(){
  }
};

struct t_mojo_audio_Channel : public bbObject{

  const char *typeName()const{return "t_mojo_audio_Channel";}

  bbInt m__0id=bbInt(0);
  bbFloat m__0volume=1.0f;

  t_mojo_audio_Channel();

  void m_Volume(bbFloat l_volume);
  bbFloat m_Volume();
  void m_Stop();
  void m_Rate(bbFloat l_rate);
  bbFloat m_Rate();
  bbBool m_Playing();
  bbBool m_Play(t_mojo_audio_Sound* l_sound,bbInt l_loops);
  void m_Paused(bbBool l_paused);
  bbBool m_Paused();
  void m_Pan(bbFloat l_pan);
  bbFloat m_Pan();
  bbBool m_Invalid();
};

#endif
