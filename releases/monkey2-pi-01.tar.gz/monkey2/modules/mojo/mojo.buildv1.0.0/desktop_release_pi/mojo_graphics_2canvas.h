
#ifndef MX2_MOJO_GRAPHICS_2CANVAS_H
#define MX2_MOJO_GRAPHICS_2CANVAS_H

#include <bbmonkey.h>

// ***** External *****

#include "mojo_graphics_2vertex.h"
#include "../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_release_pi/std_geom_2affinemat3.h"
#include "../../../std/std.buildv1.0.0/desktop_release_pi/std_geom_2mat4.h"
#include "../../../std/std.buildv1.0.0/desktop_release_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.0/desktop_release_pi/std_geom_2vec2.h"
#include "../../../std/std.buildv1.0.0/desktop_release_pi/std_graphics_2color.h"

struct t_mojo_graphics_ShaderEnv;
struct t_mojo_graphics_Font;
struct t_mojo_graphics_Shader;
struct t_mojo_graphics_Material;
struct t_mojo_graphics_Texture;
struct t_mojo_graphics_ParamBuffer;
struct t_mojo_graphics_GraphicsDevice;
struct t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2;
struct t_std_collections_Stack_1Tt_std_geom_Rect_1i_2;
struct t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2;
struct t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2;
struct t_mojo_graphics_Image;
struct t_std_graphics_Pixmap;

// ***** Internal *****

struct t_mojo_graphics_DrawOp;
struct t_mojo_graphics_Canvas;
struct t_mojo_graphics_Canvas_LightInst;

extern bbGCRootVar<t_mojo_graphics_ShaderEnv> g_mojo_graphics_Canvas__0ambientEnv;
extern bbGCRootVar<t_mojo_graphics_Font> g_mojo_graphics_Canvas__0defaultFont;
extern bbBool g_mojo_graphics_Canvas__0inited;
extern bbGCRootVar<t_mojo_graphics_Shader> g_mojo_graphics_Canvas__0nullShader;

struct t_mojo_graphics_DrawOp : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_DrawOp";}

  bbInt m_blendMode{};
  bbGCVar<t_mojo_graphics_Material> m_material{};
  bbInt m_order{};
  bbInt m_count{};

  void gcMark();

  t_mojo_graphics_DrawOp(){
  }
};

struct t_mojo_graphics_Canvas : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_Canvas";}

  bbInt m__0dirty{};
  bbGCVar<t_mojo_graphics_Texture> m__0target{};
  t_std_geom_Vec2_1i m__0targetSize{};
  t_std_geom_Rect_1i m__0targetRect{};
  bbGCVar<t_mojo_graphics_ParamBuffer> m__0envParams{};
  bbGCVar<t_mojo_graphics_GraphicsDevice> m__0device{};
  t_std_geom_Rect_1i m__0viewport{};
  t_std_geom_Rect_1i m__0scissor{};
  t_std_geom_Mat4_1f m__0viewMatrix{};
  t_std_geom_Mat4_1f m__0modelMatrix{};
  t_std_graphics_Color m__0ambientLight{};
  bbBool m__0filter=true;
  t_std_graphics_Color m__0renderColor{};
  t_std_geom_AffineMat3_1f m__0renderMatrix{};
  bbGCVar<t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2> m__0renderMatrixStack{};
  t_std_geom_Rect_1i m__0renderBounds{};
  bbGCVar<t_std_collections_Stack_1Tt_std_geom_Rect_1i_2> m__0renderBoundsStack{};
  bbGCVar<t_mojo_graphics_Font> m__0font{};
  bbFloat m__0alpha{};
  t_std_graphics_Color m__0color{};
  bbUInt m__0pmcolor{};
  t_std_geom_AffineMat3_1f m__0matrix{};
  bbInt m__0blendMode{};
  bbGCVar<t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2> m__0matrixStack{};
  bbGCVar<t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2> m__0ops{};
  bbGCVar<t_mojo_graphics_DrawOp> m__0op{};
  bbGCVar<t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2> m__0vertices{};
  bbGCVar<bbArray<t_mojo_graphics_Vertex2f>> m__0vertexData{};
  bbInt m__0vertex{};
  bbGCVar<bbArray<bbGCVar<t_mojo_graphics_Material>>> m__0materials{};

  void init();

  void gcMark();

  t_mojo_graphics_Canvas(bbInt l_width,bbInt l_height);
  t_mojo_graphics_Canvas(t_mojo_graphics_Texture* l_texture);
  t_mojo_graphics_Canvas(t_mojo_graphics_Image* l_image);

  void m_Viewport(t_std_geom_Rect_1i l_viewport);
  t_std_geom_Rect_1i m_Viewport();
  void m_ViewMatrix(t_std_geom_Mat4_1f l_viewMatrix);
  t_std_geom_Mat4_1f m_ViewMatrix();
  void m_Validate();
  void m_Translate(bbFloat l_tx,bbFloat l_ty);
  void m_TextureFilteringEnabled(bbBool l_enabled);
  bbBool m_TextureFilteringEnabled();
  void m_Scissor(t_std_geom_Rect_1i l_scissor);
  t_std_geom_Rect_1i m_Scissor();
  void m_Scale(bbFloat l_sx,bbFloat l_sy);
  void m_Rotate(bbFloat l_rz);
  void m_Resize(t_std_geom_Vec2_1i l_size);
  void m_RenderDrawOps();
  void m_RenderColor(t_std_graphics_Color l_renderColor);
  t_std_graphics_Color m_RenderColor();
  void m_PushMatrix();
  bbArray<bbGCVar<t_mojo_graphics_Material>>* m_PrimitiveMaterials();
  void m_PopMatrix();
  void m_ModelMatrix(t_std_geom_Mat4_1f l_modelMatrix);
  t_std_geom_Mat4_1f m_ModelMatrix();
  void m_Matrix(t_std_geom_AffineMat3_1f l_matrix);
  t_std_geom_AffineMat3_1f m_Matrix();
  void m_Init(t_mojo_graphics_Texture* l_target,t_std_geom_Vec2_1i l_size,t_std_geom_Rect_1i l_viewport);
  void m_Font(t_mojo_graphics_Font* l_font);
  t_mojo_graphics_Font* m_Font();
  void m_Flush();
  void m_EndRender();
  void m_DrawTriangle(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1,bbFloat l_x2,bbFloat l_y2);
  void m_DrawTriangle(t_std_geom_Vec2_1f l_v0,t_std_geom_Vec2_1f l_v1,t_std_geom_Vec2_1f l_v2);
  void m_DrawText(bbString l_text,bbFloat l_tx,bbFloat l_ty,bbFloat l_handleX,bbFloat l_handleY);
  void m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height,t_mojo_graphics_Image* l_srcImage,bbInt l_srcX,bbInt l_srcY,bbInt l_srcWidth,bbInt l_srcHeight);
  void m_DrawRect(t_std_geom_Rect_1f l_rect,t_mojo_graphics_Image* l_srcImage,t_std_geom_Rect_1i l_srcRect);
  void m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height,t_mojo_graphics_Image* l_srcImage);
  void m_DrawRect(t_std_geom_Rect_1f l_rect,t_mojo_graphics_Image* l_srcImage);
  void m_DrawRect(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height);
  void m_DrawRect(t_std_geom_Rect_1f l_rect);
  void m_DrawQuad(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1,bbFloat l_x2,bbFloat l_y2,bbFloat l_x3,bbFloat l_y3);
  void m_DrawPrimitives(bbInt l_order,bbInt l_count,bbFloat* l_vertices,bbInt l_verticesPitch,bbFloat* l_texCoords,bbInt l_texCoordsPitch,bbInt* l_indices);
  void m_DrawPoly(bbArray<bbFloat>* l_vertices);
  void m_DrawPoint(bbFloat l_x,bbFloat l_y);
  void m_DrawPoint(t_std_geom_Vec2_1f l_v);
  void m_DrawOval(bbFloat l_x,bbFloat l_y,bbFloat l_width,bbFloat l_height);
  void m_DrawLine(bbFloat l_x0,bbFloat l_y0,bbFloat l_x1,bbFloat l_y1);
  void m_DrawLine(t_std_geom_Vec2_1f l_v0,t_std_geom_Vec2_1f l_v1);
  void m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_tv,bbFloat l_rz,t_std_geom_Vec2_1f l_scale);
  void m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty,bbFloat l_rz,bbFloat l_sx,bbFloat l_sy);
  void m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_translation,bbFloat l_rz);
  void m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty,bbFloat l_rz);
  void m_DrawImage(t_mojo_graphics_Image* l_image,t_std_geom_Vec2_1f l_translation);
  void m_DrawImage(t_mojo_graphics_Image* l_image,bbFloat l_tx,bbFloat l_ty);
  void m_DrawEllipse(bbFloat l_x,bbFloat l_y,bbFloat l_xRadius,bbFloat l_yRadius);
  void m_DrawCircle(bbFloat l_x,bbFloat l_y,bbFloat l_radius);
  t_std_graphics_Pixmap* m_CopyPixmap(t_std_geom_Rect_1i l_rect);
  void m_Color(t_std_graphics_Color l_color);
  t_std_graphics_Color m_Color();
  void m_ClearMatrix();
  void m_ClearDrawOps();
  void m_Clear(t_std_graphics_Color l_color);
  void m_BlendMode(bbInt l_blendMode);
  bbInt m_BlendMode();
  void m_BeginRender(t_std_geom_Rect_1i l_bounds,t_std_geom_AffineMat3_1f l_matrix);
  void m_AmbientLight(t_std_graphics_Color l_ambientLight);
  t_std_graphics_Color m_AmbientLight();
  void m_Alpha(bbFloat l_alpha);
  bbFloat m_Alpha();
  void m_AddVertex(bbFloat l_tx,bbFloat l_ty,bbFloat l_s0,bbFloat l_t0);
  void m_AddDrawOp(t_mojo_graphics_Material* l_material,bbInt l_order,bbInt l_count);

  t_mojo_graphics_Canvas(){
    init();
  }
};

struct t_mojo_graphics_Canvas_LightInst{
  const char *typeName()const{return "t_mojo_graphics_Canvas_LightInst";}

  t_std_geom_Vec2_1f m_position{};
  bbFloat m_radius{};
  t_std_graphics_Color m_color{};

  t_mojo_graphics_Canvas_LightInst(){
  }

  t_mojo_graphics_Canvas_LightInst(bbNullCtor_t){
  }
};

int bbCompare(const t_mojo_graphics_Canvas_LightInst&x,const t_mojo_graphics_Canvas_LightInst&y);

#endif
