
#ifndef MX2_MOJO_INPUT_2KEYBOARD_H
#define MX2_MOJO_INPUT_2KEYBOARD_H

#include <bbmonkey.h>
#include "../../input/native/keyinfo.h"

// ***** External *****

#include "mojo_input_2device.h"
#include "../../../sdl2/sdl2.buildv1.0.0/desktop_release_pi/sdl2_sdl2.h"

// ***** Internal *****

struct t_mojo_input_KeyboardDevice;

extern bbGCRootVar<t_mojo_input_KeyboardDevice> g_mojo_input_Keyboard;

extern bbInt g_mojo_input_KeyboardDevice__0EventFilter(void* l_userData,SDL_Event* l_event);

struct t_mojo_input_KeyboardDevice : public t_mojo_input_InputDevice{

  const char *typeName()const{return "t_mojo_input_KeyboardDevice";}

  bbBool m__0init{};
  bbInt m__0modifiers{};
  bbGCVar<bbArray<bbBool>> m__0matrix{};
  bbGCVar<bbArray<bbBool>> m__0pressed{};
  bbGCVar<bbArray<bbBool>> m__0released{};
  bbGCVar<bbArray<bbString>> m__0names{};
  bbGCVar<bbArray<bbInt>> m__0raw2scan{};
  bbGCVar<bbArray<bbInt>> m__0scan2raw{};
  bbGCVar<bbArray<bbInt>> m__0key2scan{};
  bbGCVar<bbArray<bbInt>> m__0scan2key{};

  void init();

  void gcMark();

  t_mojo_input_KeyboardDevice();

  bbInt m_TranslateKey(bbInt l_key);
  bbInt m_ScanCodeToRawKey(bbInt l_scanCode);
  bbInt m_ScanCode(bbInt l_key);
  void m_Reset();
  bbInt m_Modifiers();
  bbBool m_KeyReleased(bbInt l_key);
  bbBool m_KeyPressed(bbInt l_key);
  bbString m_KeyName(bbInt l_key);
  bbBool m_KeyHit(bbInt l_key);
  bbBool m_KeyDown(bbInt l_key);
  bbInt m_KeyCodeToKey(bbInt l_keyCode);
  void m_Init();
  bbInt m_EventFilter(void* l_userData,SDL_Event* l_event);
};

#endif
