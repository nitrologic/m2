
#ifndef MX2_MOJO_STD_COLLECTIONS_2MAP_H
#define MX2_MOJO_STD_COLLECTIONS_2MAP_H

#include <bbmonkey.h>
#include "../../../std/std.buildv1.0.0/desktop_release_pi/std_collections_2map.h"

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.0/desktop_release_pi/std_graphics_2color.h"

struct t_mojo_graphics_Texture;
struct t_mojo_graphics_Shader;
struct t_mojo_graphics_Font;
struct t_mojo_app_Window;
struct t_mojo_graphics_Image;
struct t_mojo_app_Style;

// ***** Internal *****

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node;
struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator;
struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator;
struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys;
struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator;
struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues;
struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2;
struct t_std_collections_Map_1si_Node;
struct t_std_collections_Map_1si_Iterator;
struct t_std_collections_Map_1si_KeyIterator;
struct t_std_collections_Map_1si_MapKeys;
struct t_std_collections_Map_1si_ValueIterator;
struct t_std_collections_Map_1si_MapValues;
struct t_std_collections_Map_1si;
struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node;
struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys;
struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues;
struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2;
struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node;
struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys;
struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues;
struct t_std_collections_Map_1sTt_mojo_graphics_Font_2;
struct t_std_collections_Map_1jTt_mojo_app_Window_2_Node;
struct t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator;
struct t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator;
struct t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys;
struct t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator;
struct t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues;
struct t_std_collections_Map_1jTt_mojo_app_Window_2;
struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node;
struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys;
struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator;
struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues;
struct t_std_collections_Map_1sTt_mojo_graphics_Image_2;
struct t_std_collections_Map_1sTt_mojo_app_Style_2_Node;
struct t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator;
struct t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator;
struct t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys;
struct t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator;
struct t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues;
struct t_std_collections_Map_1sTt_mojo_app_Style_2;
struct t_std_collections_Map_1iFvE_Node;
struct t_std_collections_Map_1iFvE_Iterator;
struct t_std_collections_Map_1iFvE_KeyIterator;
struct t_std_collections_Map_1iFvE_MapKeys;
struct t_std_collections_Map_1iFvE_ValueIterator;
struct t_std_collections_Map_1iFvE_MapValues;
struct t_std_collections_Map_1iFvE;
struct t_std_collections_Map_1iz_Node;
struct t_std_collections_Map_1iz_Iterator;
struct t_std_collections_Map_1iz_KeyIterator;
struct t_std_collections_Map_1iz_MapKeys;
struct t_std_collections_Map_1iz_ValueIterator;
struct t_std_collections_Map_1iz_MapValues;
struct t_std_collections_Map_1iz;

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node";}

  t_std_graphics_Color m__0key{};
  bbGCVar<t_mojo_graphics_Texture> m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value,bbInt l_color,t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent);

  t_mojo_graphics_Texture* m_Value();
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* m_PrevNode();
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* m_NextNode();
  t_std_graphics_Color m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* m_Copy(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent);

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node(){
  }
};

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator";}

  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node> m__0node{};

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator(){
  }

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&y);

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator&);

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator";}

  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node> m__0node{};

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node);

  bbBool m_Valid();
  t_std_graphics_Color m_Current();
  void m_Bump();

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator(){
  }

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator&);

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys";}

  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2> m__0map{};

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* l_map);

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_KeyIterator m_All();

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys(){
  }

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys&);

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator";}

  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node> m__0node{};

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node);

  bbBool m_Valid();
  t_mojo_graphics_Texture* m_Current();
  void m_Bump();

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator(){
  }

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator&);

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues";}

  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2> m__0map{};

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* l_map);

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_ValueIterator m_All();

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues(){
  }

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&x,const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&y);

void bbGCMark(const t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues&);

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2 : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2";}

  bbGCVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_root);
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2();

  void m__idxeq(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value);
  t_mojo_graphics_Texture* m__idx(t_std_graphics_Color l_key);
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapValues m_Values();
  bbBool m_Update(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value);
  bbBool m_Set(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value);
  void m_RotateRight(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node);
  bbBool m_Remove(t_std_graphics_Color l_key);
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* m_LastNode();
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node);
  t_mojo_graphics_Texture* m_Get(t_std_graphics_Color l_key);
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* m_FirstNode();
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* m_FindNode(t_std_graphics_Color l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_node,t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2* m_Copy();
  bbBool m_Contains(t_std_graphics_Color l_key);
  void m_Clear();
  t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2_Iterator m_All();
  bbBool m_Add(t_std_graphics_Color l_key,t_mojo_graphics_Texture* l_value);
};

struct t_std_collections_Map_1si_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1si_Node";}

  bbString m__0key{};
  bbInt m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1si_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1si_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1si_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1si_Node(bbString l_key,bbInt l_value,bbInt l_color,t_std_collections_Map_1si_Node* l_parent);

  bbInt m_Value();
  t_std_collections_Map_1si_Node* m_PrevNode();
  t_std_collections_Map_1si_Node* m_NextNode();
  bbString m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1si_Node* m_Copy(t_std_collections_Map_1si_Node* l_parent);

  t_std_collections_Map_1si_Node(){
  }
};

struct t_std_collections_Map_1si_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1si_Iterator";}

  bbGCVar<t_std_collections_Map_1si_Node> m__0node{};

  t_std_collections_Map_1si_Iterator(t_std_collections_Map_1si_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1si_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1si_Iterator(){
  }

  t_std_collections_Map_1si_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1si_Iterator&x,const t_std_collections_Map_1si_Iterator&y);

void bbGCMark(const t_std_collections_Map_1si_Iterator&);

struct t_std_collections_Map_1si_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1si_KeyIterator";}

  bbGCVar<t_std_collections_Map_1si_Node> m__0node{};

  t_std_collections_Map_1si_KeyIterator(t_std_collections_Map_1si_Node* l_node);

  bbBool m_Valid();
  bbString m_Current();
  void m_Bump();

  t_std_collections_Map_1si_KeyIterator(){
  }

  t_std_collections_Map_1si_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1si_KeyIterator&x,const t_std_collections_Map_1si_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1si_KeyIterator&);

struct t_std_collections_Map_1si_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1si_MapKeys";}

  bbGCVar<t_std_collections_Map_1si> m__0map{};

  t_std_collections_Map_1si_MapKeys(t_std_collections_Map_1si* l_map);

  t_std_collections_Map_1si_KeyIterator m_All();

  t_std_collections_Map_1si_MapKeys(){
  }

  t_std_collections_Map_1si_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1si_MapKeys&x,const t_std_collections_Map_1si_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1si_MapKeys&);

struct t_std_collections_Map_1si_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1si_ValueIterator";}

  bbGCVar<t_std_collections_Map_1si_Node> m__0node{};

  t_std_collections_Map_1si_ValueIterator(t_std_collections_Map_1si_Node* l_node);

  bbBool m_Valid();
  bbInt m_Current();
  void m_Bump();

  t_std_collections_Map_1si_ValueIterator(){
  }

  t_std_collections_Map_1si_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1si_ValueIterator&x,const t_std_collections_Map_1si_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1si_ValueIterator&);

struct t_std_collections_Map_1si_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1si_MapValues";}

  bbGCVar<t_std_collections_Map_1si> m__0map{};

  t_std_collections_Map_1si_MapValues(t_std_collections_Map_1si* l_map);

  t_std_collections_Map_1si_ValueIterator m_All();

  t_std_collections_Map_1si_MapValues(){
  }

  t_std_collections_Map_1si_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1si_MapValues&x,const t_std_collections_Map_1si_MapValues&y);

void bbGCMark(const t_std_collections_Map_1si_MapValues&);

struct t_std_collections_Map_1si : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1si";}

  bbGCVar<t_std_collections_Map_1si_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1si(t_std_collections_Map_1si_Node* l_root);
  t_std_collections_Map_1si();

  void m__idxeq(bbString l_key,bbInt l_value);
  bbInt m__idx(bbString l_key);
  t_std_collections_Map_1si_MapValues m_Values();
  bbBool m_Update(bbString l_key,bbInt l_value);
  bbBool m_Set(bbString l_key,bbInt l_value);
  void m_RotateRight(t_std_collections_Map_1si_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1si_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1si_Node* l_node);
  bbBool m_Remove(bbString l_key);
  t_std_collections_Map_1si_Node* m_LastNode();
  t_std_collections_Map_1si_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1si_Node* l_node);
  bbInt m_Get(bbString l_key);
  t_std_collections_Map_1si_Node* m_FirstNode();
  t_std_collections_Map_1si_Node* m_FindNode(bbString l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1si_Node* l_node,t_std_collections_Map_1si_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1si* m_Copy();
  bbBool m_Contains(bbString l_key);
  void m_Clear();
  t_std_collections_Map_1si_Iterator m_All();
  bbBool m_Add(bbString l_key,bbInt l_value);
};

struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node";}

  bbString m__0key{};
  bbGCVar<t_mojo_graphics_Shader> m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node(bbString l_key,t_mojo_graphics_Shader* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent);

  t_mojo_graphics_Shader* m_Value();
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* m_PrevNode();
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* m_NextNode();
  bbString m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent);

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node(){
  }
};

struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node);

  bbBool m_Valid();
  bbString m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2> m__0map{};

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Shader_2* l_map);

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_KeyIterator m_All();

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys&);

struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node);

  bbBool m_Valid();
  t_mojo_graphics_Shader* m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2> m__0map{};

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Shader_2* l_map);

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_ValueIterator m_All();

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues&);

struct t_std_collections_Map_1sTt_mojo_graphics_Shader_2 : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Shader_2";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1sTt_mojo_graphics_Shader_2(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_root);
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2();

  void m__idxeq(bbString l_key,t_mojo_graphics_Shader* l_value);
  t_mojo_graphics_Shader* m__idx(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapValues m_Values();
  bbBool m_Update(bbString l_key,t_mojo_graphics_Shader* l_value);
  bbBool m_Set(bbString l_key,t_mojo_graphics_Shader* l_value);
  void m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node);
  bbBool m_Remove(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* m_LastNode();
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node);
  t_mojo_graphics_Shader* m_Get(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* m_FirstNode();
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* m_FindNode(bbString l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2* m_Copy();
  bbBool m_Contains(bbString l_key);
  void m_Clear();
  t_std_collections_Map_1sTt_mojo_graphics_Shader_2_Iterator m_All();
  bbBool m_Add(bbString l_key,t_mojo_graphics_Shader* l_value);
};

struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node";}

  bbString m__0key{};
  bbGCVar<t_mojo_graphics_Font> m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node(bbString l_key,t_mojo_graphics_Font* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent);

  t_mojo_graphics_Font* m_Value();
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* m_PrevNode();
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* m_NextNode();
  bbString m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent);

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node(){
  }
};

struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node);

  bbBool m_Valid();
  bbString m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2> m__0map{};

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Font_2* l_map);

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_KeyIterator m_All();

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys&);

struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node);

  bbBool m_Valid();
  t_mojo_graphics_Font* m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2> m__0map{};

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Font_2* l_map);

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_ValueIterator m_All();

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues&);

struct t_std_collections_Map_1sTt_mojo_graphics_Font_2 : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Font_2";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1sTt_mojo_graphics_Font_2(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_root);
  t_std_collections_Map_1sTt_mojo_graphics_Font_2();

  void m__idxeq(bbString l_key,t_mojo_graphics_Font* l_value);
  t_mojo_graphics_Font* m__idx(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapValues m_Values();
  bbBool m_Update(bbString l_key,t_mojo_graphics_Font* l_value);
  bbBool m_Set(bbString l_key,t_mojo_graphics_Font* l_value);
  void m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node);
  bbBool m_Remove(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* m_LastNode();
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node);
  t_mojo_graphics_Font* m_Get(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* m_FirstNode();
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* m_FindNode(bbString l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Font_2_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1sTt_mojo_graphics_Font_2* m_Copy();
  bbBool m_Contains(bbString l_key);
  void m_Clear();
  t_std_collections_Map_1sTt_mojo_graphics_Font_2_Iterator m_All();
  bbBool m_Add(bbString l_key,t_mojo_graphics_Font* l_value);
};

struct t_std_collections_Map_1jTt_mojo_app_Window_2_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1jTt_mojo_app_Window_2_Node";}

  bbUInt m__0key{};
  bbGCVar<t_mojo_app_Window> m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1jTt_mojo_app_Window_2_Node(bbUInt l_key,t_mojo_app_Window* l_value,bbInt l_color,t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent);

  t_mojo_app_Window* m_Value();
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node* m_PrevNode();
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node* m_NextNode();
  bbUInt m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node* m_Copy(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent);

  t_std_collections_Map_1jTt_mojo_app_Window_2_Node(){
  }
};

struct t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator";}

  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2_Node> m__0node{};

  t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator(){
  }

  t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&y);

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator&);

struct t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator";}

  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2_Node> m__0node{};

  t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node);

  bbBool m_Valid();
  bbUInt m_Current();
  void m_Bump();

  t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator(){
  }

  t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator&);

struct t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys";}

  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2> m__0map{};

  t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys(t_std_collections_Map_1jTt_mojo_app_Window_2* l_map);

  t_std_collections_Map_1jTt_mojo_app_Window_2_KeyIterator m_All();

  t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys(){
  }

  t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys&);

struct t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator";}

  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2_Node> m__0node{};

  t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node);

  bbBool m_Valid();
  t_mojo_app_Window* m_Current();
  void m_Bump();

  t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator(){
  }

  t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator&);

struct t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues";}

  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2> m__0map{};

  t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues(t_std_collections_Map_1jTt_mojo_app_Window_2* l_map);

  t_std_collections_Map_1jTt_mojo_app_Window_2_ValueIterator m_All();

  t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues(){
  }

  t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&x,const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&y);

void bbGCMark(const t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues&);

struct t_std_collections_Map_1jTt_mojo_app_Window_2 : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1jTt_mojo_app_Window_2";}

  bbGCVar<t_std_collections_Map_1jTt_mojo_app_Window_2_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1jTt_mojo_app_Window_2(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_root);
  t_std_collections_Map_1jTt_mojo_app_Window_2();

  void m__idxeq(bbUInt l_key,t_mojo_app_Window* l_value);
  t_mojo_app_Window* m__idx(bbUInt l_key);
  t_std_collections_Map_1jTt_mojo_app_Window_2_MapValues m_Values();
  bbBool m_Update(bbUInt l_key,t_mojo_app_Window* l_value);
  bbBool m_Set(bbUInt l_key,t_mojo_app_Window* l_value);
  void m_RotateRight(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node);
  bbBool m_Remove(bbUInt l_key);
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node* m_LastNode();
  t_std_collections_Map_1jTt_mojo_app_Window_2_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node);
  t_mojo_app_Window* m_Get(bbUInt l_key);
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node* m_FirstNode();
  t_std_collections_Map_1jTt_mojo_app_Window_2_Node* m_FindNode(bbUInt l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_node,t_std_collections_Map_1jTt_mojo_app_Window_2_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1jTt_mojo_app_Window_2* m_Copy();
  bbBool m_Contains(bbUInt l_key);
  void m_Clear();
  t_std_collections_Map_1jTt_mojo_app_Window_2_Iterator m_All();
  bbBool m_Add(bbUInt l_key,t_mojo_app_Window* l_value);
};

struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node";}

  bbString m__0key{};
  bbGCVar<t_mojo_graphics_Image> m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node(bbString l_key,t_mojo_graphics_Image* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent);

  t_mojo_graphics_Image* m_Value();
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* m_PrevNode();
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* m_NextNode();
  bbString m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* m_Copy(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent);

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node(){
  }
};

struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node);

  bbBool m_Valid();
  bbString m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2> m__0map{};

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys(t_std_collections_Map_1sTt_mojo_graphics_Image_2* l_map);

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_KeyIterator m_All();

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys&);

struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node);

  bbBool m_Valid();
  t_mojo_graphics_Image* m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator&);

struct t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2> m__0map{};

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues(t_std_collections_Map_1sTt_mojo_graphics_Image_2* l_map);

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_ValueIterator m_All();

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues(){
  }

  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues&);

struct t_std_collections_Map_1sTt_mojo_graphics_Image_2 : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_graphics_Image_2";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1sTt_mojo_graphics_Image_2(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_root);
  t_std_collections_Map_1sTt_mojo_graphics_Image_2();

  void m__idxeq(bbString l_key,t_mojo_graphics_Image* l_value);
  t_mojo_graphics_Image* m__idx(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapValues m_Values();
  bbBool m_Update(bbString l_key,t_mojo_graphics_Image* l_value);
  bbBool m_Set(bbString l_key,t_mojo_graphics_Image* l_value);
  void m_RotateRight(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node);
  bbBool m_Remove(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* m_LastNode();
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node);
  t_mojo_graphics_Image* m_Get(bbString l_key);
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* m_FirstNode();
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* m_FindNode(bbString l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_node,t_std_collections_Map_1sTt_mojo_graphics_Image_2_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1sTt_mojo_graphics_Image_2* m_Copy();
  bbBool m_Contains(bbString l_key);
  void m_Clear();
  t_std_collections_Map_1sTt_mojo_graphics_Image_2_Iterator m_All();
  bbBool m_Add(bbString l_key,t_mojo_graphics_Image* l_value);
};

struct t_std_collections_Map_1sTt_mojo_app_Style_2_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_app_Style_2_Node";}

  bbString m__0key{};
  bbGCVar<t_mojo_app_Style> m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1sTt_mojo_app_Style_2_Node(bbString l_key,t_mojo_app_Style* l_value,bbInt l_color,t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent);

  t_mojo_app_Style* m_Value();
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node* m_PrevNode();
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node* m_NextNode();
  bbString m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node* m_Copy(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent);

  t_std_collections_Map_1sTt_mojo_app_Style_2_Node(){
  }
};

struct t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator(){
  }

  t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator&);

struct t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node);

  bbBool m_Valid();
  bbString m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator(){
  }

  t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator&);

struct t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2> m__0map{};

  t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys(t_std_collections_Map_1sTt_mojo_app_Style_2* l_map);

  t_std_collections_Map_1sTt_mojo_app_Style_2_KeyIterator m_All();

  t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys(){
  }

  t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys&);

struct t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2_Node> m__0node{};

  t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node);

  bbBool m_Valid();
  t_mojo_app_Style* m_Current();
  void m_Bump();

  t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator(){
  }

  t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator&);

struct t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2> m__0map{};

  t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues(t_std_collections_Map_1sTt_mojo_app_Style_2* l_map);

  t_std_collections_Map_1sTt_mojo_app_Style_2_ValueIterator m_All();

  t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues(){
  }

  t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&x,const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&y);

void bbGCMark(const t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues&);

struct t_std_collections_Map_1sTt_mojo_app_Style_2 : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1sTt_mojo_app_Style_2";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1sTt_mojo_app_Style_2(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_root);
  t_std_collections_Map_1sTt_mojo_app_Style_2();

  void m__idxeq(bbString l_key,t_mojo_app_Style* l_value);
  t_mojo_app_Style* m__idx(bbString l_key);
  t_std_collections_Map_1sTt_mojo_app_Style_2_MapValues m_Values();
  bbBool m_Update(bbString l_key,t_mojo_app_Style* l_value);
  bbBool m_Set(bbString l_key,t_mojo_app_Style* l_value);
  void m_RotateRight(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node);
  bbBool m_Remove(bbString l_key);
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node* m_LastNode();
  t_std_collections_Map_1sTt_mojo_app_Style_2_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node);
  t_mojo_app_Style* m_Get(bbString l_key);
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node* m_FirstNode();
  t_std_collections_Map_1sTt_mojo_app_Style_2_Node* m_FindNode(bbString l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_node,t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1sTt_mojo_app_Style_2* m_Copy();
  bbBool m_Contains(bbString l_key);
  void m_Clear();
  t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator m_All();
  bbBool m_Add(bbString l_key,t_mojo_app_Style* l_value);
};

struct t_std_collections_Map_1iFvE_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1iFvE_Node";}

  bbInt m__0key{};
  bbFunction<void()> m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1iFvE_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1iFvE_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1iFvE_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1iFvE_Node(bbInt l_key,bbFunction<void()> l_value,bbInt l_color,t_std_collections_Map_1iFvE_Node* l_parent);

  bbFunction<void()> m_Value();
  t_std_collections_Map_1iFvE_Node* m_PrevNode();
  t_std_collections_Map_1iFvE_Node* m_NextNode();
  bbInt m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1iFvE_Node* m_Copy(t_std_collections_Map_1iFvE_Node* l_parent);

  t_std_collections_Map_1iFvE_Node(){
  }
};

struct t_std_collections_Map_1iFvE_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1iFvE_Iterator";}

  bbGCVar<t_std_collections_Map_1iFvE_Node> m__0node{};

  t_std_collections_Map_1iFvE_Iterator(t_std_collections_Map_1iFvE_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1iFvE_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1iFvE_Iterator(){
  }

  t_std_collections_Map_1iFvE_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iFvE_Iterator&x,const t_std_collections_Map_1iFvE_Iterator&y);

void bbGCMark(const t_std_collections_Map_1iFvE_Iterator&);

struct t_std_collections_Map_1iFvE_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1iFvE_KeyIterator";}

  bbGCVar<t_std_collections_Map_1iFvE_Node> m__0node{};

  t_std_collections_Map_1iFvE_KeyIterator(t_std_collections_Map_1iFvE_Node* l_node);

  bbBool m_Valid();
  bbInt m_Current();
  void m_Bump();

  t_std_collections_Map_1iFvE_KeyIterator(){
  }

  t_std_collections_Map_1iFvE_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iFvE_KeyIterator&x,const t_std_collections_Map_1iFvE_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1iFvE_KeyIterator&);

struct t_std_collections_Map_1iFvE_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1iFvE_MapKeys";}

  bbGCVar<t_std_collections_Map_1iFvE> m__0map{};

  t_std_collections_Map_1iFvE_MapKeys(t_std_collections_Map_1iFvE* l_map);

  t_std_collections_Map_1iFvE_KeyIterator m_All();

  t_std_collections_Map_1iFvE_MapKeys(){
  }

  t_std_collections_Map_1iFvE_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iFvE_MapKeys&x,const t_std_collections_Map_1iFvE_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1iFvE_MapKeys&);

struct t_std_collections_Map_1iFvE_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1iFvE_ValueIterator";}

  bbGCVar<t_std_collections_Map_1iFvE_Node> m__0node{};

  t_std_collections_Map_1iFvE_ValueIterator(t_std_collections_Map_1iFvE_Node* l_node);

  bbBool m_Valid();
  bbFunction<void()> m_Current();
  void m_Bump();

  t_std_collections_Map_1iFvE_ValueIterator(){
  }

  t_std_collections_Map_1iFvE_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iFvE_ValueIterator&x,const t_std_collections_Map_1iFvE_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1iFvE_ValueIterator&);

struct t_std_collections_Map_1iFvE_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1iFvE_MapValues";}

  bbGCVar<t_std_collections_Map_1iFvE> m__0map{};

  t_std_collections_Map_1iFvE_MapValues(t_std_collections_Map_1iFvE* l_map);

  t_std_collections_Map_1iFvE_ValueIterator m_All();

  t_std_collections_Map_1iFvE_MapValues(){
  }

  t_std_collections_Map_1iFvE_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iFvE_MapValues&x,const t_std_collections_Map_1iFvE_MapValues&y);

void bbGCMark(const t_std_collections_Map_1iFvE_MapValues&);

struct t_std_collections_Map_1iFvE : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1iFvE";}

  bbGCVar<t_std_collections_Map_1iFvE_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1iFvE(t_std_collections_Map_1iFvE_Node* l_root);
  t_std_collections_Map_1iFvE();

  void m__idxeq(bbInt l_key,bbFunction<void()> l_value);
  bbFunction<void()> m__idx(bbInt l_key);
  t_std_collections_Map_1iFvE_MapValues m_Values();
  bbBool m_Update(bbInt l_key,bbFunction<void()> l_value);
  bbBool m_Set(bbInt l_key,bbFunction<void()> l_value);
  void m_RotateRight(t_std_collections_Map_1iFvE_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1iFvE_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1iFvE_Node* l_node);
  bbBool m_Remove(bbInt l_key);
  t_std_collections_Map_1iFvE_Node* m_LastNode();
  t_std_collections_Map_1iFvE_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1iFvE_Node* l_node);
  bbFunction<void()> m_Get(bbInt l_key);
  t_std_collections_Map_1iFvE_Node* m_FirstNode();
  t_std_collections_Map_1iFvE_Node* m_FindNode(bbInt l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1iFvE_Node* l_node,t_std_collections_Map_1iFvE_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1iFvE* m_Copy();
  bbBool m_Contains(bbInt l_key);
  void m_Clear();
  t_std_collections_Map_1iFvE_Iterator m_All();
  bbBool m_Add(bbInt l_key,bbFunction<void()> l_value);
};

struct t_std_collections_Map_1iz_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1iz_Node";}

  bbInt m__0key{};
  bbBool m__0value{};
  bbInt m__0color{};
  bbGCVar<t_std_collections_Map_1iz_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1iz_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1iz_Node> m__0parent{};

  void gcMark();

  t_std_collections_Map_1iz_Node(bbInt l_key,bbBool l_value,bbInt l_color,t_std_collections_Map_1iz_Node* l_parent);

  bbBool m_Value();
  t_std_collections_Map_1iz_Node* m_PrevNode();
  t_std_collections_Map_1iz_Node* m_NextNode();
  bbInt m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1iz_Node* m_Copy(t_std_collections_Map_1iz_Node* l_parent);

  t_std_collections_Map_1iz_Node(){
  }
};

struct t_std_collections_Map_1iz_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1iz_Iterator";}

  bbGCVar<t_std_collections_Map_1iz_Node> m__0node{};

  t_std_collections_Map_1iz_Iterator(t_std_collections_Map_1iz_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1iz_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1iz_Iterator(){
  }

  t_std_collections_Map_1iz_Iterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iz_Iterator&x,const t_std_collections_Map_1iz_Iterator&y);

void bbGCMark(const t_std_collections_Map_1iz_Iterator&);

struct t_std_collections_Map_1iz_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1iz_KeyIterator";}

  bbGCVar<t_std_collections_Map_1iz_Node> m__0node{};

  t_std_collections_Map_1iz_KeyIterator(t_std_collections_Map_1iz_Node* l_node);

  bbBool m_Valid();
  bbInt m_Current();
  void m_Bump();

  t_std_collections_Map_1iz_KeyIterator(){
  }

  t_std_collections_Map_1iz_KeyIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iz_KeyIterator&x,const t_std_collections_Map_1iz_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1iz_KeyIterator&);

struct t_std_collections_Map_1iz_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1iz_MapKeys";}

  bbGCVar<t_std_collections_Map_1iz> m__0map{};

  t_std_collections_Map_1iz_MapKeys(t_std_collections_Map_1iz* l_map);

  t_std_collections_Map_1iz_KeyIterator m_All();

  t_std_collections_Map_1iz_MapKeys(){
  }

  t_std_collections_Map_1iz_MapKeys(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iz_MapKeys&x,const t_std_collections_Map_1iz_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1iz_MapKeys&);

struct t_std_collections_Map_1iz_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1iz_ValueIterator";}

  bbGCVar<t_std_collections_Map_1iz_Node> m__0node{};

  t_std_collections_Map_1iz_ValueIterator(t_std_collections_Map_1iz_Node* l_node);

  bbBool m_Valid();
  bbBool m_Current();
  void m_Bump();

  t_std_collections_Map_1iz_ValueIterator(){
  }

  t_std_collections_Map_1iz_ValueIterator(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iz_ValueIterator&x,const t_std_collections_Map_1iz_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1iz_ValueIterator&);

struct t_std_collections_Map_1iz_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1iz_MapValues";}

  bbGCVar<t_std_collections_Map_1iz> m__0map{};

  t_std_collections_Map_1iz_MapValues(t_std_collections_Map_1iz* l_map);

  t_std_collections_Map_1iz_ValueIterator m_All();

  t_std_collections_Map_1iz_MapValues(){
  }

  t_std_collections_Map_1iz_MapValues(bbNullCtor_t){
  }
};

int bbCompare(const t_std_collections_Map_1iz_MapValues&x,const t_std_collections_Map_1iz_MapValues&y);

void bbGCMark(const t_std_collections_Map_1iz_MapValues&);

struct t_std_collections_Map_1iz : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1iz";}

  bbGCVar<t_std_collections_Map_1iz_Node> m__0root{};

  void gcMark();

  t_std_collections_Map_1iz(t_std_collections_Map_1iz_Node* l_root);
  t_std_collections_Map_1iz();

  void m__idxeq(bbInt l_key,bbBool l_value);
  bbBool m__idx(bbInt l_key);
  t_std_collections_Map_1iz_MapValues m_Values();
  bbBool m_Update(bbInt l_key,bbBool l_value);
  bbBool m_Set(bbInt l_key,bbBool l_value);
  void m_RotateRight(t_std_collections_Map_1iz_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1iz_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1iz_Node* l_node);
  bbBool m_Remove(bbInt l_key);
  t_std_collections_Map_1iz_Node* m_LastNode();
  t_std_collections_Map_1iz_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1iz_Node* l_node);
  bbBool m_Get(bbInt l_key);
  t_std_collections_Map_1iz_Node* m_FirstNode();
  t_std_collections_Map_1iz_Node* m_FindNode(bbInt l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1iz_Node* l_node,t_std_collections_Map_1iz_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1iz* m_Copy();
  bbBool m_Contains(bbInt l_key);
  void m_Clear();
  t_std_collections_Map_1iz_Iterator m_All();
  bbBool m_Add(bbInt l_key,bbBool l_value);
};

#endif
