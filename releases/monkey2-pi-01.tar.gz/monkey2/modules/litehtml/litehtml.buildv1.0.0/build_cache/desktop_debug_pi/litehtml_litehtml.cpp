
#include "../../desktop_debug_pi/litehtml_litehtml.h"

// ***** External *****

// ***** Internal *****

void mx2_litehtml_litehtml_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_litehtml_litehtml_init_v("litehtml_litehtml",&mx2_litehtml_litehtml_init);
