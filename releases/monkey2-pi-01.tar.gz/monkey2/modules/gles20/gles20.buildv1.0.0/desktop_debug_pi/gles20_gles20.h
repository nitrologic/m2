
#ifndef MX2_GLES20_GLES20_H
#define MX2_GLES20_GLES20_H

#include <bbmonkey.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>

// ***** External *****

// ***** Internal *****

extern bbString g_gles20_glGetProgramInfoLogEx(bbUInt l_program);
extern bbString g_gles20_glGetShaderInfoLogEx(bbUInt l_shader);
extern void g_gles20_glShaderSourceEx(bbUInt l_shader,bbString l_source);
extern void g_gles20_glInitEx();

#endif
