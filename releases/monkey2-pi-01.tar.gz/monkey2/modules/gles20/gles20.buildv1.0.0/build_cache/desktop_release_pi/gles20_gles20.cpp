
#include "../../desktop_release_pi/gles20_gles20.h"

// ***** External *****

#include "../../../../libc/libc.buildv1.0.0/desktop_release_pi/libc_libc.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_release_pi/monkey_types.h"

// ***** Internal *****

bbString g_gles20_glGetProgramInfoLogEx(bbUInt l_program){
  struct f0_t : public bbGCFrame{
    bbArray<bbByte>* l_buf{};
    void gcMark(){
      bbGCMarkPtr(l_buf);
    }
  }f0{};
  f0.l_buf=bbArray<bbByte>::create(1024);
  bbInt l_length{};
  glGetProgramInfoLog(l_program,f0.l_buf->length(),&l_length,((char*)(&f0.l_buf->at(bbInt(0)))));
  return bbString::fromCString(((void*)(&f0.l_buf->at(bbInt(0)))));
}

bbString g_gles20_glGetShaderInfoLogEx(bbUInt l_shader){
  struct f0_t : public bbGCFrame{
    bbArray<bbByte>* l_buf{};
    void gcMark(){
      bbGCMarkPtr(l_buf);
    }
  }f0{};
  f0.l_buf=bbArray<bbByte>::create(1024);
  bbInt l_length{};
  glGetShaderInfoLog(l_shader,f0.l_buf->length(),&l_length,((char*)(&f0.l_buf->at(bbInt(0)))));
  return bbString::fromCString(((void*)(&f0.l_buf->at(bbInt(0)))));
}

void g_gles20_glShaderSourceEx(bbUInt l_shader,bbString l_source){
  bbInt l_n=l_source.length();
  bbByte* l_buf=((bbByte*)(malloc((l_n+1))));
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<l_n);l_i+=1){
      l_buf[l_i]=bbByte(l_source[l_i]);
    }
  }
  l_buf[l_n]=bbByte(0);
  const char* l_p=((const char*)(l_buf));
  glShaderSource(l_shader,1,&l_p,((bbInt*)0));
  free(((void*)(l_buf)));
}

void g_gles20_glInitEx(){
}

void mx2_gles20_gles20_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_gles20_gles20_init_v("gles20_gles20",&mx2_gles20_gles20_init);
