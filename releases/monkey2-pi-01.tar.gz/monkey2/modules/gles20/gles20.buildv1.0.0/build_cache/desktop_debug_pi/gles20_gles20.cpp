
#include "../../desktop_debug_pi/gles20_gles20.h"

// ***** External *****

#include "../../../../libc/libc.buildv1.0.0/desktop_debug_pi/libc_libc.h"
#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"

// ***** Internal *****

bbString g_gles20_glGetProgramInfoLogEx(bbUInt l_program){
  struct f0_t : public bbGCFrame{
    bbArray<bbByte>* l_buf{};
    void gcMark(){
      bbGCMarkPtr(l_buf);
    }
  }f0{};
  bbDBFrame db_f{"glGetProgramInfoLogEx:String(program:GLuint:Uint)","/home/pi/monkey2/modules/gles20/gles20.monkey2"};
  bbDBLocal("program",&l_program);
  bbDBStmt(2457607);
  f0.l_buf=bbArray<bbByte>::create(1024);
  bbDBLocal("buf",&f0.l_buf);
  bbDBStmt(2457627);
  bbInt l_length{};
  bbDBLocal("length",&l_length);
  bbDBStmt(2465793);
  glGetProgramInfoLog(l_program,f0.l_buf->length(),&l_length,((char*)(&f0.l_buf->at(bbInt(0)))));
  bbDBStmt(2473985);
  return bbString::fromCString(((void*)(&f0.l_buf->at(bbInt(0)))));
}

bbString g_gles20_glGetShaderInfoLogEx(bbUInt l_shader){
  struct f0_t : public bbGCFrame{
    bbArray<bbByte>* l_buf{};
    void gcMark(){
      bbGCMarkPtr(l_buf);
    }
  }f0{};
  bbDBFrame db_f{"glGetShaderInfoLogEx:String(shader:GLuint:Uint)","/home/pi/monkey2/modules/gles20/gles20.monkey2"};
  bbDBLocal("shader",&l_shader);
  bbDBStmt(2420743);
  f0.l_buf=bbArray<bbByte>::create(1024);
  bbDBLocal("buf",&f0.l_buf);
  bbDBStmt(2420763);
  bbInt l_length{};
  bbDBLocal("length",&l_length);
  bbDBStmt(2428929);
  glGetShaderInfoLog(l_shader,f0.l_buf->length(),&l_length,((char*)(&f0.l_buf->at(bbInt(0)))));
  bbDBStmt(2437121);
  return bbString::fromCString(((void*)(&f0.l_buf->at(bbInt(0)))));
}

void g_gles20_glShaderSourceEx(bbUInt l_shader,bbString l_source){
  bbDBFrame db_f{"glShaderSourceEx:Void(shader:GLuint:Uint,source:String)","/home/pi/monkey2/modules/gles20/gles20.monkey2"};
  bbDBLocal("shader",&l_shader);
  bbDBLocal("source",&l_source);
  bbDBStmt(2355207);
  bbInt l_n=l_source.length();
  bbDBLocal("n",&l_n);
  bbDBStmt(2359303);
  bbByte* l_buf=((bbByte*)(malloc((l_n+1))));
  bbDBLocal("buf",&l_buf);
  bbDBStmt(2363393);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(2363393);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(2367490);
      l_buf[l_i]=bbByte(l_source[l_i]);
    }
  }
  bbDBStmt(2375681);
  l_buf[l_n]=bbByte(0);
  bbDBStmt(2383879);
  const char* l_p=((const char*)(l_buf));
  bbDBLocal("p",&l_p);
  bbDBStmt(2392065);
  glShaderSource(l_shader,1,&l_p,((bbInt*)0));
  bbDBStmt(2400257);
  free(((void*)(l_buf)));
}

void g_gles20_glInitEx(){
  bbDBFrame db_f{"glInitEx:Void()","/home/pi/monkey2/modules/gles20/gles20.monkey2"};
}

void mx2_gles20_gles20_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_gles20_gles20_init_v("gles20_gles20",&mx2_gles20_gles20_init);
