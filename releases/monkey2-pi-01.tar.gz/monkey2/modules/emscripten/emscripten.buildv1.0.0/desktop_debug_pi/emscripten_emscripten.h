
#ifndef MX2_EMSCRIPTEN_EMSCRIPTEN_H
#define MX2_EMSCRIPTEN_EMSCRIPTEN_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

#endif
