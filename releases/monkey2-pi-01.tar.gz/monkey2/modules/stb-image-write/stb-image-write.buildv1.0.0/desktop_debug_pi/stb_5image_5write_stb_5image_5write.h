
#ifndef MX2_STB_5IMAGE_5WRITE_STB_5IMAGE_5WRITE_H
#define MX2_STB_5IMAGE_5WRITE_STB_5IMAGE_5WRITE_H

#include <bbmonkey.h>
#include "../../native/stb_image_write.h"

// ***** External *****

// ***** Internal *****

#endif
