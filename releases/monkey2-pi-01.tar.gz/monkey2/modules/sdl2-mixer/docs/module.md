
# The sdl2-mixer module.

SDL\_mixer is a sample multi-channel audio mixer library. 

More information about SDL\_mixer can be found at <a href=https://www.libsdl.org/projects/SDL_mixer/ target=blank>https://www.libsdl.org/projects/SDL_mixer/</a>.
