
#include "../../desktop_debug_pi/sdl2_5mixer_sdl2_5mixer.h"

// ***** External *****

// ***** Internal *****

void mx2_sdl2_5mixer_sdl2_5mixer_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_sdl2_5mixer_sdl2_5mixer_init_v("sdl2_5mixer_sdl2_5mixer",&mx2_sdl2_5mixer_sdl2_5mixer_init);
