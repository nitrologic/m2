
# The stb-truetype module

stb-truetype is an open source library for rendering true type fonts.

More information about stb-truetype can be found at <a href=https://github.com/nothings/stb>https://github.com/nothings/stb/</a>.