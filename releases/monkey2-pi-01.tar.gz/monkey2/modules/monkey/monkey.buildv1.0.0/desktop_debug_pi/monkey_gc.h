
#ifndef MX2_MONKEY_GC_H
#define MX2_MONKEY_GC_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

#endif
