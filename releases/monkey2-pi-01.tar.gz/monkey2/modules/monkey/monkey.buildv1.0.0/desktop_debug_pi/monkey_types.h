
#ifndef MX2_MONKEY_TYPES_H
#define MX2_MONKEY_TYPES_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

#endif
