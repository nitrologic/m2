
#ifndef MX2_MONKEY_MONKEY_H
#define MX2_MONKEY_MONKEY_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

#endif
