
#include "../../desktop_release_pi/monkey_math.h"

// ***** External *****

// ***** Internal *****

bbDouble g_monkey_math_Pi;
bbDouble g_monkey_math_TwoPi;

void mx2_monkey_math_init(){
  static bool done;
  if(done) return;
  done=true;
  g_monkey_math_Pi=3.1415926535897931;
  g_monkey_math_TwoPi=6.2831853071795862;
}

bbInit mx2_monkey_math_init_v("monkey_math",&mx2_monkey_math_init);
