
#include "../../desktop_release_pi/monkey_monkey.h"

// ***** External *****

// ***** Internal *****

void mx2_monkey_monkey_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_monkey_monkey_init_v("monkey_monkey",&mx2_monkey_monkey_init);
