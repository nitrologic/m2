
#ifndef BB_STD_H
#define BB_STD_H

#include <new>
#include <initializer_list>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>

#endif
