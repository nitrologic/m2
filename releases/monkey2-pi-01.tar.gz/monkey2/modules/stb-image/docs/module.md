
# The stb-image module

stb-image is an open source library for loading image files.

More information about stb-image can be found at <a href=https://github.com/nothings/stb>https://github.com/nothings/stb/</a>.
