
#ifndef MX2_STB_5IMAGE_STB_5IMAGE_H
#define MX2_STB_5IMAGE_STB_5IMAGE_H

#include <bbmonkey.h>
#include "../../native/stb_image.h"

// ***** External *****

// ***** Internal *****

#endif
