
#ifndef MX2_HOEDOWN_HOEDOWN_H
#define MX2_HOEDOWN_HOEDOWN_H

#include <bbmonkey.h>
#include "../../hoedown/src/document.h"
#include "../../hoedown/src/html.h"

// ***** External *****

// ***** Internal *****

extern bbString g_hoedown_MarkdownToHtml(bbString l_markdown,bbBool l_toc);

#endif
