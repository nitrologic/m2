
#include "../../desktop_debug_pi/hoedown_hoedown.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.0/desktop_debug_pi/monkey_types.h"

// ***** Internal *****

bbString g_hoedown_MarkdownToHtml(bbString l_markdown,bbBool l_toc){
  bbDBFrame db_f{"MarkdownToHtml:String(markdown:String,toc:Bool)","/home/pi/monkey2/modules/hoedown/hoedown.monkey2"};
  bbDBLocal("markdown",&l_markdown);
  bbDBLocal("toc",&l_toc);
  bbDBStmt(483335);
  hoedown_buffer* l_ob=hoedown_buffer_new(4096);
  bbDBLocal("ob",&l_ob);
  bbDBStmt(491527);
  hoedown_renderer* l_r{};
  bbDBLocal("r",&l_r);
  bbDBStmt(499713);
  if(l_toc){
    bbDBBlock db_blk;
    bbDBStmt(503810);
    l_r=hoedown_html_toc_renderer_new(10);
  }else{
    bbDBStmt(507905);
    bbDBBlock db_blk;
    bbDBStmt(512002);
    l_r=hoedown_html_renderer_new((hoedown_html_flags)0,10);
  }
  bbDBStmt(524295);
  hoedown_document* l_doc=hoedown_document_new(l_r,hoedown_extensions(HOEDOWN_EXT_TABLES|HOEDOWN_EXT_FENCED_CODE),10);
  bbDBLocal("doc",&l_doc);
  bbDBStmt(532481);
  hoedown_document_render(l_doc,l_ob,bbUtf8String(l_markdown),l_markdown.utf8Length());
  bbDBStmt(540679);
  bbString l_html=bbString::fromCString(hoedown_buffer_cstr(l_ob));
  bbDBLocal("html",&l_html);
  bbDBStmt(548865);
  hoedown_document_free(l_doc);
  bbDBStmt(557057);
  hoedown_html_renderer_free(l_r);
  bbDBStmt(565249);
  hoedown_buffer_free(l_ob);
  bbDBStmt(573441);
  return l_html;
}

void mx2_hoedown_hoedown_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_hoedown_hoedown_init_v("hoedown_hoedown",&mx2_hoedown_hoedown_init);
