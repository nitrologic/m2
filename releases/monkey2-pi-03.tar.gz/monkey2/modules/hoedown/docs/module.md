
# The hoedown module

Hoedown is an open source library for converting markdown to html.

More information about hoedown can be found at <a href=https://github.com/hoedown/hoedown target=blank>https://github.com/hoedown/hoedown</a>.
