
#include "../../desktop_release_pi/hoedown_hoedown.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_types.h"

// ***** Internal *****

bbString g_hoedown_MarkdownToHtml(bbString l_markdown,bbBool l_toc){
  hoedown_buffer* l_ob=hoedown_buffer_new(4096);
  hoedown_renderer* l_r{};
  if(l_toc){
    l_r=hoedown_html_toc_renderer_new(10);
  }else{
    l_r=hoedown_html_renderer_new((hoedown_html_flags)0,10);
  }
  hoedown_document* l_doc=hoedown_document_new(l_r,hoedown_extensions((int(HOEDOWN_EXT_TABLES)|int(HOEDOWN_EXT_FENCED_CODE))),10);
  hoedown_document_render(l_doc,l_ob,bbUtf8String(l_markdown),l_markdown.utf8Length());
  bbString l_html=bbString::fromCString(hoedown_buffer_cstr(l_ob));
  hoedown_document_free(l_doc);
  hoedown_html_renderer_free(l_r);
  hoedown_buffer_free(l_ob);
  return l_html;
}

void mx2_hoedown_hoedown_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_hoedown_hoedown_init_v("hoedown_hoedown",&mx2_hoedown_hoedown_init);
