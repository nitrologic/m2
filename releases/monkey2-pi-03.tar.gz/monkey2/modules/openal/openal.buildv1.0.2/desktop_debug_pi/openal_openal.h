
#ifndef MX2_OPENAL_OPENAL_H
#define MX2_OPENAL_OPENAL_H

#include <bbmonkey.h>
#include <AL/al.h>
#include <AL/alc.h>

// ***** External *****

// ***** Internal *****

#endif
