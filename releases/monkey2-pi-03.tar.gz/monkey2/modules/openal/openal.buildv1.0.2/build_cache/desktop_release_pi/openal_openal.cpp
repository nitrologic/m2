
#include "../../desktop_release_pi/openal_openal.h"

// ***** External *****

// ***** Internal *****

void mx2_openal_openal_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_openal_openal_init_v("openal_openal",&mx2_openal_openal_init);
