
#include "../../desktop_release_pi/miniz_miniz.h"

// ***** External *****

// ***** Internal *****

void mx2_miniz_miniz_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_miniz_miniz_init_v("miniz_miniz",&mx2_miniz_miniz_init);
