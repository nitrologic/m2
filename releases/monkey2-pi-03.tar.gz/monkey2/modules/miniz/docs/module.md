
# The miniz module

Miniz is an open source library for reading and writing zip files.

More information about miniz can be found at <a href=https://code.google.com/archive/p/miniz/ target=blank>https://code.google.com/archive/p/miniz/</a>.
