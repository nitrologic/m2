
#ifndef MX2_MOJO_APP_2EVENT_H
#define MX2_MOJO_APP_2EVENT_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2vec2.h"

struct t_mojo_app_View;
bbString bbDBType(t_mojo_app_View**);
bbString bbDBValue(t_mojo_app_View**);
enum class t_mojo_input_Key;
enum class t_mojo_input_Modifier;
enum class t_mojo_input_MouseButton;
struct t_mojo_app_Window;
bbString bbDBType(t_mojo_app_Window**);
bbString bbDBValue(t_mojo_app_Window**);

// ***** Internal *****

enum class t_mojo_app_EventType;

struct t_mojo_app_Event;
struct t_mojo_app_KeyEvent;
struct t_mojo_app_MouseEvent;
struct t_mojo_app_WindowEvent;

struct t_mojo_app_Event : public bbObject{

  const char *typeName()const{return "t_mojo_app_Event";}

  t_mojo_app_EventType m__0type{};
  bbGCVar<t_mojo_app_View> m__0view{};

  void gcMark();
  void dbEmit();

  t_mojo_app_Event(t_mojo_app_EventType l_type,t_mojo_app_View* l_view);

  t_mojo_app_View* m_View();
  t_mojo_app_EventType m_Type();
  bbBool m_Eaten();
  void m_Eat();

  t_mojo_app_Event(){
  }
};
bbString bbDBType(t_mojo_app_Event**);
bbString bbDBValue(t_mojo_app_Event**);

struct t_mojo_app_KeyEvent : public t_mojo_app_Event{

  const char *typeName()const{return "t_mojo_app_KeyEvent";}

  t_mojo_input_Key m__0key{};
  t_mojo_input_Key m__0rawKey{};
  t_mojo_input_Modifier m__0modifiers{};
  bbString m__0text{};
  void dbEmit();

  t_mojo_app_KeyEvent(t_mojo_app_EventType l_type,t_mojo_app_View* l_view,t_mojo_input_Key l_key,t_mojo_input_Key l_rawKey,t_mojo_input_Modifier l_modifiers,bbString l_text);

  bbString m_Text();
  t_mojo_input_Key m_RawKey();
  t_mojo_input_Modifier m_Modifiers();
  t_mojo_input_Key m_Key();

  t_mojo_app_KeyEvent(){
  }
};
bbString bbDBType(t_mojo_app_KeyEvent**);
bbString bbDBValue(t_mojo_app_KeyEvent**);

struct t_mojo_app_MouseEvent : public t_mojo_app_Event{

  const char *typeName()const{return "t_mojo_app_MouseEvent";}

  t_std_geom_Vec2_1i m__0location{};
  t_mojo_input_MouseButton m__0button{};
  t_std_geom_Vec2_1i m__0wheel{};
  t_mojo_input_Modifier m__0modifiers{};
  void dbEmit();

  t_mojo_app_MouseEvent(t_mojo_app_EventType l_type,t_mojo_app_View* l_view,t_std_geom_Vec2_1i l_location,t_mojo_input_MouseButton l_button,t_std_geom_Vec2_1i l_wheel,t_mojo_input_Modifier l_modifiers);

  t_std_geom_Vec2_1i m_Wheel();
  t_mojo_input_Modifier m_Modifiers();
  t_std_geom_Vec2_1i m_Location();
  t_mojo_input_MouseButton m_Button();

  t_mojo_app_MouseEvent(){
  }
};
bbString bbDBType(t_mojo_app_MouseEvent**);
bbString bbDBValue(t_mojo_app_MouseEvent**);

struct t_mojo_app_WindowEvent : public t_mojo_app_Event{

  const char *typeName()const{return "t_mojo_app_WindowEvent";}

  bbGCVar<t_mojo_app_Window> m__0window{};

  void gcMark();
  void dbEmit();

  t_mojo_app_WindowEvent(t_mojo_app_EventType l_type,t_mojo_app_Window* l_window);

  t_mojo_app_Window* m_Window();

  t_mojo_app_WindowEvent(){
  }
};
bbString bbDBType(t_mojo_app_WindowEvent**);
bbString bbDBValue(t_mojo_app_WindowEvent**);

#endif
