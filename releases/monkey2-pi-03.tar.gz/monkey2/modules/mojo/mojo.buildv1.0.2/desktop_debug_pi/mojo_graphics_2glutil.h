
#ifndef MX2_MOJO_GRAPHICS_2GLUTIL_H
#define MX2_MOJO_GRAPHICS_2GLUTIL_H

#include <bbmonkey.h>

// ***** External *****

enum class t_std_graphics_PixelFormat;

// ***** Internal *****

extern bbInt g_mojo_graphics_glutil_tmpi;
extern bbInt g_mojo_graphics_glutil_glGraphicsSeq;

extern void g_mojo_graphics_glutil_glLink(bbInt l_program);
extern bbInt g_mojo_graphics_glutil_glCompile(bbInt l_type,bbString l_source);
extern void g_mojo_graphics_glutil_glPopFramebuffer();
extern void g_mojo_graphics_glutil_glPushFramebuffer(bbInt l_framebuf);
extern void g_mojo_graphics_glutil_glPopTexture2d();
extern void g_mojo_graphics_glutil_glPushTexture2d(bbInt l_tex);
extern bbInt g_mojo_graphics_glutil_glFormat(t_std_graphics_PixelFormat l_format);
extern void g_mojo_graphics_glutil_glCheck();

#endif
