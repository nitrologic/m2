
#ifndef MX2_MOJO_AUDIO_2AUDIO_H
#define MX2_MOJO_AUDIO_2AUDIO_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"
#include "../../../openal/openal.buildv1.0.2/desktop_debug_pi/openal_openal.h"

enum class t_std_audio_AudioFormat;
struct t_std_collections_Stack_1Tt_mojo_audio_Channel_2;
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_audio_Channel_2**);
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_audio_Channel_2**);
struct t_std_audio_AudioData;
bbString bbDBType(t_std_audio_AudioData**);
bbString bbDBValue(t_std_audio_AudioData**);
struct t_std_collections_Stack_1j;
bbString bbDBType(t_std_collections_Stack_1j**);
bbString bbDBValue(t_std_collections_Stack_1j**);
struct t_std_fiber_Future_1i;
bbString bbDBType(t_std_fiber_Future_1i**);
bbString bbDBValue(t_std_fiber_Future_1i**);
struct bbTimer;

// ***** Internal *****

struct t_mojo_audio_AudioDevice;
struct t_mojo_audio_Sound;
struct t_mojo_audio_Channel;

extern bbGCRootVar<t_mojo_audio_AudioDevice> g_mojo_audio_Audio;

extern t_mojo_audio_Sound* g_mojo_audio_Sound_Load(bbString l_path);
extern bbInt g_mojo_audio_ALFormat(t_std_audio_AudioFormat l_format);

struct t_mojo_audio_AudioDevice : public bbObject{

  const char *typeName()const{return "t_mojo_audio_AudioDevice";}

  ALCdevice* m__0alcDevice{};
  ALCcontext* m__0alcContext{};
  bbString m__0error{};
  bbGCVar<t_std_collections_Stack_1Tt_mojo_audio_Channel_2> m__0channels{};

  void init();

  void gcMark();
  void dbEmit();

  void m_Init();
  void m_FlushTmpChannels();
  t_mojo_audio_Channel* m_AllocTmpChannel();

  t_mojo_audio_AudioDevice(){
    init();
  }
};
bbString bbDBType(t_mojo_audio_AudioDevice**);
bbString bbDBValue(t_mojo_audio_AudioDevice**);

struct t_mojo_audio_Sound : public bbObject{

  const char *typeName()const{return "t_mojo_audio_Sound";}

  bbUInt m__0alBuffer{};
  void dbEmit();

  t_mojo_audio_Sound(t_std_audio_AudioData* l_data);

  t_mojo_audio_Channel* m_Play(bbBool l_loop);
  void m_Discard();

  t_mojo_audio_Sound(){
  }
};
bbString bbDBType(t_mojo_audio_Sound**);
bbString bbDBValue(t_mojo_audio_Sound**);

struct t_mojo_audio_Channel : public bbObject{

  const char *typeName()const{return "t_mojo_audio_Channel";}

  bbUInt m__0alSource{};
  bbFloat m__0volume=1.0f;
  bbFloat m__0rate=1.0f;
  bbFloat m__0pan=0.0f;
  bbGCVar<t_std_collections_Stack_1j> m__0tmpBuffers{};
  bbGCVar<t_std_collections_Stack_1j> m__0freeBuffers{};
  bbGCVar<t_std_fiber_Future_1i> m__0future{};
  bbBool m__0waiting{};
  bbInt m__0queued{};
  bbGCVar<bbTimer> m__0timer{};

  void gcMark();
  void dbEmit();

  t_mojo_audio_Channel();

  void m_WaitQueued(bbInt l_queued);
  void m_Volume(bbFloat l_volume);
  bbFloat m_Volume();
  void m_Stop();
  void m_Rate(bbFloat l_rate);
  bbFloat m_Rate();
  void m_Queue(t_std_audio_AudioData* l_data);
  bbBool m_Playing();
  void m_Play(t_mojo_audio_Sound* l_sound,bbBool l_loop);
  void m_Paused(bbBool l_paused);
  bbBool m_Paused();
  void m_Pan(bbFloat l_pan);
  bbFloat m_Pan();
  bbInt m_FlushProcessed();
  void m_Discard();
  bbInt m_ALState();
};
bbString bbDBType(t_mojo_audio_Channel**);
bbString bbDBValue(t_mojo_audio_Channel**);

#endif
