
#ifndef MX2_MOJO_GRAPHICS_2DEVICE_H
#define MX2_MOJO_GRAPHICS_2DEVICE_H

#include <bbmonkey.h>

// ***** External *****

#include "mojo_graphics_2vertex.h"
#include "../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_graphics_2color.h"

struct t_mojo_graphics_Texture;
bbString bbDBType(t_mojo_graphics_Texture**);
bbString bbDBValue(t_mojo_graphics_Texture**);
struct t_mojo_graphics_ShaderEnv;
bbString bbDBType(t_mojo_graphics_ShaderEnv**);
bbString bbDBValue(t_mojo_graphics_ShaderEnv**);
struct t_mojo_graphics_ParamBuffer;
bbString bbDBType(t_mojo_graphics_ParamBuffer**);
bbString bbDBValue(t_mojo_graphics_ParamBuffer**);
struct t_mojo_graphics_Shader;
bbString bbDBType(t_mojo_graphics_Shader**);
bbString bbDBValue(t_mojo_graphics_Shader**);
struct t_std_graphics_Pixmap;
bbString bbDBType(t_std_graphics_Pixmap**);
bbString bbDBValue(t_std_graphics_Pixmap**);

// ***** Internal *****

enum class t_mojo_graphics_BlendMode;
enum class t_mojo_graphics_GraphicsDevice_Dirty;

struct t_mojo_graphics_GraphicsDevice;

extern bbInt g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX;
extern bbGCRootVar<t_mojo_graphics_GraphicsDevice> g_mojo_graphics_GraphicsDevice__0current;
extern bbInt g_mojo_graphics_GraphicsDevice__0defaultFbo;
extern bbGCRootVar<bbArray<bbUShort>> g_mojo_graphics_GraphicsDevice__0qindices;
extern bbInt g_mojo_graphics_GraphicsDevice__0seq;
extern bbGCRootVar<bbArray<t_mojo_graphics_Vertex2f>> g_mojo_graphics_GraphicsDevice__0vertices;

extern void g_mojo_graphics_GraphicsDevice_InitGLState();

struct t_mojo_graphics_GraphicsDevice : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_GraphicsDevice";}

  t_mojo_graphics_GraphicsDevice_Dirty m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty(127);
  bbBool m__0modified{};
  bbGCVar<t_mojo_graphics_Texture> m__0target{};
  t_std_geom_Rect_1i m__0windowRect{};
  t_std_geom_Rect_1i m__0viewport{};
  t_std_geom_Rect_1i m__0scissor{};
  t_mojo_graphics_BlendMode m__0blendMode{};
  bbGCVar<t_mojo_graphics_ShaderEnv> m__0shaderEnv{};
  bbGCVar<t_mojo_graphics_ParamBuffer> m__0envParams{};
  bbGCVar<t_mojo_graphics_Shader> m__0shader{};
  bbGCVar<t_mojo_graphics_ParamBuffer> m__0params{};
  bbBool m__0filter=true;
  t_std_geom_Rect_1i m__0rscissor{};

  void gcMark();
  void dbEmit();

  t_mojo_graphics_GraphicsDevice();

  void m_Viewport(t_std_geom_Rect_1i l_viewport);
  t_std_geom_Rect_1i m_Viewport();
  void m_Validate();
  void m_ShaderEnv(t_mojo_graphics_ShaderEnv* l_shaderEnv);
  t_mojo_graphics_ShaderEnv* m_ShaderEnv();
  void m_Shader(t_mojo_graphics_Shader* l_shader);
  t_mojo_graphics_Shader* m_Shader();
  void m_Scissor(t_std_geom_Rect_1i l_scissor);
  t_std_geom_Rect_1i m_Scissor();
  void m_RenderTarget(t_mojo_graphics_Texture* l_renderTarget);
  t_mojo_graphics_Texture* m_RenderTarget();
  void m_Render(t_mojo_graphics_Vertex2f* l_vertices,bbInt l_order,bbInt l_count);
  void m_Params(t_mojo_graphics_ParamBuffer* l_params);
  t_mojo_graphics_ParamBuffer* m_Params();
  void m_FlushTarget();
  void m_FilteringEnabled(bbBool l_filteringEnabled);
  bbBool m_FilteringEnabled();
  void m_EnvParams(t_mojo_graphics_ParamBuffer* l_envParams);
  t_mojo_graphics_ParamBuffer* m_EnvParams();
  t_std_graphics_Pixmap* m_CopyPixmap(t_std_geom_Rect_1i l_rect);
  void m_Clear(t_std_graphics_Color l_color);
  void m_BlendMode(t_mojo_graphics_BlendMode l_blendMode);
  t_mojo_graphics_BlendMode m_BlendMode();
};
bbString bbDBType(t_mojo_graphics_GraphicsDevice**);
bbString bbDBValue(t_mojo_graphics_GraphicsDevice**);

#endif
