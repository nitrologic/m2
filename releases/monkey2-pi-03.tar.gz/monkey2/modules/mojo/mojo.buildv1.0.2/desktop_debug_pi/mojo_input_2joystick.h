
#ifndef MX2_MOJO_INPUT_2JOYSTICK_H
#define MX2_MOJO_INPUT_2JOYSTICK_H

#include <bbmonkey.h>

// ***** External *****

#include "mojo_input_2device.h"
#include "../../../sdl2/sdl2.buildv1.0.2/desktop_debug_pi/sdl2_sdl2.h"
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2vec2.h"

// ***** Internal *****

enum class t_mojo_input_JoystickHat;

struct t_mojo_input_JoystickDevice;

extern bbGCRootVar<bbArray<bbGCVar<t_mojo_input_JoystickDevice>>> g_mojo_input_JoystickDevice__0joysticks;

extern void g_mojo_input_JoystickDevice_UpdateJoysticks();
extern t_mojo_input_JoystickDevice* g_mojo_input_JoystickDevice_Open(bbInt l_index);
extern bbInt g_mojo_input_JoystickDevice_NumJoysticks();

struct t_mojo_input_JoystickDevice : public t_mojo_input_InputDevice{

  const char *typeName()const{return "t_mojo_input_JoystickDevice";}

  SDL_Joystick* m__0joystick{};
  bbString m__0name{};
  bbString m__0guid{};
  bbInt m__0numAxes{};
  bbInt m__0numBalls{};
  bbInt m__0numButtons{};
  bbInt m__0numHats{};
  bbGCVar<bbArray<bbBool>> m__0hits{};

  void init();

  void gcMark();
  void dbEmit();

  t_mojo_input_JoystickDevice(SDL_Joystick* l_joystick);

  bbInt m_NumHats();
  bbInt m_NumButtons();
  bbInt m_NumBalls();
  bbInt m_NumAxes();
  bbString m_Name();
  t_mojo_input_JoystickHat m_GetHat(bbInt l_hat);
  t_std_geom_Vec2_1i m_GetBall(bbInt l_ball);
  bbFloat m_GetAxis(bbInt l_axis);
  bbString m_GUID();
  bbBool m_ButtonPressed(bbInt l_button);
  bbBool m_ButtonDown(bbInt l_button);

  t_mojo_input_JoystickDevice(){
    init();
  }
};
bbString bbDBType(t_mojo_input_JoystickDevice**);
bbString bbDBValue(t_mojo_input_JoystickDevice**);

#endif
