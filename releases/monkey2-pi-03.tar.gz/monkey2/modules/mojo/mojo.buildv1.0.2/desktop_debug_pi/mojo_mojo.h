
#ifndef MX2_MOJO_MOJO_H
#define MX2_MOJO_MOJO_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

extern void mx2_mojo_main();

#endif
