
#ifndef MX2_MOJO_APP_2STYLE_H
#define MX2_MOJO_APP_2STYLE_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_graphics_2color.h"

struct t_std_collections_Map_1sTt_mojo_app_Style_2;
bbString bbDBType(t_std_collections_Map_1sTt_mojo_app_Style_2**);
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_app_Style_2**);
struct t_mojo_app_Skin;
bbString bbDBType(t_mojo_app_Skin**);
bbString bbDBValue(t_mojo_app_Skin**);
struct t_mojo_graphics_Font;
bbString bbDBType(t_mojo_graphics_Font**);
bbString bbDBValue(t_mojo_graphics_Font**);
struct t_std_collections_Map_1sTt_mojo_graphics_Image_2;
bbString bbDBType(t_std_collections_Map_1sTt_mojo_graphics_Image_2**);
bbString bbDBValue(t_std_collections_Map_1sTt_mojo_graphics_Image_2**);
struct t_mojo_graphics_Image;
bbString bbDBType(t_mojo_graphics_Image**);
bbString bbDBValue(t_mojo_graphics_Image**);
struct t_mojo_graphics_Canvas;
bbString bbDBType(t_mojo_graphics_Canvas**);
bbString bbDBValue(t_mojo_graphics_Canvas**);

// ***** Internal *****

struct t_mojo_app_Style;

extern bbGCRootVar<t_mojo_app_Style> g_mojo_app_Style__0defaultStyle;
extern bbGCRootVar<t_std_collections_Map_1sTt_mojo_app_Style_2> g_mojo_app_Style__0styles;

extern t_mojo_app_Style* g_mojo_app_Style_GetStyle(bbString l_name);

struct t_mojo_app_Style : public bbObject{

  const char *typeName()const{return "t_mojo_app_Style";}

  bbGCVar<t_std_collections_Map_1sTt_mojo_app_Style_2> m__0states{};
  t_std_graphics_Color m__0bgcolor=g_std_graphics_Color_None;
  t_std_geom_Rect_1i m__0padding{};
  bbGCVar<t_mojo_app_Skin> m__0skin{};
  t_std_graphics_Color m__0skcolor=g_std_graphics_Color_White;
  t_std_geom_Rect_1i m__0border{};
  t_std_graphics_Color m__0bdcolor=g_std_graphics_Color_None;
  t_std_geom_Rect_1i m__0margin{};
  t_std_graphics_Color m__0color{};
  bbGCVar<t_mojo_graphics_Font> m__0font{};
  bbGCVar<t_std_collections_Map_1sTt_mojo_graphics_Image_2> m__0images{};

  void init();

  void gcMark();
  void dbEmit();

  t_mojo_app_Style(bbString l_name,t_mojo_app_Style* l_style);
  t_mojo_app_Style(bbString l_name);
  t_mojo_app_Style(t_mojo_app_Style* l_style);
  t_mojo_app_Style();

  void m_SkinColor(t_std_graphics_Color l_skinColor);
  t_std_graphics_Color m_SkinColor();
  void m_Skin(t_mojo_app_Skin* l_skin);
  t_mojo_app_Skin* m_Skin();
  void m_SetImage(bbString l_name,t_mojo_graphics_Image* l_image);
  void m_Render(t_mojo_graphics_Canvas* l_canvas,t_std_geom_Rect_1i l_bounds);
  void m_Padding(t_std_geom_Rect_1i l_padding);
  t_std_geom_Rect_1i m_Padding();
  void m_Margin(t_std_geom_Rect_1i l_margin);
  t_std_geom_Rect_1i m_Margin();
  void m_Init(bbString l_name,t_mojo_app_Style* l_style,bbBool l_copyStates);
  t_mojo_app_Style* m_GetState(bbString l_state);
  t_mojo_graphics_Image* m_GetImage(bbString l_name);
  void m_DefaultFont(t_mojo_graphics_Font* l_font);
  t_mojo_graphics_Font* m_DefaultFont();
  void m_DefaultColor(t_std_graphics_Color l_color);
  t_std_graphics_Color m_DefaultColor();
  t_std_geom_Rect_1i m_Bounds();
  void m_BorderColor(t_std_graphics_Color l_borderColor);
  t_std_graphics_Color m_BorderColor();
  void m_Border(t_std_geom_Rect_1i l_border);
  t_std_geom_Rect_1i m_Border();
  void m_BackgroundColor(t_std_graphics_Color l_backgroundColor);
  t_std_graphics_Color m_BackgroundColor();
  t_mojo_app_Style* m_AddState(bbString l_state,bbString l_srcState);
};
bbString bbDBType(t_mojo_app_Style**);
bbString bbDBValue(t_mojo_app_Style**);

#endif
