
#ifndef MX2_MOJO_INPUT_2DEVICE_H
#define MX2_MOJO_INPUT_2DEVICE_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"

// ***** Internal *****

struct t_mojo_input_InputDevice;

struct t_mojo_input_InputDevice : public bbObject{

  const char *typeName()const{return "t_mojo_input_InputDevice";}

  void dbEmit();

  t_mojo_input_InputDevice(){
  }
};
bbString bbDBType(t_mojo_input_InputDevice**);
bbString bbDBValue(t_mojo_input_InputDevice**);

#endif
