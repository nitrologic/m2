
#ifndef MX2_MOJO_INPUT_2KEYCODES_H
#define MX2_MOJO_INPUT_2KEYCODES_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

enum class t_mojo_input_Key;
enum class t_mojo_input_Modifier;

#endif
