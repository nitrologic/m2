
#ifndef MX2_MOJO_STD_GEOM_2RECT_H
#define MX2_MOJO_STD_GEOM_2RECT_H

#include <bbmonkey.h>
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2rect.h"

// ***** External *****

#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2affinemat3.h"
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2rect.h"

// ***** Internal *****

extern t_std_geom_Rect_1i g_std_geom_TransformRecti_1f(t_std_geom_Rect_1i l_rect,t_std_geom_AffineMat3_1f l_matrix);

#endif
