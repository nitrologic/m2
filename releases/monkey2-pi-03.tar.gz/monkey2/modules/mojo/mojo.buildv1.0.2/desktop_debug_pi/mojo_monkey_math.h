
#ifndef MX2_MOJO_MONKEY_MATH_H
#define MX2_MOJO_MONKEY_MATH_H

#include <bbmonkey.h>
#include "../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_math.h"

// ***** External *****

// ***** Internal *****

extern bbFloat g_monkey_math_Clamp_1f(bbFloat l_value,bbFloat l_min,bbFloat l_max);

#endif
