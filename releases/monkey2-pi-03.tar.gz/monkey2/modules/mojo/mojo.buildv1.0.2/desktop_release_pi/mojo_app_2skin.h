
#ifndef MX2_MOJO_APP_2SKIN_H
#define MX2_MOJO_APP_2SKIN_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_geom_2rect.h"

struct t_mojo_graphics_Image;
struct t_std_graphics_Pixmap;
struct t_mojo_graphics_Canvas;

// ***** Internal *****

struct t_mojo_app_Skin;

extern t_mojo_app_Skin* g_mojo_app_Skin_Load(bbString l_path);

struct t_mojo_app_Skin : public bbObject{

  const char *typeName()const{return "t_mojo_app_Skin";}

  bbGCVar<t_mojo_graphics_Image> m__0image{};
  t_std_geom_Rect_1i m__0bounds{};
  t_std_geom_Rect_1i m__0rect{};
  bbInt m__0x0{};
  bbInt m__0x1{};
  bbInt m__0x2{};
  bbInt m__0x3{};
  bbInt m__0y0{};
  bbInt m__0y1{};
  bbInt m__0y2{};
  bbInt m__0y3{};

  void gcMark();

  t_mojo_app_Skin(t_std_graphics_Pixmap* l_pixmap);

  t_mojo_graphics_Image* m_Image();
  void m_Draw(t_mojo_graphics_Canvas* l_canvas,t_std_geom_Rect_1i l_rect);
  t_std_geom_Rect_1i m_Bounds();

  t_mojo_app_Skin(){
  }
};

#endif
