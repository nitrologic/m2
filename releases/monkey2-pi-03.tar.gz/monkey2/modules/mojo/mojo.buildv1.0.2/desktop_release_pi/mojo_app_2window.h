
#ifndef MX2_MOJO_APP_2WINDOW_H
#define MX2_MOJO_APP_2WINDOW_H

#include <bbmonkey.h>

// ***** External *****

#include "mojo_app_2view.h"
#include "../../../sdl2/sdl2.buildv1.0.2/desktop_release_pi/sdl2_sdl2.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_geom_2vec2.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_graphics_2color.h"

struct t_std_collections_Stack_1Tt_mojo_app_Window_2;
struct t_std_collections_Map_1jTt_mojo_app_Window_2;
struct t_mojo_graphics_Canvas;
struct t_mojo_app_AppInstance;
struct t_mojo_app_WindowEvent;

// ***** Internal *****

enum class t_mojo_app_WindowFlags;

struct t_mojo_app_Window;

extern bbGCRootVar<t_std_collections_Stack_1Tt_mojo_app_Window_2> g_mojo_app_Window__0allWindows;
extern bbGCRootVar<t_std_collections_Stack_1Tt_mojo_app_Window_2> g_mojo_app_Window__0visibleWindows;
extern bbGCRootVar<t_std_collections_Map_1jTt_mojo_app_Window_2> g_mojo_app_Window__0windowsByID;

extern t_mojo_app_Window* g_mojo_app_Window_WindowForID(bbUInt l_id);
extern bbArray<bbGCVar<t_mojo_app_Window>>* g_mojo_app_Window_VisibleWindows();
extern bbArray<bbGCVar<t_mojo_app_Window>>* g_mojo_app_Window_AllWindows();

struct t_mojo_app_Window : public t_mojo_app_View{

  using t_mojo_app_View::m_Render;
  const char *typeName()const{return "t_mojo_app_Window";}

  SDL_Window* m__0sdlWindow{};
  void* m__0sdlGLContext{};
  t_mojo_app_WindowFlags m__0flags{};
  bbBool m__0fullscreen=false;
  bbInt m__0swapInterval=1;
  bbGCVar<t_mojo_graphics_Canvas> m__0canvas{};
  t_std_graphics_Color m__0clearColor=g_std_graphics_Color_Grey;
  bbBool m__0clearEnabled=true;
  bbGCVar<t_mojo_app_View> m__0keyView{};
  t_std_geom_Vec2_1i m__0minSize{};
  t_std_geom_Vec2_1i m__0maxSize{};
  t_std_geom_Rect_1i m__0frame{};
  bbBool m__0weirdHack{};

  void gcMark();

  t_mojo_app_Window(bbString l_title,t_mojo_app_AppInstance* l_app);
  t_mojo_app_Window(bbString l_title,t_std_geom_Rect_1i l_rect,t_mojo_app_WindowFlags l_flags);
  t_mojo_app_Window(bbString l_title,bbInt l_width,bbInt l_height,t_mojo_app_WindowFlags l_flags);
  t_mojo_app_Window();

  void m_Update();
  void m_Title(bbString l_title);
  bbString m_Title();
  void m_SwapInterval(bbInt l_swapInterval);
  bbInt m_SwapInterval();
  void m_SendWindowEvent(t_mojo_app_WindowEvent* l_event);
  SDL_Window* m_SDLWindow();
  void* m_SDLGLContext();
  void m_Render();
  virtual void m_OnWindowEvent(t_mojo_app_WindowEvent* l_event);
  void m_KeyView(t_mojo_app_View* l_keyView);
  t_mojo_app_View* m_KeyView();
  void m_Init(bbString l_title,t_std_geom_Rect_1i l_rect,t_mojo_app_WindowFlags l_flags);
  t_std_geom_Vec2_1i m_GetMinSize();
  t_std_geom_Vec2_1i m_GetMaxSize();
  t_std_geom_Rect_1i m_GetFrame();
  void m_Fullscreen(bbBool l_fullscreen);
  bbBool m_Fullscreen();
  t_mojo_app_Window* m_FindWindow();
  void m_ClearEnabled(bbBool l_clearEnabled);
  bbBool m_ClearEnabled();
  void m_ClearColor(t_std_graphics_Color l_clearColor);
  t_std_graphics_Color m_ClearColor();
};

#endif
