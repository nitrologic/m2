
#ifndef MX2_MOJO_GRAPHICS_2TEXTURE_H
#define MX2_MOJO_GRAPHICS_2TEXTURE_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_geom_2rect.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_graphics_2color.h"

struct t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2;
enum class t_std_graphics_PixelFormat;
struct t_std_graphics_Pixmap;
struct t_mojo_graphics_GraphicsDevice;

// ***** Internal *****

enum class t_mojo_graphics_TextureFlags;

struct t_mojo_graphics_Texture;

extern bbGCRootVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2> g_mojo_graphics_Texture__0colorTextures;

extern t_mojo_graphics_Texture* g_mojo_graphics_Texture_Load(bbString l_path,t_mojo_graphics_TextureFlags l_flags);
extern t_mojo_graphics_Texture* g_mojo_graphics_Texture_ColorTexture(t_std_graphics_Color l_color);

struct t_mojo_graphics_Texture : public bbObject{

  const char *typeName()const{return "t_mojo_graphics_Texture";}

  bbFunction<void()> m_OnDiscarded{};
  t_std_geom_Rect_1i m__0rect{};
  t_std_graphics_PixelFormat m__0format{};
  t_mojo_graphics_TextureFlags m__0flags{};
  bbGCVar<t_std_graphics_Pixmap> m__0managed{};
  bbBool m__0discarded{};
  bbInt m__0texSeq{};
  bbBool m__0texDirty{};
  bbBool m__0mipsDirty{};
  bbUInt m__0glTexture{};
  bbInt m__0fbSeq{};
  bbUInt m__0glFramebuffer{};

  void gcMark();

  t_mojo_graphics_Texture(bbInt l_width,bbInt l_height,t_std_graphics_PixelFormat l_format,t_mojo_graphics_TextureFlags l_flags);
  t_mojo_graphics_Texture(t_std_graphics_Pixmap* l_pixmap,t_mojo_graphics_TextureFlags l_flags);

  bbInt m_Width();
  t_std_geom_Rect_1i m_Rect();
  void m_PastePixmap(t_std_graphics_Pixmap* l_pixmap,bbInt l_x,bbInt l_y);
  void m_Modified(t_mojo_graphics_GraphicsDevice* l_device);
  bbInt m_Height();
  bbUInt m_GLTexture();
  bbUInt m_GLFramebuffer();
  t_std_graphics_PixelFormat m_Format();
  t_mojo_graphics_TextureFlags m_Flags();
  void m_Discard();

  t_mojo_graphics_Texture(){
  }
};

#endif
