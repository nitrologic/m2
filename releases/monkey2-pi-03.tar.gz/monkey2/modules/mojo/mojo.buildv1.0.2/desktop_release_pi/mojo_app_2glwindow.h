
#ifndef MX2_MOJO_APP_2GLWINDOW_H
#define MX2_MOJO_APP_2GLWINDOW_H

#include <bbmonkey.h>

// ***** External *****

#include "mojo_app_2window.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_geom_2rect.h"

struct t_mojo_graphics_Canvas;

// ***** Internal *****

struct t_mojo_app_GLWindow;

struct t_mojo_app_GLWindow : public t_mojo_app_Window{

  using t_mojo_app_Window::m_Init;
  const char *typeName()const{return "t_mojo_app_GLWindow";}

  void* m__0sdlGLContext{};

  t_mojo_app_GLWindow(bbString l_title,t_std_geom_Rect_1i l_rect,t_mojo_app_WindowFlags l_flags);
  t_mojo_app_GLWindow(bbString l_title,bbInt l_width,bbInt l_height,t_mojo_app_WindowFlags l_flags);
  t_mojo_app_GLWindow();

  virtual void m_OnRenderGL();
  void m_OnRender(t_mojo_graphics_Canvas* l_canvas);
  void m_Init();
  void m_EndGL();
  void m_BeginGL();
};

#endif
