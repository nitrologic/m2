
#ifndef MX2_MOJO_INPUT_2MOUSE_H
#define MX2_MOJO_INPUT_2MOUSE_H

#include <bbmonkey.h>

// ***** External *****

#include "mojo_input_2device.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_geom_2vec2.h"

// ***** Internal *****

enum class t_mojo_input_MouseButton;

struct t_mojo_input_MouseDevice;

extern bbGCRootVar<t_mojo_input_MouseDevice> g_mojo_input_Mouse;

struct t_mojo_input_MouseDevice : public t_mojo_input_InputDevice{

  const char *typeName()const{return "t_mojo_input_MouseDevice";}

  bbBool m__0init{};
  t_std_geom_Vec2_1i m__0location{};
  bbGCVar<bbArray<bbBool>> m__0buttons{};
  bbGCVar<bbArray<bbBool>> m__0pressed{};
  bbGCVar<bbArray<bbBool>> m__0released{};

  void init();

  void gcMark();

  t_mojo_input_MouseDevice();

  bbInt m_Y();
  bbInt m_X();
  void m_Reset();
  void m_Poll();
  void m_PointerVisible(bbBool l_pointerVisible);
  bbBool m_PointerVisible();
  t_std_geom_Vec2_1i m_Location();
  void m_Init();
  bbBool m_ButtonReleased(t_mojo_input_MouseButton l_button);
  bbBool m_ButtonPressed(t_mojo_input_MouseButton l_button);
  bbBool m_ButtonHit(t_mojo_input_MouseButton l_button);
  bbBool m_ButtonDown(t_mojo_input_MouseButton l_button);
};

#endif
