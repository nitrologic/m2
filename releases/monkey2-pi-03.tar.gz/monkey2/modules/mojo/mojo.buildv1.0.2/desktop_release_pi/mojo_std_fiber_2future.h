
#ifndef MX2_MOJO_STD_FIBER_2FUTURE_H
#define MX2_MOJO_STD_FIBER_2FUTURE_H

#include <bbmonkey.h>
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_fiber_2future.h"

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_types.h"
#include "../../../std/std.buildv1.0.2/desktop_release_pi/std_fiber_2fiber.h"

// ***** Internal *****

struct t_std_fiber_Future_1i;

struct t_std_fiber_Future_1i : public bbObject{

  const char *typeName()const{return "t_std_fiber_Future_1i";}

  t_std_fiber_Fiber m__0fiber{};
  bbInt m__0value{};

  t_std_fiber_Future_1i();

  void m_Set(bbInt l_value);
  bbInt m_Get();
};

#endif
