
#ifndef MX2_MOJO_INPUT_2DEVICE_H
#define MX2_MOJO_INPUT_2DEVICE_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_types.h"

// ***** Internal *****

struct t_mojo_input_InputDevice;

struct t_mojo_input_InputDevice : public bbObject{

  const char *typeName()const{return "t_mojo_input_InputDevice";}

  t_mojo_input_InputDevice(){
  }
};

#endif
