
#include "../../desktop_release_pi/mojo_graphics_2texture.h"

// ***** External *****

#include "../../../../gles20/gles20.buildv1.0.2/desktop_release_pi/gles20_gles20.h"
#include "../../desktop_release_pi/mojo_graphics_2device.h"
#include "../../desktop_release_pi/mojo_std_collections_2map.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_debug.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_graphics_2pixmap.h"

extern bbInt g_mojo_graphics_glutil_glGraphicsSeq;

extern void g_mojo_graphics_glutil_glPushTexture2d(bbInt l_tex);
extern bbInt g_mojo_graphics_glutil_glFormat(t_std_graphics_PixelFormat l_format);
extern void g_mojo_graphics_glutil_glPopTexture2d();
extern void g_mojo_graphics_glutil_glPushFramebuffer(bbInt l_framebuf);
extern void g_mojo_graphics_glutil_glPopFramebuffer();

// ***** Internal *****

bbGCRootVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2> g_mojo_graphics_Texture__0colorTextures;

t_mojo_graphics_Texture* g_mojo_graphics_Texture_Load(bbString l_path,t_mojo_graphics_TextureFlags l_flags){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    t_mojo_graphics_Texture* l_texture{};
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
      bbGCMarkPtr(l_texture);
    }
  }f0{};
  f0.l_pixmap=g_std_graphics_Pixmap_Load(l_path,t_std_graphics_PixelFormat(0));
  if(!bbBool(f0.l_pixmap)){
    return ((t_mojo_graphics_Texture*)0);
  }
  f0.l_pixmap->m_PremultiplyAlpha();
  f0.l_texture=bbGCNew<t_mojo_graphics_Texture>(f0.l_pixmap,l_flags);
  struct lambda0 : public bbFunction<void()>::Rep{
    t_std_graphics_Pixmap* l_pixmap;
    lambda0(t_std_graphics_Pixmap* l_pixmap):l_pixmap(l_pixmap){
    }
    void invoke(){
      l_pixmap->m_Discard();
    }
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  };
  f0.l_texture->m_OnDiscarded+=bbFunction<void()>(new lambda0(f0.l_pixmap));
  return f0.l_texture;
}

t_mojo_graphics_Texture* g_mojo_graphics_Texture_ColorTexture(t_std_graphics_Color l_color){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* l_texture{};
    void gcMark(){
      bbGCMarkPtr(l_texture);
    }
  }f0{};
  f0.l_texture=g_mojo_graphics_Texture__0colorTextures->m__idx(l_color);
  if(!bbBool(f0.l_texture)){
    struct f1_t : public bbGCFrame{
      t_std_graphics_Pixmap* l_pixmap{};
      void gcMark(){
        bbGCMarkPtr(l_pixmap);
      }
    }f1{};
    f1.l_pixmap=bbGCNew<t_std_graphics_Pixmap>(1,1,t_std_graphics_PixelFormat(5));
    f1.l_pixmap->m_Clear(l_color);
    f0.l_texture=bbGCNew<t_mojo_graphics_Texture>(f1.l_pixmap,t_mojo_graphics_TextureFlags(0));
    g_mojo_graphics_Texture__0colorTextures->m__idxeq(l_color,f0.l_texture);
  }
  return f0.l_texture;
}

void t_mojo_graphics_Texture::gcMark(){
  bbGCMark(m_OnDiscarded);
  bbGCMark(m__0managed);
}

t_mojo_graphics_Texture::t_mojo_graphics_Texture(bbInt l_width,bbInt l_height,t_std_graphics_PixelFormat l_format,t_mojo_graphics_TextureFlags l_flags){
  this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_width,l_height);
  this->m__0format=l_format;
  this->m__0flags=l_flags;
  if(!bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(4096)))))){
    this->m__0managed=bbGCNew<t_std_graphics_Pixmap>(l_width,l_height,l_format);
    this->m__0managed->m_Clear(g_std_graphics_Color_Magenta);
    struct lambda1 : public bbFunction<void()>::Rep{
      t_mojo_graphics_Texture* l_self;
      lambda1(t_mojo_graphics_Texture* l_self):l_self(l_self){
      }
      void invoke(){
        l_self->m__0managed->m_Discard();
        l_self->m__0managed=((t_std_graphics_Pixmap*)0);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_OnDiscarded+=bbFunction<void()>(new lambda1(this));
  }
}

t_mojo_graphics_Texture::t_mojo_graphics_Texture(t_std_graphics_Pixmap* l_pixmap,t_mojo_graphics_TextureFlags l_flags){
  this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_pixmap->m_Width(),l_pixmap->m_Height());
  this->m__0format=l_pixmap->m_Format();
  this->m__0flags=l_flags;
  if(bbBool(t_mojo_graphics_TextureFlags((int(l_flags)&int(t_mojo_graphics_TextureFlags(4096)))))){
    this->m_PastePixmap(l_pixmap,bbInt(0),bbInt(0));
  }else{
    this->m__0managed=l_pixmap;
  }
}

bbInt t_mojo_graphics_Texture::m_Width(){
  return this->m__0rect.m_Width();
}

t_std_geom_Rect_1i t_mojo_graphics_Texture::m_Rect(){
  return this->m__0rect;
}

void t_mojo_graphics_Texture::m_PastePixmap(t_std_graphics_Pixmap* l_pixmap,bbInt l_x,bbInt l_y){
  if(bbBool(this->m__0managed)){
    this->m__0managed->m_Paste(l_pixmap,l_x,l_y);
    this->m__0texDirty=true;
  }else{
    g_mojo_graphics_glutil_glPushTexture2d(bbInt(this->m_GLTexture()));
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    if((l_pixmap->m_Pitch()==(l_pixmap->m_Width()*l_pixmap->m_Depth()))){
      glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),l_x,l_y,l_pixmap->m_Width(),l_pixmap->m_Height(),g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(l_pixmap->m_Data())));
    }else{
      {
        bbInt l_iy=bbInt(0);
        for(;(l_iy<l_pixmap->m_Height());l_iy+=1){
          glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),l_x,(l_y+l_iy),l_pixmap->m_Width(),1,g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(l_pixmap->m_PixelPtr(bbInt(0),l_iy))));
        }
      }
    }
    g_mojo_graphics_glutil_glPopTexture2d();
    this->m__0mipsDirty=true;
  }
}

void t_mojo_graphics_Texture::m_Modified(t_mojo_graphics_GraphicsDevice* l_device){
  if(bbBool(this->m__0managed)){
    t_std_geom_Rect_1i l_r=l_device->m_Viewport().m__and(l_device->m_Scissor());
    glPixelStorei(GL_PACK_ALIGNMENT,1);
    glReadPixels(l_r.m_X(),l_r.m_Y(),l_r.m_Width(),l_r.m_Height(),GL_RGBA,GL_UNSIGNED_BYTE,((void*)(this->m__0managed->m_PixelPtr(l_r.m_X(),l_r.m_Y()))));
  }
  if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(2)))))){
    this->m__0mipsDirty=true;
  }
}

bbInt t_mojo_graphics_Texture::m_Height(){
  return this->m__0rect.m_Height();
}

bbUInt t_mojo_graphics_Texture::m_GLTexture(){
  bbDebugAssert(!this->m__0discarded,BB_T("texture has been discarded"));
  if((((this->m__0texSeq==g_mojo_graphics_glutil_glGraphicsSeq)&&!this->m__0texDirty)&&!this->m__0mipsDirty)){
    return this->m__0glTexture;
  }
  if((this->m__0texSeq==g_mojo_graphics_glutil_glGraphicsSeq)){
    g_mojo_graphics_glutil_glPushTexture2d(bbInt(this->m__0glTexture));
  }else{
    glGenTextures(1,&this->m__0glTexture);
    g_mojo_graphics_glutil_glPushTexture2d(bbInt(this->m__0glTexture));
    if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(1)))))){
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    }else{
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
    }
    if((bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(2)))))&&bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(1))))))){
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
    }else if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(2)))))){
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
    }else if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(1)))))){
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    }else{
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    }
    if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(4)))))){
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    }else{
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    }
    if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(8)))))){
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    }else{
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
    }
    glTexImage2D(GL_TEXTURE_2D,bbInt(0),g_mojo_graphics_glutil_glFormat(this->m__0format),this->m_Width(),this->m_Height(),bbInt(0),g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)0));
    this->m__0texSeq=g_mojo_graphics_glutil_glGraphicsSeq;
    this->m__0texDirty=true;
  }
  if(this->m__0texDirty){
    if(bbBool(this->m__0managed)){
      glPixelStorei(GL_UNPACK_ALIGNMENT,1);
      if((this->m__0managed->m_Pitch()==(this->m__0managed->m_Width()*this->m__0managed->m_Depth()))){
        glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),bbInt(0),bbInt(0),this->m__0managed->m_Width(),this->m__0managed->m_Height(),g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(this->m__0managed->m_Data())));
      }else{
        {
          bbInt l_iy=bbInt(0);
          for(;(l_iy<this->m_Height());l_iy+=1){
            glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),bbInt(0),l_iy,this->m_Width(),1,g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(this->m__0managed->m_PixelPtr(bbInt(0),l_iy))));
          }
        }
      }
      glFlush();
    }else{
      struct f2_t : public bbGCFrame{
        t_std_graphics_Pixmap* l_tmp{};
        void gcMark(){
          bbGCMarkPtr(l_tmp);
        }
      }f2{};
      f2.l_tmp=bbGCNew<t_std_graphics_Pixmap>(this->m_Width(),1,this->m_Format());
      f2.l_tmp->m_Clear(g_std_graphics_Color_Red);
      {
        bbInt l_iy=bbInt(0);
        for(;(l_iy<this->m_Height());l_iy+=1){
          glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),bbInt(0),l_iy,this->m_Width(),1,g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(f2.l_tmp->m_Data())));
        }
      }
      f2.l_tmp->m_Discard();
    }
    this->m__0texDirty=false;
    this->m__0mipsDirty=true;
  }
  if(this->m__0mipsDirty){
    if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(2)))))){
      glGenerateMipmap(GL_TEXTURE_2D);
    }
    this->m__0mipsDirty=false;
  }
  g_mojo_graphics_glutil_glPopTexture2d();
  return this->m__0glTexture;
}

bbUInt t_mojo_graphics_Texture::m_GLFramebuffer(){
  bbDebugAssert(!this->m__0discarded,BB_T("texture has been discarded"));
  if((this->m__0fbSeq==g_mojo_graphics_glutil_glGraphicsSeq)){
    return this->m__0glFramebuffer;
  }
  glGenFramebuffers(1,&this->m__0glFramebuffer);
  g_mojo_graphics_glutil_glPushFramebuffer(bbInt(this->m__0glFramebuffer));
  glBindFramebuffer(GL_FRAMEBUFFER,this->m__0glFramebuffer);
  glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,this->m_GLTexture(),bbInt(0));
  if((glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)){
    bbAssert(false,BB_T("Incomplete framebuffer"));
  }
  g_mojo_graphics_glutil_glPopFramebuffer();
  this->m__0fbSeq=g_mojo_graphics_glutil_glGraphicsSeq;
  return this->m__0glFramebuffer;
}

t_std_graphics_PixelFormat t_mojo_graphics_Texture::m_Format(){
  return this->m__0format;
}

t_mojo_graphics_TextureFlags t_mojo_graphics_Texture::m_Flags(){
  return this->m__0flags;
}

void t_mojo_graphics_Texture::m_Discard(){
  if(this->m__0discarded){
    return;
  }
  if((this->m__0texSeq==g_mojo_graphics_glutil_glGraphicsSeq)){
    glDeleteTextures(1,&this->m__0glTexture);
  }
  if((this->m__0fbSeq==g_mojo_graphics_glutil_glGraphicsSeq)){
    glDeleteFramebuffers(1,&this->m__0glFramebuffer);
  }
  this->m__0discarded=true;
  this->m_OnDiscarded();
}

void mx2_mojo_graphics_2texture_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2texture_init_v("mojo_graphics_2texture",&mx2_mojo_graphics_2texture_init);
