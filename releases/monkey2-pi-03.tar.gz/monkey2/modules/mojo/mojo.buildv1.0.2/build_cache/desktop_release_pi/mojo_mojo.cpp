
#include "../../desktop_release_pi/mojo_mojo.h"

// ***** External *****

// ***** Internal *****

void mx2_mojo_main(){
  static bool done;
  if(done) return;
  done=true;
  void mx2_std_main();mx2_std_main();
}

void mx2_mojo_mojo_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_mojo_init_v("mojo_mojo",&mx2_mojo_mojo_init);
