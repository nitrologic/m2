
#include "../../desktop_release_pi/mojo_input_2joystick.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_types.h"

extern bbInt g_monkey_math_Min_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

bbGCRootVar<bbArray<bbGCVar<t_mojo_input_JoystickDevice>>> g_mojo_input_JoystickDevice__0joysticks;

void g_mojo_input_JoystickDevice_UpdateJoysticks(){
  SDL_JoystickUpdate();
}

t_mojo_input_JoystickDevice* g_mojo_input_JoystickDevice_Open(bbInt l_index){
  struct f0_t : public bbGCFrame{
    t_mojo_input_JoystickDevice* l_joystick{};
    void gcMark(){
      bbGCMarkPtr(l_joystick);
    }
  }f0{};
  bbAssert(((l_index>=bbInt(0))&&(l_index<8)),BB_T("Assert failed"));
  f0.l_joystick=g_mojo_input_JoystickDevice__0joysticks->at(l_index);
  if(!bbBool(f0.l_joystick)){
    SDL_Joystick* l_sdlJoystick=SDL_JoystickOpen(l_index);
    if(!bbBool(l_sdlJoystick)){
      return ((t_mojo_input_JoystickDevice*)0);
    }
    f0.l_joystick=bbGCNew<t_mojo_input_JoystickDevice>(l_sdlJoystick);
    g_mojo_input_JoystickDevice__0joysticks->at(l_index)=f0.l_joystick;
  }
  return f0.l_joystick;
}

bbInt g_mojo_input_JoystickDevice_NumJoysticks(){
  return g_monkey_math_Min_1i(SDL_NumJoysticks(),8);
}

void t_mojo_input_JoystickDevice::init(){
  m__0hits=bbArray<bbBool>::create(32);
}

void t_mojo_input_JoystickDevice::gcMark(){
  t_mojo_input_InputDevice::gcMark();
  bbGCMark(m__0hits);
}

t_mojo_input_JoystickDevice::t_mojo_input_JoystickDevice(SDL_Joystick* l_joystick){
  init();
  struct f0_t : public bbGCFrame{
    bbArray<bbByte>* l_buf{};
    void gcMark(){
      bbGCMarkPtr(l_buf);
    }
  }f0{};
  this->m__0joystick=l_joystick;
  this->m__0name=bbString::fromCString(((void*)(SDL_JoystickName(this->m__0joystick))));
  this->m__0numAxes=SDL_JoystickNumAxes(this->m__0joystick);
  this->m__0numBalls=SDL_JoystickNumBalls(this->m__0joystick);
  this->m__0numButtons=SDL_JoystickNumButtons(this->m__0joystick);
  this->m__0numHats=SDL_JoystickNumHats(this->m__0joystick);
  f0.l_buf=bbArray<bbByte>::create(64);
  SDL_JoystickGUID l_guid=SDL_JoystickGetGUID(this->m__0joystick);
  SDL_JoystickGetGUIDString(l_guid,((char*)(f0.l_buf->data())),f0.l_buf->length());
  f0.l_buf->at((f0.l_buf->length()-1))=bbByte(0);
  this->m__0guid=bbString::fromCString(((void*)(f0.l_buf->data())));
}

bbInt t_mojo_input_JoystickDevice::m_NumHats(){
  return this->m__0numHats;
}

bbInt t_mojo_input_JoystickDevice::m_NumButtons(){
  return this->m__0numButtons;
}

bbInt t_mojo_input_JoystickDevice::m_NumBalls(){
  return this->m__0numBalls;
}

bbInt t_mojo_input_JoystickDevice::m_NumAxes(){
  return this->m__0numAxes;
}

bbString t_mojo_input_JoystickDevice::m_Name(){
  return this->m__0name;
}

t_mojo_input_JoystickHat t_mojo_input_JoystickDevice::m_GetHat(bbInt l_hat){
  return ((t_mojo_input_JoystickHat)(SDL_JoystickGetHat(this->m__0joystick,l_hat)));
}

t_std_geom_Vec2_1i t_mojo_input_JoystickDevice::m_GetBall(bbInt l_ball){
  bbInt l_x{};
  bbInt l_y{};
  SDL_JoystickGetBall(this->m__0joystick,l_ball,&l_x,&l_y);
  return t_std_geom_Vec2_1i(l_x,l_y);
}

bbFloat t_mojo_input_JoystickDevice::m_GetAxis(bbInt l_axis){
  return (((bbFloat(SDL_JoystickGetAxis(this->m__0joystick,l_axis))+32768.0f)/32767.5f)-1.0f);
}

bbString t_mojo_input_JoystickDevice::m_GUID(){
  return this->m__0guid;
}

bbBool t_mojo_input_JoystickDevice::m_ButtonPressed(bbInt l_button){
  if(this->m_ButtonDown(l_button)){
    if(this->m__0hits->at(l_button)){
      return false;
    }
    this->m__0hits->at(l_button)=true;
    return true;
  }
  this->m__0hits->at(l_button)=false;
  return false;
}

bbBool t_mojo_input_JoystickDevice::m_ButtonDown(bbInt l_button){
  return bbBool(SDL_JoystickGetButton(this->m__0joystick,l_button));
}

void mx2_mojo_input_2joystick_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_input_JoystickDevice__0joysticks=bbArray<bbGCVar<t_mojo_input_JoystickDevice>>::create(8);
}

bbInit mx2_mojo_input_2joystick_init_v("mojo_input_2joystick",&mx2_mojo_input_2joystick_init);
