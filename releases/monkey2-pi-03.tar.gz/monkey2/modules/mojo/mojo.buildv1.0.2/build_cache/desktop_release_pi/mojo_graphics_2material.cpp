
#include "../../desktop_release_pi/mojo_graphics_2material.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_graphics_2shader.h"

// ***** Internal *****

void t_mojo_graphics_Material::init(){
  m__0params=bbGCNew<t_mojo_graphics_ParamBuffer>();
}

void t_mojo_graphics_Material::gcMark(){
  bbGCMark(m__0shader);
  bbGCMark(m__0params);
}

t_mojo_graphics_Material::t_mojo_graphics_Material(t_mojo_graphics_Shader* l_shader){
  init();
  this->m__0shader=l_shader;
}

t_mojo_graphics_Shader* t_mojo_graphics_Material::m_Shader(){
  return this->m__0shader;
}

void t_mojo_graphics_Material::m_SetVector(bbString l_name,t_std_geom_Vec4_1f l_value){
  this->m__0params->m_SetVector(l_name,l_value);
}

void t_mojo_graphics_Material::m_SetTexture(bbString l_name,t_mojo_graphics_Texture* l_value){
  this->m__0params->m_SetTexture(l_name,l_value);
}

void t_mojo_graphics_Material::m_SetMatrix(bbString l_name,t_std_geom_Mat4_1f l_value){
  this->m__0params->m_SetMatrix(l_name,l_value);
}

void t_mojo_graphics_Material::m_SetColor(bbString l_name,t_std_graphics_Color l_value){
  this->m__0params->m_SetColor(l_name,l_value);
}

t_mojo_graphics_ParamBuffer* t_mojo_graphics_Material::m_Params(){
  return this->m__0params;
}

void mx2_mojo_graphics_2material_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2material_init_v("mojo_graphics_2material",&mx2_mojo_graphics_2material_init);
