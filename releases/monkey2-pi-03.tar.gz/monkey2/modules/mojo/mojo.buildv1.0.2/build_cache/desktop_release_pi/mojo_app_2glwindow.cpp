
#include "../../desktop_release_pi/mojo_app_2glwindow.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_debug.h"
#include "../../../../sdl2/sdl2.buildv1.0.2/desktop_release_pi/sdl2_sdl2.h"

// ***** Internal *****

t_mojo_app_GLWindow::t_mojo_app_GLWindow(bbString l_title,t_std_geom_Rect_1i l_rect,t_mojo_app_WindowFlags l_flags):t_mojo_app_Window(l_title,l_rect,l_flags){
  this->m_Init();
}

t_mojo_app_GLWindow::t_mojo_app_GLWindow(bbString l_title,bbInt l_width,bbInt l_height,t_mojo_app_WindowFlags l_flags):t_mojo_app_Window(l_title,l_width,l_height,l_flags){
  this->m_Init();
}

t_mojo_app_GLWindow::t_mojo_app_GLWindow(){
  this->m_Init();
}

void t_mojo_app_GLWindow::m_OnRenderGL(){
}

void t_mojo_app_GLWindow::m_OnRender(t_mojo_graphics_Canvas* l_canvas){
  this->m_BeginGL();
  this->m_OnRenderGL();
  this->m_EndGL();
}

void t_mojo_app_GLWindow::m_Init(){
  this->m__0sdlGLContext=SDL_GL_CreateContext(this->m_SDLWindow());
  bbAssert(bbBool(this->m__0sdlGLContext),BB_T("FATAL ERROR: SDL_GL_CreateContext failed"));
}

void t_mojo_app_GLWindow::m_EndGL(){
  SDL_GL_MakeCurrent(t_mojo_app_Window::m_SDLWindow(),t_mojo_app_Window::m_SDLGLContext());
}

void t_mojo_app_GLWindow::m_BeginGL(){
  SDL_GL_MakeCurrent(this->m_SDLWindow(),this->m__0sdlGLContext);
}

void mx2_mojo_app_2glwindow_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_app_2glwindow_init_v("mojo_app_2glwindow",&mx2_mojo_app_2glwindow_init);
