
#include "../../desktop_release_pi/mojo_app_2view.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_app_2app.h"
#include "../../desktop_release_pi/mojo_app_2event.h"
#include "../../desktop_release_pi/mojo_app_2style.h"
#include "../../desktop_release_pi/mojo_app_2window.h"
#include "../../desktop_release_pi/mojo_graphics_2canvas.h"
#include "../../desktop_release_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_math.h"

extern bbFloat g_monkey_math_Min_1f(bbFloat l_x,bbFloat l_y);
extern t_std_geom_Rect_1i g_std_geom_TransformRecti_1f(t_std_geom_Rect_1i l_rect,t_std_geom_AffineMat3_1f l_matrix);
extern bbInt g_monkey_math_Max_1i(bbInt l_x,bbInt l_y);
extern bbInt g_monkey_math_Min_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

void t_mojo_app_View::init(){
  m__0children=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_View_2>();
  m__0gravity=t_std_geom_Vec2_1f(.5f,.5f);
  m__0offset=t_std_geom_Vec2_1i(bbInt(0),bbInt(0));
}

void t_mojo_app_View::gcMark(){
  bbGCMark(m__0parent);
  bbGCMark(m__0children);
  bbGCMark(m__0style);
  bbGCMark(m__0rstyle);
}

t_mojo_app_View::t_mojo_app_View(){
  init();
  this->m__0style=bbGCNew<t_mojo_app_Style>();
}

bbInt t_mojo_app_View::m_Width(){
  return this->m__0rect.m_Width();
}

void t_mojo_app_View::m_Visible(bbBool l_visible){
  if((l_visible==this->m__0visible)){
    return;
  }
  this->m__0visible=l_visible;
}

bbBool t_mojo_app_View::m_Visible(){
  return this->m__0visible;
}

void t_mojo_app_View::m_ValidateStyle(){
  if(!bbBool(t_mojo_app_View_Dirty((int(this->m__0dirty)&int(t_mojo_app_View_Dirty(1)))))){
    return;
  }
  this->m__0rstyle=this->m__0style;
  if(!this->m_ReallyEnabled()){
    this->m__0rstyle=this->m__0style->m_GetState(BB_T("disabled"));
  }else if(bbBool(this->m__0styleState)){
    this->m__0rstyle=this->m__0style->m_GetState(this->m__0styleState);
  }
  this->m__0styleBounds=this->m__0rstyle->m_Bounds();
  this->m__0dirty=t_mojo_app_View_Dirty((int(this->m__0dirty)&int(t_mojo_app_View_Dirty(~int(t_mojo_app_View_Dirty(1))))));
  this->m_OnValidateStyle();
}

void t_mojo_app_View::m_UpdateLayout(){
  this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m__0measuredSize);
  this->m__0bounds=this->m__0rect.m__add(this->m__0styleBounds);
  this->m__0matrix=t_std_geom_AffineMat3_1f(bbNullCtor);
  if(bbBool(this->m__0parent)){
    this->m__0matrix=this->m__0matrix.m_Translate(bbFloat(this->m__0frame.m_min.m_x),bbFloat(this->m__0frame.m_min.m_y));
  }
  this->m__0matrix=this->m__0matrix.m_Translate(bbFloat(this->m__0offset.m_x),bbFloat(this->m__0offset.m_y));
  if(this->m__0layout==BB_T("fill")||this->m__0layout==BB_T("resize")){
    this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m__0frame.m_Size().m__sub(this->m__0styleBounds.m_Size()));
    this->m__0bounds=this->m__0rect.m__add(this->m__0styleBounds);
  }else if(this->m__0layout==BB_T("fill-x")){
    this->m__0rect.m_max.m_x=(this->m__0frame.m_Width()-this->m__0styleBounds.m_Width());
    this->m__0bounds.m_min.m_x=(this->m__0rect.m_min.m_x+this->m__0styleBounds.m_min.m_x);
    this->m__0bounds.m_max.m_x=(this->m__0rect.m_max.m_x+this->m__0styleBounds.m_max.m_x);
    this->m__0matrix=this->m__0matrix.m_Translate(0.0f,(bbFloat((this->m__0frame.m_Height()-this->m__0bounds.m_Height()))*this->m__0gravity.m_y));
  }else if(this->m__0layout==BB_T("float")){
    this->m__0matrix=this->m__0matrix.m_Translate((bbFloat((this->m__0frame.m_Width()-this->m__0bounds.m_Width()))*this->m__0gravity.m_x),(bbFloat((this->m__0frame.m_Height()-this->m__0bounds.m_Height()))*this->m__0gravity.m_y));
    this->m__0matrix.m_t.m_x=bbFloat(std::round(bbDouble(this->m__0matrix.m_t.m_x)));
    this->m__0matrix.m_t.m_y=bbFloat(std::round(bbDouble(this->m__0matrix.m_t.m_y)));
  }else if(this->m__0layout==BB_T("stretch")){
    bbFloat l_sx=(bbFloat(this->m__0frame.m_Width())/bbFloat(this->m__0bounds.m_Width()));
    bbFloat l_sy=(bbFloat(this->m__0frame.m_Height())/bbFloat(this->m__0bounds.m_Height()));
    this->m__0matrix=this->m__0matrix.m_Scale(l_sx,l_sy);
  }else if(this->m__0layout==BB_T("stretch-int")){
    bbFloat l_sx=(bbFloat(this->m__0frame.m_Width())/bbFloat(this->m__0bounds.m_Width()));
    bbFloat l_sy=(bbFloat(this->m__0frame.m_Height())/bbFloat(this->m__0bounds.m_Height()));
    if((l_sx>1.0f)){
      l_sx=bbFloat(std::floor(bbDouble(l_sx)));
    }
    if((l_sy>1.0f)){
      l_sy=bbFloat(std::floor(bbDouble(l_sy)));
    }
    this->m__0matrix=this->m__0matrix.m_Scale(l_sx,l_sy);
  }else if(this->m__0layout==BB_T("scale")||this->m__0layout==BB_T("letterbox")){
    bbFloat l_sx=(bbFloat(this->m__0frame.m_Width())/bbFloat(this->m__0bounds.m_Width()));
    bbFloat l_sy=(bbFloat(this->m__0frame.m_Height())/bbFloat(this->m__0bounds.m_Height()));
    if((l_sx<l_sy)){
      this->m__0matrix=this->m__0matrix.m_Translate(0.0f,((bbFloat(this->m__0frame.m_Height())-(bbFloat(this->m__0bounds.m_Height())*l_sx))*this->m__0gravity.m_y));
      this->m__0matrix=this->m__0matrix.m_Scale(l_sx,l_sx);
    }else{
      this->m__0matrix=this->m__0matrix.m_Translate(((bbFloat(this->m__0frame.m_Width())-(bbFloat(this->m__0bounds.m_Width())*l_sy))*this->m__0gravity.m_x),0.0f);
      this->m__0matrix=this->m__0matrix.m_Scale(l_sy,l_sy);
    }
  }else if(this->m__0layout==BB_T("scale-int")||this->m__0layout==BB_T("letterbox-int")){
    bbFloat l_sx=(bbFloat(this->m__0frame.m_Width())/bbFloat(this->m__0bounds.m_Width()));
    bbFloat l_sy=(bbFloat(this->m__0frame.m_Height())/bbFloat(this->m__0bounds.m_Height()));
    if((l_sx>1.0f)){
      l_sx=bbFloat(std::floor(bbDouble(l_sx)));
    }
    if((l_sy>1.0f)){
      l_sy=bbFloat(std::floor(bbDouble(l_sy)));
    }
    bbFloat l_sc=g_monkey_math_Min_1f(l_sx,l_sy);
    this->m__0matrix=this->m__0matrix.m_Translate(((bbFloat(this->m__0frame.m_Width())-(bbFloat(this->m__0bounds.m_Width())*l_sc))*this->m__0gravity.m_x),((bbFloat(this->m__0frame.m_Height())-(bbFloat(this->m__0bounds.m_Height())*l_sc))*this->m__0gravity.m_y));
    this->m__0matrix=this->m__0matrix.m_Scale(l_sc,l_sc);
  }
  this->m__0matrix=this->m__0matrix.m_Translate(bbFloat(-this->m__0bounds.m_min.m_x),bbFloat(-this->m__0bounds.m_min.m_y));
  if(bbBool(this->m__0parent)){
    this->m__0rmatrix=this->m__0parent->m__0rmatrix.m__mul(this->m__0matrix);
  }else{
    this->m__0rmatrix=this->m__0matrix;
  }
  this->m__0rclip=g_std_geom_TransformRecti_1f(this->m__0rect,this->m__0rmatrix);
  this->m__0rbounds=g_std_geom_TransformRecti_1f(this->m__0bounds,this->m__0rmatrix);
  if(bbBool(this->m__0parent)){
    this->m__0rclip.m__andeq(this->m__0parent->m__0rclip);
    this->m__0rbounds.m__andeq(this->m__0parent->m__0rclip);
    this->m__0clip=g_std_geom_TransformRecti_1f(this->m__0rclip,this->m__0rmatrix.m__sub());
  }else{
    this->m__0clip=this->m__0rclip;
  }
  this->m_OnLayout();
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    f1.l_0=this->m__0children->m_All();
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      f2.l_view=f1.l_0.m_Current();
      f2.l_view->m_UpdateLayout();
    }
  }
}

t_std_geom_Vec2_1i t_mojo_app_View::m_TransformWindowPointToView(t_std_geom_Vec2_1i l_point){
  t_std_geom_Vec2_1f l_t=this->m__0rmatrix.m__sub().m__mul(t_std_geom_Vec2_1f(bbFloat(l_point.m_x),bbFloat(l_point.m_y)));
  return t_std_geom_Vec2_1i(bbInt(std::round(bbDouble(l_t.m_x))),bbInt(std::round(bbDouble(l_t.m_y))));
}

t_std_geom_Rect_1i t_mojo_app_View::m_TransformRectToView(t_std_geom_Rect_1i l_rect,t_mojo_app_View* l_view){
  return t_std_geom_Rect_1i(this->m_TransformPointToView(l_rect.m_min,l_view),this->m_TransformPointToView(l_rect.m_max,l_view));
}

t_std_geom_Rect_1i t_mojo_app_View::m_TransformRectFromView(t_std_geom_Rect_1i l_rect,t_mojo_app_View* l_view){
  return t_std_geom_Rect_1i(this->m_TransformPointFromView(l_rect.m_min,l_view),this->m_TransformPointFromView(l_rect.m_max,l_view));
}

t_std_geom_Vec2_1i t_mojo_app_View::m_TransformPointToView(t_std_geom_Vec2_1i l_point,t_mojo_app_View* l_view){
  t_std_geom_Vec2_1f l_t=this->m__0rmatrix.m__mul(t_std_geom_Vec2_1f(bbFloat(l_point.m_x),bbFloat(l_point.m_y)));
  if(bbBool(l_view)){
    l_t=l_view->m__0rmatrix.m__sub().m__mul(l_t);
  }
  return t_std_geom_Vec2_1i(bbInt(std::round(bbDouble(l_t.m_x))),bbInt(std::round(bbDouble(l_t.m_y))));
}

t_std_geom_Vec2_1i t_mojo_app_View::m_TransformPointFromView(t_std_geom_Vec2_1i l_point,t_mojo_app_View* l_view){
  t_std_geom_Vec2_1f l_t=t_std_geom_Vec2_1f(bbFloat(l_point.m_x),bbFloat(l_point.m_y));
  if(bbBool(l_view)){
    l_t=l_view->m__0matrix.m__mul(l_t);
  }
  l_t=this->m__0rmatrix.m__sub().m__mul(l_t);
  return t_std_geom_Vec2_1i(bbInt(std::round(bbDouble(l_t.m_x))),bbInt(std::round(bbDouble(l_t.m_y))));
}

void t_mojo_app_View::m_StyleState(bbString l_styleState){
  if((l_styleState==this->m__0styleState)){
    return;
  }
  this->m__0styleState=l_styleState;
  this->m_InvalidateStyle();
}

bbString t_mojo_app_View::m_StyleState(){
  return this->m__0styleState;
}

t_std_geom_Rect_1i t_mojo_app_View::m_StyleBounds(){
  return this->m__0styleBounds;
}

void t_mojo_app_View::m_Style(t_mojo_app_Style* l_style){
  if((l_style==this->m__0style)){
    return;
  }
  this->m__0style=l_style;
  this->m_InvalidateStyle();
}

t_mojo_app_Style* t_mojo_app_View::m_Style(){
  return this->m__0style;
}

void t_mojo_app_View::m_SendMouseEvent(t_mojo_app_MouseEvent* l_event){
  if(!this->m_ReallyEnabled()){
    t_mojo_app_EventType l_0=l_event->m_Type();
    if(l_0==t_mojo_app_EventType(5)||l_0==t_mojo_app_EventType(9)){
      this->m_OnMouseEvent(l_event);
    }
    return;
  }
  this->m_OnMouseEvent(l_event);
  if(l_event->m_Eaten()){
    return;
  }
  t_mojo_app_EventType l_1=l_event->m_Type();
  if(l_1==t_mojo_app_EventType(7)){
    struct f1_t : public bbGCFrame{
      t_mojo_app_View* l_view{};
      void gcMark(){
        bbGCMarkPtr(l_view);
      }
    }f1{};
    f1.l_view=this->m__0parent;
    while(bbBool(f1.l_view)){
      f1.l_view->m_OnMouseEvent(l_event);
      if(l_event->m_Eaten()){
        return;
      }
      f1.l_view=f1.l_view->m__0parent;
    }
  }
}

void t_mojo_app_View::m_SendKeyEvent(t_mojo_app_KeyEvent* l_event){
  if(!this->m_ReallyEnabled()){
    return;
  }
  this->m_OnKeyEvent(l_event);
}

t_mojo_app_Style* t_mojo_app_View::m_RenderStyle(){
  this->m_ValidateStyle();
  return this->m__0rstyle;
}

t_std_geom_Rect_1i t_mojo_app_View::m_RenderRect(){
  return this->m__0rclip;
}

t_std_geom_AffineMat3_1f t_mojo_app_View::m_RenderMatrix(){
  return this->m__0rmatrix;
}

t_std_geom_Rect_1i t_mojo_app_View::m_RenderBounds(){
  return this->m__0rbounds;
}

void t_mojo_app_View::m_Render(t_mojo_graphics_Canvas* l_canvas){
  if(!this->m__0visible){
    return;
  }
  l_canvas->m_BeginRender(this->m__0bounds,this->m__0matrix);
  this->m__0rstyle->m_Render(l_canvas,t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m__0bounds.m_Size()));
  l_canvas->m_Viewport(this->m__0rect);
  this->m_OnRender(l_canvas);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    f1.l_0=this->m__0children->m_All();
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      f2.l_view=f1.l_0.m_Current();
      f2.l_view->m_Render(l_canvas);
    }
  }
  l_canvas->m_EndRender();
}

void t_mojo_app_View::m_RemoveChild(t_mojo_app_View* l_view){
  if(!bbBool(l_view)){
    return;
  }
  bbAssert((l_view->m__0parent==this),BB_T("Assert failed"));
  this->m__0children->m_Remove(l_view,bbInt(0));
  l_view->m__0parent=((t_mojo_app_View*)0);
}

t_std_geom_Rect_1i t_mojo_app_View::m_Rect(){
  return this->m__0rect;
}

bbBool t_mojo_app_View::m_ReallyVisible(){
  return (this->m__0visible&&(!bbBool(this->m__0parent)||this->m__0parent->m_ReallyVisible()));
}

bbBool t_mojo_app_View::m_ReallyEnabled(){
  return ((this->m__0enabled&&this->m__0visible)&&(!bbBool(this->m__0parent)||this->m__0parent->m_ReallyEnabled()));
}

t_mojo_app_View* t_mojo_app_View::m_Parent(){
  return this->m__0parent;
}

void t_mojo_app_View::m_OnValidateStyle(){
}

void t_mojo_app_View::m_OnRenderBounds(t_mojo_graphics_Canvas* l_canvas){
}

void t_mojo_app_View::m_OnRender(t_mojo_graphics_Canvas* l_canvas){
}

void t_mojo_app_View::m_OnMouseEvent(t_mojo_app_MouseEvent* l_event){
}

t_std_geom_Vec2_1i t_mojo_app_View::m_OnMeasure2(t_std_geom_Vec2_1i l_size){
  return t_std_geom_Vec2_1i(bbInt(0),bbInt(0));
}

t_std_geom_Vec2_1i t_mojo_app_View::m_OnMeasure(){
  return t_std_geom_Vec2_1i(bbInt(0),bbInt(0));
}

void t_mojo_app_View::m_OnMakeKeyView(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_window{};
    void gcMark(){
      bbGCMarkPtr(l_window);
    }
  }f0{};
  f0.l_window=this->m_FindWindow();
  if(bbBool(f0.l_window)){
    f0.l_window->m_KeyView(this);
  }
}

void t_mojo_app_View::m_OnLayout(){
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    f1.l_0=this->m__0children->m_All();
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      f2.l_view=f1.l_0.m_Current();
      f2.l_view->m_Frame(this->m_Rect());
    }
  }
}

void t_mojo_app_View::m_OnKeyEvent(t_mojo_app_KeyEvent* l_event){
}

void t_mojo_app_View::m_Offset(t_std_geom_Vec2_1i l_offset){
  if((bbCompare(l_offset,this->m__0offset)==0)){
    return;
  }
  this->m__0offset=l_offset;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_Offset(){
  return this->m__0offset;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_MouseLocation(){
  return this->m_TransformPointFromView(g_mojo_app_App->m_MouseLocation(),((t_mojo_app_View*)0));
}

void t_mojo_app_View::m_MinSize(t_std_geom_Vec2_1i l_minSize){
  this->m__0minSize=l_minSize;
  this->m_InvalidateStyle();
}

t_std_geom_Vec2_1i t_mojo_app_View::m_MinSize(){
  return this->m__0minSize;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_MeasuredSize(){
  return this->m__0measuredSize;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_Measure2(t_std_geom_Vec2_1i l_size){
  l_size=this->m_OnMeasure2(l_size.m__sub(this->m__0styleBounds.m_Size()));
  if((bbBool(l_size.m_x)&&bbBool(l_size.m_y))){
    this->m__0layoutSize=l_size.m__add(this->m__0styleBounds.m_Size());
  }
  return this->m__0layoutSize;
}

void t_mojo_app_View::m_Measure(){
  if(!this->m__0visible){
    return;
  }
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    f1.l_0=this->m__0children->m_All();
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      f2.l_view=f1.l_0.m_Current();
      f2.l_view->m_Measure();
    }
  }
  this->m_ValidateStyle();
  t_std_geom_Vec2_1i l_size=this->m_OnMeasure();
  if(bbBool(this->m__0minSize.m_x)){
    l_size.m_x=g_monkey_math_Max_1i(l_size.m_x,this->m__0minSize.m_x);
  }
  if(bbBool(this->m__0minSize.m_y)){
    l_size.m_y=g_monkey_math_Max_1i(l_size.m_y,this->m__0minSize.m_y);
  }
  if(bbBool(this->m__0maxSize.m_x)){
    l_size.m_x=g_monkey_math_Min_1i(l_size.m_x,this->m__0maxSize.m_x);
  }
  if(bbBool(this->m__0maxSize.m_y)){
    l_size.m_y=g_monkey_math_Min_1i(l_size.m_y,this->m__0maxSize.m_y);
  }
  this->m__0measuredSize=l_size;
  this->m__0layoutSize=l_size.m__add(this->m__0styleBounds.m_Size());
}

void t_mojo_app_View::m_MaxSize(t_std_geom_Vec2_1i l_maxSize){
  this->m__0maxSize=l_maxSize;
  this->m_InvalidateStyle();
}

t_std_geom_Vec2_1i t_mojo_app_View::m_MaxSize(){
  return this->m__0maxSize;
}

void t_mojo_app_View::m_MakeKeyView(){
  if(!this->m_ReallyEnabled()){
    return;
  }
  this->m_OnMakeKeyView();
}

t_std_geom_AffineMat3_1f t_mojo_app_View::m_LocalMatrix(){
  return this->m__0matrix;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_LayoutSize(){
  return this->m__0layoutSize;
}

void t_mojo_app_View::m_Layout(bbString l_layout){
  if((l_layout==this->m__0layout)){
    return;
  }
  this->m__0layout=l_layout;
}

bbString t_mojo_app_View::m_Layout(){
  return this->m__0layout;
}

bbBool t_mojo_app_View::m_IsChildOf(t_mojo_app_View* l_view){
  if((l_view==this)){
    return true;
  }
  if(bbBool(this->m__0parent)){
    return this->m__0parent->m_IsChildOf(l_view);
  }
  return false;
}

void t_mojo_app_View::m_InvalidateStyle(){
  this->m__0dirty=t_mojo_app_View_Dirty((int(this->m__0dirty)|int(t_mojo_app_View_Dirty(1))));
}

bbInt t_mojo_app_View::m_Height(){
  return this->m__0rect.m_Height();
}

void t_mojo_app_View::m_Gravity(t_std_geom_Vec2_1f l_gravity){
  if((bbCompare(l_gravity,this->m__0gravity)==0)){
    return;
  }
  this->m__0gravity=l_gravity;
}

t_std_geom_Vec2_1f t_mojo_app_View::m_Gravity(){
  return this->m__0gravity;
}

void t_mojo_app_View::m_Frame(t_std_geom_Rect_1i l_frame){
  if((bbCompare(l_frame,this->m__0frame)==0)){
    return;
  }
  this->m__0frame=l_frame;
}

t_std_geom_Rect_1i t_mojo_app_View::m_Frame(){
  return this->m__0frame;
}

t_mojo_app_Window* t_mojo_app_View::m_FindWindow(){
  if(bbBool(this->m__0parent)){
    return this->m__0parent->m_FindWindow();
  }
  return ((t_mojo_app_Window*)0);
}

t_mojo_app_View* t_mojo_app_View::m_FindViewAtWindowPoint(t_std_geom_Vec2_1i l_point){
  if(!this->m__0visible){
    return ((t_mojo_app_View*)0);
  }
  if(!this->m__0rbounds.m_Contains(l_point)){
    return ((t_mojo_app_View*)0);
  }
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<this->m__0children->m_Length());l_i+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_child{};
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_child);
          bbGCMarkPtr(l_view);
        }
      }f2{};
      f2.l_child=this->m__0children->m__idx(((this->m__0children->m_Length()-l_i)-1));
      f2.l_view=f2.l_child->m_FindViewAtWindowPoint(l_point);
      if(bbBool(f2.l_view)){
        return f2.l_view;
      }
    }
  }
  return this;
}

void t_mojo_app_View::m_Enabled(bbBool l_enabled){
  if((l_enabled==this->m__0enabled)){
    return;
  }
  this->m__0enabled=l_enabled;
  this->m_InvalidateStyle();
}

bbBool t_mojo_app_View::m_Enabled(){
  return this->m__0enabled;
}

t_mojo_app_View* t_mojo_app_View::m_Container(){
  return this;
}

t_std_geom_Rect_1i t_mojo_app_View::m_ClipRect(){
  return this->m__0clip;
}

t_std_geom_Rect_1i t_mojo_app_View::m_Bounds(){
  return this->m__0bounds;
}

void t_mojo_app_View::m_AddChild(t_mojo_app_View* l_view){
  if(!bbBool(l_view)){
    return;
  }
  bbAssert(!bbBool(l_view->m__0parent),BB_T("Assert failed"));
  this->m__0children->m_Add(l_view);
  l_view->m__0parent=this;
}

void mx2_mojo_app_2view_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_app_2view_init_v("mojo_app_2view",&mx2_mojo_app_2view_init);
