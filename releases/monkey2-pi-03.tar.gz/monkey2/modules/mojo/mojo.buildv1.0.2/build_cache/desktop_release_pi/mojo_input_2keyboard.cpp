
#include "../../desktop_release_pi/mojo_input_2keyboard.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_types.h"

// ***** Internal *****

bbGCRootVar<t_mojo_input_KeyboardDevice> g_mojo_input_Keyboard;

bbInt g_mojo_input_KeyboardDevice__0EventFilter(void* l_userData,SDL_Event* l_event){
  if(!bbBool(l_event)){
    return bbInt(0);
  }
  return g_mojo_input_Keyboard->m_EventFilter(l_userData,l_event);
}

void t_mojo_input_KeyboardDevice::init(){
  m__0matrix=bbArray<bbBool>::create(512);
  m__0pressed=bbArray<bbBool>::create(512);
  m__0released=bbArray<bbBool>::create(512);
  m__0names=bbArray<bbString>::create(512);
  m__0raw2scan=bbArray<bbInt>::create(512);
  m__0scan2raw=bbArray<t_mojo_input_Key>::create(512);
  m__0key2scan=bbArray<bbInt>::create(512);
  m__0scan2key=bbArray<bbInt>::create(512);
}

void t_mojo_input_KeyboardDevice::gcMark(){
  t_mojo_input_InputDevice::gcMark();
  bbGCMark(m__0matrix);
  bbGCMark(m__0pressed);
  bbGCMark(m__0released);
  bbGCMark(m__0names);
  bbGCMark(m__0raw2scan);
  bbGCMark(m__0scan2raw);
  bbGCMark(m__0key2scan);
  bbGCMark(m__0scan2key);
}

t_mojo_input_KeyboardDevice::t_mojo_input_KeyboardDevice(){
  init();
}

t_mojo_input_Key t_mojo_input_KeyboardDevice::m_TranslateKey(t_mojo_input_Key l_key){
  if(bbBool(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(65536)))))){
    bbInt l_keyCode=SDL_GetKeyFromScancode(((SDL_Scancode)(this->m__0raw2scan->at(bbInt(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(~int(t_mojo_input_Key(65536)))))))))));
    return this->m_KeyCodeToKey(l_keyCode);
  }else{
    bbInt l_scanCode=this->m__0key2scan->at(bbInt(l_key));
    return this->m__0scan2raw->at(l_scanCode);
  }
}

t_mojo_input_Key t_mojo_input_KeyboardDevice::m_ScanCodeToRawKey(bbInt l_scanCode){
  return this->m__0scan2raw->at(l_scanCode);
}

bbInt t_mojo_input_KeyboardDevice::m_ScanCode(t_mojo_input_Key l_key){
  if(bbBool(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(65536)))))){
    return this->m__0raw2scan->at(bbInt(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(~int(t_mojo_input_Key(65536))))))));
  }
  return this->m__0key2scan->at(bbInt(l_key));
}

void t_mojo_input_KeyboardDevice::m_Reset(){
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<512);l_i+=1){
      this->m__0matrix->at(l_i)=false;
      this->m__0pressed->at(l_i)=true;
      this->m__0released->at(l_i)=true;
    }
  }
  this->m__0modifiers=t_mojo_input_Modifier(0);
}

t_mojo_input_Modifier t_mojo_input_KeyboardDevice::m_Modifiers(){
  return this->m__0modifiers;
}

bbBool t_mojo_input_KeyboardDevice::m_KeyReleased(t_mojo_input_Key l_key){
  bbInt l_scode=this->m_ScanCode(l_key);
  if(!this->m__0matrix->at(l_scode)){
    if(this->m__0released->at(l_scode)){
      return false;
    }
    this->m__0released->at(l_scode)=true;
    return true;
  }
  this->m__0released->at(l_scode)=false;
  return false;
}

bbBool t_mojo_input_KeyboardDevice::m_KeyPressed(t_mojo_input_Key l_key){
  bbInt l_scode=this->m_ScanCode(l_key);
  if(this->m__0matrix->at(l_scode)){
    if(this->m__0pressed->at(l_scode)){
      return false;
    }
    this->m__0pressed->at(l_scode)=true;
    return true;
  }
  this->m__0pressed->at(l_scode)=false;
  return false;
}

bbString t_mojo_input_KeyboardDevice::m_KeyName(t_mojo_input_Key l_key){
  if(bbBool(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(65536)))))){
    l_key=this->m_TranslateKey(l_key);
  }
  return this->m__0names->at(bbInt(l_key));
}

bbBool t_mojo_input_KeyboardDevice::m_KeyHit(t_mojo_input_Key l_key){
  return this->m_KeyPressed(l_key);
}

bbBool t_mojo_input_KeyboardDevice::m_KeyDown(t_mojo_input_Key l_key){
  bbInt l_scode=this->m_ScanCode(l_key);
  return this->m__0matrix->at(l_scode);
}

t_mojo_input_Key t_mojo_input_KeyboardDevice::m_KeyCodeToKey(bbInt l_keyCode){
  if(bbBool((l_keyCode&1073741824))){
    l_keyCode=((l_keyCode&~1073741824)+128);
  }
  return ((t_mojo_input_Key)(l_keyCode));
}

void t_mojo_input_KeyboardDevice::m_Init(){
  if(this->m__0init){
    return;
  }
  this->m__0init=true;
  bbKeyInfo* l_p=bbKeyInfos;
  while(bbBool(l_p[bbInt(0)].name)){
    bbString l_name=bbString::fromCString(l_p[bbInt(0)].name);
    bbInt l_scanCode=l_p[bbInt(0)].scanCode;
    bbInt l_keyCode=l_p[bbInt(0)].keyCode;
    t_mojo_input_Key l_key=this->m_KeyCodeToKey(l_keyCode);
    this->m__0names->at(bbInt(l_key))=l_name;
    this->m__0raw2scan->at(bbInt(l_key))=l_scanCode;
    this->m__0scan2raw->at(l_scanCode)=t_mojo_input_Key((int(l_key)|int(t_mojo_input_Key(65536))));
    this->m__0key2scan->at(bbInt(l_key))=bbInt(SDL_GetScancodeFromKey(l_keyCode));
    this->m__0scan2key->at(this->m__0key2scan->at(bbInt(l_key)))=l_scanCode;
    l_p=(l_p+1);
  }
  SDL_AddEventWatch(g_mojo_input_KeyboardDevice__0EventFilter,((void*)0));
  this->m_Reset();
}

bbInt t_mojo_input_KeyboardDevice::m_EventFilter(void* l_userData,SDL_Event* l_event){
  if(l_event[bbInt(0)].type==bbInt(SDL_KEYDOWN)){
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    this->m__0matrix->at(bbInt(l_kevent[bbInt(0)].keysym.scancode))=true;
    if(l_kevent[bbInt(0)].keysym.sym==1073742048){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(64))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742049){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(1))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742050){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(256))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742051){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(1024))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742052){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(128))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742053){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(2))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742054){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(512))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742055){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(2048))));
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_KEYUP)){
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    this->m__0matrix->at(bbInt(l_kevent[bbInt(0)].keysym.scancode))=false;
    if(l_kevent[bbInt(0)].keysym.sym==1073742048){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(64))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742049){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(1))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742050){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(256))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742051){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(1024))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742052){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(128))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742053){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(2))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742054){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(512))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742055){
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(2048))))));
    }
  }
  return 1;
}

void mx2_mojo_input_2keyboard_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_input_Keyboard=bbGCNew<t_mojo_input_KeyboardDevice>();
}

bbInit mx2_mojo_input_2keyboard_init_v("mojo_input_2keyboard",&mx2_mojo_input_2keyboard_init);
