
#include "../../desktop_release_pi/mojo_audio_2audio.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_std_collections_2stack.h"
#include "../../desktop_release_pi/mojo_std_fiber_2future.h"
#include "../../desktop_release_pi/mojo_timer_2timer.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_audio_2audiodata.h"

extern bbFloat g_monkey_math_Clamp_1f(bbFloat l_value,bbFloat l_min,bbFloat l_max);

// ***** Internal *****

bbGCRootVar<t_mojo_audio_AudioDevice> g_mojo_audio_Audio;

t_mojo_audio_Sound* g_mojo_audio_Sound_Load(bbString l_path){
  struct f0_t : public bbGCFrame{
    t_std_audio_AudioData* l_data{};
    t_mojo_audio_Sound* l_sound{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_sound);
    }
  }f0{};
  f0.l_data=g_std_audio_AudioData_Load(l_path);
  if(!bbBool(f0.l_data)){
    return ((t_mojo_audio_Sound*)0);
  }
  f0.l_sound=bbGCNew<t_mojo_audio_Sound>(f0.l_data);
  f0.l_data->m_Discard();
  return f0.l_sound;
}

bbInt g_mojo_audio_ALFormat(t_std_audio_AudioFormat l_format){
  bbInt l_alFormat{};
  if(l_format==t_std_audio_AudioFormat(1)){
    l_alFormat=AL_FORMAT_MONO8;
  }else if(l_format==t_std_audio_AudioFormat(2)){
    l_alFormat=AL_FORMAT_MONO16;
  }else if(l_format==t_std_audio_AudioFormat(3)){
    l_alFormat=AL_FORMAT_STEREO8;
  }else if(l_format==t_std_audio_AudioFormat(4)){
    l_alFormat=AL_FORMAT_STEREO16;
  }
  return l_alFormat;
}

void t_mojo_audio_AudioDevice::init(){
  m__0channels=bbGCNew<t_std_collections_Stack_1Tt_mojo_audio_Channel_2>();
}

void t_mojo_audio_AudioDevice::gcMark(){
  bbGCMark(m__0channels);
}

void t_mojo_audio_AudioDevice::m_Init(){
  bbString l_error{};
  this->m__0alcDevice=alcOpenDevice(((char*)0));
  if(bbBool(this->m__0alcDevice)){
    this->m__0alcContext=alcCreateContext(this->m__0alcDevice,((bbInt*)0));
    if(bbBool(this->m__0alcContext)){
      if(alcMakeContextCurrent(this->m__0alcContext)){
        return;
      }else{
        l_error=BB_T("Failed to make OpenAL current");
      }
    }else{
      l_error=BB_T("Failed to create OpenAL context");
    }
  }else{
    l_error=BB_T("Failed to create OpenAL device");
  }
}

void t_mojo_audio_AudioDevice::m_FlushTmpChannels(){
  bbInt l_put=bbInt(0);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    f1.l_0=this->m__0channels->m_All();
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_audio_Channel* l_chan{};
        void gcMark(){
          bbGCMarkPtr(l_chan);
        }
      }f2{};
      f2.l_chan=f1.l_0.m_Current();
      if(f2.l_chan->m_Playing()){
        this->m__0channels->m__idxeq(l_put,f2.l_chan);
        l_put+=1;
        continue;
      }
      f2.l_chan->m_Discard();
    }
  }
  this->m__0channels->m_Resize(l_put);
}

t_mojo_audio_Channel* t_mojo_audio_AudioDevice::m_AllocTmpChannel(){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_channel{};
    void gcMark(){
      bbGCMarkPtr(l_channel);
    }
  }f0{};
  this->m_FlushTmpChannels();
  f0.l_channel=bbGCNew<t_mojo_audio_Channel>();
  this->m__0channels->m_Push(f0.l_channel);
  return f0.l_channel;
}

t_mojo_audio_Sound::t_mojo_audio_Sound(t_std_audio_AudioData* l_data){
  alGenBuffers(1,&this->m__0alBuffer);
  alBufferData(this->m__0alBuffer,g_mojo_audio_ALFormat(l_data->m_Format()),((void*)(l_data->m_Data())),bbUInt(l_data->m_Size()),bbUInt(l_data->m_Hertz()));
}

t_mojo_audio_Channel* t_mojo_audio_Sound::m_Play(bbBool l_loop){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_channel{};
    void gcMark(){
      bbGCMarkPtr(l_channel);
    }
  }f0{};
  f0.l_channel=g_mojo_audio_Audio->m_AllocTmpChannel();
  f0.l_channel->m_Play(this,l_loop);
  return f0.l_channel;
}

void t_mojo_audio_Sound::m_Discard(){
  if(!bbBool(this->m__0alBuffer)){
    return;
  }
  alDeleteBuffers(1,&this->m__0alBuffer);
  this->m__0alBuffer=bbUInt(0);
}

void t_mojo_audio_Channel::gcMark(){
  bbGCMark(m__0tmpBuffers);
  bbGCMark(m__0freeBuffers);
  bbGCMark(m__0future);
  bbGCMark(m__0timer);
}

t_mojo_audio_Channel::t_mojo_audio_Channel(){
  g_mojo_audio_Audio->m_FlushTmpChannels();
  alGenSources(1,&this->m__0alSource);
}

void t_mojo_audio_Channel::m_WaitQueued(bbInt l_queued){
  while((this->m__0queued>l_queued)){
    this->m_FlushProcessed();
    if((this->m__0queued<=l_queued)){
      return;
    }
    this->m__0waiting=true;
    this->m__0future->m_Get();
  }
}

void t_mojo_audio_Channel::m_Volume(bbFloat l_volume){
  if(!bbBool(this->m__0alSource)){
    return;
  }
  this->m__0volume=g_monkey_math_Clamp_1f(l_volume,0.0f,1.0f);
  alSourcef(this->m__0alSource,AL_GAIN,this->m__0volume);
}

bbFloat t_mojo_audio_Channel::m_Volume(){
  if(!bbBool(this->m__0alSource)){
    return 0.0f;
  }
  return this->m__0volume;
}

void t_mojo_audio_Channel::m_Stop(){
  if(!bbBool(this->m__0alSource)){
    return;
  }
  alSourceStop(this->m__0alSource);
}

void t_mojo_audio_Channel::m_Rate(bbFloat l_rate){
  if(!bbBool(this->m__0alSource)){
    return;
  }
  this->m__0rate=l_rate;
  alSourcef(this->m__0alSource,AL_PITCH,this->m__0rate);
}

bbFloat t_mojo_audio_Channel::m_Rate(){
  if(!bbBool(this->m__0alSource)){
    return 0.0f;
  }
  return this->m__0rate;
}

void t_mojo_audio_Channel::m_Queue(t_std_audio_AudioData* l_data){
  bbUInt l_buf{};
  if(!bbBool(this->m__0tmpBuffers)){
    this->m__0tmpBuffers=bbGCNew<t_std_collections_Stack_1j>();
    this->m__0freeBuffers=bbGCNew<t_std_collections_Stack_1j>();
    this->m__0future=bbGCNew<t_std_fiber_Future_1i>();
    this->m__0waiting=false;
    this->m__0queued=bbInt(0);
    struct lambda0 : public bbFunction<void()>::Rep{
      t_mojo_audio_Channel* l_self;
      lambda0(t_mojo_audio_Channel* l_self):l_self(l_self){
      }
      void invoke(){
        l_self->m_FlushProcessed();
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m__0timer=bbGCNew<bbTimer>(20,bbFunction<void()>(new lambda0(this)));
  }
  if(this->m__0freeBuffers->m_Empty()){
    alGenBuffers(1,&l_buf);
    this->m__0tmpBuffers->m_Push(l_buf);
  }else{
    l_buf=this->m__0freeBuffers->m_Pop();
  }
  alBufferData(l_buf,g_mojo_audio_ALFormat(l_data->m_Format()),((void*)(l_data->m_Data())),bbUInt(l_data->m_Size()),bbUInt(l_data->m_Hertz()));
  alSourceQueueBuffers(this->m__0alSource,1,&l_buf);
  this->m__0queued+=1;
  bbInt l_state=this->m_ALState();
  if(((l_state==AL_INITIAL)||(l_state==AL_STOPPED))){
    alSourcePlay(this->m__0alSource);
  }
}

bbBool t_mojo_audio_Channel::m_Playing(){
  if(!bbBool(this->m__0alSource)){
    return false;
  }
  bbInt l_state=this->m_ALState();
  return ((l_state==AL_PLAYING)||(l_state==AL_PAUSED));
}

void t_mojo_audio_Channel::m_Play(t_mojo_audio_Sound* l_sound,bbBool l_loop){
  if(((!bbBool(this->m__0alSource)||!bbBool(l_sound))||!bbBool(l_sound->m__0alBuffer))){
    return;
  }
  alSourcei(this->m__0alSource,AL_LOOPING,(l_loop ? AL_TRUE : AL_FALSE));
  alSourcei(this->m__0alSource,AL_BUFFER,bbInt(l_sound->m__0alBuffer));
  alSourcePlay(this->m__0alSource);
}

void t_mojo_audio_Channel::m_Paused(bbBool l_paused){
  if(!this->m_Playing()){
    return;
  }
  if(l_paused){
    alSourcePause(this->m__0alSource);
  }else{
    alSourcePlay(this->m__0alSource);
  }
}

bbBool t_mojo_audio_Channel::m_Paused(){
  if(!bbBool(this->m__0alSource)){
    return false;
  }
  return (this->m_ALState()==AL_PAUSED);
}

void t_mojo_audio_Channel::m_Pan(bbFloat l_pan){
  if(!bbBool(this->m__0alSource)){
    return;
  }
  this->m__0pan=g_monkey_math_Clamp_1f(l_pan,-1.0f,1.0f);
  bbDouble l_x=std::sin(bbDouble(this->m__0pan));
  bbDouble l_z=-std::cos(bbDouble(this->m__0pan));
  alSource3f(this->m__0alSource,AL_POSITION,bbFloat(l_x),0.0f,bbFloat(l_z));
}

bbFloat t_mojo_audio_Channel::m_Pan(){
  if(!bbBool(this->m__0alSource)){
    return 0.0f;
  }
  return this->m__0pan;
}

bbInt t_mojo_audio_Channel::m_FlushProcessed(){
  bbInt l_proc{};
  alGetSourcei(this->m__0alSource,AL_BUFFERS_PROCESSED,&l_proc);
  if(!bbBool(l_proc)){
    return bbInt(0);
  }
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<l_proc);l_i+=1){
      bbUInt l_buf{};
      alSourceUnqueueBuffers(this->m__0alSource,1,&l_buf);
      this->m__0queued-=1;
      if(this->m__0tmpBuffers->m_Contains(l_buf)){
        this->m__0freeBuffers->m_Push(l_buf);
      }
    }
  }
  if(this->m__0waiting){
    this->m__0waiting=false;
    this->m__0future->m_Set(l_proc);
  }
  return l_proc;
}

void t_mojo_audio_Channel::m_Discard(){
  if(!bbBool(this->m__0alSource)){
    return;
  }
  alDeleteSources(1,&this->m__0alSource);
  this->m__0alSource=bbUInt(0);
}

bbInt t_mojo_audio_Channel::m_ALState(){
  bbInt l_state{};
  alGetSourcei(this->m__0alSource,AL_SOURCE_STATE,&l_state);
  return l_state;
}

void mx2_mojo_audio_2audio_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_audio_Audio=bbGCNew<t_mojo_audio_AudioDevice>();
}

bbInit mx2_mojo_audio_2audio_init_v("mojo_audio_2audio",&mx2_mojo_audio_2audio_init);
