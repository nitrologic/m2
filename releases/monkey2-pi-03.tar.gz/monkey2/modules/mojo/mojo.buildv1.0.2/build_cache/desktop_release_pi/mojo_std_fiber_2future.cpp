
#include "../../desktop_release_pi/mojo_std_fiber_2future.h"

// ***** External *****

// ***** Internal *****

t_std_fiber_Future_1i::t_std_fiber_Future_1i(){
  this->m__0fiber=g_std_fiber_Fiber_Current();
}

void t_std_fiber_Future_1i::m_Set(bbInt l_value){
  this->m__0value=l_value;
  this->m__0fiber.m_Resume();
}

bbInt t_std_fiber_Future_1i::m_Get(){
  g_std_fiber_Fiber_Suspend();
  return this->m__0value;
}

void mx2_mojo_std_fiber_2future_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_fiber_2future_init_v("mojo_std_fiber_2future",&mx2_mojo_std_fiber_2future_init);
