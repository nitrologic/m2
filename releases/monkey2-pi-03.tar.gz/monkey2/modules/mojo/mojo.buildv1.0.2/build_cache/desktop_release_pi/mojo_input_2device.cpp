
#include "../../desktop_release_pi/mojo_input_2device.h"

// ***** External *****

// ***** Internal *****

void mx2_mojo_input_2device_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_input_2device_init_v("mojo_input_2device",&mx2_mojo_input_2device_init);
