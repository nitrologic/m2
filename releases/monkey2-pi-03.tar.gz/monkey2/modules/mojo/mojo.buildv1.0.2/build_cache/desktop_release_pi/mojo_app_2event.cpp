
#include "../../desktop_release_pi/mojo_app_2event.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_app_2view.h"
#include "../../desktop_release_pi/mojo_app_2window.h"

// ***** Internal *****

void t_mojo_app_Event::gcMark(){
  bbGCMark(m__0view);
}

t_mojo_app_Event::t_mojo_app_Event(t_mojo_app_EventType l_type,t_mojo_app_View* l_view){
  this->m__0type=l_type;
  this->m__0view=l_view;
}

t_mojo_app_View* t_mojo_app_Event::m_View(){
  return this->m__0view;
}

t_mojo_app_EventType t_mojo_app_Event::m_Type(){
  return this->m__0type;
}

bbBool t_mojo_app_Event::m_Eaten(){
  return (t_mojo_app_EventType((int(this->m__0type)&int(t_mojo_app_EventType(2147483647))))==t_mojo_app_EventType(2147483647));
}

void t_mojo_app_Event::m_Eat(){
  this->m__0type=t_mojo_app_EventType((int(this->m__0type)|int(t_mojo_app_EventType(2147483647))));
}

t_mojo_app_KeyEvent::t_mojo_app_KeyEvent(t_mojo_app_EventType l_type,t_mojo_app_View* l_view,t_mojo_input_Key l_key,t_mojo_input_Key l_rawKey,t_mojo_input_Modifier l_modifiers,bbString l_text):t_mojo_app_Event(l_type,l_view){
  this->m__0key=l_key;
  this->m__0rawKey=l_rawKey;
  this->m__0modifiers=l_modifiers;
  this->m__0text=l_text;
}

bbString t_mojo_app_KeyEvent::m_Text(){
  return this->m__0text;
}

t_mojo_input_Key t_mojo_app_KeyEvent::m_RawKey(){
  return this->m__0rawKey;
}

t_mojo_input_Modifier t_mojo_app_KeyEvent::m_Modifiers(){
  return this->m__0modifiers;
}

t_mojo_input_Key t_mojo_app_KeyEvent::m_Key(){
  return this->m__0key;
}

t_mojo_app_MouseEvent::t_mojo_app_MouseEvent(t_mojo_app_EventType l_type,t_mojo_app_View* l_view,t_std_geom_Vec2_1i l_location,t_mojo_input_MouseButton l_button,t_std_geom_Vec2_1i l_wheel,t_mojo_input_Modifier l_modifiers):t_mojo_app_Event(l_type,l_view){
  this->m__0location=l_location;
  this->m__0button=l_button;
  this->m__0wheel=l_wheel;
  this->m__0modifiers=l_modifiers;
}

t_std_geom_Vec2_1i t_mojo_app_MouseEvent::m_Wheel(){
  return this->m__0wheel;
}

t_mojo_input_Modifier t_mojo_app_MouseEvent::m_Modifiers(){
  return this->m__0modifiers;
}

t_std_geom_Vec2_1i t_mojo_app_MouseEvent::m_Location(){
  return this->m__0location;
}

t_mojo_input_MouseButton t_mojo_app_MouseEvent::m_Button(){
  return this->m__0button;
}

void t_mojo_app_WindowEvent::gcMark(){
  t_mojo_app_Event::gcMark();
  bbGCMark(m__0window);
}

t_mojo_app_WindowEvent::t_mojo_app_WindowEvent(t_mojo_app_EventType l_type,t_mojo_app_Window* l_window):t_mojo_app_Event(l_type,((t_mojo_app_View*)(l_window))){
  this->m__0window=l_window;
}

t_mojo_app_Window* t_mojo_app_WindowEvent::m_Window(){
  return this->m__0window;
}

void mx2_mojo_app_2event_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_app_2event_init_v("mojo_app_2event",&mx2_mojo_app_2event_init);
