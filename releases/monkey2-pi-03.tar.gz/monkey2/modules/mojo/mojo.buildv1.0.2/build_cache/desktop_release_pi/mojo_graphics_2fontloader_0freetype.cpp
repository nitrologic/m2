
#include "../../desktop_release_pi/mojo_graphics_2fontloader_0freetype.h"

// ***** External *****

#include "../../desktop_release_pi/mojo_graphics_2font.h"
#include "../../desktop_release_pi/mojo_graphics_2image.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_geom_2rect.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_geom_2vec2.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_graphics_2color.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_graphics_2pixmap.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_memory_2databuffer.h"

extern bbInt g_monkey_math_Max_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

FT_LibraryRec_* g_mojo_graphics_fontloader_FreeType;

t_mojo_graphics_Font* g_mojo_graphics_fontloader_LoadFont(bbString l_path,bbFloat l_fheight,t_mojo_graphics_TextureFlags l_textureFlags,t_mojo_graphics_Shader* l_shader){
  struct f0_t : public bbGCFrame{
    t_std_memory_DataBuffer* l_data{};
    t_mojo_graphics_Font* l_font{};
    bbArray<t_mojo_graphics_Glyph>* l_glyphs{};
    t_mojo_graphics_Image* l_image{};
    t_std_graphics_Pixmap* l_pixmap{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_font);
      bbGCMarkPtr(l_glyphs);
      bbGCMarkPtr(l_image);
      bbGCMarkPtr(l_pixmap);
    }
  }f0{};
  if((!bbBool(g_mojo_graphics_fontloader_FreeType)&&bbBool(FT_Init_FreeType(&g_mojo_graphics_fontloader_FreeType)))){
    return ((t_mojo_graphics_Font*)0);
  }
  f0.l_data=g_std_memory_DataBuffer_Load(l_path);
  if(!bbBool(f0.l_data)){
    return ((t_mojo_graphics_Font*)0);
  }
  FT_FaceRec_* l_face{};
  if(bbBool(FT_New_Memory_Face(g_mojo_graphics_fontloader_FreeType,f0.l_data->m_Data(),f0.l_data->m_Length(),bbInt(0),&l_face))){
    f0.l_data->m_Discard();
    return ((t_mojo_graphics_Font*)0);
  }
  FT_Size_RequestRec_ l_size_0req{};
  l_size_0req.type=FT_SIZE_REQUEST_TYPE_REAL_DIM;
  l_size_0req.width=bbInt(0);
  l_size_0req.height=bbInt((l_fheight*64.0f));
  l_size_0req.horiResolution=bbUInt(0);
  l_size_0req.vertResolution=bbUInt(0);
  if(bbBool(FT_Request_Size(l_face,&l_size_0req))){
    f0.l_data->m_Discard();
    return ((t_mojo_graphics_Font*)0);
  }
  bbInt l_height=((l_face[bbInt(0)].size[bbInt(0)].metrics.height+32)>>6);
  bbInt l_ascent=((l_face[bbInt(0)].size[bbInt(0)].metrics.ascender+32)>>6);
  bbInt l_firstChar=32;
  bbInt l_numChars=96;
  f0.l_glyphs=bbArray<t_mojo_graphics_Glyph>::create(l_numChars);
  f0.l_pixmap=bbGCNew<t_std_graphics_Pixmap>(512,512,t_std_graphics_PixelFormat(2));
  f0.l_pixmap->m_Clear(g_std_graphics_Color_None);
  FT_GlyphSlotRec_* l_slot=l_face[bbInt(0)].glyph;
  bbInt l_x=bbInt(0);
  bbInt l_y=bbInt(0);
  bbInt l_h=bbInt(0);
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<l_numChars);l_i+=1){
      struct f2_t : public bbGCFrame{
        t_std_graphics_Pixmap* l_tmp{};
        void gcMark(){
          bbGCMarkPtr(l_tmp);
        }
      }f2{};
      if(bbBool(FT_Load_Char(l_face,bbULong((l_firstChar+l_i)),(FT_LOAD_RENDER|FT_LOAD_FORCE_AUTOHINT)))){
        continue;
      }
      bbUInt l_gw=l_slot[bbInt(0)].bitmap.width;
      bbUInt l_gh=l_slot[bbInt(0)].bitmap.rows;
      if((((bbUInt(l_x)+l_gw)+1)>bbUInt(f0.l_pixmap->m_Width()))){
        l_y+=l_h;
        l_h=bbInt(0);
        l_x=bbInt(0);
      }
      f2.l_tmp=bbGCNew<t_std_graphics_Pixmap>(bbInt(l_gw),bbInt(l_gh),t_std_graphics_PixelFormat(2),l_slot[bbInt(0)].bitmap.buffer,l_slot[bbInt(0)].bitmap.pitch);
      f0.l_pixmap->m_Paste(f2.l_tmp,l_x,l_y);
      f0.l_glyphs->at(l_i)=t_mojo_graphics_Glyph(t_std_geom_Rect_1i(l_x,l_y,bbInt((bbUInt(l_x)+l_gw)),bbInt((bbUInt(l_y)+l_gh))),t_std_geom_Vec2_1f(bbFloat(l_slot[bbInt(0)].bitmap_left),bbFloat((l_ascent-l_slot[bbInt(0)].bitmap_top))),bbFloat((l_slot[bbInt(0)].advance.x>>6)));
      l_h=g_monkey_math_Max_1i(l_h,(bbInt(l_gh)+1));
      l_x+=bbInt((l_gw+1));
    }
  }
  FT_Done_Face(l_face);
  f0.l_data->m_Discard();
  f0.l_image=bbGCNew<t_mojo_graphics_Image>(f0.l_pixmap,l_textureFlags,l_shader);
  f0.l_font=bbGCNew<t_mojo_graphics_Font>(f0.l_image,bbFloat(l_height),l_firstChar,f0.l_glyphs);
  return f0.l_font;
}

void mx2_mojo_graphics_2fontloader_0freetype_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2fontloader_0freetype_init_v("mojo_graphics_2fontloader_0freetype",&mx2_mojo_graphics_2fontloader_0freetype_init);
