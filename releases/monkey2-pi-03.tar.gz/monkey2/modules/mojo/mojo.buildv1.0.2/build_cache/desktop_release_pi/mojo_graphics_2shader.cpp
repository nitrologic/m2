
#include "../../desktop_release_pi/mojo_graphics_2shader.h"

// ***** External *****

#include "../../../../gles20/gles20.buildv1.0.2/desktop_release_pi/gles20_gles20.h"
#include "../../desktop_release_pi/mojo_graphics_2texture.h"
#include "../../desktop_release_pi/mojo_std_collections_2map.h"
#include "../../desktop_release_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_debug.h"

extern bbInt g_mojo_graphics_glutil_glGraphicsSeq;

extern bbString g_std_stringio_LoadString(bbString l_path);
extern bbInt g_mojo_graphics_glutil_glCompile(bbInt l_type,bbString l_source);
extern void g_mojo_graphics_glutil_glLink(bbInt l_program);

// ***** Internal *****

bbGCRootVar<t_std_collections_Map_1si> g_mojo_graphics_ShaderParam__0ids;
bbInt g_mojo_graphics_ShaderParam__0nextId;
bbInt g_mojo_graphics_ShaderEnv__0nextId;
bbGCRootVar<t_mojo_graphics_ShaderProgram> g_mojo_graphics_Shader__0bound;
bbInt g_mojo_graphics_Shader__0seq;
bbGCRootVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2> g_mojo_graphics_Shader__0shaders;

t_mojo_graphics_Shader* g_mojo_graphics_Shader_GetShader(bbString l_name){
  if(!bbBool(g_mojo_graphics_Shader__0shaders)){
    struct f1_t : public bbGCFrame{
      t_mojo_graphics_Shader* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    g_mojo_graphics_Shader__0shaders=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2>();
    g_mojo_graphics_Shader__0shaders->m__idxeq(BB_T("sprite"),f1.t0=bbGCNew<t_mojo_graphics_Shader>(g_std_stringio_LoadString(BB_T("asset::mojo/shader_sprite.glsl"))));
    g_mojo_graphics_Shader__0shaders->m__idxeq(BB_T("phong"),f1.t0=bbGCNew<t_mojo_graphics_Shader>(g_std_stringio_LoadString(BB_T("asset::mojo/shader_phong.glsl"))));
    g_mojo_graphics_Shader__0shaders->m__idxeq(BB_T("font"),f1.t0=bbGCNew<t_mojo_graphics_Shader>(g_std_stringio_LoadString(BB_T("asset::mojo/shader_font.glsl"))));
    g_mojo_graphics_Shader__0shaders->m__idxeq(BB_T("null"),f1.t0=bbGCNew<t_mojo_graphics_Shader>(g_std_stringio_LoadString(BB_T("asset::mojo/shader_null.glsl"))));
  }
  return g_mojo_graphics_Shader__0shaders->m__idx(l_name);
}

bbInt g_mojo_graphics_ShaderParam_ParamId(bbString l_name){
  bbInt l_id=g_mojo_graphics_ShaderParam__0ids->m__idx(l_name);
  if(bbBool(l_id)){
    return l_id;
  }
  g_mojo_graphics_ShaderParam__0nextId+=1;
  g_mojo_graphics_ShaderParam__0ids->m__idxeq(l_name,g_mojo_graphics_ShaderParam__0nextId);
  return g_mojo_graphics_ShaderParam__0nextId;
}

void g_mojo_graphics_BindUniforms(bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_uniforms,t_mojo_graphics_ParamBuffer* l_params,bbBool l_filter){
  {
    bbInt l_0=bbInt(0);
    bbInt l_1=l_uniforms->length();
    for(;(l_0<l_1);l_0+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_ShaderParam l_p{};
        t_mojo_graphics_Uniform* l_u{};
        void gcMark(){
          bbGCMark(l_p);
          bbGCMarkPtr(l_u);
        }
      }f2{};
      f2.l_u=l_uniforms->at(l_0);
      f2.l_p=l_params->m__0params->at(f2.l_u->m_id);
      if(f2.l_u->m_type==GL_FLOAT){
        glUniform1f(f2.l_u->m_location,f2.l_p.m_scalar);
      }else if(f2.l_u->m_type==GL_FLOAT_VEC4){
        glUniform4fv(f2.l_u->m_location,1,&f2.l_p.m_vector.m_x);
      }else if(f2.l_u->m_type==GL_FLOAT_MAT4){
        glUniformMatrix4fv(f2.l_u->m_location,1,false,&f2.l_p.m_matrix.m_i.m_x);
      }else if(f2.l_u->m_type==GL_SAMPLER_2D){
        struct f3_t : public bbGCFrame{
          t_mojo_graphics_Texture* l_tex{};
          void gcMark(){
            bbGCMarkPtr(l_tex);
          }
        }f3{};
        f3.l_tex=f2.l_p.m_texture;
        bbDebugAssert(bbBool(f3.l_tex),((BB_T("Can't bind shader texture uniform '")+f2.l_u->m_name)+BB_T("' - no texture!")));
        glActiveTexture((GL_TEXTURE0+f2.l_u->m_texunit));
        glBindTexture(GL_TEXTURE_2D,f3.l_tex->m_GLTexture());
        if((bbBool(t_mojo_graphics_TextureFlags((int(f3.l_tex->m_Flags())&int(t_mojo_graphics_TextureFlags(1)))))&&l_filter)){
          glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        }else{
          glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
        }
        glUniform1i(f2.l_u->m_location,f2.l_u->m_texunit);
      }else{
        bbAssert(false,(BB_T("Unsupported uniform type for param:")+f2.l_u->m_name));
      }
    }
  }
  glActiveTexture(GL_TEXTURE0);
}

t_mojo_graphics_Uniform::t_mojo_graphics_Uniform(bbString l_name,bbInt l_location,bbInt l_texunit,bbInt l_size,bbInt l_type){
  this->m_name=l_name;
  this->m_id=g_mojo_graphics_ShaderParam_ParamId(this->m_name);
  this->m_texunit=l_texunit;
  this->m_location=l_location;
  this->m_size=l_size;
  this->m_type=l_type;
}

void t_mojo_graphics_ParamBuffer::init(){
  m__0params=bbArray<t_mojo_graphics_ShaderParam>::create(32);
}

void t_mojo_graphics_ParamBuffer::gcMark(){
  bbGCMark(m__0params);
}

void t_mojo_graphics_ParamBuffer::m_SetVector(bbString l_name,t_std_geom_Vec4_1f l_value){
  this->m__0params->at(g_mojo_graphics_ShaderParam_ParamId(l_name)).m_vector=l_value;
}

void t_mojo_graphics_ParamBuffer::m_SetTexture(bbString l_name,t_mojo_graphics_Texture* l_value){
  this->m__0params->at(g_mojo_graphics_ShaderParam_ParamId(l_name)).m_texture=l_value;
}

void t_mojo_graphics_ParamBuffer::m_SetMatrix(bbString l_name,t_std_geom_Mat4_1f l_value){
  this->m__0params->at(g_mojo_graphics_ShaderParam_ParamId(l_name)).m_matrix=l_value;
}

void t_mojo_graphics_ParamBuffer::m_SetColor(bbString l_name,t_std_graphics_Color l_value){
  this->m__0params->at(g_mojo_graphics_ShaderParam_ParamId(l_name)).m_vector=t_std_geom_Vec4_1f(l_value.m_r,l_value.m_g,l_value.m_b,l_value.m_a);
}

void t_mojo_graphics_ShaderProgram::gcMark(){
  bbGCMark(m__0sources);
  bbGCMark(m__0envUniforms);
  bbGCMark(m__0uniforms);
}

t_mojo_graphics_ShaderProgram::t_mojo_graphics_ShaderProgram(bbArray<bbString>* l_sources){
  this->m__0sources=l_sources;
}

bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t_mojo_graphics_ShaderProgram::m_Uniforms(){
  return this->m__0uniforms;
}

bbArray<bbString>* t_mojo_graphics_ShaderProgram::m_Sources(){
  return this->m__0sources;
}

bbUInt t_mojo_graphics_ShaderProgram::m_GLProgram(){
  if((this->m__0seq==g_mojo_graphics_glutil_glGraphicsSeq)){
    return this->m__0glProgram;
  }
  this->m_BuildProgram();
  this->m_EnumUniforms();
  this->m__0seq=g_mojo_graphics_glutil_glGraphicsSeq;
  return this->m__0glProgram;
}

bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t_mojo_graphics_ShaderProgram::m_EnvUniforms(){
  return this->m__0envUniforms;
}

void t_mojo_graphics_ShaderProgram::m_EnumUniforms(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_envUniforms{};
    bbArray<bbByte>* l_nameBuf{};
    t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_uniforms{};
    void gcMark(){
      bbGCMarkPtr(l_envUniforms);
      bbGCMarkPtr(l_nameBuf);
      bbGCMarkPtr(l_uniforms);
    }
  }f0{};
  f0.l_envUniforms=bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2>();
  f0.l_uniforms=bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2>();
  bbInt l_n{};
  glGetProgramiv(this->m__0glProgram,GL_ACTIVE_UNIFORMS,&l_n);
  bbInt l_size{};
  bbUInt l_type{};
  bbInt l_length{};
  f0.l_nameBuf=bbArray<bbByte>::create(256);
  bbInt l_texunit=bbInt(0);
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<l_n);l_i+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_Uniform* l_u{};
        void gcMark(){
          bbGCMarkPtr(l_u);
        }
      }f2{};
      glGetActiveUniform(this->m__0glProgram,bbUInt(l_i),f0.l_nameBuf->length(),&l_length,&l_size,&l_type,((char*)(&f0.l_nameBuf->at(bbInt(0)))));
      bbString l_name=bbString::fromCString(((void*)(f0.l_nameBuf->data())));
      bbInt l_location=glGetUniformLocation(this->m__0glProgram,bbCString(l_name));
      if((l_location==-1)){
        continue;
      }
      f2.l_u=bbGCNew<t_mojo_graphics_Uniform>(l_name,l_location,l_texunit,l_size,bbInt(l_type));
      if(l_name.startsWith(BB_T("mx2_"))){
        f0.l_envUniforms->m_Push(f2.l_u);
      }else{
        f0.l_uniforms->m_Push(f2.l_u);
      }
      if(l_type==bbUInt(GL_SAMPLER_2D)){
        l_texunit+=1;
      }
    }
  }
  this->m__0envUniforms=f0.l_envUniforms->m_ToArray();
  this->m__0uniforms=f0.l_uniforms->m_ToArray();
}

void t_mojo_graphics_ShaderProgram::m_BuildProgram(){
  bbString l_csource=bbString{};
  bbString l_vsource=bbString{};
  bbString l_fsource=bbString{};
  {
    bbInt l_0=bbInt(0);
    bbInt l_1=this->m__0sources->length();
    for(;(l_0<l_1);l_0+=1){
      bbString l_source=this->m__0sources->at(l_0);
      bbInt l_i0=l_source.find(BB_T("//@vertex"),bbInt(0));
      if((l_i0==-1)){
        puts((BB_T("Shader source:\n")+l_source).c_str());fflush( stdout );
        bbAssert(false,BB_T("Can't find //@vertex chunk"));
      }
      bbInt l_i1=l_source.find(BB_T("//@fragment"),bbInt(0));
      if((l_i1==-1)){
        puts((BB_T("Shader source:\n")+l_source).c_str());fflush( stdout );
        bbAssert(false,BB_T("Can't find //@fragment chunk"));
      }
      l_csource+=(l_source.slice(bbInt(0),l_i0)+BB_T("\n"));
      l_vsource+=(l_source.slice(l_i0,l_i1)+BB_T("\n"));
      l_fsource+=(l_source.slice(l_i1)+BB_T("\n"));
    }
  }
  l_vsource=(l_csource+l_vsource);
  l_fsource=(l_csource+l_fsource);
  bbInt l_vshader=g_mojo_graphics_glutil_glCompile(GL_VERTEX_SHADER,l_vsource);
  bbInt l_fshader=g_mojo_graphics_glutil_glCompile(GL_FRAGMENT_SHADER,l_fsource);
  this->m__0glProgram=glCreateProgram();
  glAttachShader(this->m__0glProgram,bbUInt(l_vshader));
  glAttachShader(this->m__0glProgram,bbUInt(l_fshader));
  glDeleteShader(bbUInt(l_vshader));
  glDeleteShader(bbUInt(l_fshader));
  glBindAttribLocation(this->m__0glProgram,bbUInt(0),bbCString(BB_T("mx2_VertexPosition")));
  glBindAttribLocation(this->m__0glProgram,1,bbCString(BB_T("mx2_VertexTexCoord0")));
  glBindAttribLocation(this->m__0glProgram,2,bbCString(BB_T("mx2_VertexTangent")));
  glBindAttribLocation(this->m__0glProgram,3,bbCString(BB_T("mx2_VertexColor")));
  g_mojo_graphics_glutil_glLink(bbInt(this->m__0glProgram));
}

int bbCompare(const t_mojo_graphics_ShaderParam&x,const t_mojo_graphics_ShaderParam&y){
  if(int t=bbCompare(x.m_scalar,y.m_scalar)) return t;
  if(int t=bbCompare(x.m_vector,y.m_vector)) return t;
  if(int t=bbCompare(x.m_matrix,y.m_matrix)) return t;
  if(int t=bbCompare(x.m_texture,y.m_texture)) return t;
  return 0;
}

void bbGCMark(const t_mojo_graphics_ShaderParam&t){
  bbGCMark(t.m_texture);
}

t_mojo_graphics_ShaderEnv::t_mojo_graphics_ShaderEnv(bbString l_sourceCode){
  this->m__0source=l_sourceCode;
  this->m__0id=g_mojo_graphics_ShaderEnv__0nextId;
  g_mojo_graphics_ShaderEnv__0nextId+=1;
}

bbString t_mojo_graphics_ShaderEnv::m_SourceCode(){
  return this->m__0source;
}

bbInt t_mojo_graphics_ShaderEnv::m_Id(){
  return this->m__0id;
}

void t_mojo_graphics_Shader::init(){
  m__0programs=bbArray<bbGCVar<t_mojo_graphics_ShaderProgram>>::create(16);
}

void t_mojo_graphics_Shader::gcMark(){
  bbGCMark(m__0programs);
}

t_mojo_graphics_Shader::t_mojo_graphics_Shader(bbString l_sourceCode){
  init();
  this->m__0source=l_sourceCode;
}

bbString t_mojo_graphics_Shader::m_SourceCode(){
  return this->m__0source;
}

void t_mojo_graphics_Shader::m_BindParams(t_mojo_graphics_ParamBuffer* l_params,bbBool l_filter){
  g_mojo_graphics_BindUniforms(g_mojo_graphics_Shader__0bound->m__0uniforms,l_params,l_filter);
}

void t_mojo_graphics_Shader::m_BindEnvParams(t_mojo_graphics_ParamBuffer* l_params){
  g_mojo_graphics_BindUniforms(g_mojo_graphics_Shader__0bound->m__0envUniforms,l_params,true);
}

void t_mojo_graphics_Shader::m_Bind(t_mojo_graphics_ShaderEnv* l_env){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_ShaderProgram* l_p{};
    void gcMark(){
      bbGCMarkPtr(l_p);
    }
  }f0{};
  if((g_mojo_graphics_Shader__0seq!=g_mojo_graphics_glutil_glGraphicsSeq)){
    g_mojo_graphics_Shader__0seq=g_mojo_graphics_glutil_glGraphicsSeq;
    g_mojo_graphics_Shader__0bound=((t_mojo_graphics_ShaderProgram*)0);
  }
  f0.l_p=this->m__0programs->at(l_env->m_Id());
  if(!bbBool(f0.l_p)){
    struct f1_t : public bbGCFrame{
      bbArray<bbString>* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    f0.l_p=bbGCNew<t_mojo_graphics_ShaderProgram>(f1.t0=bbArray<bbString>::create({l_env->m__0source,this->m__0source},2));
    this->m__0programs->at(l_env->m_Id())=f0.l_p;
  }
  if((g_mojo_graphics_Shader__0bound==f0.l_p)){
    return;
  }
  glUseProgram(f0.l_p->m_GLProgram());
  g_mojo_graphics_Shader__0bound=f0.l_p;
}

void mx2_mojo_graphics_2shader_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_graphics_ShaderParam__0ids=bbGCNew<t_std_collections_Map_1si>();
  g_mojo_graphics_ShaderEnv__0nextId=bbInt(0);
}

bbInit mx2_mojo_graphics_2shader_init_v("mojo_graphics_2shader",&mx2_mojo_graphics_2shader_init);
