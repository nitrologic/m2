
#include "../../desktop_release_pi/mojo_app_2app.h"

// ***** External *****

#include "../../../../libc/libc.buildv1.0.2/desktop_release_pi/libc_libc.h"
#include "../../desktop_release_pi/mojo_app_2event.h"
#include "../../desktop_release_pi/mojo_app_2style.h"
#include "../../desktop_release_pi/mojo_app_2view.h"
#include "../../desktop_release_pi/mojo_app_2window.h"
#include "../../desktop_release_pi/mojo_audio_2audio.h"
#include "../../desktop_release_pi/mojo_graphics_2font.h"
#include "../../desktop_release_pi/mojo_input_2keyboard.h"
#include "../../desktop_release_pi/mojo_input_2mouse.h"
#include "../../desktop_release_pi/mojo_std_collections_2map.h"
#include "../../desktop_release_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_release_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_graphics_2color.h"

// ***** Internal *****

bbGCRootVar<t_mojo_app_AppInstance> g_mojo_app_App;
bbGCRootVar<t_std_collections_Map_1iFvE> g_mojo_app_AppInstance__0asyncCallbacks;
bbGCRootVar<t_std_collections_Map_1iz> g_mojo_app_AppInstance__0disabledCallbacks;
bbInt g_mojo_app_AppInstance__0nextCallbackId;

bbInt g_mojo_app_AppInstance__0EventFilter(void* l_userData,SDL_Event* l_event){
  return g_mojo_app_App->m_EventFilter(l_userData,l_event);
}

void g_mojo_app_AppInstance_RemoveAsyncCallback(bbInt l_id){
  g_mojo_app_AppInstance__0disabledCallbacks->m_Remove(l_id);
  g_mojo_app_AppInstance__0asyncCallbacks->m_Remove(l_id);
}

void g_mojo_app_AppInstance_EnableAsyncCallback(bbInt l_id){
  g_mojo_app_AppInstance__0disabledCallbacks->m_Remove(l_id);
}

void g_mojo_app_AppInstance_EmscriptenMainLoop(){
  g_mojo_app_App->m__0requestRender=true;
  g_mojo_app_App->m_MainLoop();
}

void g_mojo_app_AppInstance_DisableAsyncCallback(bbInt l_id){
  if(g_mojo_app_AppInstance__0asyncCallbacks->m_Contains(l_id)){
    g_mojo_app_AppInstance__0disabledCallbacks->m__idxeq(l_id,true);
  }
}

bbInt g_mojo_app_AppInstance_AddAsyncCallback(bbFunction<void()> l_func){
  g_mojo_app_AppInstance__0nextCallbackId+=1;
  bbInt l_id=g_mojo_app_AppInstance__0nextCallbackId;
  g_mojo_app_AppInstance__0asyncCallbacks->m__idxeq(l_id,l_func);
  return l_id;
}

void t_mojo_app_AppInstance::init(){
  m__0modalStack=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_View_2>();
}

void t_mojo_app_AppInstance::gcMark(){
  bbGCMark(m_Idle);
  bbGCMark(m_NextIdle);
  bbGCMark(m_KeyEventFilter);
  bbGCMark(m_MouseEventFilter);
  bbGCMark(m__0config);
  bbGCMark(m__0dummyWindow);
  bbGCMark(m__0defaultFont);
  bbGCMark(m__0defaultMonoFont);
  bbGCMark(m__0hoverView);
  bbGCMark(m__0mouseView);
  bbGCMark(m__0window);
  bbGCMark(m__0modalView);
  bbGCMark(m__0modalStack);
}

t_mojo_app_AppInstance::t_mojo_app_AppInstance(t_std_collections_Map_1ss* l_config){
  init();
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1ss* l_config{};
    t_mojo_app_Style* l_style{};
    f0_t(t_std_collections_Map_1ss* l_config):l_config(l_config){
    }
    void gcMark(){
      bbGCMarkPtr(l_config);
      bbGCMarkPtr(l_style);
    }
  }f0{l_config};
  g_mojo_app_App=this;
  if(!bbBool(f0.l_config)){
    f0.l_config=bbGCNew<t_std_collections_Map_1ss>();
  }
  this->m__0config=f0.l_config;
  SDL_Init((SDL_INIT_EVERYTHING&~SDL_INIT_AUDIO));
  this->m__0sdlThread=SDL_ThreadID();
  g_mojo_input_Keyboard->m_Init();
  g_mojo_input_Mouse->m_Init();
  g_mojo_audio_Audio->m_Init();
  SDL_GL_SetAttribute(SDL_GL_SHARE_WITH_CURRENT_CONTEXT,1);
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER,1);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,bbInt(this->m_GetConfig(BB_T("GL_depth_buffer_enabled"),BB_T("0"))));
  SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE,bbInt(this->m_GetConfig(BB_T("GL_stencil_buffer_enabled"),BB_T("0"))));
  this->m__0dummyWindow=bbGCNew<t_mojo_app_Window>(BB_T("<hidden>"),this);
  this->m__0defaultFont=g_mojo_graphics_Font_Open(this->m_DefaultFontName(),16.0f);
  this->m__0defaultMonoFont=g_mojo_graphics_Font_Open(this->m_DefaultMonoFontName(),16.0f);
  f0.l_style=g_mojo_app_Style_GetStyle(bbString{});
  f0.l_style->m_DefaultFont(this->m__0defaultFont);
  f0.l_style->m_DefaultColor(g_std_graphics_Color_White);
}

void t_mojo_app_AppInstance::m_UpdateFPS(){
  this->m__0fpsFrames+=1;
  bbInt l_elapsed=(g_mojo_app_App->m_Millisecs()-this->m__0fpsMillis);
  if((l_elapsed>=250)){
    this->m__0fps=bbFloat(std::round(bbDouble((bbFloat(this->m__0fpsFrames)/(bbFloat(l_elapsed)/1000.0f)))));
    this->m__0fpsMillis+=l_elapsed;
    this->m__0fpsFrames=bbInt(0);
  }
}

void t_mojo_app_AppInstance::m_UpdateEvents(){
  struct f0_t : public bbGCFrame{
    bbFunction<void()> l_idle{};
    void gcMark(){
      bbGCMark(l_idle);
    }
  }f0{};
  SDL_Event l_event{};
  this->m__0polling=true;
  while(bbBool(SDL_PollEvent(&l_event))){
    this->m_DispatchEvent(&l_event);
  }
  this->m__0polling=false;
  f0.l_idle=this->m_Idle;
  this->m_Idle=this->m_NextIdle;
  this->m_NextIdle=bbFunction<void()>{};
  f0.l_idle();
  {
    struct f1_t : public bbGCFrame{
      bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
      void gcMark(){
        bbGCMarkPtr(l_0);
      }
    }f1{};
    f1.l_0=g_mojo_app_Window_VisibleWindows();
    bbInt l_1=bbInt(0);
    bbInt l_2=f1.l_0->length();
    for(;(l_1<l_2);l_1+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_window{};
        void gcMark(){
          bbGCMarkPtr(l_window);
        }
      }f2{};
      f2.l_window=f1.l_0->at(l_1);
    }
  }
}

void t_mojo_app_AppInstance::m_Terminate(){
  SDL_Quit();
  exit(bbInt(0));
}

void t_mojo_app_AppInstance::m_SendWindowEvent(t_mojo_app_EventType l_type){
  struct f0_t : public bbGCFrame{
    t_mojo_app_WindowEvent* l_event{};
    void gcMark(){
      bbGCMarkPtr(l_event);
    }
  }f0{};
  f0.l_event=bbGCNew<t_mojo_app_WindowEvent>(l_type,this->m__0window);
  this->m__0window->m_SendWindowEvent(f0.l_event);
}

void t_mojo_app_AppInstance::m_SendMouseEvent(t_mojo_app_EventType l_type,t_mojo_app_View* l_view){
  struct f0_t : public bbGCFrame{
    t_mojo_app_MouseEvent* l_event{};
    void gcMark(){
      bbGCMarkPtr(l_event);
    }
  }f0{};
  t_std_geom_Vec2_1i l_location=l_view->m_TransformWindowPointToView(this->m__0mouseLocation);
  f0.l_event=bbGCNew<t_mojo_app_MouseEvent>(l_type,l_view,l_location,this->m__0mouseButton,this->m__0mouseWheel,this->m__0modifiers);
  this->m_MouseEventFilter(f0.l_event);
  if(f0.l_event->m_Eaten()){
    return;
  }
  if((bbBool(this->m__0modalView)&&!l_view->m_IsChildOf(this->m__0modalView))){
    return;
  }
  l_view->m_SendMouseEvent(f0.l_event);
}

void t_mojo_app_AppInstance::m_SendKeyEvent(t_mojo_app_EventType l_type){
  struct f0_t : public bbGCFrame{
    t_mojo_app_KeyEvent* l_event{};
    t_mojo_app_View* l_view{};
    void gcMark(){
      bbGCMarkPtr(l_event);
      bbGCMarkPtr(l_view);
    }
  }f0{};
  f0.l_view=this->m_KeyView();
  if((bbBool(f0.l_view)&&!f0.l_view->m_ReallyEnabled())){
    f0.l_view=((t_mojo_app_View*)0);
  }
  f0.l_event=bbGCNew<t_mojo_app_KeyEvent>(l_type,f0.l_view,this->m__0key,this->m__0rawKey,this->m__0modifiers,this->m__0keyChar);
  this->m_KeyEventFilter(f0.l_event);
  if(f0.l_event->m_Eaten()){
    return;
  }
  if((bbBool(this->m__0modalView)&&!f0.l_view->m_IsChildOf(this->m__0modalView))){
    return;
  }
  if(bbBool(f0.l_view)){
    f0.l_view->m_SendKeyEvent(f0.l_event);
  }else if(bbBool(this->m_ActiveWindow())){
    struct f1_t : public bbGCFrame{
      t_mojo_app_Window* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    (f1.t0=this->m_ActiveWindow())->m_SendKeyEvent(f0.l_event);
  }
}

void t_mojo_app_AppInstance::m_Run(){
  SDL_AddEventWatch(g_mojo_app_AppInstance__0EventFilter,((void*)0));
  this->m_RequestRender();
  for(;;){
    this->m_MainLoop();
  }
}

void t_mojo_app_AppInstance::m_RequestRender(){
  this->m__0requestRender=true;
}

t_mojo_app_View* t_mojo_app_AppInstance::m_MouseView(){
  return this->m__0mouseView;
}

t_std_geom_Vec2_1i t_mojo_app_AppInstance::m_MouseLocation(){
  return this->m__0mouseLocation;
}

bbInt t_mojo_app_AppInstance::m_Millisecs(){
  return SDL_GetTicks();
}

void t_mojo_app_AppInstance::m_MainLoop(){
  if(!this->m__0requestRender){
    SDL_WaitEvent(((SDL_Event*)0));
  }
  this->m_UpdateEvents();
  if(!this->m__0requestRender){
    return;
  }
  this->m__0requestRender=false;
  this->m_UpdateFPS();
  {
    struct f1_t : public bbGCFrame{
      bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
      void gcMark(){
        bbGCMarkPtr(l_0);
      }
    }f1{};
    f1.l_0=g_mojo_app_Window_VisibleWindows();
    bbInt l_1=bbInt(0);
    bbInt l_2=f1.l_0->length();
    for(;(l_1<l_2);l_1+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_window{};
        void gcMark(){
          bbGCMarkPtr(l_window);
        }
      }f2{};
      f2.l_window=f1.l_0->at(l_1);
      f2.l_window->m_Update();
      f2.l_window->m_Render();
    }
  }
}

void t_mojo_app_AppInstance::m_KeyView(t_mojo_app_View* l_keyView){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_window{};
    void gcMark(){
      bbGCMarkPtr(l_window);
    }
  }f0{};
  f0.l_window=this->m_ActiveWindow();
  if(bbBool(f0.l_window)){
    f0.l_window->m_KeyView(l_keyView);
  }
}

t_mojo_app_View* t_mojo_app_AppInstance::m_KeyView(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_window{};
    void gcMark(){
      bbGCMarkPtr(l_window);
    }
  }f0{};
  f0.l_window=this->m_ActiveWindow();
  if(bbBool(f0.l_window)){
    return f0.l_window->m_KeyView();
  }
  return ((t_mojo_app_View*)0);
}

t_mojo_app_View* t_mojo_app_AppInstance::m_HoverView(){
  return this->m__0hoverView;
}

bbArray<t_mojo_app_DisplayMode>* t_mojo_app_AppInstance::m_GetDisplayModes(){
  struct f0_t : public bbGCFrame{
    bbArray<t_mojo_app_DisplayMode>* l_modes{};
    void gcMark(){
      bbGCMarkPtr(l_modes);
    }
  }f0{};
  bbInt l_n=SDL_GetNumDisplayModes(bbInt(0));
  f0.l_modes=bbArray<t_mojo_app_DisplayMode>::create(l_n);
  {
    bbInt l_i=bbInt(0);
    for(;(l_i<l_n);l_i+=1){
      SDL_DisplayMode l_mode{};
      SDL_GetDisplayMode(bbInt(0),l_i,&l_mode);
      f0.l_modes->at(l_i).m_width=l_mode.w;
      f0.l_modes->at(l_i).m_height=l_mode.h;
      f0.l_modes->at(l_i).m_hertz=l_mode.refresh_rate;
    }
  }
  return f0.l_modes;
}

bbString t_mojo_app_AppInstance::m_GetConfig(bbString l_name,bbString l_defValue){
  if(this->m__0config->m_Contains(l_name)){
    return this->m__0config->m__idx(l_name);
  }
  return l_defValue;
}

bbFloat t_mojo_app_AppInstance::m_FPS(){
  return this->m__0fps;
}

bbInt t_mojo_app_AppInstance::m_EventFilter(void* l_userData,SDL_Event* l_event){
  if(l_event[bbInt(0)].type==bbInt(SDL_WINDOWEVENT)){
    SDL_WindowEvent* l_wevent=((SDL_WindowEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_wevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return 1;
    }
    if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_MOVED)){
      this->m_SendWindowEvent(t_mojo_app_EventType(11));
      return bbInt(0);
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_RESIZED)){
      this->m_SendWindowEvent(t_mojo_app_EventType(12));
      if(this->m__0requestRender){
        this->m__0requestRender=false;
        {
          struct f4_t : public bbGCFrame{
            bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
            void gcMark(){
              bbGCMarkPtr(l_0);
            }
          }f4{};
          f4.l_0=g_mojo_app_Window_VisibleWindows();
          bbInt l_1=bbInt(0);
          bbInt l_2=f4.l_0->length();
          for(;(l_1<l_2);l_1+=1){
            struct f5_t : public bbGCFrame{
              t_mojo_app_Window* l_window{};
              void gcMark(){
                bbGCMarkPtr(l_window);
              }
            }f5{};
            f5.l_window=f4.l_0->at(l_1);
            f5.l_window->m_Update();
            f5.l_window->m_Render();
          }
        }
      }
      return bbInt(0);
    }
  }
  return 1;
}

void t_mojo_app_AppInstance::m_EndModal(){
  this->m__0modalView=this->m__0modalStack->m_Pop();
}

void t_mojo_app_AppInstance::m_DispatchEvent(SDL_Event* l_event){
  if(l_event[bbInt(0)].type==bbInt(SDL_KEYDOWN)){
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_kevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return;
    }
    this->m__0key=g_mojo_input_Keyboard->m_KeyCodeToKey(l_kevent[bbInt(0)].keysym.sym);
    this->m__0rawKey=g_mojo_input_Keyboard->m_ScanCodeToRawKey(bbInt(l_kevent[bbInt(0)].keysym.scancode));
    this->m__0keyChar=g_mojo_input_Keyboard->m_KeyName(this->m__0key);
    if(bbBool(l_kevent[bbInt(0)].repeat)){
      this->m_SendKeyEvent(t_mojo_app_EventType(1));
    }else{
      this->m_SendKeyEvent(t_mojo_app_EventType(0));
    }
    this->m__0modifiers=g_mojo_input_Keyboard->m_Modifiers();
  }else if(l_event[bbInt(0)].type==bbInt(SDL_KEYUP)){
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_kevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return;
    }
    this->m__0key=g_mojo_input_Keyboard->m_KeyCodeToKey(l_kevent[bbInt(0)].keysym.sym);
    this->m__0rawKey=g_mojo_input_Keyboard->m_ScanCodeToRawKey(bbInt(l_kevent[bbInt(0)].keysym.scancode));
    this->m__0keyChar=g_mojo_input_Keyboard->m_KeyName(this->m__0key);
    this->m_SendKeyEvent(t_mojo_app_EventType(2));
    this->m__0modifiers=g_mojo_input_Keyboard->m_Modifiers();
  }else if(l_event[bbInt(0)].type==bbInt(SDL_TEXTINPUT)){
    SDL_TextInputEvent* l_tevent=((SDL_TextInputEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_tevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return;
    }
    this->m__0keyChar=bbString::fromChar(bbInt(l_tevent[bbInt(0)].text[bbInt(0)]));
    this->m_SendKeyEvent(t_mojo_app_EventType(3));
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEBUTTONDOWN)){
    SDL_MouseButtonEvent* l_mevent=((SDL_MouseButtonEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return;
    }
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    this->m__0mouseButton=((t_mojo_input_MouseButton)(l_mevent[bbInt(0)].button));
    if(!bbBool(this->m__0mouseView)){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      f2.l_view=this->m__0window->m_FindViewAtWindowPoint(this->m__0mouseLocation);
      if(bbBool(f2.l_view)){
        SDL_CaptureMouse(SDL_TRUE);
        this->m__0mouseView=f2.l_view;
      }
    }
    if(bbBool(this->m__0mouseView)){
      this->m_SendMouseEvent(t_mojo_app_EventType(4),this->m__0mouseView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEBUTTONUP)){
    SDL_MouseButtonEvent* l_mevent=((SDL_MouseButtonEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return;
    }
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    this->m__0mouseButton=((t_mojo_input_MouseButton)(l_mevent[bbInt(0)].button));
    if(bbBool(this->m__0mouseView)){
      this->m_SendMouseEvent(t_mojo_app_EventType(5),this->m__0mouseView);
      SDL_CaptureMouse(SDL_FALSE);
      this->m__0mouseView=((t_mojo_app_View*)0);
      this->m__0mouseButton=t_mojo_input_MouseButton(0);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEMOTION)){
    struct f1_t : public bbGCFrame{
      t_mojo_app_View* l_view{};
      void gcMark(){
        bbGCMarkPtr(l_view);
      }
    }f1{};
    SDL_MouseMotionEvent* l_mevent=((SDL_MouseMotionEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return;
    }
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    f1.l_view=this->m__0window->m_FindViewAtWindowPoint(this->m__0mouseLocation);
    if((bbBool(this->m__0mouseView)&&(f1.l_view!=this->m__0mouseView))){
      f1.l_view=((t_mojo_app_View*)0);
    }
    if((f1.l_view!=this->m__0hoverView)){
      if(bbBool(this->m__0hoverView)){
        this->m_SendMouseEvent(t_mojo_app_EventType(9),this->m__0hoverView);
      }
      this->m__0hoverView=f1.l_view;
      if(bbBool(this->m__0hoverView)){
        this->m_SendMouseEvent(t_mojo_app_EventType(8),this->m__0hoverView);
      }
    }
    if(bbBool(this->m__0mouseView)){
      this->m_SendMouseEvent(t_mojo_app_EventType(6),this->m__0mouseView);
    }else if(bbBool(this->m__0hoverView)){
      this->m_SendMouseEvent(t_mojo_app_EventType(6),this->m__0hoverView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEWHEEL)){
    SDL_MouseWheelEvent* l_mevent=((SDL_MouseWheelEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return;
    }
    this->m__0mouseWheel=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    if(bbBool(this->m__0mouseView)){
      this->m_SendMouseEvent(t_mojo_app_EventType(7),this->m__0mouseView);
    }else if(bbBool(this->m__0hoverView)){
      this->m_SendMouseEvent(t_mojo_app_EventType(7),this->m__0hoverView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_WINDOWEVENT)){
    SDL_WindowEvent* l_wevent=((SDL_WindowEvent*)(l_event));
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_wevent[bbInt(0)].windowID));
    if(!bbBool(this->m__0window)){
      return;
    }
    if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_CLOSE)){
      this->m_SendWindowEvent(t_mojo_app_EventType(10));
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_MOVED)){
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_RESIZED)){
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_SIZE_CHANGED)){
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_FOCUS_GAINED)){
      this->m_SendWindowEvent(t_mojo_app_EventType(13));
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_FOCUS_LOST)){
      this->m_SendWindowEvent(t_mojo_app_EventType(14));
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_LEAVE)){
      if(bbBool(this->m__0hoverView)){
        this->m_SendMouseEvent(t_mojo_app_EventType(9),this->m__0hoverView);
        this->m__0hoverView=((t_mojo_app_View*)0);
      }
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_USEREVENT)){
    SDL_UserEvent* l_t=((SDL_UserEvent*)(l_event));
    bbInt l_code=l_t[bbInt(0)].code;
    bbInt l_id=(l_code&1073741823);
    if(bbBool((l_code&1073741824))){
      struct f2_t : public bbGCFrame{
        bbFunction<void()> l_func{};
        void gcMark(){
          bbGCMark(l_func);
        }
      }f2{};
      f2.l_func=g_mojo_app_AppInstance__0asyncCallbacks->m__idx(l_id);
      if(bbBool((l_code&2147483648))){
        g_mojo_app_AppInstance_RemoveAsyncCallback(l_id);
      }
      if(!g_mojo_app_AppInstance__0disabledCallbacks->m__idx(l_id)){
        f2.l_func();
      }
    }else if(bbBool((l_code&2147483648))){
      g_mojo_app_AppInstance_RemoveAsyncCallback(l_id);
    }
  }
}

t_std_geom_Vec2_1i t_mojo_app_AppInstance::m_DesktopSize(){
  SDL_DisplayMode l_dm{};
  if(bbBool(SDL_GetDesktopDisplayMode(bbInt(0),&l_dm))){
    return t_std_geom_Vec2_1i(bbNullCtor);
  }
  return t_std_geom_Vec2_1i(l_dm.w,l_dm.h);
}

bbString t_mojo_app_AppInstance::m_DefaultMonoFontName(){
  return BB_T("asset::mojo/RobotoMono-Regular.ttf");
}

t_mojo_graphics_Font* t_mojo_app_AppInstance::m_DefaultMonoFont(){
  return this->m__0defaultMonoFont;
}

bbString t_mojo_app_AppInstance::m_DefaultFontName(){
  return BB_T("asset::mojo/Roboto-Regular.ttf");
}

t_mojo_graphics_Font* t_mojo_app_AppInstance::m_DefaultFont(){
  return this->m__0defaultFont;
}

bbBool t_mojo_app_AppInstance::m_ClipboardTextEmpty(){
  return (SDL_HasClipboardText()==SDL_FALSE);
}

void t_mojo_app_AppInstance::m_ClipboardText(bbString l_text){
  SDL_SetClipboardText(bbUtf8String(l_text));
}

bbString t_mojo_app_AppInstance::m_ClipboardText(){
  if((SDL_HasClipboardText()==SDL_FALSE)){
    return bbString{};
  }
  char* l_p=SDL_GetClipboardText();
  bbString l_str=bbString::fromUtf8String(((void*)(l_p)));
  l_str=l_str.replace(BB_T("\r\n"),BB_T("\n"));
  l_str=l_str.replace(BB_T("\r"),BB_T("\n"));
  SDL_free(((void*)(l_p)));
  return l_str;
}

void t_mojo_app_AppInstance::m_BeginModal(t_mojo_app_View* l_view){
  this->m__0modalStack->m_Push(this->m__0modalView);
  this->m__0modalView=l_view;
}

t_mojo_app_Window* t_mojo_app_AppInstance::m_ActiveWindow(){
  return g_mojo_app_Window_VisibleWindows()->at(bbInt(0));
}

int bbCompare(const t_mojo_app_DisplayMode&x,const t_mojo_app_DisplayMode&y){
  if(int t=bbCompare(x.m_width,y.m_width)) return t;
  if(int t=bbCompare(x.m_height,y.m_height)) return t;
  if(int t=bbCompare(x.m_hertz,y.m_hertz)) return t;
  return 0;
}

void mx2_mojo_app_2app_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_app_AppInstance__0asyncCallbacks=bbGCNew<t_std_collections_Map_1iFvE>();
  g_mojo_app_AppInstance__0disabledCallbacks=bbGCNew<t_std_collections_Map_1iz>();
}

bbInit mx2_mojo_app_2app_init_v("mojo_app_2app",&mx2_mojo_app_2app_init);
