
#include "../../desktop_debug_pi/mojo_app_2view.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2app.h"
#include "../../desktop_debug_pi/mojo_app_2event.h"
#include "../../desktop_debug_pi/mojo_app_2style.h"
#include "../../desktop_debug_pi/mojo_app_2window.h"
#include "../../desktop_debug_pi/mojo_graphics_2canvas.h"
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_math.h"

extern bbFloat g_monkey_math_Min_1f(bbFloat l_x,bbFloat l_y);
extern t_std_geom_Rect_1i g_std_geom_TransformRecti_1f(t_std_geom_Rect_1i l_rect,t_std_geom_AffineMat3_1f l_matrix);
extern bbInt g_monkey_math_Max_1i(bbInt l_x,bbInt l_y);
extern bbInt g_monkey_math_Min_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

void t_mojo_app_View::init(){
  m__0children=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_View_2>();
  m__0gravity=t_std_geom_Vec2_1f(.5f,.5f);
  m__0offset=t_std_geom_Vec2_1i(bbInt(0),bbInt(0));
}

void t_mojo_app_View::gcMark(){
  bbGCMark(m__0parent);
  bbGCMark(m__0children);
  bbGCMark(m__0style);
  bbGCMark(m__0rstyle);
}

void t_mojo_app_View::dbEmit(){
  bbDBEmit("_dirty",&m__0dirty);
  bbDBEmit("_parent",&m__0parent);
  bbDBEmit("_children",&m__0children);
  bbDBEmit("_visible",&m__0visible);
  bbDBEmit("_enabled",&m__0enabled);
  bbDBEmit("_style",&m__0style);
  bbDBEmit("_styleState",&m__0styleState);
  bbDBEmit("_layout",&m__0layout);
  bbDBEmit("_gravity",&m__0gravity);
  bbDBEmit("_offset",&m__0offset);
  bbDBEmit("_minSize",&m__0minSize);
  bbDBEmit("_maxSize",&m__0maxSize);
  bbDBEmit("_frame",&m__0frame);
  bbDBEmit("_rstyle",&m__0rstyle);
  bbDBEmit("_styleBounds",&m__0styleBounds);
  bbDBEmit("_measuredSize",&m__0measuredSize);
  bbDBEmit("_layoutSize",&m__0layoutSize);
  bbDBEmit("_rect",&m__0rect);
  bbDBEmit("_bounds",&m__0bounds);
  bbDBEmit("_matrix",&m__0matrix);
  bbDBEmit("_rmatrix",&m__0rmatrix);
  bbDBEmit("_rbounds",&m__0rbounds);
  bbDBEmit("_rclip",&m__0rclip);
  bbDBEmit("_clip",&m__0clip);
}

t_mojo_app_View::t_mojo_app_View(){
  init();
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  bbDBStmt(40962);
  this->m__0style=bbGCNew<t_mojo_app_Style>();
}

bbInt t_mojo_app_View::m_Width(){
  bbDBFrame db_f{"Width:Int()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(851970);
  return this->m__0rect.m_Width();
}

void t_mojo_app_View::m_Visible(bbBool l_visible){
  bbDBFrame db_f{"Visible:Void(visible:Bool)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("visible",&l_visible);
  bbDBStmt(94210);
  if((l_visible==this->m__0visible)){
    bbDBBlock db_blk;
    bbDBStmt(94230);
    return;
  }
  bbDBStmt(102402);
  this->m__0visible=l_visible;
}

bbBool t_mojo_app_View::m_Visible(){
  bbDBFrame db_f{"Visible:Bool()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(81922);
  return this->m__0visible;
}

void t_mojo_app_View::m_ValidateStyle(){
  bbDBFrame db_f{"ValidateStyle:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1998850);
  if(!bbBool(t_mojo_app_View_Dirty((int(this->m__0dirty)&int(t_mojo_app_View_Dirty(1)))))){
    bbDBBlock db_blk;
    bbDBStmt(1998880);
    return;
  }
  bbDBStmt(2007042);
  this->m__0rstyle=this->m__0style;
  bbDBStmt(2015234);
  if(!this->m_ReallyEnabled()){
    bbDBBlock db_blk;
    bbDBStmt(2019331);
    this->m__0rstyle=this->m__0style->m_GetState(BB_T("disabled"));
  }else if(bbDBStmt(2023426),bbBool(this->m__0styleState)){
    bbDBBlock db_blk;
    bbDBStmt(2027523);
    this->m__0rstyle=this->m__0style->m_GetState(this->m__0styleState);
  }
  bbDBStmt(2039810);
  this->m__0styleBounds=this->m__0rstyle->m_Bounds();
  bbDBStmt(2048002);
  this->m__0dirty=t_mojo_app_View_Dirty((int(this->m__0dirty)&int(t_mojo_app_View_Dirty(~int(t_mojo_app_View_Dirty(1))))));
  bbDBStmt(2056194);
  this->m_OnValidateStyle();
}

void t_mojo_app_View::m_UpdateLayout(){
  bbDBFrame db_f{"UpdateLayout:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2199554);
  this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m__0measuredSize);
  bbDBStmt(2207746);
  this->m__0bounds=this->m__0rect.m__add(this->m__0styleBounds);
  bbDBStmt(2215938);
  this->m__0matrix=t_std_geom_AffineMat3_1f(bbNullCtor);
  bbDBStmt(2224130);
  if(bbBool(this->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2224141);
    this->m__0matrix=this->m__0matrix.m_Translate(bbFloat(this->m__0frame.m_min.m_x),bbFloat(this->m__0frame.m_min.m_y));
  }
  bbDBStmt(2232322);
  this->m__0matrix=this->m__0matrix.m_Translate(bbFloat(this->m__0offset.m_x),bbFloat(this->m__0offset.m_y));
  bbDBStmt(2240514);
  if(this->m__0layout==BB_T("fill")||this->m__0layout==BB_T("resize")){
    bbDBBlock db_blk;
    bbDBStmt(2252803);
    this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m__0frame.m_Size().m__sub(this->m__0styleBounds.m_Size()));
    bbDBStmt(2260995);
    this->m__0bounds=this->m__0rect.m__add(this->m__0styleBounds);
  }else if(this->m__0layout==BB_T("fill-x")){
    bbDBBlock db_blk;
    bbDBStmt(2277379);
    this->m__0rect.m_max.m_x=(this->m__0frame.m_Width()-this->m__0styleBounds.m_Width());
    bbDBStmt(2285571);
    this->m__0bounds.m_min.m_x=(this->m__0rect.m_min.m_x+this->m__0styleBounds.m_min.m_x);
    bbDBStmt(2289667);
    this->m__0bounds.m_max.m_x=(this->m__0rect.m_max.m_x+this->m__0styleBounds.m_max.m_x);
    bbDBStmt(2297859);
    this->m__0matrix=this->m__0matrix.m_Translate(0.0f,(bbFloat((this->m__0frame.m_Height()-this->m__0bounds.m_Height()))*this->m__0gravity.m_y));
  }else if(this->m__0layout==BB_T("float")){
    bbDBBlock db_blk;
    bbDBStmt(2314243);
    this->m__0matrix=this->m__0matrix.m_Translate((bbFloat((this->m__0frame.m_Width()-this->m__0bounds.m_Width()))*this->m__0gravity.m_x),(bbFloat((this->m__0frame.m_Height()-this->m__0bounds.m_Height()))*this->m__0gravity.m_y));
    bbDBStmt(2322435);
    this->m__0matrix.m_t.m_x=bbFloat(std::round(bbDouble(this->m__0matrix.m_t.m_x)));
    bbDBStmt(2326531);
    this->m__0matrix.m_t.m_y=bbFloat(std::round(bbDouble(this->m__0matrix.m_t.m_y)));
  }else if(this->m__0layout==BB_T("stretch")){
    bbDBBlock db_blk;
    bbDBStmt(2342921);
    bbFloat l_sx=(bbFloat(this->m__0frame.m_Width())/bbFloat(this->m__0bounds.m_Width()));
    bbDBLocal("sx",&l_sx);
    bbDBStmt(2347017);
    bbFloat l_sy=(bbFloat(this->m__0frame.m_Height())/bbFloat(this->m__0bounds.m_Height()));
    bbDBLocal("sy",&l_sy);
    bbDBStmt(2351107);
    this->m__0matrix=this->m__0matrix.m_Scale(l_sx,l_sy);
  }else if(this->m__0layout==BB_T("stretch-int")){
    bbDBBlock db_blk;
    bbDBStmt(2367497);
    bbFloat l_sx=(bbFloat(this->m__0frame.m_Width())/bbFloat(this->m__0bounds.m_Width()));
    bbDBLocal("sx",&l_sx);
    bbDBStmt(2371593);
    bbFloat l_sy=(bbFloat(this->m__0frame.m_Height())/bbFloat(this->m__0bounds.m_Height()));
    bbDBLocal("sy",&l_sy);
    bbDBStmt(2379779);
    if((l_sx>1.0f)){
      bbDBBlock db_blk;
      bbDBStmt(2379787);
      l_sx=bbFloat(std::floor(bbDouble(l_sx)));
    }
    bbDBStmt(2383875);
    if((l_sy>1.0f)){
      bbDBBlock db_blk;
      bbDBStmt(2383883);
      l_sy=bbFloat(std::floor(bbDouble(l_sy)));
    }
    bbDBStmt(2392067);
    this->m__0matrix=this->m__0matrix.m_Scale(l_sx,l_sy);
  }else if(this->m__0layout==BB_T("scale")||this->m__0layout==BB_T("letterbox")){
    bbDBBlock db_blk;
    bbDBStmt(2408457);
    bbFloat l_sx=(bbFloat(this->m__0frame.m_Width())/bbFloat(this->m__0bounds.m_Width()));
    bbDBLocal("sx",&l_sx);
    bbDBStmt(2412553);
    bbFloat l_sy=(bbFloat(this->m__0frame.m_Height())/bbFloat(this->m__0bounds.m_Height()));
    bbDBLocal("sy",&l_sy);
    bbDBStmt(2420739);
    if((l_sx<l_sy)){
      bbDBBlock db_blk;
      bbDBStmt(2424836);
      this->m__0matrix=this->m__0matrix.m_Translate(0.0f,((bbFloat(this->m__0frame.m_Height())-(bbFloat(this->m__0bounds.m_Height())*l_sx))*this->m__0gravity.m_y));
      bbDBStmt(2428932);
      this->m__0matrix=this->m__0matrix.m_Scale(l_sx,l_sx);
    }else{
      bbDBStmt(2433027);
      bbDBBlock db_blk;
      bbDBStmt(2437124);
      this->m__0matrix=this->m__0matrix.m_Translate(((bbFloat(this->m__0frame.m_Width())-(bbFloat(this->m__0bounds.m_Width())*l_sy))*this->m__0gravity.m_x),0.0f);
      bbDBStmt(2441220);
      this->m__0matrix=this->m__0matrix.m_Scale(l_sy,l_sy);
    }
  }else if(this->m__0layout==BB_T("scale-int")||this->m__0layout==BB_T("letterbox-int")){
    bbDBBlock db_blk;
    bbDBStmt(2461705);
    bbFloat l_sx=(bbFloat(this->m__0frame.m_Width())/bbFloat(this->m__0bounds.m_Width()));
    bbDBLocal("sx",&l_sx);
    bbDBStmt(2465801);
    bbFloat l_sy=(bbFloat(this->m__0frame.m_Height())/bbFloat(this->m__0bounds.m_Height()));
    bbDBLocal("sy",&l_sy);
    bbDBStmt(2473987);
    if((l_sx>1.0f)){
      bbDBBlock db_blk;
      bbDBStmt(2473995);
      l_sx=bbFloat(std::floor(bbDouble(l_sx)));
    }
    bbDBStmt(2478083);
    if((l_sy>1.0f)){
      bbDBBlock db_blk;
      bbDBStmt(2478091);
      l_sy=bbFloat(std::floor(bbDouble(l_sy)));
    }
    bbDBStmt(2486281);
    bbFloat l_sc=g_monkey_math_Min_1f(l_sx,l_sy);
    bbDBLocal("sc",&l_sc);
    bbDBStmt(2490371);
    this->m__0matrix=this->m__0matrix.m_Translate(((bbFloat(this->m__0frame.m_Width())-(bbFloat(this->m__0bounds.m_Width())*l_sc))*this->m__0gravity.m_x),((bbFloat(this->m__0frame.m_Height())-(bbFloat(this->m__0bounds.m_Height())*l_sc))*this->m__0gravity.m_y));
    bbDBStmt(2494467);
    this->m__0matrix=this->m__0matrix.m_Scale(l_sc,l_sc);
  }
  bbDBStmt(2510850);
  this->m__0matrix=this->m__0matrix.m_Translate(bbFloat(-this->m__0bounds.m_min.m_x),bbFloat(-this->m__0bounds.m_min.m_y));
  bbDBStmt(2519042);
  if(bbBool(this->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2519053);
    this->m__0rmatrix=this->m__0parent->m__0rmatrix.m__mul(this->m__0matrix);
  }else{
    bbDBStmt(2519089);
    bbDBBlock db_blk;
    bbDBStmt(2519094);
    this->m__0rmatrix=this->m__0matrix;
  }
  bbDBStmt(2539522);
  this->m__0rclip=g_std_geom_TransformRecti_1f(this->m__0rect,this->m__0rmatrix);
  bbDBStmt(2543618);
  this->m__0rbounds=g_std_geom_TransformRecti_1f(this->m__0bounds,this->m__0rmatrix);
  bbDBStmt(2551810);
  if(bbBool(this->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(2555907);
    this->m__0rclip.m__andeq(this->m__0parent->m__0rclip);
    bbDBStmt(2560003);
    this->m__0rbounds.m__andeq(this->m__0parent->m__0rclip);
    bbDBStmt(2564099);
    this->m__0clip=g_std_geom_TransformRecti_1f(this->m__0rclip,this->m__0rmatrix.m__sub());
  }else{
    bbDBStmt(2568194);
    bbDBBlock db_blk;
    bbDBStmt(2572291);
    this->m__0clip=this->m__0rclip;
  }
  bbDBStmt(2584578);
  this->m_OnLayout();
  bbDBStmt(2592770);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=this->m__0children->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_view=f1.l_0.m_Current();
      bbDBLocal("view",&f2.l_view);
      bbDBStmt(2596867);
      f2.l_view->m_UpdateLayout();
    }
  }
}

t_std_geom_Vec2_1i t_mojo_app_View::m_TransformWindowPointToView(t_std_geom_Vec2_1i l_point){
  bbDBFrame db_f{"TransformWindowPointToView:Vec2i:std.geom.Vec2<Int>(point:Vec2i:std.geom.Vec2<Int>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("point",&l_point);
  bbDBStmt(1617928);
  t_std_geom_Vec2_1f l_t=this->m__0rmatrix.m__sub().m__mul(t_std_geom_Vec2_1f(bbFloat(l_point.m_x),bbFloat(l_point.m_y)));
  bbDBLocal("t",&l_t);
  bbDBStmt(1626114);
  return t_std_geom_Vec2_1i(bbInt(std::round(bbDouble(l_t.m_x))),bbInt(std::round(bbDouble(l_t.m_y))));
}

t_std_geom_Rect_1i t_mojo_app_View::m_TransformRectToView(t_std_geom_Rect_1i l_rect,t_mojo_app_View* l_view){
  bbDBFrame db_f{"TransformRectToView:Recti:std.geom.Rect<Int>(rect:Recti:std.geom.Rect<Int>,view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("view",&l_view);
  bbDBStmt(1531906);
  return t_std_geom_Rect_1i(this->m_TransformPointToView(l_rect.m_min,l_view),this->m_TransformPointToView(l_rect.m_max,l_view));
}

t_std_geom_Rect_1i t_mojo_app_View::m_TransformRectFromView(t_std_geom_Rect_1i l_rect,t_mojo_app_View* l_view){
  bbDBFrame db_f{"TransformRectFromView:Recti:std.geom.Rect<Int>(rect:Recti:std.geom.Rect<Int>,view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("view",&l_view);
  bbDBStmt(1589250);
  return t_std_geom_Rect_1i(this->m_TransformPointFromView(l_rect.m_min,l_view),this->m_TransformPointFromView(l_rect.m_max,l_view));
}

t_std_geom_Vec2_1i t_mojo_app_View::m_TransformPointToView(t_std_geom_Vec2_1i l_point,t_mojo_app_View* l_view){
  bbDBFrame db_f{"TransformPointToView:Vec2i:std.geom.Vec2<Int>(point:Vec2i:std.geom.Vec2<Int>,view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("point",&l_point);
  bbDBLocal("view",&l_view);
  bbDBStmt(1376264);
  t_std_geom_Vec2_1f l_t=this->m__0rmatrix.m__mul(t_std_geom_Vec2_1f(bbFloat(l_point.m_x),bbFloat(l_point.m_y)));
  bbDBLocal("t",&l_t);
  bbDBStmt(1384450);
  if(bbBool(l_view)){
    bbDBBlock db_blk;
    bbDBStmt(1384458);
    l_t=l_view->m__0rmatrix.m__sub().m__mul(l_t);
  }
  bbDBStmt(1392642);
  return t_std_geom_Vec2_1i(bbInt(std::round(bbDouble(l_t.m_x))),bbInt(std::round(bbDouble(l_t.m_y))));
}

t_std_geom_Vec2_1i t_mojo_app_View::m_TransformPointFromView(t_std_geom_Vec2_1i l_point,t_mojo_app_View* l_view){
  bbDBFrame db_f{"TransformPointFromView:Vec2i:std.geom.Vec2<Int>(point:Vec2i:std.geom.Vec2<Int>,view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("point",&l_point);
  bbDBLocal("view",&l_view);
  bbDBStmt(1449992);
  t_std_geom_Vec2_1f l_t=t_std_geom_Vec2_1f(bbFloat(l_point.m_x),bbFloat(l_point.m_y));
  bbDBLocal("t",&l_t);
  bbDBStmt(1458178);
  if(bbBool(l_view)){
    bbDBBlock db_blk;
    bbDBStmt(1458186);
    l_t=l_view->m__0matrix.m__mul(l_t);
  }
  bbDBStmt(1466370);
  l_t=this->m__0rmatrix.m__sub().m__mul(l_t);
  bbDBStmt(1474562);
  return t_std_geom_Vec2_1i(bbInt(std::round(bbDouble(l_t.m_x))),bbInt(std::round(bbDouble(l_t.m_y))));
}

void t_mojo_app_View::m_StyleState(bbString l_styleState){
  bbDBFrame db_f{"StyleState:Void(styleState:String)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("styleState",&l_styleState);
  bbDBStmt(352258);
  if((l_styleState==this->m__0styleState)){
    bbDBBlock db_blk;
    bbDBStmt(352284);
    return;
  }
  bbDBStmt(360450);
  this->m__0styleState=l_styleState;
  bbDBStmt(368642);
  this->m_InvalidateStyle();
}

bbString t_mojo_app_View::m_StyleState(){
  bbDBFrame db_f{"StyleState:String()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(339970);
  return this->m__0styleState;
}

t_std_geom_Rect_1i t_mojo_app_View::m_StyleBounds(){
  bbDBFrame db_f{"StyleBounds:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3063810);
  return this->m__0styleBounds;
}

void t_mojo_app_View::m_Style(t_mojo_app_Style* l_style){
  bbDBFrame db_f{"Style:Void(style:mojo.app.Style)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("style",&l_style);
  bbDBStmt(294914);
  if((l_style==this->m__0style)){
    bbDBBlock db_blk;
    bbDBStmt(294930);
    return;
  }
  bbDBStmt(303106);
  this->m__0style=l_style;
  bbDBStmt(311298);
  this->m_InvalidateStyle();
}

t_mojo_app_Style* t_mojo_app_View::m_Style(){
  bbDBFrame db_f{"Style:mojo.app.Style()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(282626);
  return this->m__0style;
}

void t_mojo_app_View::m_SendMouseEvent(t_mojo_app_MouseEvent* l_event){
  bbDBFrame db_f{"SendMouseEvent:Void(event:mojo.app.MouseEvent)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbDBStmt(1708034);
  if(!this->m_ReallyEnabled()){
    bbDBBlock db_blk;
    t_mojo_app_EventType l_0=l_event->m_Type();
    bbDBLocal("0",&l_0);
    bbDBStmt(1712131);
    if(l_0==t_mojo_app_EventType(5)||l_0==t_mojo_app_EventType(9)){
      bbDBBlock db_blk;
      bbDBStmt(1720324);
      this->m_OnMouseEvent(l_event);
    }
    bbDBStmt(1728515);
    return;
  }
  bbDBStmt(1740802);
  this->m_OnMouseEvent(l_event);
  bbDBStmt(1748994);
  if(l_event->m_Eaten()){
    bbDBBlock db_blk;
    bbDBStmt(1749009);
    return;
  }
  t_mojo_app_EventType l_1=l_event->m_Type();
  bbDBLocal("1",&l_1);
  bbDBStmt(1757186);
  if(l_1==t_mojo_app_EventType(7)){
    struct f1_t : public bbGCFrame{
      t_mojo_app_View* l_view{};
      void gcMark(){
        bbGCMarkPtr(l_view);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(1765385);
    f1.l_view=this->m__0parent;
    bbDBLocal("view",&f1.l_view);
    bbDBStmt(1769475);
    {
      bbDBLoop db_loop;
      while(bbBool(f1.l_view)){
        bbDBBlock db_blk;
        bbDBStmt(1773572);
        f1.l_view->m_OnMouseEvent(l_event);
        bbDBStmt(1777668);
        if(l_event->m_Eaten()){
          bbDBBlock db_blk;
          bbDBStmt(1777683);
          return;
        }
        bbDBStmt(1781764);
        f1.l_view=f1.l_view->m__0parent;
      }
    }
  }
}

void t_mojo_app_View::m_SendKeyEvent(t_mojo_app_KeyEvent* l_event){
  bbDBFrame db_f{"SendKeyEvent:Void(event:mojo.app.KeyEvent)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbDBStmt(1822722);
  if(!this->m_ReallyEnabled()){
    bbDBBlock db_blk;
    bbDBStmt(1822743);
    return;
  }
  bbDBStmt(1830914);
  this->m_OnKeyEvent(l_event);
}

t_mojo_app_Style* t_mojo_app_View::m_RenderStyle(){
  bbDBFrame db_f{"RenderStyle:mojo.app.Style()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(397314);
  this->m_ValidateStyle();
  bbDBStmt(405506);
  return this->m__0rstyle;
}

t_std_geom_Rect_1i t_mojo_app_View::m_RenderRect(){
  bbDBFrame db_f{"RenderRect:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1015810);
  return this->m__0rclip;
}

t_std_geom_AffineMat3_1f t_mojo_app_View::m_RenderMatrix(){
  bbDBFrame db_f{"RenderMatrix:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1101826);
  return this->m__0rmatrix;
}

t_std_geom_Rect_1i t_mojo_app_View::m_RenderBounds(){
  bbDBFrame db_f{"RenderBounds:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1044482);
  return this->m__0rbounds;
}

void t_mojo_app_View::m_Render(t_mojo_graphics_Canvas* l_canvas){
  bbDBFrame db_f{"Render:Void(canvas:mojo.graphics.Canvas)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
  bbDBStmt(2629634);
  if(!this->m__0visible){
    bbDBBlock db_blk;
    bbDBStmt(2629650);
    return;
  }
  bbDBStmt(2637826);
  l_canvas->m_BeginRender(this->m__0bounds,this->m__0matrix);
  bbDBStmt(2646018);
  this->m__0rstyle->m_Render(l_canvas,t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m__0bounds.m_Size()));
  bbDBStmt(2654210);
  l_canvas->m_Viewport(this->m__0rect);
  bbDBStmt(2662402);
  this->m_OnRender(l_canvas);
  bbDBStmt(2670594);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=this->m__0children->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_view=f1.l_0.m_Current();
      bbDBLocal("view",&f2.l_view);
      bbDBStmt(2674691);
      f2.l_view->m_Render(l_canvas);
    }
  }
  bbDBStmt(2686978);
  l_canvas->m_EndRender();
}

void t_mojo_app_View::m_RemoveChild(t_mojo_app_View* l_view){
  bbDBFrame db_f{"RemoveChild:Void(view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("view",&l_view);
  bbDBStmt(1212418);
  if(!bbBool(l_view)){
    bbDBBlock db_blk;
    bbDBStmt(1212430);
    return;
  }
  bbDBStmt(1220610);
  bbAssert((l_view->m__0parent==this),BB_T("Assert failed"));
  bbDBStmt(1228802);
  this->m__0children->m_Remove(l_view,bbInt(0));
  bbDBStmt(1236994);
  l_view->m__0parent=((t_mojo_app_View*)0);
}

t_std_geom_Rect_1i t_mojo_app_View::m_Rect(){
  bbDBFrame db_f{"Rect:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(823298);
  return this->m__0rect;
}

bbBool t_mojo_app_View::m_ReallyVisible(){
  bbDBFrame db_f{"ReallyVisible:Bool()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(143362);
  return (this->m__0visible&&(!bbBool(this->m__0parent)||this->m__0parent->m_ReallyVisible()));
}

bbBool t_mojo_app_View::m_ReallyEnabled(){
  bbDBFrame db_f{"ReallyEnabled:Bool()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(253954);
  return ((this->m__0enabled&&this->m__0visible)&&(!bbBool(this->m__0parent)||this->m__0parent->m_ReallyEnabled()));
}

t_mojo_app_View* t_mojo_app_View::m_Parent(){
  bbDBFrame db_f{"Parent:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1130498);
  return this->m__0parent;
}

void t_mojo_app_View::m_OnValidateStyle(){
  bbDBFrame db_f{"OnValidateStyle:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
}

void t_mojo_app_View::m_OnRenderBounds(t_mojo_graphics_Canvas* l_canvas){
  bbDBFrame db_f{"OnRenderBounds:Void(canvas:mojo.graphics.Canvas)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
}

void t_mojo_app_View::m_OnRender(t_mojo_graphics_Canvas* l_canvas){
  bbDBFrame db_f{"OnRender:Void(canvas:mojo.graphics.Canvas)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
}

void t_mojo_app_View::m_OnMouseEvent(t_mojo_app_MouseEvent* l_event){
  bbDBFrame db_f{"OnMouseEvent:Void(event:mojo.app.MouseEvent)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
}

t_std_geom_Vec2_1i t_mojo_app_View::m_OnMeasure2(t_std_geom_Vec2_1i l_size){
  bbDBFrame db_f{"OnMeasure2:Vec2i:std.geom.Vec2<Int>(size:Vec2i:std.geom.Vec2<Int>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("size",&l_size);
  bbDBStmt(2781186);
  return t_std_geom_Vec2_1i(bbInt(0),bbInt(0));
}

t_std_geom_Vec2_1i t_mojo_app_View::m_OnMeasure(){
  bbDBFrame db_f{"OnMeasure:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2752514);
  return t_std_geom_Vec2_1i(bbInt(0),bbInt(0));
}

void t_mojo_app_View::m_OnMakeKeyView(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_window{};
    void gcMark(){
      bbGCMarkPtr(l_window);
    }
  }f0{};
  bbDBFrame db_f{"OnMakeKeyView:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2904072);
  f0.l_window=this->m_FindWindow();
  bbDBLocal("window",&f0.l_window);
  bbDBStmt(2908162);
  if(bbBool(f0.l_window)){
    bbDBBlock db_blk;
    bbDBStmt(2908172);
    f0.l_window->m_KeyView(this);
  }
}

void t_mojo_app_View::m_OnLayout(){
  bbDBFrame db_f{"OnLayout:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2809858);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=this->m__0children->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_view=f1.l_0.m_Current();
      bbDBLocal("view",&f2.l_view);
      bbDBStmt(2813955);
      f2.l_view->m_Frame(this->m_Rect());
    }
  }
}

void t_mojo_app_View::m_OnKeyEvent(t_mojo_app_KeyEvent* l_event){
  bbDBFrame db_f{"OnKeyEvent:Void(event:mojo.app.KeyEvent)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
}

void t_mojo_app_View::m_Offset(t_std_geom_Vec2_1i l_offset){
  bbDBFrame db_f{"Offset:Void(offset:Vec2i:std.geom.Vec2<Int>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("offset",&l_offset);
  bbDBStmt(659458);
  if((bbCompare(l_offset,this->m__0offset)==0)){
    bbDBBlock db_blk;
    bbDBStmt(659476);
    return;
  }
  bbDBStmt(667650);
  this->m__0offset=l_offset;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_Offset(){
  bbDBFrame db_f{"Offset:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(647170);
  return this->m__0offset;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_MouseLocation(){
  bbDBFrame db_f{"MouseLocation:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(937986);
  return this->m_TransformPointFromView(g_mojo_app_App->m_MouseLocation(),((t_mojo_app_View*)0));
}

void t_mojo_app_View::m_MinSize(t_std_geom_Vec2_1i l_minSize){
  bbDBFrame db_f{"MinSize:Void(minSize:Vec2i:std.geom.Vec2<Int>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("minSize",&l_minSize);
  bbDBStmt(712706);
  this->m__0minSize=l_minSize;
  bbDBStmt(720898);
  this->m_InvalidateStyle();
}

t_std_geom_Vec2_1i t_mojo_app_View::m_MinSize(){
  bbDBFrame db_f{"MinSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(696322);
  return this->m__0minSize;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_MeasuredSize(){
  bbDBFrame db_f{"MeasuredSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3006466);
  return this->m__0measuredSize;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_Measure2(t_std_geom_Vec2_1i l_size){
  bbDBFrame db_f{"Measure2:Vec2i:std.geom.Vec2<Int>(size:Vec2i:std.geom.Vec2<Int>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("size",&l_size);
  bbDBStmt(3088386);
  l_size=this->m_OnMeasure2(l_size.m__sub(this->m__0styleBounds.m_Size()));
  bbDBStmt(3092482);
  if((bbBool(l_size.m_x)&&bbBool(l_size.m_y))){
    bbDBBlock db_blk;
    bbDBStmt(3092503);
    this->m__0layoutSize=l_size.m__add(this->m__0styleBounds.m_Size());
  }
  bbDBStmt(3096578);
  return this->m__0layoutSize;
}

void t_mojo_app_View::m_Measure(){
  bbDBFrame db_f{"Measure:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2093058);
  if(!this->m__0visible){
    bbDBBlock db_blk;
    bbDBStmt(2093074);
    return;
  }
  bbDBStmt(2101250);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=this->m__0children->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_view=f1.l_0.m_Current();
      bbDBLocal("view",&f2.l_view);
      bbDBStmt(2109443);
      f2.l_view->m_Measure();
    }
  }
  bbDBStmt(2125826);
  this->m_ValidateStyle();
  bbDBStmt(2134024);
  t_std_geom_Vec2_1i l_size=this->m_OnMeasure();
  bbDBLocal("size",&l_size);
  bbDBStmt(2142210);
  if(bbBool(this->m__0minSize.m_x)){
    bbDBBlock db_blk;
    bbDBStmt(2142224);
    l_size.m_x=g_monkey_math_Max_1i(l_size.m_x,this->m__0minSize.m_x);
  }
  bbDBStmt(2146306);
  if(bbBool(this->m__0minSize.m_y)){
    bbDBBlock db_blk;
    bbDBStmt(2146320);
    l_size.m_y=g_monkey_math_Max_1i(l_size.m_y,this->m__0minSize.m_y);
  }
  bbDBStmt(2150402);
  if(bbBool(this->m__0maxSize.m_x)){
    bbDBBlock db_blk;
    bbDBStmt(2150416);
    l_size.m_x=g_monkey_math_Min_1i(l_size.m_x,this->m__0maxSize.m_x);
  }
  bbDBStmt(2154498);
  if(bbBool(this->m__0maxSize.m_y)){
    bbDBBlock db_blk;
    bbDBStmt(2154512);
    l_size.m_y=g_monkey_math_Min_1i(l_size.m_y,this->m__0maxSize.m_y);
  }
  bbDBStmt(2162690);
  this->m__0measuredSize=l_size;
  bbDBStmt(2170882);
  this->m__0layoutSize=l_size.m__add(this->m__0styleBounds.m_Size());
}

void t_mojo_app_View::m_MaxSize(t_std_geom_Vec2_1i l_maxSize){
  bbDBFrame db_f{"MaxSize:Void(maxSize:Vec2i:std.geom.Vec2<Int>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("maxSize",&l_maxSize);
  bbDBStmt(765954);
  this->m__0maxSize=l_maxSize;
  bbDBStmt(774146);
  this->m_InvalidateStyle();
}

t_std_geom_Vec2_1i t_mojo_app_View::m_MaxSize(){
  bbDBFrame db_f{"MaxSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(749570);
  return this->m__0maxSize;
}

void t_mojo_app_View::m_MakeKeyView(){
  bbDBFrame db_f{"MakeKeyView:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1671170);
  if(!this->m_ReallyEnabled()){
    bbDBBlock db_blk;
    bbDBStmt(1671191);
    return;
  }
  bbDBStmt(1679362);
  this->m_OnMakeKeyView();
}

t_std_geom_AffineMat3_1f t_mojo_app_View::m_LocalMatrix(){
  bbDBFrame db_f{"LocalMatrix:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1073154);
  return this->m__0matrix;
}

t_std_geom_Vec2_1i t_mojo_app_View::m_LayoutSize(){
  bbDBFrame db_f{"LayoutSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3035138);
  return this->m__0layoutSize;
}

void t_mojo_app_View::m_Layout(bbString l_layout){
  bbDBFrame db_f{"Layout:Void(layout:String)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("layout",&l_layout);
  bbDBStmt(487426);
  if((l_layout==this->m__0layout)){
    bbDBBlock db_blk;
    bbDBStmt(487444);
    return;
  }
  bbDBStmt(495618);
  this->m__0layout=l_layout;
}

bbString t_mojo_app_View::m_Layout(){
  bbDBFrame db_f{"Layout:String()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(475138);
  return this->m__0layout;
}

bbBool t_mojo_app_View::m_IsChildOf(t_mojo_app_View* l_view){
  bbDBFrame db_f{"IsChildOf:Bool(view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("view",&l_view);
  bbDBStmt(1925122);
  if((l_view==this)){
    bbDBBlock db_blk;
    bbDBStmt(1925135);
    return true;
  }
  bbDBStmt(1933314);
  if(bbBool(this->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(1933325);
    return this->m__0parent->m_IsChildOf(l_view);
  }
  bbDBStmt(1941506);
  return false;
}

void t_mojo_app_View::m_InvalidateStyle(){
  bbDBFrame db_f{"InvalidateStyle:Void()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1970178);
  this->m__0dirty=t_mojo_app_View_Dirty((int(this->m__0dirty)|int(t_mojo_app_View_Dirty(1))));
}

bbInt t_mojo_app_View::m_Height(){
  bbDBFrame db_f{"Height:Int()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(880642);
  return this->m__0rect.m_Height();
}

void t_mojo_app_View::m_Gravity(t_std_geom_Vec2_1f l_gravity){
  bbDBFrame db_f{"Gravity:Void(gravity:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("gravity",&l_gravity);
  bbDBStmt(610306);
  if((bbCompare(l_gravity,this->m__0gravity)==0)){
    bbDBBlock db_blk;
    bbDBStmt(610326);
    return;
  }
  bbDBStmt(618498);
  this->m__0gravity=l_gravity;
}

t_std_geom_Vec2_1f t_mojo_app_View::m_Gravity(){
  bbDBFrame db_f{"Gravity:Vec2f:std.geom.Vec2<Float>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(598018);
  return this->m__0gravity;
}

void t_mojo_app_View::m_Frame(t_std_geom_Rect_1i l_frame){
  bbDBFrame db_f{"Frame:Void(frame:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("frame",&l_frame);
  bbDBStmt(557058);
  if((bbCompare(l_frame,this->m__0frame)==0)){
    bbDBBlock db_blk;
    bbDBStmt(557074);
    return;
  }
  bbDBStmt(565250);
  this->m__0frame=l_frame;
}

t_std_geom_Rect_1i t_mojo_app_View::m_Frame(){
  bbDBFrame db_f{"Frame:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(544770);
  return this->m__0frame;
}

t_mojo_app_Window* t_mojo_app_View::m_FindWindow(){
  bbDBFrame db_f{"FindWindow:mojo.app.Window()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1888258);
  if(bbBool(this->m__0parent)){
    bbDBBlock db_blk;
    bbDBStmt(1888269);
    return this->m__0parent->m_FindWindow();
  }
  bbDBStmt(1896450);
  return ((t_mojo_app_Window*)0);
}

t_mojo_app_View* t_mojo_app_View::m_FindViewAtWindowPoint(t_std_geom_Vec2_1i l_point){
  bbDBFrame db_f{"FindViewAtWindowPoint:mojo.app.View(point:Vec2i:std.geom.Vec2<Int>)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("point",&l_point);
  bbDBStmt(1265666);
  if(!this->m__0visible){
    bbDBBlock db_blk;
    bbDBStmt(1265682);
    return ((t_mojo_app_View*)0);
  }
  bbDBStmt(1273858);
  if(!this->m__0rbounds.m_Contains(l_point)){
    bbDBBlock db_blk;
    bbDBStmt(1273892);
    return ((t_mojo_app_View*)0);
  }
  bbDBStmt(1282050);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1282050);
    for(;(l_i<this->m__0children->m_Length());l_i+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_child{};
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_child);
          bbGCMarkPtr(l_view);
        }
      }f2{};
      bbDBBlock db_blk;
      bbDBStmt(1290249);
      f2.l_child=this->m__0children->m__idx(((this->m__0children->m_Length()-l_i)-1));
      bbDBLocal("child",&f2.l_child);
      bbDBStmt(1298441);
      f2.l_view=f2.l_child->m_FindViewAtWindowPoint(l_point);
      bbDBLocal("view",&f2.l_view);
      bbDBStmt(1302531);
      if(bbBool(f2.l_view)){
        bbDBBlock db_blk;
        bbDBStmt(1302539);
        return f2.l_view;
      }
    }
  }
  bbDBStmt(1318914);
  return this;
}

void t_mojo_app_View::m_Enabled(bbBool l_enabled){
  bbDBFrame db_f{"Enabled:Void(enabled:Bool)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("enabled",&l_enabled);
  bbDBStmt(196610);
  if((l_enabled==this->m__0enabled)){
    bbDBBlock db_blk;
    bbDBStmt(196630);
    return;
  }
  bbDBStmt(204802);
  this->m__0enabled=l_enabled;
  bbDBStmt(212994);
  this->m_InvalidateStyle();
}

bbBool t_mojo_app_View::m_Enabled(){
  bbDBFrame db_f{"Enabled:Bool()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(184322);
  return this->m__0enabled;
}

t_mojo_app_View* t_mojo_app_View::m_Container(){
  bbDBFrame db_f{"Container:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1859586);
  return this;
}

t_std_geom_Rect_1i t_mojo_app_View::m_ClipRect(){
  bbDBFrame db_f{"ClipRect:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(987138);
  return this->m__0clip;
}

t_std_geom_Rect_1i t_mojo_app_View::m_Bounds(){
  bbDBFrame db_f{"Bounds:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(909314);
  return this->m__0bounds;
}

void t_mojo_app_View::m_AddChild(t_mojo_app_View* l_view){
  bbDBFrame db_f{"AddChild:Void(view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/view.monkey2"};
  t_mojo_app_View*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("view",&l_view);
  bbDBStmt(1159170);
  if(!bbBool(l_view)){
    bbDBBlock db_blk;
    bbDBStmt(1159182);
    return;
  }
  bbDBStmt(1167362);
  bbAssert(!bbBool(l_view->m__0parent),BB_T("Assert failed"));
  bbDBStmt(1175554);
  this->m__0children->m_Add(l_view);
  bbDBStmt(1183746);
  l_view->m__0parent=this;
}
bbString bbDBType(t_mojo_app_View**){
  return "mojo.app.View";
}
bbString bbDBValue(t_mojo_app_View**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_app_2view_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_app_2view_init_v("mojo_app_2view",&mx2_mojo_app_2view_init);
