
#include "../../desktop_debug_pi/mojo_graphics_2shader.h"

// ***** External *****

#include "../../../../gles20/gles20.buildv1.0.2/desktop_debug_pi/gles20_gles20.h"
#include "../../desktop_debug_pi/mojo_graphics_2texture.h"
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"

extern bbInt g_mojo_graphics_glutil_glGraphicsSeq;

extern bbString g_std_stringio_LoadString(bbString l_path);
extern bbInt g_mojo_graphics_glutil_glCompile(bbInt l_type,bbString l_source);
extern void g_mojo_graphics_glutil_glLink(bbInt l_program);

// ***** Internal *****

bbGCRootVar<t_std_collections_Map_1si> g_mojo_graphics_ShaderParam__0ids;
bbInt g_mojo_graphics_ShaderParam__0nextId;
bbInt g_mojo_graphics_ShaderEnv__0nextId;
bbGCRootVar<t_mojo_graphics_ShaderProgram> g_mojo_graphics_Shader__0bound;
bbInt g_mojo_graphics_Shader__0seq;
bbGCRootVar<t_std_collections_Map_1sTt_mojo_graphics_Shader_2> g_mojo_graphics_Shader__0shaders;

t_mojo_graphics_Shader* g_mojo_graphics_Shader_GetShader(bbString l_name){
  bbDBFrame db_f{"GetShader:mojo.graphics.Shader(name:String)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  bbDBLocal("name",&l_name);
  bbDBStmt(1314818);
  if(!bbBool(g_mojo_graphics_Shader__0shaders)){
    struct f1_t : public bbGCFrame{
      t_mojo_graphics_Shader* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(1318915);
    g_mojo_graphics_Shader__0shaders=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Shader_2>();
    bbDBStmt(1323011);
    g_mojo_graphics_Shader__0shaders->m__idxeq(BB_T("sprite"),f1.t0=bbGCNew<t_mojo_graphics_Shader>(g_std_stringio_LoadString(BB_T("asset::mojo/shader_sprite.glsl"))));
    bbDBStmt(1327107);
    g_mojo_graphics_Shader__0shaders->m__idxeq(BB_T("phong"),f1.t0=bbGCNew<t_mojo_graphics_Shader>(g_std_stringio_LoadString(BB_T("asset::mojo/shader_phong.glsl"))));
    bbDBStmt(1331203);
    g_mojo_graphics_Shader__0shaders->m__idxeq(BB_T("font"),f1.t0=bbGCNew<t_mojo_graphics_Shader>(g_std_stringio_LoadString(BB_T("asset::mojo/shader_font.glsl"))));
    bbDBStmt(1335299);
    g_mojo_graphics_Shader__0shaders->m__idxeq(BB_T("null"),f1.t0=bbGCNew<t_mojo_graphics_Shader>(g_std_stringio_LoadString(BB_T("asset::mojo/shader_null.glsl"))));
  }
  bbDBStmt(1347586);
  return g_mojo_graphics_Shader__0shaders->m__idx(l_name);
}

bbInt g_mojo_graphics_ShaderParam_ParamId(bbString l_name){
  bbDBFrame db_f{"ParamId:Int(name:String)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  bbDBLocal("name",&l_name);
  bbDBStmt(839688);
  bbInt l_id=g_mojo_graphics_ShaderParam__0ids->m__idx(l_name);
  bbDBLocal("id",&l_id);
  bbDBStmt(843778);
  if(bbBool(l_id)){
    bbDBBlock db_blk;
    bbDBStmt(843784);
    return l_id;
  }
  bbDBStmt(847874);
  g_mojo_graphics_ShaderParam__0nextId+=1;
  bbDBStmt(851970);
  g_mojo_graphics_ShaderParam__0ids->m__idxeq(l_name,g_mojo_graphics_ShaderParam__0nextId);
  bbDBStmt(860162);
  return g_mojo_graphics_ShaderParam__0nextId;
}

void g_mojo_graphics_BindUniforms(bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_uniforms,t_mojo_graphics_ParamBuffer* l_params,bbBool l_filter){
  bbDBFrame db_f{"BindUniforms:Void(uniforms:mojo.graphics.Uniform[],params:mojo.graphics.ParamBuffer,filter:Bool)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  bbDBLocal("uniforms",&l_uniforms);
  bbDBLocal("params",&l_params);
  bbDBLocal("filter",&l_filter);
  bbDBStmt(53249);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_uniforms->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_ShaderParam l_p{};
        t_mojo_graphics_Uniform* l_u{};
        void gcMark(){
          bbGCMark(l_p);
          bbGCMarkPtr(l_u);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_u=l_uniforms->at(l_0);
      bbDBLocal("u",&f2.l_u);
      bbDBStmt(61448);
      f2.l_p=l_params->m__0params->at(f2.l_u->m_id);
      bbDBLocal("p",&f2.l_p);
      bbDBStmt(69634);
      if(f2.l_u->m_type==GL_FLOAT){
        bbDBBlock db_blk;
        bbDBStmt(77827);
        glUniform1f(f2.l_u->m_location,f2.l_p.m_scalar);
      }else if(f2.l_u->m_type==GL_FLOAT_VEC4){
        bbDBBlock db_blk;
        bbDBStmt(86019);
        glUniform4fv(f2.l_u->m_location,1,&f2.l_p.m_vector.m_x);
      }else if(f2.l_u->m_type==GL_FLOAT_MAT4){
        bbDBBlock db_blk;
        bbDBStmt(94211);
        glUniformMatrix4fv(f2.l_u->m_location,1,false,&f2.l_p.m_matrix.m_i.m_x);
      }else if(f2.l_u->m_type==GL_SAMPLER_2D){
        struct f3_t : public bbGCFrame{
          t_mojo_graphics_Texture* l_tex{};
          void gcMark(){
            bbGCMarkPtr(l_tex);
          }
        }f3{};
        bbDBBlock db_blk;
        bbDBStmt(102409);
        f3.l_tex=f2.l_p.m_texture;
        bbDBLocal("tex",&f3.l_tex);
        bbDBStmt(106499);
        bbDebugAssert(bbBool(f3.l_tex),((BB_T("Can't bind shader texture uniform '")+f2.l_u->m_name)+BB_T("' - no texture!")));
        bbDBStmt(110595);
        glActiveTexture((GL_TEXTURE0+f2.l_u->m_texunit));
        bbDBStmt(114691);
        glBindTexture(GL_TEXTURE_2D,f3.l_tex->m_GLTexture());
        bbDBStmt(118787);
        if((bbBool(t_mojo_graphics_TextureFlags((int(f3.l_tex->m_Flags())&int(t_mojo_graphics_TextureFlags(1)))))&&l_filter)){
          bbDBBlock db_blk;
          bbDBStmt(122884);
          glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        }else{
          bbDBStmt(126979);
          bbDBBlock db_blk;
          bbDBStmt(131076);
          glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
        }
        bbDBStmt(139267);
        glUniform1i(f2.l_u->m_location,f2.l_u->m_texunit);
      }else{
        bbDBBlock db_blk;
        bbDBStmt(147459);
        bbAssert(false,(BB_T("Unsupported uniform type for param:")+f2.l_u->m_name));
      }
    }
  }
  bbDBStmt(167937);
  glActiveTexture(GL_TEXTURE0);
}

void t_mojo_graphics_Uniform::dbEmit(){
  bbDBEmit("name",&m_name);
  bbDBEmit("id",&m_id);
  bbDBEmit("location",&m_location);
  bbDBEmit("texunit",&m_texunit);
  bbDBEmit("size",&m_size);
  bbDBEmit("type",&m_type);
}

t_mojo_graphics_Uniform::t_mojo_graphics_Uniform(bbString l_name,bbInt l_location,bbInt l_texunit,bbInt l_size,bbInt l_type){
  bbDBFrame db_f{"new:Void(name:String,location:Int,texunit:Int,size:Int,type:Int)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  bbDBLocal("name",&l_name);
  bbDBLocal("location",&l_location);
  bbDBLocal("texunit",&l_texunit);
  bbDBLocal("size",&l_size);
  bbDBLocal("type",&l_type);
  bbDBStmt(221186);
  this->m_name=l_name;
  bbDBStmt(225282);
  this->m_id=g_mojo_graphics_ShaderParam_ParamId(this->m_name);
  bbDBStmt(229378);
  this->m_texunit=l_texunit;
  bbDBStmt(233474);
  this->m_location=l_location;
  bbDBStmt(237570);
  this->m_size=l_size;
  bbDBStmt(241666);
  this->m_type=l_type;
}
bbString bbDBType(t_mojo_graphics_Uniform**){
  return "mojo.graphics.Uniform";
}
bbString bbDBValue(t_mojo_graphics_Uniform**p){
  return bbDBObjectValue(*p);
}

void t_mojo_graphics_ParamBuffer::init(){
  m__0params=bbArray<t_mojo_graphics_ShaderParam>::create(32);
}

void t_mojo_graphics_ParamBuffer::gcMark(){
  bbGCMark(m__0params);
}

void t_mojo_graphics_ParamBuffer::dbEmit(){
  bbDBEmit("_params",&m__0params);
}

void t_mojo_graphics_ParamBuffer::m_SetVector(bbString l_name,t_std_geom_Vec4_1f l_value){
  bbDBFrame db_f{"SetVector:Void(name:String,value:Vec4f:std.geom.Vec4<Float>)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ParamBuffer*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("value",&l_value);
  bbDBStmt(1028098);
  this->m__0params->at(g_mojo_graphics_ShaderParam_ParamId(l_name)).m_vector=l_value;
}

void t_mojo_graphics_ParamBuffer::m_SetTexture(bbString l_name,t_mojo_graphics_Texture* l_value){
  bbDBFrame db_f{"SetTexture:Void(name:String,value:mojo.graphics.Texture)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ParamBuffer*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("value",&l_value);
  bbDBStmt(1060866);
  this->m__0params->at(g_mojo_graphics_ShaderParam_ParamId(l_name)).m_texture=l_value;
}

void t_mojo_graphics_ParamBuffer::m_SetMatrix(bbString l_name,t_std_geom_Mat4_1f l_value){
  bbDBFrame db_f{"SetMatrix:Void(name:String,value:Mat4f:std.geom.Mat4<Float>)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ParamBuffer*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("value",&l_value);
  bbDBStmt(1044482);
  this->m__0params->at(g_mojo_graphics_ShaderParam_ParamId(l_name)).m_matrix=l_value;
}

void t_mojo_graphics_ParamBuffer::m_SetColor(bbString l_name,t_std_graphics_Color l_value){
  bbDBFrame db_f{"SetColor:Void(name:String,value:std.graphics.Color)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ParamBuffer*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("value",&l_value);
  bbDBStmt(1077250);
  this->m__0params->at(g_mojo_graphics_ShaderParam_ParamId(l_name)).m_vector=t_std_geom_Vec4_1f(l_value.m_r,l_value.m_g,l_value.m_b,l_value.m_a);
}
bbString bbDBType(t_mojo_graphics_ParamBuffer**){
  return "mojo.graphics.ParamBuffer";
}
bbString bbDBValue(t_mojo_graphics_ParamBuffer**p){
  return bbDBObjectValue(*p);
}

void t_mojo_graphics_ShaderProgram::gcMark(){
  bbGCMark(m__0sources);
  bbGCMark(m__0envUniforms);
  bbGCMark(m__0uniforms);
}

void t_mojo_graphics_ShaderProgram::dbEmit(){
  bbDBEmit("_sources",&m__0sources);
  bbDBEmit("_seq",&m__0seq);
  bbDBEmit("_glProgram",&m__0glProgram);
  bbDBEmit("_envUniforms",&m__0envUniforms);
  bbDBEmit("_uniforms",&m__0uniforms);
}

t_mojo_graphics_ShaderProgram::t_mojo_graphics_ShaderProgram(bbArray<bbString>* l_sources){
  bbDBFrame db_f{"new:Void(sources:String[])","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  bbDBLocal("sources",&l_sources);
  bbDBStmt(278530);
  this->m__0sources=l_sources;
}

bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t_mojo_graphics_ShaderProgram::m_Uniforms(){
  bbDBFrame db_f{"Uniforms:mojo.graphics.Uniform[]()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ShaderProgram*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(339970);
  return this->m__0uniforms;
}

bbArray<bbString>* t_mojo_graphics_ShaderProgram::m_Sources(){
  bbDBFrame db_f{"Sources:String[]()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ShaderProgram*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(299010);
  return this->m__0sources;
}

bbUInt t_mojo_graphics_ShaderProgram::m_GLProgram(){
  bbDBFrame db_f{"GLProgram:GLuint:Uint()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ShaderProgram*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(360450);
  if((this->m__0seq==g_mojo_graphics_glutil_glGraphicsSeq)){
    bbDBBlock db_blk;
    bbDBStmt(364547);
    return this->m__0glProgram;
  }
  bbDBStmt(376834);
  this->m_BuildProgram();
  bbDBStmt(385026);
  this->m_EnumUniforms();
  bbDBStmt(393218);
  this->m__0seq=g_mojo_graphics_glutil_glGraphicsSeq;
  bbDBStmt(401410);
  return this->m__0glProgram;
}

bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t_mojo_graphics_ShaderProgram::m_EnvUniforms(){
  bbDBFrame db_f{"EnvUniforms:mojo.graphics.Uniform[]()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ShaderProgram*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(319490);
  return this->m__0envUniforms;
}

void t_mojo_graphics_ShaderProgram::m_EnumUniforms(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_envUniforms{};
    bbArray<bbByte>* l_nameBuf{};
    t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_uniforms{};
    void gcMark(){
      bbGCMarkPtr(l_envUniforms);
      bbGCMarkPtr(l_nameBuf);
      bbGCMarkPtr(l_uniforms);
    }
  }f0{};
  bbDBFrame db_f{"EnumUniforms:Void()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ShaderProgram*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(638984);
  f0.l_envUniforms=bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2>();
  bbDBLocal("envUniforms",&f0.l_envUniforms);
  bbDBStmt(643080);
  f0.l_uniforms=bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2>();
  bbDBLocal("uniforms",&f0.l_uniforms);
  bbDBStmt(651272);
  bbInt l_n{};
  bbDBLocal("n",&l_n);
  bbDBStmt(655362);
  glGetProgramiv(this->m__0glProgram,GL_ACTIVE_UNIFORMS,&l_n);
  bbDBStmt(663560);
  bbInt l_size{};
  bbDBLocal("size",&l_size);
  bbDBStmt(663569);
  bbUInt l_type{};
  bbDBLocal("type",&l_type);
  bbDBStmt(663579);
  bbInt l_length{};
  bbDBLocal("length",&l_length);
  bbDBStmt(663590);
  f0.l_nameBuf=bbArray<bbByte>::create(256);
  bbDBLocal("nameBuf",&f0.l_nameBuf);
  bbDBStmt(663613);
  bbInt l_texunit=bbInt(0);
  bbDBLocal("texunit",&l_texunit);
  bbDBStmt(671746);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(671746);
    for(;(l_i<l_n);l_i+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_Uniform* l_u{};
        void gcMark(){
          bbGCMarkPtr(l_u);
        }
      }f2{};
      bbDBBlock db_blk;
      bbDBStmt(679939);
      glGetActiveUniform(this->m__0glProgram,bbUInt(l_i),f0.l_nameBuf->length(),&l_length,&l_size,&l_type,((char*)(&f0.l_nameBuf->at(bbInt(0)))));
      bbDBStmt(688137);
      bbString l_name=bbString::fromCString(((void*)(f0.l_nameBuf->data())));
      bbDBLocal("name",&l_name);
      bbDBStmt(696329);
      bbInt l_location=glGetUniformLocation(this->m__0glProgram,bbCString(l_name));
      bbDBLocal("location",&l_location);
      bbDBStmt(700419);
      if((l_location==-1)){
        bbDBBlock db_blk;
        bbDBStmt(700434);
        continue;
      }
      bbDBStmt(716809);
      f2.l_u=bbGCNew<t_mojo_graphics_Uniform>(l_name,l_location,l_texunit,l_size,bbInt(l_type));
      bbDBLocal("u",&f2.l_u);
      bbDBStmt(720899);
      if(l_name.startsWith(BB_T("mx2_"))){
        bbDBBlock db_blk;
        bbDBStmt(724996);
        f0.l_envUniforms->m_Push(f2.l_u);
      }else{
        bbDBStmt(729091);
        bbDBBlock db_blk;
        bbDBStmt(733188);
        f0.l_uniforms->m_Push(f2.l_u);
      }
      bbDBStmt(741379);
      if(l_type==bbUInt(GL_SAMPLER_2D)){
        bbDBBlock db_blk;
        bbDBStmt(749572);
        l_texunit+=1;
      }
    }
  }
  bbDBStmt(765954);
  this->m__0envUniforms=f0.l_envUniforms->m_ToArray();
  bbDBStmt(770050);
  this->m__0uniforms=f0.l_uniforms->m_ToArray();
}

void t_mojo_graphics_ShaderProgram::m_BuildProgram(){
  bbDBFrame db_f{"BuildProgram:Void()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ShaderProgram*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(458760);
  bbString l_csource=bbString{};
  bbDBLocal("csource",&l_csource);
  bbDBStmt(462856);
  bbString l_vsource=bbString{};
  bbDBLocal("vsource",&l_vsource);
  bbDBStmt(466952);
  bbString l_fsource=bbString{};
  bbDBLocal("fsource",&l_fsource);
  bbDBStmt(475138);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=this->m__0sources->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      bbDBBlock db_blk;
      bbString l_source=this->m__0sources->at(l_0);
      bbDBLocal("source",&l_source);
      bbDBStmt(479241);
      bbInt l_i0=l_source.find(BB_T("//@vertex"),bbInt(0));
      bbDBLocal("i0",&l_i0);
      bbDBStmt(483331);
      if((l_i0==-1)){
        bbDBBlock db_blk;
        bbDBStmt(487428);
        puts((BB_T("Shader source:\n")+l_source).c_str());fflush( stdout );
        bbDBStmt(491524);
        bbAssert(false,BB_T("Can't find //@vertex chunk"));
      }
      bbDBStmt(499721);
      bbInt l_i1=l_source.find(BB_T("//@fragment"),bbInt(0));
      bbDBLocal("i1",&l_i1);
      bbDBStmt(503811);
      if((l_i1==-1)){
        bbDBBlock db_blk;
        bbDBStmt(507908);
        puts((BB_T("Shader source:\n")+l_source).c_str());fflush( stdout );
        bbDBStmt(512004);
        bbAssert(false,BB_T("Can't find //@fragment chunk"));
      }
      bbDBStmt(524291);
      l_csource+=(l_source.slice(bbInt(0),l_i0)+BB_T("\n"));
      bbDBStmt(528387);
      l_vsource+=(l_source.slice(l_i0,l_i1)+BB_T("\n"));
      bbDBStmt(532483);
      l_fsource+=(l_source.slice(l_i1)+BB_T("\n"));
    }
  }
  bbDBStmt(544770);
  l_vsource=(l_csource+l_vsource);
  bbDBStmt(548866);
  l_fsource=(l_csource+l_fsource);
  bbDBStmt(557064);
  bbInt l_vshader=g_mojo_graphics_glutil_glCompile(GL_VERTEX_SHADER,l_vsource);
  bbDBLocal("vshader",&l_vshader);
  bbDBStmt(561160);
  bbInt l_fshader=g_mojo_graphics_glutil_glCompile(GL_FRAGMENT_SHADER,l_fsource);
  bbDBLocal("fshader",&l_fshader);
  bbDBStmt(569346);
  this->m__0glProgram=glCreateProgram();
  bbDBStmt(577538);
  glAttachShader(this->m__0glProgram,bbUInt(l_vshader));
  bbDBStmt(581634);
  glAttachShader(this->m__0glProgram,bbUInt(l_fshader));
  bbDBStmt(585730);
  glDeleteShader(bbUInt(l_vshader));
  bbDBStmt(589826);
  glDeleteShader(bbUInt(l_fshader));
  bbDBStmt(598018);
  glBindAttribLocation(this->m__0glProgram,bbUInt(0),bbCString(BB_T("mx2_VertexPosition")));
  bbDBStmt(602114);
  glBindAttribLocation(this->m__0glProgram,1,bbCString(BB_T("mx2_VertexTexCoord0")));
  bbDBStmt(606210);
  glBindAttribLocation(this->m__0glProgram,2,bbCString(BB_T("mx2_VertexTangent")));
  bbDBStmt(610306);
  glBindAttribLocation(this->m__0glProgram,3,bbCString(BB_T("mx2_VertexColor")));
  bbDBStmt(618498);
  g_mojo_graphics_glutil_glLink(bbInt(this->m__0glProgram));
}
bbString bbDBType(t_mojo_graphics_ShaderProgram**){
  return "mojo.graphics.ShaderProgram";
}
bbString bbDBValue(t_mojo_graphics_ShaderProgram**p){
  return bbDBObjectValue(*p);
}

void t_mojo_graphics_ShaderParam::dbEmit(t_mojo_graphics_ShaderParam*p){
  bbDBEmit("scalar",&p->m_scalar);
  bbDBEmit("vector",&p->m_vector);
  bbDBEmit("matrix",&p->m_matrix);
  bbDBEmit("texture",&p->m_texture);
}
bbString bbDBType(t_mojo_graphics_ShaderParam*){
  return "mojo.graphics.ShaderParam";
}
bbString bbDBValue(t_mojo_graphics_ShaderParam*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_mojo_graphics_ShaderParam&x,const t_mojo_graphics_ShaderParam&y){
  if(int t=bbCompare(x.m_scalar,y.m_scalar)) return t;
  if(int t=bbCompare(x.m_vector,y.m_vector)) return t;
  if(int t=bbCompare(x.m_matrix,y.m_matrix)) return t;
  if(int t=bbCompare(x.m_texture,y.m_texture)) return t;
  return 0;
}

void bbGCMark(const t_mojo_graphics_ShaderParam&t){
  bbGCMark(t.m_texture);
}

void t_mojo_graphics_ShaderEnv::dbEmit(){
  bbDBEmit("_source",&m__0source);
  bbDBEmit("_id",&m__0id);
}

t_mojo_graphics_ShaderEnv::t_mojo_graphics_ShaderEnv(bbString l_sourceCode){
  bbDBFrame db_f{"new:Void(sourceCode:String)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  bbDBLocal("sourceCode",&l_sourceCode);
  bbDBStmt(917506);
  this->m__0source=l_sourceCode;
  bbDBStmt(921602);
  this->m__0id=g_mojo_graphics_ShaderEnv__0nextId;
  bbDBStmt(925698);
  g_mojo_graphics_ShaderEnv__0nextId+=1;
}

bbString t_mojo_graphics_ShaderEnv::m_SourceCode(){
  bbDBFrame db_f{"SourceCode:String()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ShaderEnv*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(942082);
  return this->m__0source;
}

bbInt t_mojo_graphics_ShaderEnv::m_Id(){
  bbDBFrame db_f{"Id:Int()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_ShaderEnv*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(958466);
  return this->m__0id;
}
bbString bbDBType(t_mojo_graphics_ShaderEnv**){
  return "mojo.graphics.ShaderEnv";
}
bbString bbDBValue(t_mojo_graphics_ShaderEnv**p){
  return bbDBObjectValue(*p);
}

void t_mojo_graphics_Shader::init(){
  m__0programs=bbArray<bbGCVar<t_mojo_graphics_ShaderProgram>>::create(16);
}

void t_mojo_graphics_Shader::gcMark(){
  bbGCMark(m__0programs);
}

void t_mojo_graphics_Shader::dbEmit(){
  bbDBEmit("_source",&m__0source);
  bbDBEmit("_programs",&m__0programs);
}

t_mojo_graphics_Shader::t_mojo_graphics_Shader(bbString l_sourceCode){
  init();
  bbDBFrame db_f{"new:Void(sourceCode:String)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  bbDBLocal("sourceCode",&l_sourceCode);
  bbDBStmt(1130498);
  this->m__0source=l_sourceCode;
}

bbString t_mojo_graphics_Shader::m_SourceCode(){
  bbDBFrame db_f{"SourceCode:String()","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_Shader*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1146882);
  return this->m__0source;
}

void t_mojo_graphics_Shader::m_BindParams(t_mojo_graphics_ParamBuffer* l_params,bbBool l_filter){
  bbDBFrame db_f{"BindParams:Void(params:mojo.graphics.ParamBuffer,filter:Bool)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_Shader*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("params",&l_params);
  bbDBLocal("filter",&l_filter);
  bbDBStmt(1286146);
  g_mojo_graphics_BindUniforms(g_mojo_graphics_Shader__0bound->m__0uniforms,l_params,l_filter);
}

void t_mojo_graphics_Shader::m_BindEnvParams(t_mojo_graphics_ParamBuffer* l_params){
  bbDBFrame db_f{"BindEnvParams:Void(params:mojo.graphics.ParamBuffer)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_Shader*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("params",&l_params);
  bbDBStmt(1257474);
  g_mojo_graphics_BindUniforms(g_mojo_graphics_Shader__0bound->m__0envUniforms,l_params,true);
}

void t_mojo_graphics_Shader::m_Bind(t_mojo_graphics_ShaderEnv* l_env){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_ShaderProgram* l_p{};
    void gcMark(){
      bbGCMarkPtr(l_p);
    }
  }f0{};
  bbDBFrame db_f{"Bind:Void(env:mojo.graphics.ShaderEnv)","/home/pi/monkey2/modules/mojo/graphics/shader.monkey2"};
  t_mojo_graphics_Shader*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("env",&l_env);
  bbDBStmt(1175554);
  if((g_mojo_graphics_Shader__0seq!=g_mojo_graphics_glutil_glGraphicsSeq)){
    bbDBBlock db_blk;
    bbDBStmt(1179651);
    g_mojo_graphics_Shader__0seq=g_mojo_graphics_glutil_glGraphicsSeq;
    bbDBStmt(1183747);
    g_mojo_graphics_Shader__0bound=((t_mojo_graphics_ShaderProgram*)0);
  }
  bbDBStmt(1196040);
  f0.l_p=this->m__0programs->at(l_env->m_Id());
  bbDBLocal("p",&f0.l_p);
  bbDBStmt(1200130);
  if(!bbBool(f0.l_p)){
    struct f1_t : public bbGCFrame{
      bbArray<bbString>* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(1204227);
    f0.l_p=bbGCNew<t_mojo_graphics_ShaderProgram>(f1.t0=bbArray<bbString>::create({l_env->m__0source,this->m__0source},2));
    bbDBStmt(1208323);
    this->m__0programs->at(l_env->m_Id())=f0.l_p;
  }
  bbDBStmt(1220610);
  if((g_mojo_graphics_Shader__0bound==f0.l_p)){
    bbDBBlock db_blk;
    bbDBStmt(1220622);
    return;
  }
  bbDBStmt(1224706);
  glUseProgram(f0.l_p->m_GLProgram());
  bbDBStmt(1228802);
  g_mojo_graphics_Shader__0bound=f0.l_p;
}
bbString bbDBType(t_mojo_graphics_Shader**){
  return "mojo.graphics.Shader";
}
bbString bbDBValue(t_mojo_graphics_Shader**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_graphics_2shader_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_graphics_ShaderParam__0ids=bbGCNew<t_std_collections_Map_1si>();
  g_mojo_graphics_ShaderEnv__0nextId=bbInt(0);
}

bbInit mx2_mojo_graphics_2shader_init_v("mojo_graphics_2shader",&mx2_mojo_graphics_2shader_init);
