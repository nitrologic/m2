
#include "../../desktop_debug_pi/mojo_app_2glwindow.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"
#include "../../../../sdl2/sdl2.buildv1.0.2/desktop_debug_pi/sdl2_sdl2.h"

// ***** Internal *****

void t_mojo_app_GLWindow::dbEmit(){
  t_mojo_app_Window::dbEmit();
  bbDBEmit("_sdlGLContext",&m__0sdlGLContext);
}

t_mojo_app_GLWindow::t_mojo_app_GLWindow(bbString l_title,t_std_geom_Rect_1i l_rect,t_mojo_app_WindowFlags l_flags):t_mojo_app_Window(l_title,l_rect,l_flags){
  bbDBFrame db_f{"new:Void(title:String,rect:Recti:std.geom.Rect<Int>,flags:mojo.app.WindowFlags)","/home/pi/monkey2/modules/mojo/app/glwindow.monkey2"};
  bbDBLocal("title",&l_title);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(69634);
  this->m_Init();
}

t_mojo_app_GLWindow::t_mojo_app_GLWindow(bbString l_title,bbInt l_width,bbInt l_height,t_mojo_app_WindowFlags l_flags):t_mojo_app_Window(l_title,l_width,l_height,l_flags){
  bbDBFrame db_f{"new:Void(title:String,width:Int,height:Int,flags:mojo.app.WindowFlags)","/home/pi/monkey2/modules/mojo/app/glwindow.monkey2"};
  bbDBLocal("title",&l_title);
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(49154);
  this->m_Init();
}

t_mojo_app_GLWindow::t_mojo_app_GLWindow(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/app/glwindow.monkey2"};
  bbDBStmt(28674);
  this->m_Init();
}

void t_mojo_app_GLWindow::m_OnRenderGL(){
  bbDBFrame db_f{"OnRenderGL:Void()","/home/pi/monkey2/modules/mojo/app/glwindow.monkey2"};
  t_mojo_app_GLWindow*self=this;
  bbDBLocal("Self",&self);
}

void t_mojo_app_GLWindow::m_OnRender(t_mojo_graphics_Canvas* l_canvas){
  bbDBFrame db_f{"OnRender:Void(canvas:mojo.graphics.Canvas)","/home/pi/monkey2/modules/mojo/app/glwindow.monkey2"};
  t_mojo_app_GLWindow*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
  bbDBStmt(172034);
  this->m_BeginGL();
  bbDBStmt(180226);
  this->m_OnRenderGL();
  bbDBStmt(188418);
  this->m_EndGL();
}

void t_mojo_app_GLWindow::m_Init(){
  bbDBFrame db_f{"Init:Void()","/home/pi/monkey2/modules/mojo/app/glwindow.monkey2"};
  t_mojo_app_GLWindow*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(237570);
  this->m__0sdlGLContext=SDL_GL_CreateContext(this->m_SDLWindow());
  bbDBStmt(241666);
  bbAssert(bbBool(this->m__0sdlGLContext),BB_T("FATAL ERROR: SDL_GL_CreateContext failed"));
}

void t_mojo_app_GLWindow::m_EndGL(){
  bbDBFrame db_f{"EndGL:Void()","/home/pi/monkey2/modules/mojo/app/glwindow.monkey2"};
  t_mojo_app_GLWindow*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(143362);
  SDL_GL_MakeCurrent(t_mojo_app_Window::m_SDLWindow(),t_mojo_app_Window::m_SDLGLContext());
}

void t_mojo_app_GLWindow::m_BeginGL(){
  bbDBFrame db_f{"BeginGL:Void()","/home/pi/monkey2/modules/mojo/app/glwindow.monkey2"};
  t_mojo_app_GLWindow*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(106498);
  SDL_GL_MakeCurrent(this->m_SDLWindow(),this->m__0sdlGLContext);
}
bbString bbDBType(t_mojo_app_GLWindow**){
  return "mojo.app.GLWindow";
}
bbString bbDBValue(t_mojo_app_GLWindow**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_app_2glwindow_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_app_2glwindow_init_v("mojo_app_2glwindow",&mx2_mojo_app_2glwindow_init);
