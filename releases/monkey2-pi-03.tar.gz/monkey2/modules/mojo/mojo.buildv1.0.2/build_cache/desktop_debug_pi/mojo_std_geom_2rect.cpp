
#include "../../desktop_debug_pi/mojo_std_geom_2rect.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2vec2.h"

// ***** Internal *****

t_std_geom_Rect_1i g_std_geom_TransformRecti_1f(t_std_geom_Rect_1i l_rect,t_std_geom_AffineMat3_1f l_matrix){
  bbDBFrame db_f{"TransformRecti<Float>:Recti:std.geom.Rect<Int>(rect:Recti:std.geom.Rect<Int>,matrix:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/geom/rect.monkey2"};
  bbDBLocal("rect",&l_rect);
  bbDBLocal("matrix",&l_matrix);
  bbDBStmt(1372167);
  t_std_geom_Vec2_1f l_min=l_matrix.m__mul(t_std_geom_Vec2_1f(bbFloat(l_rect.m_min.m_x),bbFloat(l_rect.m_min.m_y)));
  bbDBLocal("min",&l_min);
  bbDBStmt(1376263);
  t_std_geom_Vec2_1f l_max=l_matrix.m__mul(t_std_geom_Vec2_1f(bbFloat(l_rect.m_max.m_x),bbFloat(l_rect.m_max.m_y)));
  bbDBLocal("max",&l_max);
  bbDBStmt(1384449);
  return t_std_geom_Rect_1i(bbInt(std::round(bbDouble(l_min.m_x))),bbInt(std::round(bbDouble(l_min.m_y))),bbInt(std::round(bbDouble(l_max.m_x))),bbInt(std::round(bbDouble(l_max.m_y))));
}

void mx2_mojo_std_geom_2rect_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_geom_2rect_init_v("mojo_std_geom_2rect",&mx2_mojo_std_geom_2rect_init);
