
#include "../../desktop_debug_pi/mojo_graphics_2font.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_graphics_2image.h"
#include "../../desktop_debug_pi/mojo_graphics_2shader.h"
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"

extern bbString g_std_filesystem_RealPath(bbString l_path);
extern t_mojo_graphics_Font* g_mojo_graphics_fontloader_LoadFont(bbString l_path,bbFloat l_fheight,t_mojo_graphics_TextureFlags l_textureFlags,t_mojo_graphics_Shader* l_shader);

// ***** Internal *****

bbGCRootVar<t_std_collections_Map_1sTt_mojo_graphics_Font_2> g_mojo_graphics_Font__0openFonts;

t_mojo_graphics_Font* g_mojo_graphics_Font_Open(bbString l_path,bbFloat l_height){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Font* l_font{};
    void gcMark(){
      bbGCMarkPtr(l_font);
    }
  }f0{};
  bbDBFrame db_f{"Open:mojo.graphics.Font(path:String,height:Float)","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  bbDBLocal("path",&l_path);
  bbDBLocal("height",&l_height);
  bbDBStmt(446472);
  bbString l_tag=((g_std_filesystem_RealPath(l_path)+BB_T(":"))+bbString(l_height));
  bbDBLocal("tag",&l_tag);
  bbDBStmt(454664);
  f0.l_font=g_mojo_graphics_Font__0openFonts->m__idx(l_tag);
  bbDBLocal("font",&f0.l_font);
  bbDBStmt(458754);
  if(!bbBool(f0.l_font)){
    bbDBBlock db_blk;
    bbDBStmt(462851);
    f0.l_font=g_mojo_graphics_Font_Load(l_path,l_height,t_mojo_graphics_TextureFlags(0),((t_mojo_graphics_Shader*)0));
    bbDBStmt(466947);
    g_mojo_graphics_Font__0openFonts->m__idxeq(l_tag,f0.l_font);
  }
  bbDBStmt(479234);
  return f0.l_font;
}

t_mojo_graphics_Font* g_mojo_graphics_Font_Load(bbString l_path,bbFloat l_height,t_mojo_graphics_TextureFlags l_textureFlags,t_mojo_graphics_Shader* l_shader){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Font* l_font{};
    t_mojo_graphics_Shader* l_shader{};
    f0_t(t_mojo_graphics_Shader* l_shader):l_shader(l_shader){
    }
    void gcMark(){
      bbGCMarkPtr(l_font);
      bbGCMarkPtr(l_shader);
    }
  }f0{l_shader};
  bbDBFrame db_f{"Load:mojo.graphics.Font(path:String,height:Float,textureFlags:mojo.graphics.TextureFlags,shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  bbDBLocal("path",&l_path);
  bbDBLocal("height",&l_height);
  bbDBLocal("textureFlags",&l_textureFlags);
  bbDBLocal("shader",&f0.l_shader);
  bbDBStmt(512002);
  if(!bbBool(f0.l_shader)){
    bbDBBlock db_blk;
    bbDBStmt(512016);
    f0.l_shader=g_mojo_graphics_Shader_GetShader(BB_T("font"));
  }
  bbDBStmt(520200);
  f0.l_font=g_mojo_graphics_fontloader_LoadFont(l_path,l_height,l_textureFlags,f0.l_shader);
  bbDBLocal("font",&f0.l_font);
  bbDBStmt(528386);
  return f0.l_font;
}

void t_mojo_graphics_Font::gcMark(){
  bbGCMark(m__0image);
  bbGCMark(m__0glyphs);
}

void t_mojo_graphics_Font::dbEmit(){
  bbDBEmit("_image",&m__0image);
  bbDBEmit("_height",&m__0height);
  bbDBEmit("_firstChar",&m__0firstChar);
  bbDBEmit("_glyphs",&m__0glyphs);
}

t_mojo_graphics_Font::t_mojo_graphics_Font(t_mojo_graphics_Image* l_image,bbFloat l_height,bbInt l_firstChar,bbArray<t_mojo_graphics_Glyph>* l_glyphs){
  bbDBFrame db_f{"new:Void(image:mojo.graphics.Image,height:Float,firstChar:Int,glyphs:mojo.graphics.Glyph[])","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  bbDBLocal("image",&l_image);
  bbDBLocal("height",&l_height);
  bbDBLocal("firstChar",&l_firstChar);
  bbDBLocal("glyphs",&l_glyphs);
  bbDBStmt(192514);
  this->m__0image=l_image;
  bbDBStmt(196610);
  this->m__0height=l_height;
  bbDBStmt(200706);
  this->m__0firstChar=l_firstChar;
  bbDBStmt(204802);
  this->m__0glyphs=l_glyphs;
}

bbFloat t_mojo_graphics_Font::m_TextWidth(bbString l_text){
  bbDBFrame db_f{"TextWidth:Float(text:String)","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  t_mojo_graphics_Font*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("text",&l_text);
  bbDBStmt(401416);
  bbFloat l_w=0.0f;
  bbDBLocal("w",&l_w);
  bbDBStmt(405506);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_text.length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      bbDBBlock db_blk;
      bbInt l_char=l_text[l_0];
      bbDBLocal("char",&l_char);
      bbDBStmt(409603);
      l_w+=this->m_GetGlyph(l_char).m_advance;
    }
  }
  bbDBStmt(417794);
  return l_w;
}

bbInt t_mojo_graphics_Font::m_NumChars(){
  bbDBFrame db_f{"NumChars:Int()","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  t_mojo_graphics_Font*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(319490);
  return this->m__0glyphs->length();
}

t_mojo_graphics_Image* t_mojo_graphics_Font::m_Image(){
  bbDBFrame db_f{"Image:mojo.graphics.Image()","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  t_mojo_graphics_Font*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(233474);
  return this->m__0image;
}

bbFloat t_mojo_graphics_Font::m_Height(){
  bbDBFrame db_f{"Height:Float()","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  t_mojo_graphics_Font*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(262146);
  return this->m__0height;
}

bbArray<t_mojo_graphics_Glyph>* t_mojo_graphics_Font::m_Glyphs(){
  bbDBFrame db_f{"Glyphs:mojo.graphics.Glyph[]()","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  t_mojo_graphics_Font*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(348162);
  return this->m__0glyphs;
}

t_mojo_graphics_Glyph t_mojo_graphics_Font::m_GetGlyph(bbInt l_char){
  bbDBFrame db_f{"GetGlyph:mojo.graphics.Glyph(char:Int)","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  t_mojo_graphics_Font*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("char",&l_char);
  bbDBStmt(372738);
  if(((l_char>=this->m__0firstChar)&&(l_char<(this->m__0firstChar+this->m__0glyphs->length())))){
    bbDBBlock db_blk;
    bbDBStmt(372793);
    return this->m__0glyphs->at((l_char-this->m__0firstChar));
  }
  bbDBStmt(376834);
  return this->m__0glyphs->at(bbInt(0));
}

bbInt t_mojo_graphics_Font::m_FirstChar(){
  bbDBFrame db_f{"FirstChar:Int()","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  t_mojo_graphics_Font*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(290818);
  return this->m__0firstChar;
}
bbString bbDBType(t_mojo_graphics_Font**){
  return "mojo.graphics.Font";
}
bbString bbDBValue(t_mojo_graphics_Font**p){
  return bbDBObjectValue(*p);
}

void t_mojo_graphics_Glyph::dbEmit(t_mojo_graphics_Glyph*p){
  bbDBEmit("rect",&p->m_rect);
  bbDBEmit("offset",&p->m_offset);
  bbDBEmit("advance",&p->m_advance);
}

t_mojo_graphics_Glyph::t_mojo_graphics_Glyph(t_std_geom_Rect_1i l_rect,t_std_geom_Vec2_1f l_offset,bbFloat l_advance){
  bbDBFrame db_f{"new:Void(rect:Recti:std.geom.Rect<Int>,offset:Vec2f:std.geom.Vec2<Float>,advance:Float)","/home/pi/monkey2/modules/mojo/graphics/font.monkey2"};
  bbDBLocal("rect",&l_rect);
  bbDBLocal("offset",&l_offset);
  bbDBLocal("advance",&l_advance);
  bbDBStmt(73730);
  (*this).m_rect=l_rect;
  bbDBStmt(77826);
  (*this).m_offset=l_offset;
  bbDBStmt(81922);
  (*this).m_advance=l_advance;
}
bbString bbDBType(t_mojo_graphics_Glyph*){
  return "mojo.graphics.Glyph";
}
bbString bbDBValue(t_mojo_graphics_Glyph*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_mojo_graphics_Glyph&x,const t_mojo_graphics_Glyph&y){
  if(int t=bbCompare(x.m_rect,y.m_rect)) return t;
  if(int t=bbCompare(x.m_offset,y.m_offset)) return t;
  if(int t=bbCompare(x.m_advance,y.m_advance)) return t;
  return 0;
}

void mx2_mojo_graphics_2font_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_graphics_Font__0openFonts=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Font_2>();
}

bbInit mx2_mojo_graphics_2font_init_v("mojo_graphics_2font",&mx2_mojo_graphics_2font_init);
