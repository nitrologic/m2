
#include "../../desktop_debug_pi/mojo_input_2mouse.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2app.h"
#include "../../desktop_debug_pi/mojo_app_2view.h"
#include "../../desktop_debug_pi/mojo_app_2window.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"
#include "../../../../sdl2/sdl2.buildv1.0.2/desktop_debug_pi/sdl2_sdl2.h"

// ***** Internal *****

bbGCRootVar<t_mojo_input_MouseDevice> g_mojo_input_Mouse;

void t_mojo_input_MouseDevice::init(){
  m__0buttons=bbArray<bbBool>::create(4);
  m__0pressed=bbArray<bbBool>::create(4);
  m__0released=bbArray<bbBool>::create(4);
}

void t_mojo_input_MouseDevice::gcMark(){
  t_mojo_input_InputDevice::gcMark();
  bbGCMark(m__0buttons);
  bbGCMark(m__0pressed);
  bbGCMark(m__0released);
}

void t_mojo_input_MouseDevice::dbEmit(){
  t_mojo_input_InputDevice::dbEmit();
  bbDBEmit("_init",&m__0init);
  bbDBEmit("_location",&m__0location);
  bbDBEmit("_buttons",&m__0buttons);
  bbDBEmit("_pressed",&m__0pressed);
  bbDBEmit("_released",&m__0released);
}

t_mojo_input_MouseDevice::t_mojo_input_MouseDevice(){
  init();
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
}

bbInt t_mojo_input_MouseDevice::m_Y(){
  bbDBFrame db_f{"Y:Int()","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(258050);
  return this->m_Location().m_y;
}

bbInt t_mojo_input_MouseDevice::m_X(){
  bbDBFrame db_f{"X:Int()","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(233474);
  return this->m_Location().m_x;
}

void t_mojo_input_MouseDevice::m_Reset(){
  bbDBFrame db_f{"Reset:Void()","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(147458);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(147458);
    for(;(l_i<4);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(151555);
      this->m__0pressed->at(l_i)=true;
      bbDBStmt(155651);
      this->m__0released->at(l_i)=true;
    }
  }
}

void t_mojo_input_MouseDevice::m_Poll(){
  bbDBFrame db_f{"Poll:Void()","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(606216);
  bbInt l_mask=SDL_GetMouseState(&this->m__0location.m_x,&this->m__0location.m_y);
  bbDBLocal("mask",&l_mask);
  bbDBStmt(610306);
  if(bbBool(g_mojo_app_App->m_ActiveWindow())){
    struct f1_t : public bbGCFrame{
      t_mojo_app_Window* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(610326);
    this->m__0location=(f1.t0=g_mojo_app_App->m_ActiveWindow())->m_TransformPointFromView(this->m__0location,((t_mojo_app_View*)0));
  }
  bbDBStmt(614402);
  this->m__0buttons->at(bbInt(t_mojo_input_MouseButton(1)))=bbBool((l_mask&1));
  bbDBStmt(618498);
  this->m__0buttons->at(bbInt(t_mojo_input_MouseButton(2)))=bbBool((l_mask&2));
  bbDBStmt(622594);
  this->m__0buttons->at(bbInt(t_mojo_input_MouseButton(3)))=bbBool((l_mask&4));
  bbDBStmt(626690);
  g_mojo_app_App->m_Idle+=bbMethod((t_mojo_input_MouseDevice*)(this),&t_mojo_input_MouseDevice::m_Poll);
}

void t_mojo_input_MouseDevice::m_PointerVisible(bbBool l_pointerVisible){
  bbDBFrame db_f{"PointerVisible:Void(pointerVisible:Bool)","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("pointerVisible",&l_pointerVisible);
  bbDBStmt(204802);
  SDL_ShowCursor((l_pointerVisible ? SDL_ENABLE : SDL_DISABLE));
}

bbBool t_mojo_input_MouseDevice::m_PointerVisible(){
  bbDBFrame db_f{"PointerVisible:Bool()","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(188418);
  return (SDL_ShowCursor(-1)==SDL_ENABLE);
}

t_std_geom_Vec2_1i t_mojo_input_MouseDevice::m_Location(){
  bbDBFrame db_f{"Location:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(282626);
  return this->m__0location;
}

void t_mojo_input_MouseDevice::m_Init(){
  bbDBFrame db_f{"Init:Void()","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(532482);
  if(this->m__0init){
    bbDBBlock db_blk;
    bbDBStmt(532491);
    return;
  }
  bbDBStmt(536578);
  g_mojo_app_App->m_Idle+=bbMethod((t_mojo_input_MouseDevice*)(this),&t_mojo_input_MouseDevice::m_Poll);
  bbDBStmt(540674);
  this->m__0init=true;
  bbDBStmt(544770);
  this->m_Reset();
}

bbBool t_mojo_input_MouseDevice::m_ButtonReleased(t_mojo_input_MouseButton l_button){
  bbDBFrame db_f{"ButtonReleased:Bool(button:mojo.input.MouseButton)","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("button",&l_button);
  bbDBStmt(446466);
  bbDebugAssert(((bbInt(l_button)>=bbInt(0))&&(bbInt(l_button)<4)),BB_T("Mouse buttton out of range"));
  bbDBStmt(450562);
  if(!this->m__0buttons->at(bbInt(l_button))){
    bbDBBlock db_blk;
    bbDBStmt(454659);
    if(this->m__0released->at(bbInt(l_button))){
      bbDBBlock db_blk;
      bbDBStmt(454680);
      return false;
    }
    bbDBStmt(458755);
    this->m__0released->at(bbInt(l_button))=true;
    bbDBStmt(462851);
    return true;
  }
  bbDBStmt(471042);
  this->m__0released->at(bbInt(l_button))=false;
  bbDBStmt(475138);
  return false;
}

bbBool t_mojo_input_MouseDevice::m_ButtonPressed(t_mojo_input_MouseButton l_button){
  bbDBFrame db_f{"ButtonPressed:Bool(button:mojo.input.MouseButton)","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("button",&l_button);
  bbDBStmt(372738);
  bbDebugAssert(((bbInt(l_button)>=bbInt(0))&&(bbInt(l_button)<4)),BB_T("Mouse buttton out of range"));
  bbDBStmt(376834);
  if(this->m__0buttons->at(bbInt(l_button))){
    bbDBBlock db_blk;
    bbDBStmt(380931);
    if(this->m__0pressed->at(bbInt(l_button))){
      bbDBBlock db_blk;
      bbDBStmt(380951);
      return false;
    }
    bbDBStmt(385027);
    this->m__0pressed->at(bbInt(l_button))=true;
    bbDBStmt(389123);
    return true;
  }
  bbDBStmt(397314);
  this->m__0pressed->at(bbInt(l_button))=false;
  bbDBStmt(401410);
  return false;
}

bbBool t_mojo_input_MouseDevice::m_ButtonHit(t_mojo_input_MouseButton l_button){
  bbDBFrame db_f{"ButtonHit:Bool(button:mojo.input.MouseButton)","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("button",&l_button);
  bbDBStmt(499714);
  return this->m_ButtonPressed(l_button);
}

bbBool t_mojo_input_MouseDevice::m_ButtonDown(t_mojo_input_MouseButton l_button){
  bbDBFrame db_f{"ButtonDown:Bool(button:mojo.input.MouseButton)","/home/pi/monkey2/modules/mojo/input/mouse.monkey2"};
  t_mojo_input_MouseDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("button",&l_button);
  bbDBStmt(323586);
  bbDebugAssert(((bbInt(l_button)>=bbInt(0))&&(bbInt(l_button)<4)),BB_T("Mouse buttton out of range"));
  bbDBStmt(327682);
  return this->m__0buttons->at(bbInt(l_button));
}
bbString bbDBType(t_mojo_input_MouseDevice**){
  return "mojo.input.MouseDevice";
}
bbString bbDBValue(t_mojo_input_MouseDevice**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_input_2mouse_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_input_Mouse=bbGCNew<t_mojo_input_MouseDevice>();
}

bbInit mx2_mojo_input_2mouse_init_v("mojo_input_2mouse",&mx2_mojo_input_2mouse_init);
