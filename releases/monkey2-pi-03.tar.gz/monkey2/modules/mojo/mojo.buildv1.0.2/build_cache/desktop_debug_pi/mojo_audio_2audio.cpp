
#include "../../desktop_debug_pi/mojo_audio_2audio.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../desktop_debug_pi/mojo_std_fiber_2future.h"
#include "../../desktop_debug_pi/mojo_timer_2timer.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_audio_2audiodata.h"

extern bbFloat g_monkey_math_Clamp_1f(bbFloat l_value,bbFloat l_min,bbFloat l_max);

// ***** Internal *****

bbGCRootVar<t_mojo_audio_AudioDevice> g_mojo_audio_Audio;

t_mojo_audio_Sound* g_mojo_audio_Sound_Load(bbString l_path){
  struct f0_t : public bbGCFrame{
    t_std_audio_AudioData* l_data{};
    t_mojo_audio_Sound* l_sound{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_sound);
    }
  }f0{};
  bbDBFrame db_f{"Load:mojo.audio.Sound(path:String)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  bbDBLocal("path",&l_path);
  bbDBStmt(548872);
  f0.l_data=g_std_audio_AudioData_Load(l_path);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(552962);
  if(!bbBool(f0.l_data)){
    bbDBBlock db_blk;
    bbDBStmt(552974);
    return ((t_mojo_audio_Sound*)0);
  }
  bbDBStmt(561160);
  f0.l_sound=bbGCNew<t_mojo_audio_Sound>(f0.l_data);
  bbDBLocal("sound",&f0.l_sound);
  bbDBStmt(569346);
  f0.l_data->m_Discard();
  bbDBStmt(573442);
  return f0.l_sound;
}

bbInt g_mojo_audio_ALFormat(t_std_audio_AudioFormat l_format){
  bbDBFrame db_f{"ALFormat:ALenum:Int(format:std.audio.AudioFormat)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  bbDBLocal("format",&l_format);
  bbDBStmt(49159);
  bbInt l_alFormat{};
  bbDBLocal("alFormat",&l_alFormat);
  bbDBStmt(53249);
  if(l_format==t_std_audio_AudioFormat(1)){
    bbDBBlock db_blk;
    bbDBStmt(61442);
    l_alFormat=AL_FORMAT_MONO8;
  }else if(l_format==t_std_audio_AudioFormat(2)){
    bbDBBlock db_blk;
    bbDBStmt(69634);
    l_alFormat=AL_FORMAT_MONO16;
  }else if(l_format==t_std_audio_AudioFormat(3)){
    bbDBBlock db_blk;
    bbDBStmt(77826);
    l_alFormat=AL_FORMAT_STEREO8;
  }else if(l_format==t_std_audio_AudioFormat(4)){
    bbDBBlock db_blk;
    bbDBStmt(86018);
    l_alFormat=AL_FORMAT_STEREO16;
  }
  bbDBStmt(94209);
  return l_alFormat;
}

void t_mojo_audio_AudioDevice::init(){
  m__0channels=bbGCNew<t_std_collections_Stack_1Tt_mojo_audio_Channel_2>();
}

void t_mojo_audio_AudioDevice::gcMark(){
  bbGCMark(m__0channels);
}

void t_mojo_audio_AudioDevice::dbEmit(){
  bbDBEmit("_alcDevice",&m__0alcDevice);
  bbDBEmit("_alcContext",&m__0alcContext);
  bbDBEmit("_error",&m__0error);
  bbDBEmit("_channels",&m__0channels);
}

void t_mojo_audio_AudioDevice::m_Init(){
  bbDBFrame db_f{"Init:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_AudioDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(176136);
  bbString l_error{};
  bbDBLocal("error",&l_error);
  bbDBStmt(180226);
  this->m__0alcDevice=alcOpenDevice(((char*)0));
  bbDBStmt(184322);
  if(bbBool(this->m__0alcDevice)){
    bbDBBlock db_blk;
    bbDBStmt(188419);
    this->m__0alcContext=alcCreateContext(this->m__0alcDevice,((bbInt*)0));
    bbDBStmt(192515);
    if(bbBool(this->m__0alcContext)){
      bbDBBlock db_blk;
      bbDBStmt(196612);
      if(alcMakeContextCurrent(this->m__0alcContext)){
        bbDBBlock db_blk;
        bbDBStmt(200709);
        return;
      }else{
        bbDBStmt(204804);
        bbDBBlock db_blk;
        bbDBStmt(208901);
        l_error=BB_T("Failed to make OpenAL current");
      }
    }else{
      bbDBStmt(217091);
      bbDBBlock db_blk;
      bbDBStmt(221188);
      l_error=BB_T("Failed to create OpenAL context");
    }
  }else{
    bbDBStmt(229378);
    bbDBBlock db_blk;
    bbDBStmt(233475);
    l_error=BB_T("Failed to create OpenAL device");
  }
}

void t_mojo_audio_AudioDevice::m_FlushTmpChannels(){
  bbDBFrame db_f{"FlushTmpChannels:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_AudioDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(294920);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(299010);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=this->m__0channels->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_audio_Channel* l_chan{};
        void gcMark(){
          bbGCMarkPtr(l_chan);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_chan=f1.l_0.m_Current();
      bbDBLocal("chan",&f2.l_chan);
      bbDBStmt(307203);
      if(f2.l_chan->m_Playing()){
        bbDBBlock db_blk;
        bbDBStmt(311300);
        this->m__0channels->m__idxeq(l_put,f2.l_chan);
        bbDBStmt(311320);
        l_put+=1;
        bbDBStmt(315396);
        continue;
      }
      bbDBStmt(327683);
      f2.l_chan->m_Discard();
    }
  }
  bbDBStmt(335874);
  this->m__0channels->m_Resize(l_put);
}

t_mojo_audio_Channel* t_mojo_audio_AudioDevice::m_AllocTmpChannel(){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_channel{};
    void gcMark(){
      bbGCMarkPtr(l_channel);
    }
  }f0{};
  bbDBFrame db_f{"AllocTmpChannel:mojo.audio.Channel()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_AudioDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(356354);
  this->m_FlushTmpChannels();
  bbDBStmt(364552);
  f0.l_channel=bbGCNew<t_mojo_audio_Channel>();
  bbDBLocal("channel",&f0.l_channel);
  bbDBStmt(368642);
  this->m__0channels->m_Push(f0.l_channel);
  bbDBStmt(376834);
  return f0.l_channel;
}
bbString bbDBType(t_mojo_audio_AudioDevice**){
  return "mojo.audio.AudioDevice";
}
bbString bbDBValue(t_mojo_audio_AudioDevice**p){
  return bbDBObjectValue(*p);
}

void t_mojo_audio_Sound::dbEmit(){
  bbDBEmit("_alBuffer",&m__0alBuffer);
}

t_mojo_audio_Sound::t_mojo_audio_Sound(t_std_audio_AudioData* l_data){
  bbDBFrame db_f{"new:Void(data:std.audio.AudioData)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  bbDBLocal("data",&l_data);
  bbDBStmt(425986);
  alGenBuffers(1,&this->m__0alBuffer);
  bbDBStmt(430082);
  alBufferData(this->m__0alBuffer,g_mojo_audio_ALFormat(l_data->m_Format()),((void*)(l_data->m_Data())),bbUInt(l_data->m_Size()),bbUInt(l_data->m_Hertz()));
}

t_mojo_audio_Channel* t_mojo_audio_Sound::m_Play(bbBool l_loop){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_channel{};
    void gcMark(){
      bbGCMarkPtr(l_channel);
    }
  }f0{};
  bbDBFrame db_f{"Play:mojo.audio.Channel(loop:Bool)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Sound*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("loop",&l_loop);
  bbDBStmt(503816);
  f0.l_channel=g_mojo_audio_Audio->m_AllocTmpChannel();
  bbDBLocal("channel",&f0.l_channel);
  bbDBStmt(512002);
  f0.l_channel->m_Play(this,l_loop);
  bbDBStmt(520194);
  return f0.l_channel;
}

void t_mojo_audio_Sound::m_Discard(){
  bbDBFrame db_f{"Discard:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Sound*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(454658);
  if(!bbBool(this->m__0alBuffer)){
    bbDBBlock db_blk;
    bbDBStmt(454675);
    return;
  }
  bbDBStmt(458754);
  alDeleteBuffers(1,&this->m__0alBuffer);
  bbDBStmt(462850);
  this->m__0alBuffer=bbUInt(0);
}
bbString bbDBType(t_mojo_audio_Sound**){
  return "mojo.audio.Sound";
}
bbString bbDBValue(t_mojo_audio_Sound**p){
  return bbDBObjectValue(*p);
}

void t_mojo_audio_Channel::gcMark(){
  bbGCMark(m__0tmpBuffers);
  bbGCMark(m__0freeBuffers);
  bbGCMark(m__0future);
  bbGCMark(m__0timer);
}

void t_mojo_audio_Channel::dbEmit(){
  bbDBEmit("_alSource",&m__0alSource);
  bbDBEmit("_volume",&m__0volume);
  bbDBEmit("_rate",&m__0rate);
  bbDBEmit("_pan",&m__0pan);
  bbDBEmit("_tmpBuffers",&m__0tmpBuffers);
  bbDBEmit("_freeBuffers",&m__0freeBuffers);
  bbDBEmit("_future",&m__0future);
  bbDBEmit("_waiting",&m__0waiting);
  bbDBEmit("_queued",&m__0queued);
  bbDBEmit("_timer",&m__0timer);
}

t_mojo_audio_Channel::t_mojo_audio_Channel(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  bbDBStmt(630786);
  g_mojo_audio_Audio->m_FlushTmpChannels();
  bbDBStmt(634882);
  alGenSources(1,&this->m__0alSource);
}

void t_mojo_audio_Channel::m_WaitQueued(bbInt l_queued){
  bbDBFrame db_f{"WaitQueued:Void(queued:Int)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("queued",&l_queued);
  bbDBStmt(1052674);
  {
    bbDBLoop db_loop;
    while((this->m__0queued>l_queued)){
      bbDBBlock db_blk;
      bbDBStmt(1060867);
      this->m_FlushProcessed();
      bbDBStmt(1069059);
      if((this->m__0queued<=l_queued)){
        bbDBBlock db_blk;
        bbDBStmt(1069078);
        return;
      }
      bbDBStmt(1077251);
      this->m__0waiting=true;
      bbDBStmt(1085443);
      this->m__0future->m_Get();
    }
  }
}

void t_mojo_audio_Channel::m_Volume(bbFloat l_volume){
  bbDBFrame db_f{"Volume:Void(volume:Float)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("volume",&l_volume);
  bbDBStmt(798722);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(798739);
    return;
  }
  bbDBStmt(806914);
  this->m__0volume=g_monkey_math_Clamp_1f(l_volume,0.0f,1.0f);
  bbDBStmt(811010);
  alSourcef(this->m__0alSource,AL_GAIN,this->m__0volume);
}

bbFloat t_mojo_audio_Channel::m_Volume(){
  bbDBFrame db_f{"Volume:Float()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(778242);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(778259);
    return 0.0f;
  }
  bbDBStmt(786434);
  return this->m__0volume;
}

void t_mojo_audio_Channel::m_Stop(){
  bbDBFrame db_f{"Stop:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1286146);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(1286163);
    return;
  }
  bbDBStmt(1290242);
  alSourceStop(this->m__0alSource);
}

void t_mojo_audio_Channel::m_Rate(bbFloat l_rate){
  bbDBFrame db_f{"Rate:Void(rate:Float)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rate",&l_rate);
  bbDBStmt(856066);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(856083);
    return;
  }
  bbDBStmt(864258);
  this->m__0rate=l_rate;
  bbDBStmt(868354);
  alSourcef(this->m__0alSource,AL_PITCH,this->m__0rate);
}

bbFloat t_mojo_audio_Channel::m_Rate(){
  bbDBFrame db_f{"Rate:Float()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(835586);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(835603);
    return 0.0f;
  }
  bbDBStmt(843778);
  return this->m__0rate;
}

void t_mojo_audio_Channel::m_Queue(t_std_audio_AudioData* l_data){
  bbDBFrame db_f{"Queue:Void(data:std.audio.AudioData)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("data",&l_data);
  bbDBStmt(1130504);
  bbUInt l_buf{};
  bbDBLocal("buf",&l_buf);
  bbDBStmt(1138690);
  if(!bbBool(this->m__0tmpBuffers)){
    bbDBBlock db_blk;
    bbDBStmt(1146883);
    this->m__0tmpBuffers=bbGCNew<t_std_collections_Stack_1j>();
    bbDBStmt(1150979);
    this->m__0freeBuffers=bbGCNew<t_std_collections_Stack_1j>();
    bbDBStmt(1155075);
    this->m__0future=bbGCNew<t_std_fiber_Future_1i>();
    bbDBStmt(1159171);
    this->m__0waiting=false;
    bbDBStmt(1163267);
    this->m__0queued=bbInt(0);
    bbDBStmt(1171459);
    struct lambda0 : public bbFunction<void()>::Rep{
      t_mojo_audio_Channel* l_self;
      lambda0(t_mojo_audio_Channel* l_self):l_self(l_self){
      }
      void invoke(){
        bbDBFrame db_f{"?????:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
        bbDBStmt(1175556);
        l_self->m_FlushProcessed();
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m__0timer=bbGCNew<bbTimer>(20,bbFunction<void()>(new lambda0(this)));
  }
  bbDBStmt(1196034);
  if(this->m__0freeBuffers->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(1204227);
    alGenBuffers(1,&l_buf);
    bbDBStmt(1208323);
    this->m__0tmpBuffers->m_Push(l_buf);
  }else{
    bbDBStmt(1216514);
    bbDBBlock db_blk;
    bbDBStmt(1220611);
    l_buf=this->m__0freeBuffers->m_Pop();
  }
  bbDBStmt(1232898);
  alBufferData(l_buf,g_mojo_audio_ALFormat(l_data->m_Format()),((void*)(l_data->m_Data())),bbUInt(l_data->m_Size()),bbUInt(l_data->m_Hertz()));
  bbDBStmt(1241090);
  alSourceQueueBuffers(this->m__0alSource,1,&l_buf);
  bbDBStmt(1245186);
  this->m__0queued+=1;
  bbDBStmt(1253384);
  bbInt l_state=this->m_ALState();
  bbDBLocal("state",&l_state);
  bbDBStmt(1257474);
  if(((l_state==AL_INITIAL)||(l_state==AL_STOPPED))){
    bbDBBlock db_blk;
    bbDBStmt(1257514);
    alSourcePlay(this->m__0alSource);
  }
}

bbBool t_mojo_audio_Channel::m_Playing(){
  bbDBFrame db_f{"Playing:Bool()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(671746);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(671763);
    return false;
  }
  bbDBStmt(679944);
  bbInt l_state=this->m_ALState();
  bbDBLocal("state",&l_state);
  bbDBStmt(684034);
  return ((l_state==AL_PLAYING)||(l_state==AL_PAUSED));
}

void t_mojo_audio_Channel::m_Play(t_mojo_audio_Sound* l_sound,bbBool l_loop){
  bbDBFrame db_f{"Play:Void(sound:mojo.audio.Sound,loop:Bool)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("sound",&l_sound);
  bbDBLocal("loop",&l_loop);
  bbDBStmt(991234);
  if(((!bbBool(this->m__0alSource)||!bbBool(l_sound))||!bbBool(l_sound->m__0alBuffer))){
    bbDBBlock db_blk;
    bbDBStmt(991287);
    return;
  }
  bbDBStmt(999426);
  alSourcei(this->m__0alSource,AL_LOOPING,(l_loop ? AL_TRUE : AL_FALSE));
  bbDBStmt(1007618);
  alSourcei(this->m__0alSource,AL_BUFFER,bbInt(l_sound->m__0alBuffer));
  bbDBStmt(1015810);
  alSourcePlay(this->m__0alSource);
}

void t_mojo_audio_Channel::m_Paused(bbBool l_paused){
  bbDBFrame db_f{"Paused:Void(paused:Bool)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("paused",&l_paused);
  bbDBStmt(729090);
  if(!this->m_Playing()){
    bbDBBlock db_blk;
    bbDBStmt(729105);
    return;
  }
  bbDBStmt(737282);
  if(l_paused){
    bbDBBlock db_blk;
    bbDBStmt(741379);
    alSourcePause(this->m__0alSource);
  }else{
    bbDBStmt(745474);
    bbDBBlock db_blk;
    bbDBStmt(749571);
    alSourcePlay(this->m__0alSource);
  }
}

bbBool t_mojo_audio_Channel::m_Paused(){
  bbDBFrame db_f{"Paused:Bool()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(708610);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(708627);
    return false;
  }
  bbDBStmt(716802);
  return (this->m_ALState()==AL_PAUSED);
}

void t_mojo_audio_Channel::m_Pan(bbFloat l_pan){
  bbDBFrame db_f{"Pan:Void(pan:Float)","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("pan",&l_pan);
  bbDBStmt(913410);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(913427);
    return;
  }
  bbDBStmt(921602);
  this->m__0pan=g_monkey_math_Clamp_1f(l_pan,-1.0f,1.0f);
  bbDBStmt(925704);
  bbDouble l_x=std::sin(bbDouble(this->m__0pan));
  bbDBLocal("x",&l_x);
  bbDBStmt(925719);
  bbDouble l_z=-std::cos(bbDouble(this->m__0pan));
  bbDBLocal("z",&l_z);
  bbDBStmt(929794);
  alSource3f(this->m__0alSource,AL_POSITION,bbFloat(l_x),0.0f,bbFloat(l_z));
}

bbFloat t_mojo_audio_Channel::m_Pan(){
  bbDBFrame db_f{"Pan:Float()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(892930);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(892947);
    return 0.0f;
  }
  bbDBStmt(901122);
  return this->m__0pan;
}

bbInt t_mojo_audio_Channel::m_FlushProcessed(){
  bbDBFrame db_f{"FlushProcessed:Int()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1368072);
  bbInt l_proc{};
  bbDBLocal("proc",&l_proc);
  bbDBStmt(1372162);
  alGetSourcei(this->m__0alSource,AL_BUFFERS_PROCESSED,&l_proc);
  bbDBStmt(1388546);
  if(!bbBool(l_proc)){
    bbDBBlock db_blk;
    bbDBStmt(1388558);
    return bbInt(0);
  }
  bbDBStmt(1396738);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1396738);
    for(;(l_i<l_proc);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1404937);
      bbUInt l_buf{};
      bbDBLocal("buf",&l_buf);
      bbDBStmt(1413123);
      alSourceUnqueueBuffers(this->m__0alSource,1,&l_buf);
      bbDBStmt(1417219);
      this->m__0queued-=1;
      bbDBStmt(1425411);
      if(this->m__0tmpBuffers->m_Contains(l_buf)){
        bbDBBlock db_blk;
        bbDBStmt(1425442);
        this->m__0freeBuffers->m_Push(l_buf);
      }
    }
  }
  bbDBStmt(1437698);
  if(this->m__0waiting){
    bbDBBlock db_blk;
    bbDBStmt(1441795);
    this->m__0waiting=false;
    bbDBStmt(1445891);
    this->m__0future->m_Set(l_proc);
  }
  bbDBStmt(1458178);
  return l_proc;
}

void t_mojo_audio_Channel::m_Discard(){
  bbDBFrame db_f{"Discard:Void()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(954370);
  if(!bbBool(this->m__0alSource)){
    bbDBBlock db_blk;
    bbDBStmt(954387);
    return;
  }
  bbDBStmt(962562);
  alDeleteSources(1,&this->m__0alSource);
  bbDBStmt(966658);
  this->m__0alSource=bbUInt(0);
}

bbInt t_mojo_audio_Channel::m_ALState(){
  bbDBFrame db_f{"ALState:ALenum:Int()","/home/pi/monkey2/modules/mojo/audio/audio.monkey2"};
  t_mojo_audio_Channel*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478664);
  bbInt l_state{};
  bbDBLocal("state",&l_state);
  bbDBStmt(1482754);
  alGetSourcei(this->m__0alSource,AL_SOURCE_STATE,&l_state);
  bbDBStmt(1486850);
  return l_state;
}
bbString bbDBType(t_mojo_audio_Channel**){
  return "mojo.audio.Channel";
}
bbString bbDBValue(t_mojo_audio_Channel**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_audio_2audio_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_audio_Audio=bbGCNew<t_mojo_audio_AudioDevice>();
}

bbInit mx2_mojo_audio_2audio_init_v("mojo_audio_2audio",&mx2_mojo_audio_2audio_init);
