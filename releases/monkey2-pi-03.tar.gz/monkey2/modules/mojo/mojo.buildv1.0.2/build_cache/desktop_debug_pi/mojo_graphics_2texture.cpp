
#include "../../desktop_debug_pi/mojo_graphics_2texture.h"

// ***** External *****

#include "../../../../gles20/gles20.buildv1.0.2/desktop_debug_pi/gles20_gles20.h"
#include "../../desktop_debug_pi/mojo_graphics_2device.h"
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_graphics_2pixmap.h"

extern bbInt g_mojo_graphics_glutil_glGraphicsSeq;

extern void g_mojo_graphics_glutil_glPushTexture2d(bbInt l_tex);
extern bbInt g_mojo_graphics_glutil_glFormat(t_std_graphics_PixelFormat l_format);
extern void g_mojo_graphics_glutil_glPopTexture2d();
extern void g_mojo_graphics_glutil_glPushFramebuffer(bbInt l_framebuf);
extern void g_mojo_graphics_glutil_glPopFramebuffer();

// ***** Internal *****

bbGCRootVar<t_std_collections_Map_1Tt_std_graphics_Color_2Tt_mojo_graphics_Texture_2> g_mojo_graphics_Texture__0colorTextures;

t_mojo_graphics_Texture* g_mojo_graphics_Texture_Load(bbString l_path,t_mojo_graphics_TextureFlags l_flags){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    t_mojo_graphics_Texture* l_texture{};
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
      bbGCMarkPtr(l_texture);
    }
  }f0{};
  bbDBFrame db_f{"Load:mojo.graphics.Texture(path:String,flags:mojo.graphics.TextureFlags)","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  bbDBLocal("path",&l_path);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(524296);
  f0.l_pixmap=g_std_graphics_Pixmap_Load(l_path,t_std_graphics_PixelFormat(0));
  bbDBLocal("pixmap",&f0.l_pixmap);
  bbDBStmt(528386);
  if(!bbBool(f0.l_pixmap)){
    bbDBBlock db_blk;
    bbDBStmt(528400);
    return ((t_mojo_graphics_Texture*)0);
  }
  bbDBStmt(536578);
  f0.l_pixmap->m_PremultiplyAlpha();
  bbDBStmt(544776);
  f0.l_texture=bbGCNew<t_mojo_graphics_Texture>(f0.l_pixmap,l_flags);
  bbDBLocal("texture",&f0.l_texture);
  bbDBStmt(552962);
  struct lambda0 : public bbFunction<void()>::Rep{
    t_std_graphics_Pixmap* l_pixmap;
    lambda0(t_std_graphics_Pixmap* l_pixmap):l_pixmap(l_pixmap){
    }
    void invoke(){
      bbDBFrame db_f{"?????:Void()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
      bbDBStmt(557059);
      l_pixmap->m_Discard();
    }
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  };
  f0.l_texture->m_OnDiscarded+=bbFunction<void()>(new lambda0(f0.l_pixmap));
  bbDBStmt(569346);
  return f0.l_texture;
}

t_mojo_graphics_Texture* g_mojo_graphics_Texture_ColorTexture(t_std_graphics_Color l_color){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* l_texture{};
    void gcMark(){
      bbGCMarkPtr(l_texture);
    }
  }f0{};
  bbDBFrame db_f{"ColorTexture:mojo.graphics.Texture(color:std.graphics.Color)","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  bbDBLocal("color",&l_color);
  bbDBStmt(585736);
  f0.l_texture=g_mojo_graphics_Texture__0colorTextures->m__idx(l_color);
  bbDBLocal("texture",&f0.l_texture);
  bbDBStmt(589826);
  if(!bbBool(f0.l_texture)){
    struct f1_t : public bbGCFrame{
      t_std_graphics_Pixmap* l_pixmap{};
      void gcMark(){
        bbGCMarkPtr(l_pixmap);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(593929);
    f1.l_pixmap=bbGCNew<t_std_graphics_Pixmap>(1,1,t_std_graphics_PixelFormat(5));
    bbDBLocal("pixmap",&f1.l_pixmap);
    bbDBStmt(598019);
    f1.l_pixmap->m_Clear(l_color);
    bbDBStmt(602115);
    f0.l_texture=bbGCNew<t_mojo_graphics_Texture>(f1.l_pixmap,t_mojo_graphics_TextureFlags(0));
    bbDBStmt(606211);
    g_mojo_graphics_Texture__0colorTextures->m__idxeq(l_color,f0.l_texture);
  }
  bbDBStmt(614402);
  return f0.l_texture;
}

void t_mojo_graphics_Texture::gcMark(){
  bbGCMark(m_OnDiscarded);
  bbGCMark(m__0managed);
}

void t_mojo_graphics_Texture::dbEmit(){
  bbDBEmit("OnDiscarded",&m_OnDiscarded);
  bbDBEmit("_rect",&m__0rect);
  bbDBEmit("_format",&m__0format);
  bbDBEmit("_flags",&m__0flags);
  bbDBEmit("_managed",&m__0managed);
  bbDBEmit("_discarded",&m__0discarded);
  bbDBEmit("_texSeq",&m__0texSeq);
  bbDBEmit("_texDirty",&m__0texDirty);
  bbDBEmit("_mipsDirty",&m__0mipsDirty);
  bbDBEmit("_glTexture",&m__0glTexture);
  bbDBEmit("_fbSeq",&m__0fbSeq);
  bbDBEmit("_glFramebuffer",&m__0glFramebuffer);
}

t_mojo_graphics_Texture::t_mojo_graphics_Texture(bbInt l_width,bbInt l_height,t_std_graphics_PixelFormat l_format,t_mojo_graphics_TextureFlags l_flags){
  bbDBFrame db_f{"new:Void(width:Int,height:Int,format:std.graphics.PixelFormat,flags:mojo.graphics.TextureFlags)","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBLocal("format",&l_format);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(221186);
  this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_width,l_height);
  bbDBStmt(225282);
  this->m__0format=l_format;
  bbDBStmt(229378);
  this->m__0flags=l_flags;
  bbDBStmt(237570);
  if(!bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(4096)))))){
    bbDBBlock db_blk;
    bbDBStmt(241667);
    this->m__0managed=bbGCNew<t_std_graphics_Pixmap>(l_width,l_height,l_format);
    bbDBStmt(245763);
    this->m__0managed->m_Clear(g_std_graphics_Color_Magenta);
    bbDBStmt(249859);
    struct lambda1 : public bbFunction<void()>::Rep{
      t_mojo_graphics_Texture* l_self;
      lambda1(t_mojo_graphics_Texture* l_self):l_self(l_self){
      }
      void invoke(){
        bbDBFrame db_f{"?????:Void()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
        bbDBStmt(253956);
        l_self->m__0managed->m_Discard();
        bbDBStmt(258052);
        l_self->m__0managed=((t_std_graphics_Pixmap*)0);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_OnDiscarded+=bbFunction<void()>(new lambda1(this));
  }
}

t_mojo_graphics_Texture::t_mojo_graphics_Texture(t_std_graphics_Pixmap* l_pixmap,t_mojo_graphics_TextureFlags l_flags){
  bbDBFrame db_f{"new:Void(pixmap:std.graphics.Pixmap,flags:mojo.graphics.TextureFlags)","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  bbDBLocal("pixmap",&l_pixmap);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(163842);
  this->m__0rect=t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_pixmap->m_Width(),l_pixmap->m_Height());
  bbDBStmt(167938);
  this->m__0format=l_pixmap->m_Format();
  bbDBStmt(172034);
  this->m__0flags=l_flags;
  bbDBStmt(180226);
  if(bbBool(t_mojo_graphics_TextureFlags((int(l_flags)&int(t_mojo_graphics_TextureFlags(4096)))))){
    bbDBBlock db_blk;
    bbDBStmt(184323);
    this->m_PastePixmap(l_pixmap,bbInt(0),bbInt(0));
  }else{
    bbDBStmt(188418);
    bbDBBlock db_blk;
    bbDBStmt(192515);
    this->m__0managed=l_pixmap;
  }
}

bbInt t_mojo_graphics_Texture::m_Width(){
  bbDBFrame db_f{"Width:Int()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(299010);
  return this->m__0rect.m_Width();
}

t_std_geom_Rect_1i t_mojo_graphics_Texture::m_Rect(){
  bbDBFrame db_f{"Rect:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(282626);
  return this->m__0rect;
}

void t_mojo_graphics_Texture::m_PastePixmap(t_std_graphics_Pixmap* l_pixmap,bbInt l_x,bbInt l_y){
  bbDBFrame db_f{"PastePixmap:Void(pixmap:std.graphics.Pixmap,x:Int,y:Int)","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("pixmap",&l_pixmap);
  bbDBLocal("x",&l_x);
  bbDBLocal("y",&l_y);
  bbDBStmt(401410);
  if(bbBool(this->m__0managed)){
    bbDBBlock db_blk;
    bbDBStmt(409603);
    this->m__0managed->m_Paste(l_pixmap,l_x,l_y);
    bbDBStmt(417795);
    this->m__0texDirty=true;
  }else{
    bbDBStmt(425986);
    bbDBBlock db_blk;
    bbDBStmt(434179);
    g_mojo_graphics_glutil_glPushTexture2d(bbInt(this->m_GLTexture()));
    bbDBStmt(442371);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    bbDBStmt(450563);
    if((l_pixmap->m_Pitch()==(l_pixmap->m_Width()*l_pixmap->m_Depth()))){
      bbDBBlock db_blk;
      bbDBStmt(454660);
      glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),l_x,l_y,l_pixmap->m_Width(),l_pixmap->m_Height(),g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(l_pixmap->m_Data())));
    }else{
      bbDBStmt(458755);
      bbDBBlock db_blk;
      bbDBStmt(462852);
      {
        bbDBLoop db_loop;
        bbInt l_iy=bbInt(0);
        bbDBLocal("iy",&l_iy);
        bbDBStmt(462852);
        for(;(l_iy<l_pixmap->m_Height());l_iy+=1){
          bbDBBlock db_blk;
          bbDBStmt(466949);
          glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),l_x,(l_y+l_iy),l_pixmap->m_Width(),1,g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(l_pixmap->m_PixelPtr(bbInt(0),l_iy))));
        }
      }
    }
    bbDBStmt(483331);
    g_mojo_graphics_glutil_glPopTexture2d();
    bbDBStmt(491523);
    this->m__0mipsDirty=true;
  }
}

void t_mojo_graphics_Texture::m_Modified(t_mojo_graphics_GraphicsDevice* l_device){
  bbDBFrame db_f{"Modified:Void(device:mojo.graphics.GraphicsDevice)","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("device",&l_device);
  bbDBStmt(1126402);
  if(bbBool(this->m__0managed)){
    bbDBBlock db_blk;
    bbDBStmt(1130505);
    t_std_geom_Rect_1i l_r=l_device->m_Viewport().m__and(l_device->m_Scissor());
    bbDBLocal("r",&l_r);
    bbDBStmt(1134595);
    glPixelStorei(GL_PACK_ALIGNMENT,1);
    bbDBStmt(1138691);
    glReadPixels(l_r.m_X(),l_r.m_Y(),l_r.m_Width(),l_r.m_Height(),GL_RGBA,GL_UNSIGNED_BYTE,((void*)(this->m__0managed->m_PixelPtr(l_r.m_X(),l_r.m_Y()))));
  }
  bbDBStmt(1150978);
  if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(2)))))){
    bbDBBlock db_blk;
    bbDBStmt(1151010);
    this->m__0mipsDirty=true;
  }
}

bbInt t_mojo_graphics_Texture::m_Height(){
  bbDBFrame db_f{"Height:Int()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(315394);
  return this->m__0rect.m_Height();
}

bbUInt t_mojo_graphics_Texture::m_GLTexture(){
  bbDBFrame db_f{"GLTexture:GLuint:Uint()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(638978);
  bbDebugAssert(!this->m__0discarded,BB_T("texture has been discarded"));
  bbDBStmt(647170);
  if((((this->m__0texSeq==g_mojo_graphics_glutil_glGraphicsSeq)&&!this->m__0texDirty)&&!this->m__0mipsDirty)){
    bbDBBlock db_blk;
    bbDBStmt(647232);
    return this->m__0glTexture;
  }
  bbDBStmt(655362);
  if((this->m__0texSeq==g_mojo_graphics_glutil_glGraphicsSeq)){
    bbDBBlock db_blk;
    bbDBStmt(663555);
    g_mojo_graphics_glutil_glPushTexture2d(bbInt(this->m__0glTexture));
  }else{
    bbDBStmt(671746);
    bbDBBlock db_blk;
    bbDBStmt(679939);
    glGenTextures(1,&this->m__0glTexture);
    bbDBStmt(688131);
    g_mojo_graphics_glutil_glPushTexture2d(bbInt(this->m__0glTexture));
    bbDBStmt(696323);
    if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(1)))))){
      bbDBBlock db_blk;
      bbDBStmt(700420);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    }else{
      bbDBStmt(704515);
      bbDBBlock db_blk;
      bbDBStmt(708612);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
    }
    bbDBStmt(720899);
    if((bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(2)))))&&bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(1))))))){
      bbDBBlock db_blk;
      bbDBStmt(724996);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
    }else if(bbDBStmt(729091),bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(2)))))){
      bbDBBlock db_blk;
      bbDBStmt(733188);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST_MIPMAP_NEAREST);
    }else if(bbDBStmt(737283),bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(1)))))){
      bbDBBlock db_blk;
      bbDBStmt(741380);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    }else{
      bbDBStmt(745475);
      bbDBBlock db_blk;
      bbDBStmt(749572);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    }
    bbDBStmt(761859);
    if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(4)))))){
      bbDBBlock db_blk;
      bbDBStmt(765956);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    }else{
      bbDBStmt(770051);
      bbDBBlock db_blk;
      bbDBStmt(774148);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    }
    bbDBStmt(786435);
    if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(8)))))){
      bbDBBlock db_blk;
      bbDBStmt(790532);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    }else{
      bbDBStmt(794627);
      bbDBBlock db_blk;
      bbDBStmt(798724);
      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
    }
    bbDBStmt(811011);
    glTexImage2D(GL_TEXTURE_2D,bbInt(0),g_mojo_graphics_glutil_glFormat(this->m__0format),this->m_Width(),this->m_Height(),bbInt(0),g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)0));
    bbDBStmt(819203);
    this->m__0texSeq=g_mojo_graphics_glutil_glGraphicsSeq;
    bbDBStmt(823299);
    this->m__0texDirty=true;
  }
  bbDBStmt(835586);
  if(this->m__0texDirty){
    bbDBBlock db_blk;
    bbDBStmt(843779);
    if(bbBool(this->m__0managed)){
      bbDBBlock db_blk;
      bbDBStmt(851972);
      glPixelStorei(GL_UNPACK_ALIGNMENT,1);
      bbDBStmt(860164);
      if((this->m__0managed->m_Pitch()==(this->m__0managed->m_Width()*this->m__0managed->m_Depth()))){
        bbDBBlock db_blk;
        bbDBStmt(864261);
        glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),bbInt(0),bbInt(0),this->m__0managed->m_Width(),this->m__0managed->m_Height(),g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(this->m__0managed->m_Data())));
      }else{
        bbDBStmt(868356);
        bbDBBlock db_blk;
        bbDBStmt(872453);
        {
          bbDBLoop db_loop;
          bbInt l_iy=bbInt(0);
          bbDBLocal("iy",&l_iy);
          bbDBStmt(872453);
          for(;(l_iy<this->m_Height());l_iy+=1){
            bbDBBlock db_blk;
            bbDBStmt(876550);
            glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),bbInt(0),l_iy,this->m_Width(),1,g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(this->m__0managed->m_PixelPtr(bbInt(0),l_iy))));
          }
        }
      }
      bbDBStmt(892932);
      glFlush();
    }else{
      bbDBStmt(901123);
      struct f2_t : public bbGCFrame{
        t_std_graphics_Pixmap* l_tmp{};
        void gcMark(){
          bbGCMarkPtr(l_tmp);
        }
      }f2{};
      bbDBBlock db_blk;
      bbDBStmt(909322);
      f2.l_tmp=bbGCNew<t_std_graphics_Pixmap>(this->m_Width(),1,this->m_Format());
      bbDBLocal("tmp",&f2.l_tmp);
      bbDBStmt(913412);
      f2.l_tmp->m_Clear(g_std_graphics_Color_Red);
      bbDBStmt(917508);
      {
        bbDBLoop db_loop;
        bbInt l_iy=bbInt(0);
        bbDBLocal("iy",&l_iy);
        bbDBStmt(917508);
        for(;(l_iy<this->m_Height());l_iy+=1){
          bbDBBlock db_blk;
          bbDBStmt(921605);
          glTexSubImage2D(GL_TEXTURE_2D,bbInt(0),bbInt(0),l_iy,this->m_Width(),1,g_mojo_graphics_glutil_glFormat(this->m__0format),GL_UNSIGNED_BYTE,((void*)(f2.l_tmp->m_Data())));
        }
      }
      bbDBStmt(929796);
      f2.l_tmp->m_Discard();
    }
    bbDBStmt(946179);
    this->m__0texDirty=false;
    bbDBStmt(950275);
    this->m__0mipsDirty=true;
  }
  bbDBStmt(962562);
  if(this->m__0mipsDirty){
    bbDBBlock db_blk;
    bbDBStmt(970755);
    if(bbBool(t_mojo_graphics_TextureFlags((int(this->m__0flags)&int(t_mojo_graphics_TextureFlags(2)))))){
      bbDBBlock db_blk;
      bbDBStmt(970787);
      glGenerateMipmap(GL_TEXTURE_2D);
    }
    bbDBStmt(974851);
    this->m__0mipsDirty=false;
  }
  bbDBStmt(987138);
  g_mojo_graphics_glutil_glPopTexture2d();
  bbDBStmt(995330);
  return this->m__0glTexture;
}

bbUInt t_mojo_graphics_Texture::m_GLFramebuffer(){
  bbDBFrame db_f{"GLFramebuffer:GLuint:Uint()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1019906);
  bbDebugAssert(!this->m__0discarded,BB_T("texture has been discarded"));
  bbDBStmt(1028098);
  if((this->m__0fbSeq==g_mojo_graphics_glutil_glGraphicsSeq)){
    bbDBBlock db_blk;
    bbDBStmt(1028122);
    return this->m__0glFramebuffer;
  }
  bbDBStmt(1036290);
  glGenFramebuffers(1,&this->m__0glFramebuffer);
  bbDBStmt(1044482);
  g_mojo_graphics_glutil_glPushFramebuffer(bbInt(this->m__0glFramebuffer));
  bbDBStmt(1052674);
  glBindFramebuffer(GL_FRAMEBUFFER,this->m__0glFramebuffer);
  bbDBStmt(1056770);
  glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,this->m_GLTexture(),bbInt(0));
  bbDBStmt(1064962);
  if((glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)){
    bbDBBlock db_blk;
    bbDBStmt(1065033);
    bbAssert(false,BB_T("Incomplete framebuffer"));
  }
  bbDBStmt(1073154);
  g_mojo_graphics_glutil_glPopFramebuffer();
  bbDBStmt(1081346);
  this->m__0fbSeq=g_mojo_graphics_glutil_glGraphicsSeq;
  bbDBStmt(1089538);
  return this->m__0glFramebuffer;
}

t_std_graphics_PixelFormat t_mojo_graphics_Texture::m_Format(){
  bbDBFrame db_f{"Format:std.graphics.PixelFormat()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(331778);
  return this->m__0format;
}

t_mojo_graphics_TextureFlags t_mojo_graphics_Texture::m_Flags(){
  bbDBFrame db_f{"Flags:mojo.graphics.TextureFlags()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(348162);
  return this->m__0flags;
}

void t_mojo_graphics_Texture::m_Discard(){
  bbDBFrame db_f{"Discard:Void()","/home/pi/monkey2/modules/mojo/graphics/texture.monkey2"};
  t_mojo_graphics_Texture*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(364546);
  if(this->m__0discarded){
    bbDBBlock db_blk;
    bbDBStmt(364560);
    return;
  }
  bbDBStmt(368642);
  if((this->m__0texSeq==g_mojo_graphics_glutil_glGraphicsSeq)){
    bbDBBlock db_blk;
    bbDBStmt(368667);
    glDeleteTextures(1,&this->m__0glTexture);
  }
  bbDBStmt(372738);
  if((this->m__0fbSeq==g_mojo_graphics_glutil_glGraphicsSeq)){
    bbDBBlock db_blk;
    bbDBStmt(372762);
    glDeleteFramebuffers(1,&this->m__0glFramebuffer);
  }
  bbDBStmt(376834);
  this->m__0discarded=true;
  bbDBStmt(380930);
  this->m_OnDiscarded();
}
bbString bbDBType(t_mojo_graphics_Texture**){
  return "mojo.graphics.Texture";
}
bbString bbDBValue(t_mojo_graphics_Texture**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_graphics_2texture_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2texture_init_v("mojo_graphics_2texture",&mx2_mojo_graphics_2texture_init);
