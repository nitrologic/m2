
#include "../../desktop_debug_pi/mojo_graphics_2device.h"

// ***** External *****

#include "../../../../gles20/gles20.buildv1.0.2/desktop_debug_pi/gles20_gles20.h"
#include "../../../../libc/libc.buildv1.0.2/desktop_debug_pi/libc_libc.h"
#include "../../desktop_debug_pi/mojo_graphics_2shader.h"
#include "../../desktop_debug_pi/mojo_graphics_2texture.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_graphics_2pixmap.h"

extern bbInt g_mojo_graphics_glutil_glGraphicsSeq;

// ***** Internal *****

bbInt g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX;
bbGCRootVar<t_mojo_graphics_GraphicsDevice> g_mojo_graphics_GraphicsDevice__0current;
bbInt g_mojo_graphics_GraphicsDevice__0defaultFbo;
bbGCRootVar<bbArray<bbUShort>> g_mojo_graphics_GraphicsDevice__0qindices;
bbInt g_mojo_graphics_GraphicsDevice__0seq;
bbGCRootVar<bbArray<t_mojo_graphics_Vertex2f>> g_mojo_graphics_GraphicsDevice__0vertices;

void g_mojo_graphics_GraphicsDevice_InitGLState(){
  bbDBFrame db_f{"InitGLState:Void()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  bbDBStmt(1073154);
  glDisable(GL_CULL_FACE);
  bbDBStmt(1077250);
  glDisable(GL_DEPTH_TEST);
  bbDBStmt(1081346);
  glGetIntegerv(GL_FRAMEBUFFER_BINDING,&g_mojo_graphics_GraphicsDevice__0defaultFbo);
}

void t_mojo_graphics_GraphicsDevice::gcMark(){
  bbGCMark(m__0target);
  bbGCMark(m__0shaderEnv);
  bbGCMark(m__0envParams);
  bbGCMark(m__0shader);
  bbGCMark(m__0params);
}

void t_mojo_graphics_GraphicsDevice::dbEmit(){
  bbDBEmit("_dirty",&m__0dirty);
  bbDBEmit("_modified",&m__0modified);
  bbDBEmit("_target",&m__0target);
  bbDBEmit("_windowRect",&m__0windowRect);
  bbDBEmit("_viewport",&m__0viewport);
  bbDBEmit("_scissor",&m__0scissor);
  bbDBEmit("_blendMode",&m__0blendMode);
  bbDBEmit("_shaderEnv",&m__0shaderEnv);
  bbDBEmit("_envParams",&m__0envParams);
  bbDBEmit("_shader",&m__0shader);
  bbDBEmit("_params",&m__0params);
  bbDBEmit("_filter",&m__0filter);
  bbDBEmit("_rscissor",&m__0rscissor);
}

t_mojo_graphics_GraphicsDevice::t_mojo_graphics_GraphicsDevice(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  bbDBStmt(114690);
  this->m_RenderTarget(((t_mojo_graphics_Texture*)0));
  bbDBStmt(118786);
  this->m_Viewport(t_std_geom_Rect_1i(bbInt(0),bbInt(0),640,480));
  bbDBStmt(122882);
  this->m_Scissor(t_std_geom_Rect_1i(bbInt(0),bbInt(0),16384,16384));
  bbDBStmt(126978);
  this->m_BlendMode(t_mojo_graphics_BlendMode(1));
}

void t_mojo_graphics_GraphicsDevice::m_Viewport(t_std_geom_Rect_1i l_viewport){
  bbDBFrame db_f{"Viewport:Void(viewport:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("viewport",&l_viewport);
  bbDBStmt(217090);
  this->m_FlushTarget();
  bbDBStmt(225282);
  this->m__0viewport=l_viewport;
  bbDBStmt(233474);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(6))));
}

t_std_geom_Rect_1i t_mojo_graphics_GraphicsDevice::m_Viewport(){
  bbDBFrame db_f{"Viewport:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(200706);
  return this->m__0viewport;
}

void t_mojo_graphics_GraphicsDevice::m_Validate(){
  bbDBFrame db_f{"Validate:Void()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1126402);
  if((g_mojo_graphics_GraphicsDevice__0seq!=g_mojo_graphics_glutil_glGraphicsSeq)){
    bbDBBlock db_blk;
    bbDBStmt(1130499);
    g_mojo_graphics_GraphicsDevice__0seq=g_mojo_graphics_glutil_glGraphicsSeq;
    bbDBStmt(1134595);
    g_mojo_graphics_GraphicsDevice__0current=((t_mojo_graphics_GraphicsDevice*)0);
    bbDBStmt(1138691);
    g_mojo_graphics_GraphicsDevice_InitGLState();
  }
  bbDBStmt(1150978);
  if((g_mojo_graphics_GraphicsDevice__0current==this)){
    bbDBBlock db_blk;
    bbDBStmt(1155075);
    if(!bbBool(this->m__0dirty)){
      bbDBBlock db_blk;
      bbDBStmt(1155089);
      return;
    }
  }else{
    bbDBStmt(1159170);
    bbDBBlock db_blk;
    bbDBStmt(1163267);
    if(bbBool(g_mojo_graphics_GraphicsDevice__0current)){
      bbDBBlock db_blk;
      bbDBStmt(1163279);
      g_mojo_graphics_GraphicsDevice__0current->m_FlushTarget();
    }
    bbDBStmt(1167363);
    g_mojo_graphics_GraphicsDevice__0current=this;
    bbDBStmt(1171459);
    this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty(127);
  }
  bbDBStmt(1183746);
  if(bbBool(t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)&int(t_mojo_graphics_GraphicsDevice_Dirty(1)))))){
    bbDBBlock db_blk;
    bbDBStmt(1187843);
    if(bbBool(this->m__0target)){
      bbDBBlock db_blk;
      bbDBStmt(1191940);
      glBindFramebuffer(GL_FRAMEBUFFER,this->m__0target->m_GLFramebuffer());
    }else{
      bbDBStmt(1196035);
      bbDBBlock db_blk;
      bbDBStmt(1200132);
      glBindFramebuffer(GL_FRAMEBUFFER,bbUInt(g_mojo_graphics_GraphicsDevice__0defaultFbo));
    }
  }
  bbDBStmt(1216514);
  if(bbBool(t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)&int(t_mojo_graphics_GraphicsDevice_Dirty(2)))))){
    bbDBBlock db_blk;
    bbDBStmt(1220611);
    glViewport(this->m__0viewport.m_X(),this->m__0viewport.m_Y(),this->m__0viewport.m_Width(),this->m__0viewport.m_Height());
  }
  bbDBStmt(1232898);
  if(bbBool(t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)&int(t_mojo_graphics_GraphicsDevice_Dirty(4)))))){
    bbDBBlock db_blk;
    bbDBStmt(1236995);
    this->m__0rscissor=this->m__0scissor.m__and(this->m__0viewport);
    bbDBStmt(1241091);
    if((bbCompare(this->m__0rscissor,this->m__0viewport)!=0)){
      bbDBBlock db_blk;
      bbDBStmt(1245188);
      glEnable(GL_SCISSOR_TEST);
      bbDBStmt(1249284);
      glScissor(this->m__0rscissor.m_X(),this->m__0rscissor.m_Y(),this->m__0rscissor.m_Width(),this->m__0rscissor.m_Height());
    }else{
      bbDBStmt(1253379);
      bbDBBlock db_blk;
      bbDBStmt(1257476);
      glDisable(GL_SCISSOR_TEST);
    }
  }
  bbDBStmt(1273858);
  if(bbBool(t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)&int(t_mojo_graphics_GraphicsDevice_Dirty(8)))))){
    bbDBBlock db_blk;
    bbDBStmt(1277955);
    if(this->m__0blendMode==t_mojo_graphics_BlendMode(0)){
      bbDBBlock db_blk;
      bbDBStmt(1286148);
      glDisable(GL_BLEND);
    }else if(this->m__0blendMode==t_mojo_graphics_BlendMode(1)){
      bbDBBlock db_blk;
      bbDBStmt(1294340);
      glEnable(GL_BLEND);
      bbDBStmt(1298436);
      glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
    }else if(this->m__0blendMode==t_mojo_graphics_BlendMode(2)){
      bbDBBlock db_blk;
      bbDBStmt(1306628);
      glEnable(GL_BLEND);
      bbDBStmt(1310724);
      glBlendFunc(GL_ONE,GL_ONE);
    }else if(this->m__0blendMode==t_mojo_graphics_BlendMode(3)){
      bbDBBlock db_blk;
      bbDBStmt(1318916);
      glEnable(GL_BLEND);
      bbDBStmt(1323012);
      glBlendFunc(GL_DST_COLOR,GL_ONE_MINUS_SRC_ALPHA);
    }
  }
  bbDBStmt(1339394);
  if((((bbBool(this->m__0shader)&&bbBool(this->m__0shaderEnv))&&bbBool(this->m__0envParams))&&bbBool(this->m__0params))){
    bbDBBlock db_blk;
    bbDBStmt(1347587);
    if(bbBool(t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)&int(t_mojo_graphics_GraphicsDevice_Dirty(16)))))){
      bbDBBlock db_blk;
      bbDBStmt(1351684);
      this->m__0shader->m_Bind(this->m__0shaderEnv);
    }
    bbDBStmt(1363971);
    if(bbBool(t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)&int(t_mojo_graphics_GraphicsDevice_Dirty(32)))))){
      bbDBBlock db_blk;
      bbDBStmt(1368068);
      this->m__0shader->m_BindEnvParams(this->m__0envParams);
    }
    bbDBStmt(1380355);
    if(bbBool(t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)&int(t_mojo_graphics_GraphicsDevice_Dirty(64)))))){
      bbDBBlock db_blk;
      bbDBStmt(1384452);
      this->m__0shader->m_BindParams(this->m__0params,this->m__0filter);
    }
  }
  bbDBStmt(1404930);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty(0);
}

void t_mojo_graphics_GraphicsDevice::m_ShaderEnv(t_mojo_graphics_ShaderEnv* l_shaderEnv){
  bbDBFrame db_f{"ShaderEnv:Void(shaderEnv:mojo.graphics.ShaderEnv)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("shaderEnv",&l_shaderEnv);
  bbDBStmt(368642);
  this->m__0shaderEnv=l_shaderEnv;
  bbDBStmt(376834);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(112))));
}

t_mojo_graphics_ShaderEnv* t_mojo_graphics_GraphicsDevice::m_ShaderEnv(){
  bbDBFrame db_f{"ShaderEnv:mojo.graphics.ShaderEnv()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(352258);
  return this->m__0shaderEnv;
}

void t_mojo_graphics_GraphicsDevice::m_Shader(t_mojo_graphics_Shader* l_shader){
  bbDBFrame db_f{"Shader:Void(shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("shader",&l_shader);
  bbDBStmt(458754);
  this->m__0shader=l_shader;
  bbDBStmt(466946);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(112))));
}

t_mojo_graphics_Shader* t_mojo_graphics_GraphicsDevice::m_Shader(){
  bbDBFrame db_f{"Shader:mojo.graphics.Shader()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(442370);
  return this->m__0shader;
}

void t_mojo_graphics_GraphicsDevice::m_Scissor(t_std_geom_Rect_1i l_scissor){
  bbDBFrame db_f{"Scissor:Void(scissor:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("scissor",&l_scissor);
  bbDBStmt(270338);
  this->m_FlushTarget();
  bbDBStmt(278530);
  this->m__0scissor=l_scissor;
  bbDBStmt(286722);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(4))));
}

t_std_geom_Rect_1i t_mojo_graphics_GraphicsDevice::m_Scissor(){
  bbDBFrame db_f{"Scissor:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(253954);
  return this->m__0scissor;
}

void t_mojo_graphics_GraphicsDevice::m_RenderTarget(t_mojo_graphics_Texture* l_renderTarget){
  bbDBFrame db_f{"RenderTarget:Void(renderTarget:mojo.graphics.Texture)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("renderTarget",&l_renderTarget);
  bbDBStmt(163842);
  this->m_FlushTarget();
  bbDBStmt(172034);
  this->m__0target=l_renderTarget;
  bbDBStmt(180226);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(1))));
}

t_mojo_graphics_Texture* t_mojo_graphics_GraphicsDevice::m_RenderTarget(){
  bbDBFrame db_f{"RenderTarget:mojo.graphics.Texture()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(147458);
  return this->m__0target;
}

void t_mojo_graphics_GraphicsDevice::m_Render(t_mojo_graphics_Vertex2f* l_vertices,bbInt l_order,bbInt l_count){
  bbDBFrame db_f{"Render:Void(vertices:mojo.graphics.Vertex2f Ptr,order:Int,count:Int)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("vertices",&l_vertices);
  bbDBLocal("order",&l_order);
  bbDBLocal("count",&l_count);
  bbDBStmt(688130);
  this->m_Validate();
  bbDBStmt(696328);
  bbInt l_n=(l_order*l_count);
  bbDBLocal("n",&l_n);
  bbDBStmt(704514);
  if((l_n>g_mojo_graphics_GraphicsDevice__0vertices->length())){
    bbDBBlock db_blk;
    bbDBStmt(708611);
    g_mojo_graphics_GraphicsDevice__0vertices=bbArray<t_mojo_graphics_Vertex2f>::create(l_n);
    bbDBStmt(712713);
    bbUByte* l_p=((bbUByte*)(g_mojo_graphics_GraphicsDevice__0vertices->data()));
    bbDBLocal("p",&l_p);
    bbDBStmt(716803);
    glEnableVertexAttribArray(bbUInt(0));
    bbDBStmt(716836);
    glVertexAttribPointer(bbUInt(0),2,GL_FLOAT,false,g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX,((void*)(l_p)));
    bbDBStmt(720899);
    glEnableVertexAttribArray(1);
    bbDBStmt(720932);
    glVertexAttribPointer(1,2,GL_FLOAT,false,g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX,((void*)((l_p+8))));
    bbDBStmt(724995);
    glEnableVertexAttribArray(2);
    bbDBStmt(725028);
    glVertexAttribPointer(2,2,GL_FLOAT,false,g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX,((void*)((l_p+16))));
    bbDBStmt(729091);
    glEnableVertexAttribArray(3);
    bbDBStmt(729124);
    glVertexAttribPointer(3,4,GL_UNSIGNED_BYTE,true,g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX,((void*)((l_p+24))));
  }
  bbDBStmt(741378);
  memcpy(((void*)(g_mojo_graphics_GraphicsDevice__0vertices->data())),((void*)(l_vertices)),(l_n*g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX));
  bbDBStmt(749570);
  if(l_order==1){
    bbDBBlock db_blk;
    bbDBStmt(757763);
    glDrawArrays(GL_POINTS,bbInt(0),l_n);
  }else if(l_order==2){
    bbDBBlock db_blk;
    bbDBStmt(765955);
    glDrawArrays(GL_LINES,bbInt(0),l_n);
  }else if(l_order==3){
    bbDBBlock db_blk;
    bbDBStmt(774147);
    glDrawArrays(GL_TRIANGLES,bbInt(0),l_n);
  }else if(l_order==4){
    bbDBBlock db_blk;
    bbDBStmt(782345);
    bbInt l_n=(l_count*6);
    bbDBLocal("n",&l_n);
    bbDBStmt(786435);
    if((l_n>g_mojo_graphics_GraphicsDevice__0qindices->length())){
      bbDBBlock db_blk;
      bbDBStmt(790532);
      g_mojo_graphics_GraphicsDevice__0qindices=bbArray<bbUShort>::create(l_n);
      bbDBStmt(794628);
      {
        bbDBLoop db_loop;
        bbInt l_i=bbInt(0);
        bbDBLocal("i",&l_i);
        bbDBStmt(794628);
        for(;(l_i<l_count);l_i+=1){
          bbDBBlock db_blk;
          bbDBStmt(798725);
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+bbInt(0)))=bbUShort((l_i*4));
          bbDBStmt(802821);
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+1))=bbUShort(((l_i*4)+1));
          bbDBStmt(806917);
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+2))=bbUShort(((l_i*4)+2));
          bbDBStmt(811013);
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+3))=bbUShort((l_i*4));
          bbDBStmt(815109);
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+4))=bbUShort(((l_i*4)+2));
          bbDBStmt(819205);
          g_mojo_graphics_GraphicsDevice__0qindices->at(((l_i*6)+5))=bbUShort(((l_i*4)+3));
        }
      }
    }
    bbDBStmt(831491);
    glDrawElements(GL_TRIANGLES,l_n,GL_UNSIGNED_SHORT,((void*)(g_mojo_graphics_GraphicsDevice__0qindices->data())));
  }else{
    bbDBBlock db_blk;
    bbDBStmt(839683);
    {
      bbDBLoop db_loop;
      bbInt l_i=bbInt(0);
      bbDBLocal("i",&l_i);
      bbDBStmt(839683);
      for(;(l_i<l_count);l_i+=1){
        bbDBBlock db_blk;
        bbDBStmt(843780);
        glDrawArrays(GL_TRIANGLE_FAN,(l_i*l_order),l_order);
      }
    }
  }
  bbDBStmt(860162);
  this->m__0modified=true;
}

void t_mojo_graphics_GraphicsDevice::m_Params(t_mojo_graphics_ParamBuffer* l_params){
  bbDBFrame db_f{"Params:Void(params:mojo.graphics.ParamBuffer)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("params",&l_params);
  bbDBStmt(503810);
  this->m__0params=l_params;
  bbDBStmt(512002);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(64))));
}

t_mojo_graphics_ParamBuffer* t_mojo_graphics_GraphicsDevice::m_Params(){
  bbDBFrame db_f{"Params:mojo.graphics.ParamBuffer()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(487426);
  return this->m__0params;
}

void t_mojo_graphics_GraphicsDevice::m_FlushTarget(){
  bbDBFrame db_f{"FlushTarget:Void()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1097730);
  if(!this->m__0modified){
    bbDBBlock db_blk;
    bbDBStmt(1097747);
    return;
  }
  bbDBStmt(1101826);
  if(bbBool(this->m__0target)){
    bbDBBlock db_blk;
    bbDBStmt(1101837);
    this->m__0target->m_Modified(this);
  }
  bbDBStmt(1105922);
  this->m__0modified=false;
}

void t_mojo_graphics_GraphicsDevice::m_FilteringEnabled(bbBool l_filteringEnabled){
  bbDBFrame db_f{"FilteringEnabled:Void(filteringEnabled:Bool)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("filteringEnabled",&l_filteringEnabled);
  bbDBStmt(548866);
  if((l_filteringEnabled==this->m__0filter)){
    bbDBBlock db_blk;
    bbDBStmt(548894);
    return;
  }
  bbDBStmt(557058);
  this->m__0filter=l_filteringEnabled;
  bbDBStmt(565250);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(64))));
}

bbBool t_mojo_graphics_GraphicsDevice::m_FilteringEnabled(){
  bbDBFrame db_f{"FilteringEnabled:Bool()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(532482);
  return this->m__0filter;
}

void t_mojo_graphics_GraphicsDevice::m_EnvParams(t_mojo_graphics_ParamBuffer* l_envParams){
  bbDBFrame db_f{"EnvParams:Void(envParams:mojo.graphics.ParamBuffer)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("envParams",&l_envParams);
  bbDBStmt(413698);
  this->m__0envParams=l_envParams;
  bbDBStmt(421890);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(32))));
}

t_mojo_graphics_ParamBuffer* t_mojo_graphics_GraphicsDevice::m_EnvParams(){
  bbDBFrame db_f{"EnvParams:mojo.graphics.ParamBuffer()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(397314);
  return this->m__0envParams;
}

t_std_graphics_Pixmap* t_mojo_graphics_GraphicsDevice::m_CopyPixmap(t_std_geom_Rect_1i l_rect){
  struct f0_t : public bbGCFrame{
    t_std_graphics_Pixmap* l_pixmap{};
    void gcMark(){
      bbGCMarkPtr(l_pixmap);
    }
  }f0{};
  bbDBFrame db_f{"CopyPixmap:std.graphics.Pixmap(rect:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("rect",&l_rect);
  bbDBStmt(880642);
  this->m_Validate();
  bbDBStmt(888840);
  f0.l_pixmap=bbGCNew<t_std_graphics_Pixmap>(l_rect.m_Width(),l_rect.m_Height(),t_std_graphics_PixelFormat(5));
  bbDBLocal("pixmap",&f0.l_pixmap);
  bbDBStmt(897026);
  glReadPixels(l_rect.m_X(),l_rect.m_Y(),l_rect.m_Width(),l_rect.m_Height(),GL_RGBA,GL_UNSIGNED_BYTE,((void*)(f0.l_pixmap->m_Data())));
  bbDBStmt(905218);
  return f0.l_pixmap;
}

void t_mojo_graphics_GraphicsDevice::m_Clear(t_std_graphics_Color l_color){
  bbDBFrame db_f{"Clear:Void(color:std.graphics.Color)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("color",&l_color);
  bbDBStmt(585730);
  this->m_Validate();
  bbDBStmt(593922);
  if((bbCompare(this->m__0rscissor,this->m__0windowRect)!=0)){
    bbDBBlock db_blk;
    bbDBStmt(598019);
    glEnable(GL_SCISSOR_TEST);
    bbDBStmt(602115);
    glScissor(this->m__0rscissor.m_X(),this->m__0rscissor.m_Y(),this->m__0rscissor.m_Width(),this->m__0rscissor.m_Height());
  }else{
    bbDBStmt(606210);
    bbDBBlock db_blk;
    bbDBStmt(610307);
    glDisable(GL_SCISSOR_TEST);
  }
  bbDBStmt(622594);
  glClearColor(l_color.m_r,l_color.m_g,l_color.m_b,l_color.m_a);
  bbDBStmt(630786);
  glClear(GL_COLOR_BUFFER_BIT);
  bbDBStmt(638978);
  if((bbCompare(this->m__0rscissor,this->m__0viewport)!=0)){
    bbDBBlock db_blk;
    bbDBStmt(643075);
    glEnable(GL_SCISSOR_TEST);
    bbDBStmt(647171);
    glScissor(this->m__0rscissor.m_X(),this->m__0rscissor.m_Y(),this->m__0rscissor.m_Width(),this->m__0rscissor.m_Height());
  }else{
    bbDBStmt(651266);
    bbDBBlock db_blk;
    bbDBStmt(655363);
    glDisable(GL_SCISSOR_TEST);
  }
  bbDBStmt(667650);
  this->m__0modified=true;
}

void t_mojo_graphics_GraphicsDevice::m_BlendMode(t_mojo_graphics_BlendMode l_blendMode){
  bbDBFrame db_f{"BlendMode:Void(blendMode:mojo.graphics.BlendMode)","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("blendMode",&l_blendMode);
  bbDBStmt(323586);
  this->m__0blendMode=l_blendMode;
  bbDBStmt(331778);
  this->m__0dirty=t_mojo_graphics_GraphicsDevice_Dirty((int(this->m__0dirty)|int(t_mojo_graphics_GraphicsDevice_Dirty(8))));
}

t_mojo_graphics_BlendMode t_mojo_graphics_GraphicsDevice::m_BlendMode(){
  bbDBFrame db_f{"BlendMode:mojo.graphics.BlendMode()","/home/pi/monkey2/modules/mojo/graphics/device.monkey2"};
  t_mojo_graphics_GraphicsDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(307202);
  return this->m__0blendMode;
}
bbString bbDBType(t_mojo_graphics_GraphicsDevice**){
  return "mojo.graphics.GraphicsDevice";
}
bbString bbDBValue(t_mojo_graphics_GraphicsDevice**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_graphics_2device_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_graphics_GraphicsDevice_BYTES_0PER_0VERTEX=28;
}

bbInit mx2_mojo_graphics_2device_init_v("mojo_graphics_2device",&mx2_mojo_graphics_2device_init);
