
#include "../../desktop_debug_pi/mojo_app_2app.h"

// ***** External *****

#include "../../../../libc/libc.buildv1.0.2/desktop_debug_pi/libc_libc.h"
#include "../../desktop_debug_pi/mojo_app_2event.h"
#include "../../desktop_debug_pi/mojo_app_2style.h"
#include "../../desktop_debug_pi/mojo_app_2view.h"
#include "../../desktop_debug_pi/mojo_app_2window.h"
#include "../../desktop_debug_pi/mojo_audio_2audio.h"
#include "../../desktop_debug_pi/mojo_graphics_2font.h"
#include "../../desktop_debug_pi/mojo_input_2keyboard.h"
#include "../../desktop_debug_pi/mojo_input_2mouse.h"
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_graphics_2color.h"

// ***** Internal *****

bbGCRootVar<t_mojo_app_AppInstance> g_mojo_app_App;
bbGCRootVar<t_std_collections_Map_1iFvE> g_mojo_app_AppInstance__0asyncCallbacks;
bbGCRootVar<t_std_collections_Map_1iz> g_mojo_app_AppInstance__0disabledCallbacks;
bbInt g_mojo_app_AppInstance__0nextCallbackId;

bbInt g_mojo_app_AppInstance__0EventFilter(void* l_userData,SDL_Event* l_event){
  bbDBFrame db_f{"_EventFilter:Int(userData:Void Ptr,event:sdl2.SDL_Event Ptr)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("userData",&l_userData);
  bbDBLocal("event",&l_event);
  bbDBStmt(2785282);
  return g_mojo_app_App->m_EventFilter(l_userData,l_event);
}

void g_mojo_app_AppInstance_RemoveAsyncCallback(bbInt l_id){
  bbDBFrame db_f{"RemoveAsyncCallback:Void(id:Int)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("id",&l_id);
  bbDBStmt(3026946);
  g_mojo_app_AppInstance__0disabledCallbacks->m_Remove(l_id);
  bbDBStmt(3031042);
  g_mojo_app_AppInstance__0asyncCallbacks->m_Remove(l_id);
}

void g_mojo_app_AppInstance_EnableAsyncCallback(bbInt l_id){
  bbDBFrame db_f{"EnableAsyncCallback:Void(id:Int)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("id",&l_id);
  bbDBStmt(3047426);
  g_mojo_app_AppInstance__0disabledCallbacks->m_Remove(l_id);
}

void g_mojo_app_AppInstance_EmscriptenMainLoop(){
  bbDBFrame db_f{"EmscriptenMainLoop:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBStmt(1355778);
  g_mojo_app_App->m__0requestRender=true;
  bbDBStmt(1363970);
  g_mojo_app_App->m_MainLoop();
}

void g_mojo_app_AppInstance_DisableAsyncCallback(bbInt l_id){
  bbDBFrame db_f{"DisableAsyncCallback:Void(id:Int)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("id",&l_id);
  bbDBStmt(3063810);
  if(g_mojo_app_AppInstance__0asyncCallbacks->m_Contains(l_id)){
    bbDBBlock db_blk;
    bbDBStmt(3063844);
    g_mojo_app_AppInstance__0disabledCallbacks->m__idxeq(l_id,true);
  }
}

bbInt g_mojo_app_AppInstance_AddAsyncCallback(bbFunction<void()> l_func){
  bbDBFrame db_f{"AddAsyncCallback:Int(func:Void())","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("func",&l_func);
  bbDBStmt(2998274);
  g_mojo_app_AppInstance__0nextCallbackId+=1;
  bbDBStmt(3002376);
  bbInt l_id=g_mojo_app_AppInstance__0nextCallbackId;
  bbDBLocal("id",&l_id);
  bbDBStmt(3006466);
  g_mojo_app_AppInstance__0asyncCallbacks->m__idxeq(l_id,l_func);
  bbDBStmt(3010562);
  return l_id;
}

void t_mojo_app_AppInstance::init(){
  m__0modalStack=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_View_2>();
}

void t_mojo_app_AppInstance::gcMark(){
  bbGCMark(m_Idle);
  bbGCMark(m_NextIdle);
  bbGCMark(m_KeyEventFilter);
  bbGCMark(m_MouseEventFilter);
  bbGCMark(m__0config);
  bbGCMark(m__0dummyWindow);
  bbGCMark(m__0defaultFont);
  bbGCMark(m__0defaultMonoFont);
  bbGCMark(m__0hoverView);
  bbGCMark(m__0mouseView);
  bbGCMark(m__0window);
  bbGCMark(m__0modalView);
  bbGCMark(m__0modalStack);
}

void t_mojo_app_AppInstance::dbEmit(){
  bbDBEmit("Idle",&m_Idle);
  bbDBEmit("NextIdle",&m_NextIdle);
  bbDBEmit("KeyEventFilter",&m_KeyEventFilter);
  bbDBEmit("MouseEventFilter",&m_MouseEventFilter);
  bbDBEmit("_sdlThread",&m__0sdlThread);
  bbDBEmit("_config",&m__0config);
  bbDBEmit("_dummyWindow",&m__0dummyWindow);
  bbDBEmit("_defaultFont",&m__0defaultFont);
  bbDBEmit("_defaultMonoFont",&m__0defaultMonoFont);
  bbDBEmit("_requestRender",&m__0requestRender);
  bbDBEmit("_hoverView",&m__0hoverView);
  bbDBEmit("_mouseView",&m__0mouseView);
  bbDBEmit("_fps",&m__0fps);
  bbDBEmit("_fpsFrames",&m__0fpsFrames);
  bbDBEmit("_fpsMillis",&m__0fpsMillis);
  bbDBEmit("_window",&m__0window);
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_rawKey",&m__0rawKey);
  bbDBEmit("_keyChar",&m__0keyChar);
  bbDBEmit("_modifiers",&m__0modifiers);
  bbDBEmit("_mouseButton",&m__0mouseButton);
  bbDBEmit("_mouseLocation",&m__0mouseLocation);
  bbDBEmit("_mouseWheel",&m__0mouseWheel);
  bbDBEmit("_modalView",&m__0modalView);
  bbDBEmit("_modalStack",&m__0modalStack);
  bbDBEmit("_polling",&m__0polling);
}

t_mojo_app_AppInstance::t_mojo_app_AppInstance(t_std_collections_Map_1ss* l_config){
  init();
  struct f0_t : public bbGCFrame{
    t_std_collections_Map_1ss* l_config{};
    t_mojo_app_Style* l_style{};
    f0_t(t_std_collections_Map_1ss* l_config):l_config(l_config){
    }
    void gcMark(){
      bbGCMarkPtr(l_config);
      bbGCMarkPtr(l_style);
    }
  }f0{l_config};
  bbDBFrame db_f{"new:Void(config:StringMap:std.collections.Map<String,String>)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  bbDBLocal("config",&f0.l_config);
  bbDBStmt(253954);
  g_mojo_app_App=this;
  bbDBStmt(262146);
  if(!bbBool(f0.l_config)){
    bbDBBlock db_blk;
    bbDBStmt(262160);
    f0.l_config=bbGCNew<t_std_collections_Map_1ss>();
  }
  bbDBStmt(270338);
  this->m__0config=f0.l_config;
  bbDBStmt(278530);
  SDL_Init((SDL_INIT_EVERYTHING&~SDL_INIT_AUDIO));
  bbDBStmt(286722);
  this->m__0sdlThread=SDL_ThreadID();
  bbDBStmt(294914);
  g_mojo_input_Keyboard->m_Init();
  bbDBStmt(303106);
  g_mojo_input_Mouse->m_Init();
  bbDBStmt(311298);
  g_mojo_audio_Audio->m_Init();
  bbDBStmt(327682);
  SDL_GL_SetAttribute(SDL_GL_SHARE_WITH_CURRENT_CONTEXT,1);
  bbDBStmt(331778);
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER,1);
  bbDBStmt(339970);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,bbInt(this->m_GetConfig(BB_T("GL_depth_buffer_enabled"),BB_T("0"))));
  bbDBStmt(344066);
  SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE,bbInt(this->m_GetConfig(BB_T("GL_stencil_buffer_enabled"),BB_T("0"))));
  bbDBStmt(352258);
  this->m__0dummyWindow=bbGCNew<t_mojo_app_Window>(BB_T("<hidden>"),this);
  bbDBStmt(364546);
  this->m__0defaultFont=g_mojo_graphics_Font_Open(this->m_DefaultFontName(),16.0f);
  bbDBStmt(372738);
  this->m__0defaultMonoFont=g_mojo_graphics_Font_Open(this->m_DefaultMonoFontName(),16.0f);
  bbDBStmt(380936);
  f0.l_style=g_mojo_app_Style_GetStyle(bbString{});
  bbDBLocal("style",&f0.l_style);
  bbDBStmt(385026);
  f0.l_style->m_DefaultFont(this->m__0defaultFont);
  bbDBStmt(389122);
  f0.l_style->m_DefaultColor(g_std_graphics_Color_White);
}

void t_mojo_app_AppInstance::m_UpdateFPS(){
  bbDBFrame db_f{"UpdateFPS:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1630210);
  this->m__0fpsFrames+=1;
  bbDBStmt(1638408);
  bbInt l_elapsed=(g_mojo_app_App->m_Millisecs()-this->m__0fpsMillis);
  bbDBLocal("elapsed",&l_elapsed);
  bbDBStmt(1646594);
  if((l_elapsed>=250)){
    bbDBBlock db_blk;
    bbDBStmt(1650691);
    this->m__0fps=bbFloat(std::round(bbDouble((bbFloat(this->m__0fpsFrames)/(bbFloat(l_elapsed)/1000.0f)))));
    bbDBStmt(1654787);
    this->m__0fpsMillis+=l_elapsed;
    bbDBStmt(1658883);
    this->m__0fpsFrames=bbInt(0);
  }
}

void t_mojo_app_AppInstance::m_UpdateEvents(){
  struct f0_t : public bbGCFrame{
    bbFunction<void()> l_idle{};
    void gcMark(){
      bbGCMark(l_idle);
    }
  }f0{};
  bbDBFrame db_f{"UpdateEvents:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1687560);
  SDL_Event l_event{};
  bbDBLocal("event",&l_event);
  bbDBStmt(1695746);
  this->m__0polling=true;
  bbDBStmt(1703938);
  {
    bbDBLoop db_loop;
    while(bbBool(SDL_PollEvent(&l_event))){
      bbDBBlock db_blk;
      bbDBStmt(1712131);
      this->m_DispatchEvent(&l_event);
    }
  }
  bbDBStmt(1728514);
  this->m__0polling=false;
  bbDBStmt(1736712);
  f0.l_idle=this->m_Idle;
  bbDBLocal("idle",&f0.l_idle);
  bbDBStmt(1740802);
  this->m_Idle=this->m_NextIdle;
  bbDBStmt(1744898);
  this->m_NextIdle=bbFunction<void()>{};
  bbDBStmt(1748994);
  f0.l_idle();
  bbDBStmt(1757186);
  {
    struct f1_t : public bbGCFrame{
      bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
      void gcMark(){
        bbGCMarkPtr(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=g_mojo_app_Window_VisibleWindows();
    bbDBLocal("0",&f1.l_0);
    bbInt l_1=bbInt(0);
    bbDBLocal("1",&l_1);
    bbInt l_2=f1.l_0->length();
    bbDBLocal("2",&l_2);
    for(;(l_1<l_2);l_1+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_window{};
        void gcMark(){
          bbGCMarkPtr(l_window);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_window=f1.l_0->at(l_1);
      bbDBLocal("window",&f2.l_window);
    }
  }
}

void t_mojo_app_AppInstance::m_Terminate(){
  bbDBFrame db_f{"Terminate:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  SDL_Quit();
  bbDBStmt(1196034);
  exit(bbInt(0));
}

void t_mojo_app_AppInstance::m_SendWindowEvent(t_mojo_app_EventType l_type){
  struct f0_t : public bbGCFrame{
    t_mojo_app_WindowEvent* l_event{};
    void gcMark(){
      bbGCMarkPtr(l_event);
    }
  }f0{};
  bbDBFrame db_f{"SendWindowEvent:Void(type:mojo.app.EventType)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("type",&l_type);
  bbDBStmt(1933320);
  f0.l_event=bbGCNew<t_mojo_app_WindowEvent>(l_type,this->m__0window);
  bbDBLocal("event",&f0.l_event);
  bbDBStmt(1941506);
  this->m__0window->m_SendWindowEvent(f0.l_event);
}

void t_mojo_app_AppInstance::m_SendMouseEvent(t_mojo_app_EventType l_type,t_mojo_app_View* l_view){
  struct f0_t : public bbGCFrame{
    t_mojo_app_MouseEvent* l_event{};
    void gcMark(){
      bbGCMarkPtr(l_event);
    }
  }f0{};
  bbDBFrame db_f{"SendMouseEvent:Void(type:mojo.app.EventType,view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("type",&l_type);
  bbDBLocal("view",&l_view);
  bbDBStmt(1871880);
  t_std_geom_Vec2_1i l_location=l_view->m_TransformWindowPointToView(this->m__0mouseLocation);
  bbDBLocal("location",&l_location);
  bbDBStmt(1880072);
  f0.l_event=bbGCNew<t_mojo_app_MouseEvent>(l_type,l_view,l_location,this->m__0mouseButton,this->m__0mouseWheel,this->m__0modifiers);
  bbDBLocal("event",&f0.l_event);
  bbDBStmt(1888258);
  this->m_MouseEventFilter(f0.l_event);
  bbDBStmt(1896450);
  if(f0.l_event->m_Eaten()){
    bbDBBlock db_blk;
    bbDBStmt(1896465);
    return;
  }
  bbDBStmt(1904642);
  if((bbBool(this->m__0modalView)&&!l_view->m_IsChildOf(this->m__0modalView))){
    bbDBBlock db_blk;
    bbDBStmt(1904693);
    return;
  }
  bbDBStmt(1912834);
  l_view->m_SendMouseEvent(f0.l_event);
}

void t_mojo_app_AppInstance::m_SendKeyEvent(t_mojo_app_EventType l_type){
  struct f0_t : public bbGCFrame{
    t_mojo_app_KeyEvent* l_event{};
    t_mojo_app_View* l_view{};
    void gcMark(){
      bbGCMarkPtr(l_event);
      bbGCMarkPtr(l_view);
    }
  }f0{};
  bbDBFrame db_f{"SendKeyEvent:Void(type:mojo.app.EventType)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("type",&l_type);
  bbDBStmt(1789960);
  f0.l_view=this->m_KeyView();
  bbDBLocal("view",&f0.l_view);
  bbDBStmt(1794050);
  if((bbBool(f0.l_view)&&!f0.l_view->m_ReallyEnabled())){
    bbDBBlock db_blk;
    bbDBStmt(1794085);
    f0.l_view=((t_mojo_app_View*)0);
  }
  bbDBStmt(1802248);
  f0.l_event=bbGCNew<t_mojo_app_KeyEvent>(l_type,f0.l_view,this->m__0key,this->m__0rawKey,this->m__0modifiers,this->m__0keyChar);
  bbDBLocal("event",&f0.l_event);
  bbDBStmt(1810434);
  this->m_KeyEventFilter(f0.l_event);
  bbDBStmt(1818626);
  if(f0.l_event->m_Eaten()){
    bbDBBlock db_blk;
    bbDBStmt(1818641);
    return;
  }
  bbDBStmt(1826818);
  if((bbBool(this->m__0modalView)&&!f0.l_view->m_IsChildOf(this->m__0modalView))){
    bbDBBlock db_blk;
    bbDBStmt(1826869);
    return;
  }
  bbDBStmt(1835010);
  if(bbBool(f0.l_view)){
    bbDBBlock db_blk;
    bbDBStmt(1839107);
    f0.l_view->m_SendKeyEvent(f0.l_event);
  }else if(bbDBStmt(1843202),bbBool(this->m_ActiveWindow())){
    struct f1_t : public bbGCFrame{
      t_mojo_app_Window* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(1847299);
    (f1.t0=this->m_ActiveWindow())->m_SendKeyEvent(f0.l_event);
  }
}

void t_mojo_app_AppInstance::m_Run(){
  bbDBFrame db_f{"Run:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1392642);
  SDL_AddEventWatch(g_mojo_app_AppInstance__0EventFilter,((void*)0));
  bbDBStmt(1400834);
  this->m_RequestRender();
  bbDBStmt(1429506);
  {
    bbDBLoop db_loop;
    for(;;){
      bbDBBlock db_blk;
      bbDBStmt(1437699);
      this->m_MainLoop();
    }
  }
}

void t_mojo_app_AppInstance::m_RequestRender(){
  bbDBFrame db_f{"RequestRender:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1224706);
  this->m__0requestRender=true;
}

t_mojo_app_View* t_mojo_app_AppInstance::m_MouseView(){
  bbDBFrame db_f{"MouseView:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(741378);
  return this->m__0mouseView;
}

t_std_geom_Vec2_1i t_mojo_app_AppInstance::m_MouseLocation(){
  bbDBFrame db_f{"MouseLocation:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1007618);
  return this->m__0mouseLocation;
}

bbInt t_mojo_app_AppInstance::m_Millisecs(){
  bbDBFrame db_f{"Millisecs:Int()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(966658);
  return SDL_GetTicks();
}

void t_mojo_app_AppInstance::m_MainLoop(){
  bbDBFrame db_f{"MainLoop:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  if(!this->m__0requestRender){
    bbDBBlock db_blk;
    bbDBStmt(1261571);
    SDL_WaitEvent(((SDL_Event*)0));
  }
  bbDBStmt(1277954);
  this->m_UpdateEvents();
  bbDBStmt(1286146);
  if(!this->m__0requestRender){
    bbDBBlock db_blk;
    bbDBStmt(1286168);
    return;
  }
  bbDBStmt(1294338);
  this->m__0requestRender=false;
  bbDBStmt(1302530);
  this->m_UpdateFPS();
  bbDBStmt(1310722);
  {
    struct f1_t : public bbGCFrame{
      bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
      void gcMark(){
        bbGCMarkPtr(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=g_mojo_app_Window_VisibleWindows();
    bbDBLocal("0",&f1.l_0);
    bbInt l_1=bbInt(0);
    bbDBLocal("1",&l_1);
    bbInt l_2=f1.l_0->length();
    bbDBLocal("2",&l_2);
    for(;(l_1<l_2);l_1+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_window{};
        void gcMark(){
          bbGCMarkPtr(l_window);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_window=f1.l_0->at(l_1);
      bbDBLocal("window",&f2.l_window);
      bbDBStmt(1314819);
      f2.l_window->m_Update();
      bbDBStmt(1318915);
      f2.l_window->m_Render();
    }
  }
}

void t_mojo_app_AppInstance::m_KeyView(t_mojo_app_View* l_keyView){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_window{};
    void gcMark(){
      bbGCMarkPtr(l_window);
    }
  }f0{};
  bbDBFrame db_f{"KeyView:Void(keyView:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("keyView",&l_keyView);
  bbDBStmt(692232);
  f0.l_window=this->m_ActiveWindow();
  bbDBLocal("window",&f0.l_window);
  bbDBStmt(696322);
  if(bbBool(f0.l_window)){
    bbDBBlock db_blk;
    bbDBStmt(696332);
    f0.l_window->m_KeyView(l_keyView);
  }
}

t_mojo_app_View* t_mojo_app_AppInstance::m_KeyView(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_window{};
    void gcMark(){
      bbGCMarkPtr(l_window);
    }
  }f0{};
  bbDBFrame db_f{"KeyView:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(663560);
  f0.l_window=this->m_ActiveWindow();
  bbDBLocal("window",&f0.l_window);
  bbDBStmt(667650);
  if(bbBool(f0.l_window)){
    bbDBBlock db_blk;
    bbDBStmt(667660);
    return f0.l_window->m_KeyView();
  }
  bbDBStmt(675842);
  return ((t_mojo_app_View*)0);
}

t_mojo_app_View* t_mojo_app_AppInstance::m_HoverView(){
  bbDBFrame db_f{"HoverView:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(782338);
  return this->m__0hoverView;
}

bbArray<t_mojo_app_DisplayMode>* t_mojo_app_AppInstance::m_GetDisplayModes(){
  struct f0_t : public bbGCFrame{
    bbArray<t_mojo_app_DisplayMode>* l_modes{};
    void gcMark(){
      bbGCMarkPtr(l_modes);
    }
  }f0{};
  bbDBFrame db_f{"GetDisplayModes:mojo.app.DisplayMode[]()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1064968);
  bbInt l_n=SDL_GetNumDisplayModes(bbInt(0));
  bbDBLocal("n",&l_n);
  bbDBStmt(1069064);
  f0.l_modes=bbArray<t_mojo_app_DisplayMode>::create(l_n);
  bbDBLocal("modes",&f0.l_modes);
  bbDBStmt(1073154);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1073154);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1077257);
      SDL_DisplayMode l_mode{};
      bbDBLocal("mode",&l_mode);
      bbDBStmt(1081347);
      SDL_GetDisplayMode(bbInt(0),l_i,&l_mode);
      bbDBStmt(1085443);
      f0.l_modes->at(l_i).m_width=l_mode.w;
      bbDBStmt(1089539);
      f0.l_modes->at(l_i).m_height=l_mode.h;
      bbDBStmt(1093635);
      f0.l_modes->at(l_i).m_hertz=l_mode.refresh_rate;
    }
  }
  bbDBStmt(1105922);
  return f0.l_modes;
}

bbString t_mojo_app_AppInstance::m_GetConfig(bbString l_name,bbString l_defValue){
  bbDBFrame db_f{"GetConfig:String(name:String,defValue:String)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("defValue",&l_defValue);
  bbDBStmt(1032194);
  if(this->m__0config->m_Contains(l_name)){
    bbDBBlock db_blk;
    bbDBStmt(1032222);
    return this->m__0config->m__idx(l_name);
  }
  bbDBStmt(1036290);
  return l_defValue;
}

bbFloat t_mojo_app_AppInstance::m_FPS(){
  bbDBFrame db_f{"FPS:Float()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(925698);
  return this->m__0fps;
}

bbInt t_mojo_app_AppInstance::m_EventFilter(void* l_userData,SDL_Event* l_event){
  bbDBFrame db_f{"EventFilter:Int(userData:Void Ptr,event:sdl2.SDL_Event Ptr)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("userData",&l_userData);
  bbDBLocal("event",&l_event);
  bbDBStmt(2834434);
  if(l_event[bbInt(0)].type==bbInt(SDL_WINDOWEVENT)){
    bbDBBlock db_blk;
    bbDBStmt(2846729);
    SDL_WindowEvent* l_wevent=((SDL_WindowEvent*)(l_event));
    bbDBLocal("wevent",&l_wevent);
    bbDBStmt(2854915);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_wevent[bbInt(0)].windowID));
    bbDBStmt(2859011);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2859026);
      return 1;
    }
    bbDBStmt(2867203);
    if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_MOVED)){
      bbDBBlock db_blk;
      bbDBStmt(2883588);
      this->m_SendWindowEvent(t_mojo_app_EventType(11));
      bbDBStmt(2891780);
      return bbInt(0);
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_RESIZED)){
      bbDBBlock db_blk;
      bbDBStmt(2908164);
      this->m_SendWindowEvent(t_mojo_app_EventType(12));
      bbDBStmt(2916356);
      if(this->m__0requestRender){
        bbDBBlock db_blk;
        bbDBStmt(2924549);
        this->m__0requestRender=false;
        bbDBStmt(2932741);
        {
          struct f4_t : public bbGCFrame{
            bbArray<bbGCVar<t_mojo_app_Window>>* l_0{};
            void gcMark(){
              bbGCMarkPtr(l_0);
            }
          }f4{};
          bbDBLoop db_loop;
          f4.l_0=g_mojo_app_Window_VisibleWindows();
          bbDBLocal("0",&f4.l_0);
          bbInt l_1=bbInt(0);
          bbDBLocal("1",&l_1);
          bbInt l_2=f4.l_0->length();
          bbDBLocal("2",&l_2);
          for(;(l_1<l_2);l_1+=1){
            struct f5_t : public bbGCFrame{
              t_mojo_app_Window* l_window{};
              void gcMark(){
                bbGCMarkPtr(l_window);
              }
            }f5{};
            bbDBBlock db_blk;
            f5.l_window=f4.l_0->at(l_1);
            bbDBLocal("window",&f5.l_window);
            bbDBStmt(2936838);
            f5.l_window->m_Update();
            bbDBStmt(2940934);
            f5.l_window->m_Render();
          }
        }
      }
      bbDBStmt(2961412);
      return bbInt(0);
    }
  }
  bbDBStmt(2981890);
  return 1;
}

void t_mojo_app_AppInstance::m_EndModal(){
  bbDBFrame db_f{"EndModal:Void()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1159170);
  this->m__0modalView=this->m__0modalStack->m_Pop();
}

void t_mojo_app_AppInstance::m_DispatchEvent(SDL_Event* l_event){
  bbDBFrame db_f{"DispatchEvent:Void(event:sdl2.SDL_Event Ptr)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  bbDBStmt(1961986);
  if(l_event[bbInt(0)].type==bbInt(SDL_KEYDOWN)){
    bbDBBlock db_blk;
    bbDBStmt(1978377);
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    bbDBLocal("kevent",&l_kevent);
    bbDBStmt(1986563);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_kevent[bbInt(0)].windowID));
    bbDBStmt(1990659);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(1990674);
      return;
    }
    bbDBStmt(1998851);
    this->m__0key=g_mojo_input_Keyboard->m_KeyCodeToKey(l_kevent[bbInt(0)].keysym.sym);
    bbDBStmt(2002947);
    this->m__0rawKey=g_mojo_input_Keyboard->m_ScanCodeToRawKey(bbInt(l_kevent[bbInt(0)].keysym.scancode));
    bbDBStmt(2011139);
    this->m__0keyChar=g_mojo_input_Keyboard->m_KeyName(this->m__0key);
    bbDBStmt(2019331);
    if(bbBool(l_kevent[bbInt(0)].repeat)){
      bbDBBlock db_blk;
      bbDBStmt(2023428);
      this->m_SendKeyEvent(t_mojo_app_EventType(1));
    }else{
      bbDBStmt(2027523);
      bbDBBlock db_blk;
      bbDBStmt(2031620);
      this->m_SendKeyEvent(t_mojo_app_EventType(0));
    }
    bbDBStmt(2043907);
    this->m__0modifiers=g_mojo_input_Keyboard->m_Modifiers();
  }else if(l_event[bbInt(0)].type==bbInt(SDL_KEYUP)){
    bbDBBlock db_blk;
    bbDBStmt(2060297);
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    bbDBLocal("kevent",&l_kevent);
    bbDBStmt(2068483);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_kevent[bbInt(0)].windowID));
    bbDBStmt(2072579);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2072594);
      return;
    }
    bbDBStmt(2080771);
    this->m__0key=g_mojo_input_Keyboard->m_KeyCodeToKey(l_kevent[bbInt(0)].keysym.sym);
    bbDBStmt(2084867);
    this->m__0rawKey=g_mojo_input_Keyboard->m_ScanCodeToRawKey(bbInt(l_kevent[bbInt(0)].keysym.scancode));
    bbDBStmt(2093059);
    this->m__0keyChar=g_mojo_input_Keyboard->m_KeyName(this->m__0key);
    bbDBStmt(2101251);
    this->m_SendKeyEvent(t_mojo_app_EventType(2));
    bbDBStmt(2109443);
    this->m__0modifiers=g_mojo_input_Keyboard->m_Modifiers();
  }else if(l_event[bbInt(0)].type==bbInt(SDL_TEXTINPUT)){
    bbDBBlock db_blk;
    bbDBStmt(2125833);
    SDL_TextInputEvent* l_tevent=((SDL_TextInputEvent*)(l_event));
    bbDBLocal("tevent",&l_tevent);
    bbDBStmt(2134019);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_tevent[bbInt(0)].windowID));
    bbDBStmt(2138115);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2138130);
      return;
    }
    bbDBStmt(2146307);
    this->m__0keyChar=bbString::fromChar(bbInt(l_tevent[bbInt(0)].text[bbInt(0)]));
    bbDBStmt(2154499);
    this->m_SendKeyEvent(t_mojo_app_EventType(3));
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEBUTTONDOWN)){
    bbDBBlock db_blk;
    bbDBStmt(2170889);
    SDL_MouseButtonEvent* l_mevent=((SDL_MouseButtonEvent*)(l_event));
    bbDBLocal("mevent",&l_mevent);
    bbDBStmt(2179075);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    bbDBStmt(2183171);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2183186);
      return;
    }
    bbDBStmt(2191363);
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    bbDBStmt(2195459);
    this->m__0mouseButton=((t_mojo_input_MouseButton)(l_mevent[bbInt(0)].button));
    bbDBStmt(2203651);
    if(!bbBool(this->m__0mouseView)){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_view{};
        void gcMark(){
          bbGCMarkPtr(l_view);
        }
      }f2{};
      bbDBBlock db_blk;
      bbDBStmt(2211850);
      f2.l_view=this->m__0window->m_FindViewAtWindowPoint(this->m__0mouseLocation);
      bbDBLocal("view",&f2.l_view);
      bbDBStmt(2215940);
      if(bbBool(f2.l_view)){
        bbDBBlock db_blk;
        bbDBStmt(2224133);
        SDL_CaptureMouse(SDL_TRUE);
        bbDBStmt(2232325);
        this->m__0mouseView=f2.l_view;
      }
    }
    bbDBStmt(2248707);
    if(bbBool(this->m__0mouseView)){
      bbDBBlock db_blk;
      bbDBStmt(2248721);
      this->m_SendMouseEvent(t_mojo_app_EventType(4),this->m__0mouseView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEBUTTONUP)){
    bbDBBlock db_blk;
    bbDBStmt(2265097);
    SDL_MouseButtonEvent* l_mevent=((SDL_MouseButtonEvent*)(l_event));
    bbDBLocal("mevent",&l_mevent);
    bbDBStmt(2273283);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    bbDBStmt(2277379);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2277394);
      return;
    }
    bbDBStmt(2285571);
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    bbDBStmt(2289667);
    this->m__0mouseButton=((t_mojo_input_MouseButton)(l_mevent[bbInt(0)].button));
    bbDBStmt(2297859);
    if(bbBool(this->m__0mouseView)){
      bbDBBlock db_blk;
      bbDBStmt(2306052);
      this->m_SendMouseEvent(t_mojo_app_EventType(5),this->m__0mouseView);
      bbDBStmt(2314244);
      SDL_CaptureMouse(SDL_FALSE);
      bbDBStmt(2322436);
      this->m__0mouseView=((t_mojo_app_View*)0);
      bbDBStmt(2330628);
      this->m__0mouseButton=t_mojo_input_MouseButton(0);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEMOTION)){
    struct f1_t : public bbGCFrame{
      t_mojo_app_View* l_view{};
      void gcMark(){
        bbGCMarkPtr(l_view);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(2351113);
    SDL_MouseMotionEvent* l_mevent=((SDL_MouseMotionEvent*)(l_event));
    bbDBLocal("mevent",&l_mevent);
    bbDBStmt(2359299);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    bbDBStmt(2363395);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2363410);
      return;
    }
    bbDBStmt(2371587);
    this->m__0mouseLocation=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    bbDBStmt(2379785);
    f1.l_view=this->m__0window->m_FindViewAtWindowPoint(this->m__0mouseLocation);
    bbDBLocal("view",&f1.l_view);
    bbDBStmt(2387971);
    if((bbBool(this->m__0mouseView)&&(f1.l_view!=this->m__0mouseView))){
      bbDBBlock db_blk;
      bbDBStmt(2388006);
      f1.l_view=((t_mojo_app_View*)0);
    }
    bbDBStmt(2396163);
    if((f1.l_view!=this->m__0hoverView)){
      bbDBBlock db_blk;
      bbDBStmt(2404356);
      if(bbBool(this->m__0hoverView)){
        bbDBBlock db_blk;
        bbDBStmt(2404370);
        this->m_SendMouseEvent(t_mojo_app_EventType(9),this->m__0hoverView);
      }
      bbDBStmt(2412548);
      this->m__0hoverView=f1.l_view;
      bbDBStmt(2420740);
      if(bbBool(this->m__0hoverView)){
        bbDBBlock db_blk;
        bbDBStmt(2420754);
        this->m_SendMouseEvent(t_mojo_app_EventType(8),this->m__0hoverView);
      }
    }
    bbDBStmt(2433027);
    if(bbBool(this->m__0mouseView)){
      bbDBBlock db_blk;
      bbDBStmt(2441220);
      this->m_SendMouseEvent(t_mojo_app_EventType(6),this->m__0mouseView);
    }else if(bbDBStmt(2449411),bbBool(this->m__0hoverView)){
      bbDBBlock db_blk;
      bbDBStmt(2457604);
      this->m_SendMouseEvent(t_mojo_app_EventType(6),this->m__0hoverView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_MOUSEWHEEL)){
    bbDBBlock db_blk;
    bbDBStmt(2482185);
    SDL_MouseWheelEvent* l_mevent=((SDL_MouseWheelEvent*)(l_event));
    bbDBLocal("mevent",&l_mevent);
    bbDBStmt(2490371);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_mevent[bbInt(0)].windowID));
    bbDBStmt(2494467);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2494482);
      return;
    }
    bbDBStmt(2502659);
    this->m__0mouseWheel=t_std_geom_Vec2_1i(l_mevent[bbInt(0)].x,l_mevent[bbInt(0)].y);
    bbDBStmt(2510851);
    if(bbBool(this->m__0mouseView)){
      bbDBBlock db_blk;
      bbDBStmt(2519044);
      this->m_SendMouseEvent(t_mojo_app_EventType(7),this->m__0mouseView);
    }else if(bbDBStmt(2527235),bbBool(this->m__0hoverView)){
      bbDBBlock db_blk;
      bbDBStmt(2535428);
      this->m_SendMouseEvent(t_mojo_app_EventType(7),this->m__0hoverView);
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_WINDOWEVENT)){
    bbDBBlock db_blk;
    bbDBStmt(2560009);
    SDL_WindowEvent* l_wevent=((SDL_WindowEvent*)(l_event));
    bbDBLocal("wevent",&l_wevent);
    bbDBStmt(2568195);
    this->m__0window=g_mojo_app_Window_WindowForID(bbUInt(l_wevent[bbInt(0)].windowID));
    bbDBStmt(2572291);
    if(!bbBool(this->m__0window)){
      bbDBBlock db_blk;
      bbDBStmt(2572306);
      return;
    }
    bbDBStmt(2580483);
    if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_CLOSE)){
      bbDBBlock db_blk;
      bbDBStmt(2596868);
      this->m_SendWindowEvent(t_mojo_app_EventType(10));
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_MOVED)){
      bbDBBlock db_blk;
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_RESIZED)){
      bbDBBlock db_blk;
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_SIZE_CHANGED)){
      bbDBBlock db_blk;
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_FOCUS_GAINED)){
      bbDBBlock db_blk;
      bbDBStmt(2637828);
      this->m_SendWindowEvent(t_mojo_app_EventType(13));
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_FOCUS_LOST)){
      bbDBBlock db_blk;
      bbDBStmt(2654212);
      this->m_SendWindowEvent(t_mojo_app_EventType(14));
    }else if(l_wevent[bbInt(0)].event==bbByte(SDL_WINDOWEVENT_LEAVE)){
      bbDBBlock db_blk;
      bbDBStmt(2670596);
      if(bbBool(this->m__0hoverView)){
        bbDBBlock db_blk;
        bbDBStmt(2674693);
        this->m_SendMouseEvent(t_mojo_app_EventType(9),this->m__0hoverView);
        bbDBStmt(2678789);
        this->m__0hoverView=((t_mojo_app_View*)0);
      }
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_USEREVENT)){
    bbDBBlock db_blk;
    bbDBStmt(2707465);
    SDL_UserEvent* l_t=((SDL_UserEvent*)(l_event));
    bbDBLocal("t",&l_t);
    bbDBStmt(2715657);
    bbInt l_code=l_t[bbInt(0)].code;
    bbDBLocal("code",&l_code);
    bbDBStmt(2719753);
    bbInt l_id=(l_code&1073741823);
    bbDBLocal("id",&l_id);
    bbDBStmt(2727939);
    if(bbBool((l_code&1073741824))){
      struct f2_t : public bbGCFrame{
        bbFunction<void()> l_func{};
        void gcMark(){
          bbGCMark(l_func);
        }
      }f2{};
      bbDBBlock db_blk;
      bbDBStmt(2732042);
      f2.l_func=g_mojo_app_AppInstance__0asyncCallbacks->m__idx(l_id);
      bbDBLocal("func",&f2.l_func);
      bbDBStmt(2736132);
      if(bbBool((l_code&2147483648))){
        bbDBBlock db_blk;
        bbDBStmt(2736152);
        g_mojo_app_AppInstance_RemoveAsyncCallback(l_id);
      }
      bbDBStmt(2740228);
      if(!g_mojo_app_AppInstance__0disabledCallbacks->m__idx(l_id)){
        bbDBBlock db_blk;
        bbDBStmt(2740258);
        f2.l_func();
      }
    }else if(bbDBStmt(2744323),bbBool((l_code&2147483648))){
      bbDBBlock db_blk;
      bbDBStmt(2748420);
      g_mojo_app_AppInstance_RemoveAsyncCallback(l_id);
    }
  }
}

t_std_geom_Vec2_1i t_mojo_app_AppInstance::m_DesktopSize(){
  bbDBFrame db_f{"DesktopSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(831496);
  SDL_DisplayMode l_dm{};
  bbDBLocal("dm",&l_dm);
  bbDBStmt(839682);
  if(bbBool(SDL_GetDesktopDisplayMode(bbInt(0),&l_dm))){
    bbDBBlock db_blk;
    bbDBStmt(839726);
    return t_std_geom_Vec2_1i(bbNullCtor);
  }
  bbDBStmt(847874);
  return t_std_geom_Vec2_1i(l_dm.w,l_dm.h);
}

bbString t_mojo_app_AppInstance::m_DefaultMonoFontName(){
  bbDBFrame db_f{"DefaultMonoFontName:String()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(438274);
  return BB_T("asset::mojo/RobotoMono-Regular.ttf");
}

t_mojo_graphics_Font* t_mojo_app_AppInstance::m_DefaultMonoFont(){
  bbDBFrame db_f{"DefaultMonoFont:mojo.graphics.Font()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(487426);
  return this->m__0defaultMonoFont;
}

bbString t_mojo_app_AppInstance::m_DefaultFontName(){
  bbDBFrame db_f{"DefaultFontName:String()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(413698);
  return BB_T("asset::mojo/Roboto-Regular.ttf");
}

t_mojo_graphics_Font* t_mojo_app_AppInstance::m_DefaultFont(){
  bbDBFrame db_f{"DefaultFont:mojo.graphics.Font()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(462850);
  return this->m__0defaultFont;
}

bbBool t_mojo_app_AppInstance::m_ClipboardTextEmpty(){
  bbDBFrame db_f{"ClipboardTextEmpty:Bool()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(528386);
  return (SDL_HasClipboardText()==SDL_FALSE);
}

void t_mojo_app_AppInstance::m_ClipboardText(bbString l_text){
  bbDBFrame db_f{"ClipboardText:Void(text:String)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("text",&l_text);
  bbDBStmt(622594);
  SDL_SetClipboardText(bbUtf8String(l_text));
}

bbString t_mojo_app_AppInstance::m_ClipboardText(){
  bbDBFrame db_f{"ClipboardText:String()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(557058);
  if((SDL_HasClipboardText()==SDL_FALSE)){
    bbDBBlock db_blk;
    bbDBStmt(557094);
    return bbString{};
  }
  bbDBStmt(565256);
  char* l_p=SDL_GetClipboardText();
  bbDBLocal("p",&l_p);
  bbDBStmt(573448);
  bbString l_str=bbString::fromUtf8String(((void*)(l_p)));
  bbDBLocal("str",&l_str);
  bbDBStmt(585730);
  l_str=l_str.replace(BB_T("\r\n"),BB_T("\n"));
  bbDBStmt(589826);
  l_str=l_str.replace(BB_T("\r"),BB_T("\n"));
  bbDBStmt(598018);
  SDL_free(((void*)(l_p)));
  bbDBStmt(606210);
  return l_str;
}

void t_mojo_app_AppInstance::m_BeginModal(t_mojo_app_View* l_view){
  bbDBFrame db_f{"BeginModal:Void(view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("view",&l_view);
  bbDBStmt(1130498);
  this->m__0modalStack->m_Push(this->m__0modalView);
  bbDBStmt(1134594);
  this->m__0modalView=l_view;
}

t_mojo_app_Window* t_mojo_app_AppInstance::m_ActiveWindow(){
  bbDBFrame db_f{"ActiveWindow:mojo.app.Window()","/home/pi/monkey2/modules/mojo/app/app.monkey2"};
  t_mojo_app_AppInstance*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(897026);
  return g_mojo_app_Window_VisibleWindows()->at(bbInt(0));
}
bbString bbDBType(t_mojo_app_AppInstance**){
  return "mojo.app.AppInstance";
}
bbString bbDBValue(t_mojo_app_AppInstance**p){
  return bbDBObjectValue(*p);
}

void t_mojo_app_DisplayMode::dbEmit(t_mojo_app_DisplayMode*p){
  bbDBEmit("width",&p->m_width);
  bbDBEmit("height",&p->m_height);
  bbDBEmit("hertz",&p->m_hertz);
}
bbString bbDBType(t_mojo_app_DisplayMode*){
  return "mojo.app.DisplayMode";
}
bbString bbDBValue(t_mojo_app_DisplayMode*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_mojo_app_DisplayMode&x,const t_mojo_app_DisplayMode&y){
  if(int t=bbCompare(x.m_width,y.m_width)) return t;
  if(int t=bbCompare(x.m_height,y.m_height)) return t;
  if(int t=bbCompare(x.m_hertz,y.m_hertz)) return t;
  return 0;
}

void mx2_mojo_app_2app_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_app_AppInstance__0asyncCallbacks=bbGCNew<t_std_collections_Map_1iFvE>();
  g_mojo_app_AppInstance__0disabledCallbacks=bbGCNew<t_std_collections_Map_1iz>();
}

bbInit mx2_mojo_app_2app_init_v("mojo_app_2app",&mx2_mojo_app_2app_init);
