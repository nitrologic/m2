
#include "../../desktop_debug_pi/mojo_std_fiber_2future.h"

// ***** External *****

// ***** Internal *****

void t_std_fiber_Future_1i::dbEmit(){
  bbDBEmit("_fiber",&m__0fiber);
  bbDBEmit("_value",&m__0value);
}

t_std_fiber_Future_1i::t_std_fiber_Future_1i(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/fiber/future.monkey2"};
  bbDBStmt(98306);
  this->m__0fiber=g_std_fiber_Fiber_Current();
}

void t_std_fiber_Future_1i::m_Set(bbInt l_value){
  bbDBFrame db_f{"Set:Void(value:Int)","/home/pi/monkey2/modules/std/fiber/future.monkey2"};
  t_std_fiber_Future_1i*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(122882);
  this->m__0value=l_value;
  bbDBStmt(126978);
  this->m__0fiber.m_Resume();
}

bbInt t_std_fiber_Future_1i::m_Get(){
  bbDBFrame db_f{"Get:Int()","/home/pi/monkey2/modules/std/fiber/future.monkey2"};
  t_std_fiber_Future_1i*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(151554);
  g_std_fiber_Fiber_Suspend();
  bbDBStmt(155650);
  return this->m__0value;
}
bbString bbDBType(t_std_fiber_Future_1i**){
  return "std.fiber.Future<Int>";
}
bbString bbDBValue(t_std_fiber_Future_1i**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_std_fiber_2future_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_fiber_2future_init_v("mojo_std_fiber_2future",&mx2_mojo_std_fiber_2future_init);
