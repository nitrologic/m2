
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2view.h"
#include "../../desktop_debug_pi/mojo_app_2window.h"
#include "../../desktop_debug_pi/mojo_audio_2audio.h"
#include "../../desktop_debug_pi/mojo_graphics_2canvas.h"
#include "../../desktop_debug_pi/mojo_graphics_2shader.h"
#include "../../desktop_debug_pi/mojo_std_collections_2list.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"

extern bbInt g_monkey_math_Max_1i(bbInt l_x,bbInt l_y);

// ***** Internal *****

void g_std_collections_Stack_1Tt_mojo_app_Window_2_AddAll_1Tt_std_collections_List_1Tt_mojo_app_Window_2_2(t_std_collections_Stack_1Tt_mojo_app_Window_2* l_self,t_std_collections_List_1Tt_mojo_app_Window_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.app.Window>>:Void(values:std.collections.List<mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_app_Window_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2064387);
      l_self->m_Add(f2.l_value);
    }
  }
}

void g_std_collections_Stack_1Tt_mojo_app_View_2_AddAll_1Tt_std_collections_List_1Tt_mojo_app_View_2_2(t_std_collections_Stack_1Tt_mojo_app_View_2* l_self,t_std_collections_List_1Tt_mojo_app_View_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.app.View>>:Void(values:std.collections.List<mojo.app.View>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2064387);
      l_self->m_Add(f2.l_value);
    }
  }
}

void g_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_2(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_self,t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.graphics.Vertex2f>>:Void(values:std.collections.List<mojo.graphics.Vertex2f>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_mojo_graphics_Vertex2f l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2064387);
      l_self->m_Add(l_value);
    }
  }
}

void g_std_collections_Stack_1Tt_std_geom_Rect_1i_2_AddAll_1Tt_std_collections_List_1Tt_std_geom_Rect_1i_2_2(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_self,t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<Recti:std.geom.Rect<Int>>>:Void(values:std.collections.List<Recti:std.geom.Rect<Int>>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_std_geom_Rect_1i l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2064387);
      l_self->m_Add(l_value);
    }
  }
}

void g_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_DrawOp_2_2(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_self,t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.graphics.DrawOp>>:Void(values:std.collections.List<mojo.graphics.DrawOp>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_DrawOp* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2064387);
      l_self->m_Add(f2.l_value);
    }
  }
}

void g_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_AddAll_1Tt_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_2(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_self,t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>>:Void(values:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_std_geom_AffineMat3_1f l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2064387);
      l_self->m_Add(l_value);
    }
  }
}

void g_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_Uniform_2_2(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_self,t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.graphics.Uniform>>:Void(values:std.collections.List<mojo.graphics.Uniform>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_Uniform* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2064387);
      l_self->m_Add(f2.l_value);
    }
  }
}

void g_std_collections_Stack_1j_AddAll_1Tt_std_collections_List_1j_2(t_std_collections_Stack_1j* l_self,t_std_collections_List_1j* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<ALuint:Uint>>:Void(values:std.collections.List<ALuint:Uint>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1j_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      bbUInt l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2064387);
      l_self->m_Add(l_value);
    }
  }
}

void g_std_collections_Stack_1Tt_mojo_audio_Channel_2_AddAll_1Tt_std_collections_List_1Tt_mojo_audio_Channel_2_2(t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_self,t_std_collections_List_1Tt_mojo_audio_Channel_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.audio.Channel>>:Void(values:std.collections.List<mojo.audio.Channel>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2060290);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_audio_Channel* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2064387);
      l_self->m_Add(f2.l_value);
    }
  }
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::dbEmit(t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator(t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.audio.Channel>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::m_Insert(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::m_Current(t_mojo_audio_Channel* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_audio_Channel* t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*){
  return "std.collections.Stack<mojo.audio.Channel>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator&x,const t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::dbEmit(t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator(t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.audio.Channel>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Insert(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Current(t_mojo_audio_Channel* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_audio_Channel* t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*){
  return "std.collections.Stack<mojo.audio.Channel>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator&x,const t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2::t_std_collections_Stack_1Tt_mojo_audio_Channel_2(t_std_collections_List_1Tt_mojo_audio_Channel_2* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.audio.Channel>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1Tt_mojo_audio_Channel_2_AddAll_1Tt_std_collections_List_1Tt_mojo_audio_Channel_2_2(this,l_values);
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2::t_std_collections_Stack_1Tt_mojo_audio_Channel_2(t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_audio_Channel>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.audio.Channel>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<bbGCVar<t_mojo_audio_Channel>>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2::t_std_collections_Stack_1Tt_mojo_audio_Channel_2(bbArray<bbGCVar<t_mojo_audio_Channel>>* l_values){
  bbDBFrame db_f{"new:Void(values:mojo.audio.Channel[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2::t_std_collections_Stack_1Tt_mojo_audio_Channel_2(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<bbGCVar<t_mojo_audio_Channel>>::create(this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2::t_std_collections_Stack_1Tt_mojo_audio_Channel_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<bbGCVar<t_mojo_audio_Channel>>::create(10);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m__idxeq(bbInt l_index,t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

t_mojo_audio_Channel* t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:mojo.audio.Channel(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

t_mojo_audio_Channel* t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Top(){
  bbDBFrame db_f{"Top:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<bbGCVar<t_mojo_audio_Channel>>* t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_ToArray(){
  bbDBFrame db_f{"ToArray:mojo.audio.Channel[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Swap(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_t{};
    void gcMark(){
      bbGCMarkPtr(l_t);
    }
  }f0{};
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  f0.l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&f0.l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=f0.l_t;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Sort(bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.audio.Channel,mojo.audio.Channel),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      struct f1_t : public bbGCFrame{
        t_mojo_audio_Channel* l_p{};
        void gcMark(){
          bbGCMarkPtr(l_p);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      f1.l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),f1.l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(f1.l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Sort(bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.audio.Channel,mojo.audio.Channel))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda0 : public bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_self;
      lambda0(t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_audio_Channel* l_x,t_mojo_audio_Channel* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.audio.Channel,y:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)>(new lambda0(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda1 : public bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_self;
      lambda1(t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_audio_Channel* l_x,t_mojo_audio_Channel* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.audio.Channel,y:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)>(new lambda1(this)));
  }
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2* t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_audio_Channel>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.audio.Channel>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1Tt_mojo_audio_Channel_2>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2* t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.audio.Channel>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Set(bbInt l_index,t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=((t_mojo_audio_Channel*)0);
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_audio_Channel>>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<bbGCVar<t_mojo_audio_Channel>>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_RemoveLast(t_mojo_audio_Channel* l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.audio.Channel,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_RemoveEach(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((this->m__0data->at(l_get)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Remove(t_mojo_audio_Channel* l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:mojo.audio.Channel,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Push(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Push:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

t_mojo_audio_Channel* t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Pop(){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"Pop:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  f0.l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=((t_mojo_audio_Channel*)0);
  bbDBStmt(3215362);
  return f0.l_value;
}

bbInt t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Insert(bbInt l_index,t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

t_mojo_audio_Channel* t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:mojo.audio.Channel(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_FindLastIndex(t_mojo_audio_Channel* l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:mojo.audio.Channel,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_FindIndex(t_mojo_audio_Channel* l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:mojo.audio.Channel,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<bbGCVar<t_mojo_audio_Channel>>* t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Data(){
  bbDBFrame db_f{"Data:mojo.audio.Channel[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Contains(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Contains:Bool(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<mojo.audio.Channel>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1Tt_mojo_audio_Channel_2_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<mojo.audio.Channel>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_AddAll(bbArray<bbGCVar<t_mojo_audio_Channel>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.audio.Channel[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1Tt_mojo_audio_Channel_2::m_Add(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_audio_Channel_2**){
  return "std.collections.Stack<mojo.audio.Channel>";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_audio_Channel_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Stack_1j_Iterator::dbEmit(t_std_collections_Stack_1j_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1j_Iterator::t_std_collections_Stack_1j_Iterator(t_std_collections_Stack_1j* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<ALuint:Uint>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1j_Iterator::m_Insert(bbUInt l_value){
  bbDBFrame db_f{"Insert:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1j_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1j_Iterator::m_Current(bbUInt l_current){
  bbDBFrame db_f{"Current:Void(current:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

bbUInt t_std_collections_Stack_1j_Iterator::m_Current(){
  bbDBFrame db_f{"Current:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1j_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1j_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1j_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1j_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1j_Iterator*){
  return "std.collections.Stack<ALuint:Uint>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1j_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1j_Iterator&x,const t_std_collections_Stack_1j_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1j_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1j_BackwardsIterator::dbEmit(t_std_collections_Stack_1j_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1j_BackwardsIterator::t_std_collections_Stack_1j_BackwardsIterator(t_std_collections_Stack_1j* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<ALuint:Uint>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1j_BackwardsIterator::m_Insert(bbUInt l_value){
  bbDBFrame db_f{"Insert:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1j_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1j_BackwardsIterator::m_Current(bbUInt l_current){
  bbDBFrame db_f{"Current:Void(current:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

bbUInt t_std_collections_Stack_1j_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1j_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1j_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1j_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1j_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1j_BackwardsIterator*){
  return "std.collections.Stack<ALuint:Uint>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1j_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1j_BackwardsIterator&x,const t_std_collections_Stack_1j_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1j_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1j::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1j::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1j::t_std_collections_Stack_1j(t_std_collections_List_1j* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<ALuint:Uint>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1j_AddAll_1Tt_std_collections_List_1j_2(this,l_values);
}

t_std_collections_Stack_1j::t_std_collections_Stack_1j(t_std_collections_Stack_1j* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<bbUInt>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<ALuint:Uint>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<bbUInt>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1j::t_std_collections_Stack_1j(bbArray<bbUInt>* l_values){
  bbDBFrame db_f{"new:Void(values:ALuint:Uint[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1j::t_std_collections_Stack_1j(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<bbUInt>::create(this->m__0length);
}

t_std_collections_Stack_1j::t_std_collections_Stack_1j(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<bbUInt>::create(10);
}

void t_std_collections_Stack_1j::m__idxeq(bbInt l_index,bbUInt l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

bbUInt t_std_collections_Stack_1j::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:ALuint:Uint(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

bbUInt t_std_collections_Stack_1j::m_Top(){
  bbDBFrame db_f{"Top:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<bbUInt>* t_std_collections_Stack_1j::m_ToArray(){
  bbDBFrame db_f{"ToArray:ALuint:Uint[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1j::m_Swap(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  bbUInt l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=l_t;
}

void t_std_collections_Stack_1j::m_Sort(bbFunction<bbInt(bbUInt,bbUInt)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(ALuint:Uint,ALuint:Uint),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      bbUInt l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1j::m_Sort(bbFunction<bbInt(bbUInt,bbUInt)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(ALuint:Uint,ALuint:Uint))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1j::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda2 : public bbFunction<bbInt(bbUInt,bbUInt)>::Rep{
      t_std_collections_Stack_1j* l_self;
      lambda2(t_std_collections_Stack_1j* l_self):l_self(l_self){
      }
      bbInt invoke(bbUInt l_x,bbUInt l_y){
        bbDBFrame db_f{"?????:Int(x:ALuint:Uint,y:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(bbUInt,bbUInt)>(new lambda2(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda3 : public bbFunction<bbInt(bbUInt,bbUInt)>::Rep{
      t_std_collections_Stack_1j* l_self;
      lambda3(t_std_collections_Stack_1j* l_self):l_self(l_self){
      }
      bbInt invoke(bbUInt l_x,bbUInt l_y){
        bbDBFrame db_f{"?????:Int(x:ALuint:Uint,y:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(bbUInt,bbUInt)>(new lambda3(this)));
  }
}

t_std_collections_Stack_1j* t_std_collections_Stack_1j::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<bbUInt>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<ALuint:Uint>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1j>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1j* t_std_collections_Stack_1j::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<ALuint:Uint>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1j::m_Set(bbInt l_index,bbUInt l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1j::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=0;
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1j::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<bbUInt>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<bbUInt>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1j::m_RemoveLast(bbUInt l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:ALuint:Uint,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1j::m_RemoveEach(bbUInt l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((this->m__0data->at(l_get)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1j::m_Remove(bbUInt l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:ALuint:Uint,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1j::m_Push(bbUInt l_value){
  bbDBFrame db_f{"Push:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

bbUInt t_std_collections_Stack_1j::m_Pop(){
  bbDBFrame db_f{"Pop:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  bbUInt l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=0;
  bbDBStmt(3215362);
  return l_value;
}

bbInt t_std_collections_Stack_1j::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1j::m_Insert(bbInt l_index,bbUInt l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

bbUInt t_std_collections_Stack_1j::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:ALuint:Uint(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1j::m_FindLastIndex(bbUInt l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:ALuint:Uint,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1j::m_FindIndex(bbUInt l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:ALuint:Uint,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1j::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1j::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1j::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<bbUInt>* t_std_collections_Stack_1j::m_Data(){
  bbDBFrame db_f{"Data:ALuint:Uint[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1j::m_Contains(bbUInt l_value){
  bbDBFrame db_f{"Contains:Bool(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1j::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1j::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1j_BackwardsIterator t_std_collections_Stack_1j::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<ALuint:Uint>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1j_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1j_Iterator t_std_collections_Stack_1j::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<ALuint:Uint>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1j_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1j::m_AddAll(bbArray<bbUInt>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:ALuint:Uint[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1j::m_Add(bbUInt l_value){
  bbDBFrame db_f{"Add:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1j**){
  return "std.collections.Stack<ALuint:Uint>";
}
bbString bbDBValue(t_std_collections_Stack_1j**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::dbEmit(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Insert(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Insert:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Current(t_std_geom_AffineMat3_1f l_current){
  bbDBFrame db_f{"Current:Void(current:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_std_geom_AffineMat3_1f t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*){
  return "std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator&x,const t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::dbEmit(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Insert(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Insert:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Current(t_std_geom_AffineMat3_1f l_current){
  bbDBFrame db_f{"Current:Void(current:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_std_geom_AffineMat3_1f t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*){
  return "std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator&x,const t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_AddAll_1Tt_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_2(this,l_values);
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<t_std_geom_AffineMat3_1f>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<t_std_geom_AffineMat3_1f>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2(bbArray<t_std_geom_AffineMat3_1f>* l_values){
  bbDBFrame db_f{"new:Void(values:AffineMat3f:std.geom.AffineMat3<Float>[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<t_std_geom_AffineMat3_1f>::create(this->m__0length);
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<t_std_geom_AffineMat3_1f>::create(10);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m__idxeq(bbInt l_index,t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

t_std_geom_AffineMat3_1f t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:AffineMat3f:std.geom.AffineMat3<Float>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

t_std_geom_AffineMat3_1f t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Top(){
  bbDBFrame db_f{"Top:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<t_std_geom_AffineMat3_1f>* t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_ToArray(){
  bbDBFrame db_f{"ToArray:AffineMat3f:std.geom.AffineMat3<Float>[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Swap(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  t_std_geom_AffineMat3_1f l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=l_t;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Sort(bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(AffineMat3f:std.geom.AffineMat3<Float>,AffineMat3f:std.geom.AffineMat3<Float>),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      t_std_geom_AffineMat3_1f l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Sort(bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(AffineMat3f:std.geom.AffineMat3<Float>,AffineMat3f:std.geom.AffineMat3<Float>))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda4 : public bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)>::Rep{
      t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_self;
      lambda4(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_std_geom_AffineMat3_1f l_x,t_std_geom_AffineMat3_1f l_y){
        bbDBFrame db_f{"?????:Int(x:AffineMat3f:std.geom.AffineMat3<Float>,y:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)>(new lambda4(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda5 : public bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)>::Rep{
      t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_self;
      lambda5(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_std_geom_AffineMat3_1f l_x,t_std_geom_AffineMat3_1f l_y){
        bbDBFrame db_f{"?????:Int(x:AffineMat3f:std.geom.AffineMat3<Float>,y:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)>(new lambda5(this)));
  }
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<t_std_geom_AffineMat3_1f>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Set(bbInt l_index,t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=t_std_geom_AffineMat3_1f{};
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<t_std_geom_AffineMat3_1f>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<t_std_geom_AffineMat3_1f>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_RemoveLast(t_std_geom_AffineMat3_1f l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:AffineMat3f:std.geom.AffineMat3<Float>,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_RemoveEach(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((bbCompare(this->m__0data->at(l_get),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Remove(t_std_geom_AffineMat3_1f l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:AffineMat3f:std.geom.AffineMat3<Float>,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Push(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Push:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

t_std_geom_AffineMat3_1f t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Pop(){
  bbDBFrame db_f{"Pop:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  t_std_geom_AffineMat3_1f l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=t_std_geom_AffineMat3_1f{};
  bbDBStmt(3215362);
  return l_value;
}

bbInt t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Insert(bbInt l_index,t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

t_std_geom_AffineMat3_1f t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:AffineMat3f:std.geom.AffineMat3<Float>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_FindLastIndex(t_std_geom_AffineMat3_1f l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:AffineMat3f:std.geom.AffineMat3<Float>,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((bbCompare(this->m__0data->at(l_i),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_FindIndex(t_std_geom_AffineMat3_1f l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:AffineMat3f:std.geom.AffineMat3<Float>,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((bbCompare(this->m__0data->at(l_i),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<t_std_geom_AffineMat3_1f>* t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Data(){
  bbDBFrame db_f{"Data:AffineMat3f:std.geom.AffineMat3<Float>[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Contains(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Contains:Bool(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_AddAll(bbArray<t_std_geom_AffineMat3_1f>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:AffineMat3f:std.geom.AffineMat3<Float>[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2::m_Add(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Add:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2**){
  return "std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::dbEmit(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.graphics.DrawOp>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Insert(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Current(t_mojo_graphics_DrawOp* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_graphics_DrawOp* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*){
  return "std.collections.Stack<mojo.graphics.DrawOp>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator&x,const t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::dbEmit(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.graphics.DrawOp>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Insert(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Current(t_mojo_graphics_DrawOp* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_graphics_DrawOp* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*){
  return "std.collections.Stack<mojo.graphics.DrawOp>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator&x,const t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.graphics.DrawOp>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_DrawOp_2_2(this,l_values);
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.graphics.DrawOp>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<bbGCVar<t_mojo_graphics_DrawOp>>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2(bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* l_values){
  bbDBFrame db_f{"new:Void(values:mojo.graphics.DrawOp[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<bbGCVar<t_mojo_graphics_DrawOp>>::create(this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<bbGCVar<t_mojo_graphics_DrawOp>>::create(10);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m__idxeq(bbInt l_index,t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

t_mojo_graphics_DrawOp* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:mojo.graphics.DrawOp(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

t_mojo_graphics_DrawOp* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Top(){
  bbDBFrame db_f{"Top:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_ToArray(){
  bbDBFrame db_f{"ToArray:mojo.graphics.DrawOp[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Swap(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_DrawOp* l_t{};
    void gcMark(){
      bbGCMarkPtr(l_t);
    }
  }f0{};
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  f0.l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&f0.l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=f0.l_t;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.DrawOp,mojo.graphics.DrawOp),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      struct f1_t : public bbGCFrame{
        t_mojo_graphics_DrawOp* l_p{};
        void gcMark(){
          bbGCMarkPtr(l_p);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      f1.l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),f1.l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(f1.l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.DrawOp,mojo.graphics.DrawOp))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda6 : public bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_self;
      lambda6(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_DrawOp* l_x,t_mojo_graphics_DrawOp* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.DrawOp,y:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)>(new lambda6(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda7 : public bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_self;
      lambda7(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_DrawOp* l_x,t_mojo_graphics_DrawOp* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.DrawOp,y:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)>(new lambda7(this)));
  }
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.graphics.DrawOp>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.graphics.DrawOp>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Set(bbInt l_index,t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=((t_mojo_graphics_DrawOp*)0);
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<bbGCVar<t_mojo_graphics_DrawOp>>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_RemoveLast(t_mojo_graphics_DrawOp* l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.graphics.DrawOp,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_RemoveEach(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((this->m__0data->at(l_get)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Remove(t_mojo_graphics_DrawOp* l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:mojo.graphics.DrawOp,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Push(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Push:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

t_mojo_graphics_DrawOp* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Pop(){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_DrawOp* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"Pop:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  f0.l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=((t_mojo_graphics_DrawOp*)0);
  bbDBStmt(3215362);
  return f0.l_value;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Insert(bbInt l_index,t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

t_mojo_graphics_DrawOp* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:mojo.graphics.DrawOp(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_FindLastIndex(t_mojo_graphics_DrawOp* l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:mojo.graphics.DrawOp,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_FindIndex(t_mojo_graphics_DrawOp* l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:mojo.graphics.DrawOp,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Data(){
  bbDBFrame db_f{"Data:mojo.graphics.DrawOp[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Contains(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Contains:Bool(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<mojo.graphics.DrawOp>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<mojo.graphics.DrawOp>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_AddAll(bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.graphics.DrawOp[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2::m_Add(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2**){
  return "std.collections.Stack<mojo.graphics.DrawOp>";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::dbEmit(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<Recti:std.geom.Rect<Int>>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::m_Insert(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Insert:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::m_Current(t_std_geom_Rect_1i l_current){
  bbDBFrame db_f{"Current:Void(current:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_std_geom_Rect_1i t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*){
  return "std.collections.Stack<Recti:std.geom.Rect<Int>>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator&x,const t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::dbEmit(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<Recti:std.geom.Rect<Int>>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Insert(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Insert:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Current(t_std_geom_Rect_1i l_current){
  bbDBFrame db_f{"Current:Void(current:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_std_geom_Rect_1i t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*){
  return "std.collections.Stack<Recti:std.geom.Rect<Int>>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator&x,const t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::t_std_collections_Stack_1Tt_std_geom_Rect_1i_2(t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<Recti:std.geom.Rect<Int>>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1Tt_std_geom_Rect_1i_2_AddAll_1Tt_std_collections_List_1Tt_std_geom_Rect_1i_2_2(this,l_values);
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::t_std_collections_Stack_1Tt_std_geom_Rect_1i_2(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<t_std_geom_Rect_1i>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<Recti:std.geom.Rect<Int>>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<t_std_geom_Rect_1i>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::t_std_collections_Stack_1Tt_std_geom_Rect_1i_2(bbArray<t_std_geom_Rect_1i>* l_values){
  bbDBFrame db_f{"new:Void(values:Recti:std.geom.Rect<Int>[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::t_std_collections_Stack_1Tt_std_geom_Rect_1i_2(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<t_std_geom_Rect_1i>::create(this->m__0length);
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::t_std_collections_Stack_1Tt_std_geom_Rect_1i_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<t_std_geom_Rect_1i>::create(10);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m__idxeq(bbInt l_index,t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

t_std_geom_Rect_1i t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:Recti:std.geom.Rect<Int>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

t_std_geom_Rect_1i t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Top(){
  bbDBFrame db_f{"Top:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<t_std_geom_Rect_1i>* t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_ToArray(){
  bbDBFrame db_f{"ToArray:Recti:std.geom.Rect<Int>[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Swap(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  t_std_geom_Rect_1i l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=l_t;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Sort(bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(Recti:std.geom.Rect<Int>,Recti:std.geom.Rect<Int>),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      t_std_geom_Rect_1i l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Sort(bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(Recti:std.geom.Rect<Int>,Recti:std.geom.Rect<Int>))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda8 : public bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)>::Rep{
      t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_self;
      lambda8(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_std_geom_Rect_1i l_x,t_std_geom_Rect_1i l_y){
        bbDBFrame db_f{"?????:Int(x:Recti:std.geom.Rect<Int>,y:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)>(new lambda8(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda9 : public bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)>::Rep{
      t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_self;
      lambda9(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_std_geom_Rect_1i l_x,t_std_geom_Rect_1i l_y){
        bbDBFrame db_f{"?????:Int(x:Recti:std.geom.Rect<Int>,y:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)>(new lambda9(this)));
  }
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<t_std_geom_Rect_1i>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<Recti:std.geom.Rect<Int>>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1Tt_std_geom_Rect_1i_2>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<Recti:std.geom.Rect<Int>>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Set(bbInt l_index,t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=t_std_geom_Rect_1i{};
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<t_std_geom_Rect_1i>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<t_std_geom_Rect_1i>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_RemoveLast(t_std_geom_Rect_1i l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:Recti:std.geom.Rect<Int>,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_RemoveEach(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((bbCompare(this->m__0data->at(l_get),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Remove(t_std_geom_Rect_1i l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:Recti:std.geom.Rect<Int>,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Push(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Push:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

t_std_geom_Rect_1i t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Pop(){
  bbDBFrame db_f{"Pop:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  t_std_geom_Rect_1i l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=t_std_geom_Rect_1i{};
  bbDBStmt(3215362);
  return l_value;
}

bbInt t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Insert(bbInt l_index,t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

t_std_geom_Rect_1i t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:Recti:std.geom.Rect<Int>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_FindLastIndex(t_std_geom_Rect_1i l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:Recti:std.geom.Rect<Int>,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((bbCompare(this->m__0data->at(l_i),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_FindIndex(t_std_geom_Rect_1i l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:Recti:std.geom.Rect<Int>,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((bbCompare(this->m__0data->at(l_i),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<t_std_geom_Rect_1i>* t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Data(){
  bbDBFrame db_f{"Data:Recti:std.geom.Rect<Int>[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Contains(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Contains:Bool(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<Recti:std.geom.Rect<Int>>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<Recti:std.geom.Rect<Int>>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_AddAll(bbArray<t_std_geom_Rect_1i>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:Recti:std.geom.Rect<Int>[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1Tt_std_geom_Rect_1i_2::m_Add(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Add:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2**){
  return "std.collections.Stack<Recti:std.geom.Rect<Int>>";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::dbEmit(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.graphics.Vertex2f>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Insert(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Current(t_mojo_graphics_Vertex2f l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_graphics_Vertex2f t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*){
  return "std.collections.Stack<mojo.graphics.Vertex2f>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator&x,const t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::dbEmit(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.graphics.Vertex2f>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Insert(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Current(t_mojo_graphics_Vertex2f l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_graphics_Vertex2f t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*){
  return "std.collections.Stack<mojo.graphics.Vertex2f>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator&x,const t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.graphics.Vertex2f>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_2(this,l_values);
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<t_mojo_graphics_Vertex2f>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.graphics.Vertex2f>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<t_mojo_graphics_Vertex2f>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2(bbArray<t_mojo_graphics_Vertex2f>* l_values){
  bbDBFrame db_f{"new:Void(values:mojo.graphics.Vertex2f[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<t_mojo_graphics_Vertex2f>::create(this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<t_mojo_graphics_Vertex2f>::create(10);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m__idxeq(bbInt l_index,t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

t_mojo_graphics_Vertex2f t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:mojo.graphics.Vertex2f(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

t_mojo_graphics_Vertex2f t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Top(){
  bbDBFrame db_f{"Top:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<t_mojo_graphics_Vertex2f>* t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_ToArray(){
  bbDBFrame db_f{"ToArray:mojo.graphics.Vertex2f[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Swap(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  t_mojo_graphics_Vertex2f l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=l_t;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.Vertex2f,mojo.graphics.Vertex2f),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      t_mojo_graphics_Vertex2f l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.Vertex2f,mojo.graphics.Vertex2f))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda10 : public bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)>::Rep{
      t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_self;
      lambda10(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_Vertex2f l_x,t_mojo_graphics_Vertex2f l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.Vertex2f,y:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)>(new lambda10(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda11 : public bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)>::Rep{
      t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_self;
      lambda11(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_Vertex2f l_x,t_mojo_graphics_Vertex2f l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.Vertex2f,y:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)>(new lambda11(this)));
  }
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<t_mojo_graphics_Vertex2f>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.graphics.Vertex2f>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.graphics.Vertex2f>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Set(bbInt l_index,t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=t_mojo_graphics_Vertex2f{};
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<t_mojo_graphics_Vertex2f>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<t_mojo_graphics_Vertex2f>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_RemoveLast(t_mojo_graphics_Vertex2f l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.graphics.Vertex2f,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_RemoveEach(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((bbCompare(this->m__0data->at(l_get),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Remove(t_mojo_graphics_Vertex2f l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:mojo.graphics.Vertex2f,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Push(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Push:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

t_mojo_graphics_Vertex2f t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Pop(){
  bbDBFrame db_f{"Pop:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  t_mojo_graphics_Vertex2f l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=t_mojo_graphics_Vertex2f{};
  bbDBStmt(3215362);
  return l_value;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Insert(bbInt l_index,t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

t_mojo_graphics_Vertex2f t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:mojo.graphics.Vertex2f(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_FindLastIndex(t_mojo_graphics_Vertex2f l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:mojo.graphics.Vertex2f,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((bbCompare(this->m__0data->at(l_i),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_FindIndex(t_mojo_graphics_Vertex2f l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:mojo.graphics.Vertex2f,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((bbCompare(this->m__0data->at(l_i),l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<t_mojo_graphics_Vertex2f>* t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Data(){
  bbDBFrame db_f{"Data:mojo.graphics.Vertex2f[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Contains(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Contains:Bool(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<mojo.graphics.Vertex2f>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<mojo.graphics.Vertex2f>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_AddAll(bbArray<t_mojo_graphics_Vertex2f>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.graphics.Vertex2f[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2::m_Add(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2**){
  return "std.collections.Stack<mojo.graphics.Vertex2f>";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::dbEmit(t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator(t_std_collections_Stack_1Tt_mojo_app_View_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.app.View>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::m_Insert(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::m_Current(t_mojo_app_View* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_app_View* t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.View()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*){
  return "std.collections.Stack<mojo.app.View>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator&x,const t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::dbEmit(t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator(t_std_collections_Stack_1Tt_mojo_app_View_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.app.View>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::m_Insert(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::m_Current(t_mojo_app_View* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_app_View* t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.View()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*){
  return "std.collections.Stack<mojo.app.View>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator&x,const t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1Tt_mojo_app_View_2::t_std_collections_Stack_1Tt_mojo_app_View_2(t_std_collections_List_1Tt_mojo_app_View_2* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.app.View>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1Tt_mojo_app_View_2_AddAll_1Tt_std_collections_List_1Tt_mojo_app_View_2_2(this,l_values);
}

t_std_collections_Stack_1Tt_mojo_app_View_2::t_std_collections_Stack_1Tt_mojo_app_View_2(t_std_collections_Stack_1Tt_mojo_app_View_2* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_app_View>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.app.View>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<bbGCVar<t_mojo_app_View>>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_app_View_2::t_std_collections_Stack_1Tt_mojo_app_View_2(bbArray<bbGCVar<t_mojo_app_View>>* l_values){
  bbDBFrame db_f{"new:Void(values:mojo.app.View[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1Tt_mojo_app_View_2::t_std_collections_Stack_1Tt_mojo_app_View_2(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<bbGCVar<t_mojo_app_View>>::create(this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_app_View_2::t_std_collections_Stack_1Tt_mojo_app_View_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<bbGCVar<t_mojo_app_View>>::create(10);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m__idxeq(bbInt l_index,t_mojo_app_View* l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

t_mojo_app_View* t_std_collections_Stack_1Tt_mojo_app_View_2::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:mojo.app.View(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

t_mojo_app_View* t_std_collections_Stack_1Tt_mojo_app_View_2::m_Top(){
  bbDBFrame db_f{"Top:mojo.app.View()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<bbGCVar<t_mojo_app_View>>* t_std_collections_Stack_1Tt_mojo_app_View_2::m_ToArray(){
  bbDBFrame db_f{"ToArray:mojo.app.View[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Swap(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    t_mojo_app_View* l_t{};
    void gcMark(){
      bbGCMarkPtr(l_t);
    }
  }f0{};
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  f0.l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&f0.l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=f0.l_t;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Sort(bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.app.View,mojo.app.View),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      struct f1_t : public bbGCFrame{
        t_mojo_app_View* l_p{};
        void gcMark(){
          bbGCMarkPtr(l_p);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      f1.l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),f1.l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(f1.l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Sort(bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.app.View,mojo.app.View))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda12 : public bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_app_View_2* l_self;
      lambda12(t_std_collections_Stack_1Tt_mojo_app_View_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_app_View* l_x,t_mojo_app_View* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.app.View,y:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)>(new lambda12(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda13 : public bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_app_View_2* l_self;
      lambda13(t_std_collections_Stack_1Tt_mojo_app_View_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_app_View* l_x,t_mojo_app_View* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.app.View,y:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)>(new lambda13(this)));
  }
}

t_std_collections_Stack_1Tt_mojo_app_View_2* t_std_collections_Stack_1Tt_mojo_app_View_2::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_app_View>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.app.View>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1Tt_mojo_app_View_2>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1Tt_mojo_app_View_2* t_std_collections_Stack_1Tt_mojo_app_View_2::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.app.View>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Set(bbInt l_index,t_mojo_app_View* l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=((t_mojo_app_View*)0);
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_app_View>>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<bbGCVar<t_mojo_app_View>>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_View_2::m_RemoveLast(t_mojo_app_View* l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.app.View,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1Tt_mojo_app_View_2::m_RemoveEach(t_mojo_app_View* l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((this->m__0data->at(l_get)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_View_2::m_Remove(t_mojo_app_View* l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:mojo.app.View,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Push(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Push:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

t_mojo_app_View* t_std_collections_Stack_1Tt_mojo_app_View_2::m_Pop(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_View* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"Pop:mojo.app.View()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  f0.l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=((t_mojo_app_View*)0);
  bbDBStmt(3215362);
  return f0.l_value;
}

bbInt t_std_collections_Stack_1Tt_mojo_app_View_2::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Insert(bbInt l_index,t_mojo_app_View* l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

t_mojo_app_View* t_std_collections_Stack_1Tt_mojo_app_View_2::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:mojo.app.View(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1Tt_mojo_app_View_2::m_FindLastIndex(t_mojo_app_View* l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:mojo.app.View,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1Tt_mojo_app_View_2::m_FindIndex(t_mojo_app_View* l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:mojo.app.View,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1Tt_mojo_app_View_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<bbGCVar<t_mojo_app_View>>* t_std_collections_Stack_1Tt_mojo_app_View_2::m_Data(){
  bbDBFrame db_f{"Data:mojo.app.View[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_View_2::m_Contains(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Contains:Bool(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1Tt_mojo_app_View_2::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator t_std_collections_Stack_1Tt_mojo_app_View_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<mojo.app.View>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1Tt_mojo_app_View_2_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator t_std_collections_Stack_1Tt_mojo_app_View_2::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<mojo.app.View>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_AddAll(bbArray<bbGCVar<t_mojo_app_View>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.app.View[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1Tt_mojo_app_View_2::m_Add(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_app_View_2**){
  return "std.collections.Stack<mojo.app.View>";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_app_View_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::dbEmit(t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator(t_std_collections_Stack_1Tt_mojo_app_Window_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.app.Window>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::m_Insert(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::m_Current(t_mojo_app_Window* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_app_Window* t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*){
  return "std.collections.Stack<mojo.app.Window>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator&x,const t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::dbEmit(t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator(t_std_collections_Stack_1Tt_mojo_app_Window_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.app.Window>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::m_Insert(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::m_Current(t_mojo_app_Window* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_app_Window* t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*){
  return "std.collections.Stack<mojo.app.Window>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator&x,const t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1Tt_mojo_app_Window_2::t_std_collections_Stack_1Tt_mojo_app_Window_2(t_std_collections_List_1Tt_mojo_app_Window_2* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1Tt_mojo_app_Window_2_AddAll_1Tt_std_collections_List_1Tt_mojo_app_Window_2_2(this,l_values);
}

t_std_collections_Stack_1Tt_mojo_app_Window_2::t_std_collections_Stack_1Tt_mojo_app_Window_2(t_std_collections_Stack_1Tt_mojo_app_Window_2* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_app_Window>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<bbGCVar<t_mojo_app_Window>>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_app_Window_2::t_std_collections_Stack_1Tt_mojo_app_Window_2(bbArray<bbGCVar<t_mojo_app_Window>>* l_values){
  bbDBFrame db_f{"new:Void(values:mojo.app.Window[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1Tt_mojo_app_Window_2::t_std_collections_Stack_1Tt_mojo_app_Window_2(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<bbGCVar<t_mojo_app_Window>>::create(this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_app_Window_2::t_std_collections_Stack_1Tt_mojo_app_Window_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<bbGCVar<t_mojo_app_Window>>::create(10);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m__idxeq(bbInt l_index,t_mojo_app_Window* l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

t_mojo_app_Window* t_std_collections_Stack_1Tt_mojo_app_Window_2::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:mojo.app.Window(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

t_mojo_app_Window* t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Top(){
  bbDBFrame db_f{"Top:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<bbGCVar<t_mojo_app_Window>>* t_std_collections_Stack_1Tt_mojo_app_Window_2::m_ToArray(){
  bbDBFrame db_f{"ToArray:mojo.app.Window[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Swap(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_t{};
    void gcMark(){
      bbGCMarkPtr(l_t);
    }
  }f0{};
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  f0.l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&f0.l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=f0.l_t;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Sort(bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.app.Window,mojo.app.Window),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      struct f1_t : public bbGCFrame{
        t_mojo_app_Window* l_p{};
        void gcMark(){
          bbGCMarkPtr(l_p);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      f1.l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),f1.l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(f1.l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Sort(bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.app.Window,mojo.app.Window))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda14 : public bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_app_Window_2* l_self;
      lambda14(t_std_collections_Stack_1Tt_mojo_app_Window_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_app_Window* l_x,t_mojo_app_Window* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.app.Window,y:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)>(new lambda14(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda15 : public bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_app_Window_2* l_self;
      lambda15(t_std_collections_Stack_1Tt_mojo_app_Window_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_app_Window* l_x,t_mojo_app_Window* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.app.Window,y:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)>(new lambda15(this)));
  }
}

t_std_collections_Stack_1Tt_mojo_app_Window_2* t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_app_Window>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.app.Window>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1Tt_mojo_app_Window_2>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1Tt_mojo_app_Window_2* t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.app.Window>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Set(bbInt l_index,t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=((t_mojo_app_Window*)0);
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_app_Window>>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<bbGCVar<t_mojo_app_Window>>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_Window_2::m_RemoveLast(t_mojo_app_Window* l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.app.Window,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1Tt_mojo_app_Window_2::m_RemoveEach(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((this->m__0data->at(l_get)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Remove(t_mojo_app_Window* l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:mojo.app.Window,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Push(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Push:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

t_mojo_app_Window* t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Pop(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"Pop:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  f0.l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=((t_mojo_app_Window*)0);
  bbDBStmt(3215362);
  return f0.l_value;
}

bbInt t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Insert(bbInt l_index,t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

t_mojo_app_Window* t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:mojo.app.Window(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1Tt_mojo_app_Window_2::m_FindLastIndex(t_mojo_app_Window* l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:mojo.app.Window,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1Tt_mojo_app_Window_2::m_FindIndex(t_mojo_app_Window* l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:mojo.app.Window,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<bbGCVar<t_mojo_app_Window>>* t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Data(){
  bbDBFrame db_f{"Data:mojo.app.Window[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Contains(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Contains:Bool(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<mojo.app.Window>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1Tt_mojo_app_Window_2_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator t_std_collections_Stack_1Tt_mojo_app_Window_2::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<mojo.app.Window>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_AddAll(bbArray<bbGCVar<t_mojo_app_Window>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.app.Window[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1Tt_mojo_app_Window_2::m_Add(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_app_Window_2**){
  return "std.collections.Stack<mojo.app.Window>";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_app_Window_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::dbEmit(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.graphics.Uniform>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(204803);
  (*this).m__0stack=l_stack;
  bbDBStmt(208899);
  (*this).m__0index=l_index;
  bbDBStmt(212995);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::m_Insert(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(413699);
  (*this).m_AssertSeq();
  bbDBStmt(417795);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(421891);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(368643);
  (*this).m_AssertSeq();
  bbDBStmt(372739);
  (*this).m__0stack->m_Erase((*this).m__0index);
  bbDBStmt(376835);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::m_Current(t_mojo_graphics_Uniform* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(286723);
  (*this).m_AssertCurrent();
  bbDBStmt(290819);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_graphics_Uniform* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(274435);
  (*this).m_AssertCurrent();
  bbDBStmt(278531);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(315395);
  (*this).m_AssertCurrent();
  bbDBStmt(319491);
  (*this).m__0index+=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(245763);
  (*this).m_AssertSeq();
  bbDBStmt(249859);
  return ((*this).m__0index==(*this).m__0stack->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(172035);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(188419);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*){
  return "std.collections.Stack<mojo.graphics.Uniform>.Iterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator&x,const t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::dbEmit(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*p){
  bbDBEmit("_stack",&p->m__0stack);
  bbDBEmit("_index",&p->m__0index);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_stack,bbInt l_index){
  bbDBFrame db_f{"new:Void(stack:std.collections.Stack<mojo.graphics.Uniform>,index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("stack",&l_stack);
  bbDBLocal("index",&l_index);
  bbDBStmt(516099);
  (*this).m__0stack=l_stack;
  bbDBStmt(520195);
  (*this).m__0index=l_index;
  bbDBStmt(524291);
  (*this).m__0seq=l_stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Insert(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(729091);
  (*this).m_AssertSeq();
  bbDBStmt(733187);
  (*this).m__0index+=1;
  bbDBStmt(737283);
  (*this).m__0stack->m_Insert((*this).m__0index,l_value);
  bbDBStmt(741379);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(679939);
  (*this).m_AssertCurrent();
  bbDBStmt(684035);
  (*this).m__0index-=1;
  bbDBStmt(688131);
  (*this).m__0stack->m_Erase(((*this).m__0index+1));
  bbDBStmt(692227);
  (*this).m__0seq=(*this).m__0stack->m__0seq;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Current(t_mojo_graphics_Uniform* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(598019);
  (*this).m_AssertCurrent();
  bbDBStmt(602115);
  (*this).m__0stack->m__0data->at((*this).m__0index)=l_current;
}

t_mojo_graphics_Uniform* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(585731);
  (*this).m_AssertCurrent();
  bbDBStmt(589827);
  return (*this).m__0stack->m__0data->at((*this).m__0index);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(626691);
  (*this).m_AssertCurrent();
  bbDBStmt(630787);
  (*this).m__0index-=1;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(557059);
  (*this).m_AssertSeq();
  bbDBStmt(561155);
  return ((*this).m__0index==-1);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(483331);
  bbDebugAssert(((*this).m__0seq==(*this).m__0stack->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(499715);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*){
  return "std.collections.Stack<mojo.graphics.Uniform>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator&x,const t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0stack,y.m__0stack)) return t;
  if(int t=bbCompare(x.m__0index,y.m__0index)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator&t){
  bbGCMark(t.m__0stack);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::gcMark(){
  bbGCMark(m__0data);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::dbEmit(){
  bbDBEmit("_data",&m__0data);
  bbDBEmit("_length",&m__0length);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2(t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_values){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.graphics.Uniform>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(942082);
  g_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_Uniform_2_2(this,l_values);
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_values){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.graphics.Uniform>)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(917506);
  this->m__0length=l_values->m_Length();
  bbDBStmt(921602);
  this->m__0data=bbArray<bbGCVar<t_mojo_graphics_Uniform>>::create(this->m__0length);
  bbDBStmt(925698);
  (f0.t0=l_values->m_Data())->copyTo(this->m__0data,bbInt(0),bbInt(0),this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2(bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_values){
  bbDBFrame db_f{"new:Void(values:mojo.graphics.Uniform[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(901122);
  this->m_AddAll(l_values);
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2(bbInt l_length){
  bbDBFrame db_f{"new:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBLocal("length",&l_length);
  bbDBStmt(880642);
  this->m__0length=l_length;
  bbDBStmt(884738);
  this->m__0data=bbArray<bbGCVar<t_mojo_graphics_Uniform>>::create(this->m__0length);
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  bbDBStmt(864258);
  this->m__0data=bbArray<bbGCVar<t_mojo_graphics_Uniform>>::create(10);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m__idxeq(bbInt l_index,t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"[]=:Void(index:Int,value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1912834);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1921026);
  this->m__0data->at(l_index)=l_value;
}

t_mojo_graphics_Uniform* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m__idx(bbInt l_index){
  bbDBFrame db_f{"[]:mojo.graphics.Uniform(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1851394);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1859586);
  return this->m__0data->at(l_index);
}

t_mojo_graphics_Uniform* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Top(){
  bbDBFrame db_f{"Top:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3141634);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3149826);
  return this->m__0data->at((this->m__0length-1));
}

bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_ToArray(){
  bbDBFrame db_f{"ToArray:mojo.graphics.Uniform[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1105922);
  return this->m__0data->slice(bbInt(0),this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Swap(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Uniform* l_t{};
    void gcMark(){
      bbGCMarkPtr(l_t);
    }
  }f0{};
  bbDBFrame db_f{"Swap:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2801666);
  bbDebugAssert(((((l_index1>=bbInt(0))&&(l_index1<this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(2809864);
  f0.l_t=this->m__0data->at(l_index1);
  bbDBLocal("t",&f0.l_t);
  bbDBStmt(2813954);
  this->m__0data->at(l_index1)=this->m__0data->at(l_index2);
  bbDBStmt(2818050);
  this->m__0data->at(l_index2)=f0.l_t;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)> l_compareFunc,bbInt l_lo,bbInt l_hi){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.Uniform,mojo.graphics.Uniform),lo:Int,hi:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBLocal("lo",&l_lo);
  bbDBLocal("hi",&l_hi);
  bbDBStmt(2949122);
  if((l_hi<=l_lo)){
    bbDBBlock db_blk;
    bbDBStmt(2949132);
    return;
  }
  bbDBStmt(2957314);
  if(((l_lo+1)==l_hi)){
    bbDBBlock db_blk;
    bbDBStmt(2961411);
    if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(2961451);
      this->m_Swap(l_hi,l_lo);
    }
    bbDBStmt(2965507);
    return;
  }
  bbDBStmt(2977800);
  bbInt l_i=((l_lo+l_hi)/2);
  bbDBLocal("i",&l_i);
  bbDBStmt(2985986);
  if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2986025);
    this->m_Swap(l_i,l_lo);
  }
  bbDBStmt(2994178);
  if((l_compareFunc(this->m__0data->at(l_hi),this->m__0data->at(l_i))<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2998275);
    this->m_Swap(l_hi,l_i);
    bbDBStmt(3002371);
    if((l_compareFunc(this->m__0data->at(l_i),this->m__0data->at(l_lo))<bbInt(0))){
      bbDBBlock db_blk;
      bbDBStmt(3002410);
      this->m_Swap(l_i,l_lo);
    }
  }
  bbDBStmt(3014664);
  bbInt l_x=(l_lo+1);
  bbDBLocal("x",&l_x);
  bbDBStmt(3018760);
  bbInt l_y=(l_hi-1);
  bbDBLocal("y",&l_y);
  bbDBStmt(3022850);
  {
    bbDBLoop db_loop;
    do{
      struct f1_t : public bbGCFrame{
        t_mojo_graphics_Uniform* l_p{};
        void gcMark(){
          bbGCMarkPtr(l_p);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(3026953);
      f1.l_p=this->m__0data->at(l_i);
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(3031043);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(this->m__0data->at(l_x),f1.l_p)<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3035140);
          l_x+=1;
        }
      }
      bbDBStmt(3043331);
      {
        bbDBLoop db_loop;
        while((l_compareFunc(f1.l_p,this->m__0data->at(l_y))<bbInt(0))){
          bbDBBlock db_blk;
          bbDBStmt(3047428);
          l_y-=1;
        }
      }
      bbDBStmt(3055619);
      if((l_x>l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3055626);
        break;
      }
      bbDBStmt(3059715);
      if((l_x<l_y)){
        bbDBBlock db_blk;
        bbDBStmt(3063812);
        this->m_Swap(l_x,l_y);
        bbDBStmt(3067908);
        if((l_i==l_x)){
          bbDBBlock db_blk;
          bbDBStmt(3067915);
          l_i=l_y;
        }else if(bbDBStmt(3067919),(l_i==l_y)){
          bbDBBlock db_blk;
          bbDBStmt(3067931);
          l_i=l_x;
        }
      }
      bbDBStmt(3076099);
      l_x+=1;
      bbDBStmt(3080195);
      l_y-=1;
    }while(!((l_x>l_y)));
  }
  bbDBStmt(3092482);
  this->m_Sort(l_compareFunc,l_lo,l_y);
  bbDBStmt(3096578);
  this->m_Sort(l_compareFunc,l_x,l_hi);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.Uniform,mojo.graphics.Uniform))","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2928642);
  this->m_Sort(l_compareFunc,bbInt(0),(this->m__0length-1));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2879490);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2883587);
    struct lambda16 : public bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_self;
      lambda16(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_Uniform* l_x,t_mojo_graphics_Uniform* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.Uniform,y:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2887684);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)>(new lambda16(this)));
  }else{
    bbDBStmt(2895874);
    bbDBBlock db_blk;
    bbDBStmt(2899971);
    struct lambda17 : public bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)>::Rep{
      t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_self;
      lambda17(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_Uniform* l_x,t_mojo_graphics_Uniform* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.Uniform,y:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2904068);
        return bbCompare(l_y,l_x);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)>(new lambda17(this)));
  }
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Slice(bbInt l_index1,bbInt l_index2){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t0{};
    void gcMark(){
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.graphics.Uniform>(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(2691074);
  if((l_index1<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2695171);
    l_index1=g_monkey_math_Max_1i((l_index1+this->m__0length),bbInt(0));
  }else if(bbDBStmt(2699266),(l_index1>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2703363);
    l_index1=this->m__0length;
  }
  bbDBStmt(2715650);
  if((l_index2<bbInt(0))){
    bbDBBlock db_blk;
    bbDBStmt(2719747);
    l_index2=g_monkey_math_Max_1i((l_index2+this->m__0length),l_index1);
  }else if(bbDBStmt(2723842),(l_index2>this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(2727939);
    l_index2=this->m__0length;
  }else if(bbDBStmt(2732034),(l_index2<l_index1)){
    bbDBBlock db_blk;
    bbDBStmt(2736131);
    l_index2=l_index1;
  }
  bbDBStmt(2748418);
  return bbGCNew<t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2>(f0.t0=this->m__0data->slice(l_index1,l_index2));
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Slice(bbInt l_index){
  bbDBFrame db_f{"Slice:std.collections.Stack<mojo.graphics.Uniform>(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(2609154);
  return this->m_Slice(l_index,this->m__0length);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Set(bbInt l_index,t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Set:Void(index:Int,value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798146);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1806338);
  this->m__0data->at(l_index)=l_value;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Resize(bbInt l_length){
  bbDBFrame db_f{"Resize:Void(length:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("length",&l_length);
  bbDBStmt(1306626);
  bbDebugAssert((l_length>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1314818);
  {
    bbDBLoop db_loop;
    bbInt l_i=l_length;
    bbDBLocal("i",&l_i);
    bbDBStmt(1314818);
    for(;(l_i<this->m__0length);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1318915);
      this->m__0data->at(l_i)=((t_mojo_graphics_Uniform*)0);
    }
  }
  bbDBStmt(1331202);
  this->m_Reserve(l_length);
  bbDBStmt(1335298);
  this->m__0length=l_length;
  bbDBStmt(1339394);
  this->m__0seq+=1;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Reserve(bbInt l_capacity){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_data{};
    void gcMark(){
      bbGCMarkPtr(l_data);
    }
  }f0{};
  bbDBFrame db_f{"Reserve:Void(capacity:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("capacity",&l_capacity);
  bbDBStmt(1404930);
  bbDebugAssert((l_capacity>=bbInt(0)),BB_T("Debug assert failed"));
  bbDBStmt(1413122);
  if((this->m__0data->length()>=l_capacity)){
    bbDBBlock db_blk;
    bbDBStmt(1413148);
    return;
  }
  bbDBStmt(1421314);
  l_capacity=g_monkey_math_Max_1i(((this->m__0length*2)+this->m__0length),l_capacity);
  bbDBStmt(1425416);
  f0.l_data=bbArray<bbGCVar<t_mojo_graphics_Uniform>>::create(l_capacity);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1429506);
  this->m__0data->copyTo(f0.l_data,bbInt(0),bbInt(0),this->m__0length);
  bbDBStmt(1433602);
  this->m__0data=f0.l_data;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_RemoveLast(t_mojo_graphics_Uniform* l_value,bbInt l_start){
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.graphics.Uniform,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2441224);
  bbInt l_i=this->m_FindLastIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2445314);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2445322);
    return false;
  }
  bbDBStmt(2449410);
  this->m_Erase(l_i);
  bbDBStmt(2453506);
  return true;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_RemoveEach(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2498568);
  bbInt l_put=bbInt(0);
  bbDBLocal("put",&l_put);
  bbDBStmt(2498575);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2502658);
  {
    bbDBLoop db_loop;
    bbInt l_get=bbInt(0);
    bbDBLocal("get",&l_get);
    bbDBStmt(2502658);
    for(;(l_get<this->m__0length);l_get+=1){
      bbDBBlock db_blk;
      bbDBStmt(2506755);
      if((this->m__0data->at(l_get)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2510852);
        l_n+=1;
        bbDBStmt(2514948);
        continue;
      }
      bbDBStmt(2523139);
      this->m__0data->at(l_put)=this->m__0data->at(l_get);
      bbDBStmt(2527235);
      l_put+=1;
    }
  }
  bbDBStmt(2535426);
  this->m_Resize(l_put);
  bbDBStmt(2539522);
  return l_n;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Remove(t_mojo_graphics_Uniform* l_value,bbInt l_start){
  bbDBFrame db_f{"Remove:Bool(value:mojo.graphics.Uniform,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2375688);
  bbInt l_i=this->m_FindIndex(l_value,l_start);
  bbDBLocal("i",&l_i);
  bbDBStmt(2379778);
  if((l_i==-1)){
    bbDBBlock db_blk;
    bbDBStmt(2379786);
    return false;
  }
  bbDBStmt(2383874);
  this->m_Erase(l_i);
  bbDBStmt(2387970);
  return true;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Push(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Push:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(3260418);
  this->m_Add(l_value);
}

t_mojo_graphics_Uniform* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Pop(){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Uniform* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"Pop:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(3190786);
  bbDebugAssert(bbBool(this->m__0length),BB_T("Stack is empty"));
  bbDBStmt(3198978);
  this->m__0length-=1;
  bbDBStmt(3203074);
  this->m__0seq+=1;
  bbDBStmt(3207176);
  f0.l_value=this->m__0data->at(this->m__0length);
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(3211266);
  this->m__0data->at(this->m__0length)=((t_mojo_graphics_Uniform*)0);
  bbDBStmt(3215362);
  return f0.l_value;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Length(){
  bbDBFrame db_f{"Length:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1187842);
  return this->m__0length;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Insert(bbInt l_index,t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Insert:Void(index:Int,value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("value",&l_value);
  bbDBStmt(1667074);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1675266);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1679362);
  this->m__0data->copyTo(this->m__0data,l_index,(l_index+1),(this->m__0length-l_index));
  bbDBStmt(1683458);
  this->m__0data->at(l_index)=l_value;
  bbDBStmt(1687554);
  this->m__0length+=1;
  bbDBStmt(1691650);
  this->m__0seq+=1;
}

t_mojo_graphics_Uniform* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Get(bbInt l_index){
  bbDBFrame db_f{"Get:mojo.graphics.Uniform(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1736706);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<this->m__0length)),BB_T("Stack index out of range"));
  bbDBStmt(1744898);
  return this->m__0data->at(l_index);
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_FindLastIndex(t_mojo_graphics_Uniform* l_value,bbInt l_start){
  bbDBFrame db_f{"FindLastIndex:Int(value:mojo.graphics.Uniform,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2248706);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2256904);
  bbInt l_i=this->m__0length;
  bbDBLocal("i",&l_i);
  bbDBStmt(2260994);
  {
    bbDBLoop db_loop;
    while((l_i>l_start)){
      bbDBBlock db_blk;
      bbDBStmt(2265091);
      l_i-=1;
      bbDBStmt(2269187);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2269205);
        return l_i;
      }
    }
  }
  bbDBStmt(2277378);
  return -1;
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_FindIndex(t_mojo_graphics_Uniform* l_value,bbInt l_start){
  bbDBFrame db_f{"FindIndex:Int(value:mojo.graphics.Uniform,start:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBLocal("start",&l_start);
  bbDBStmt(2158594);
  bbDebugAssert(((l_start>=bbInt(0))&&(l_start<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(2166792);
  bbInt l_i=l_start;
  bbDBLocal("i",&l_i);
  bbDBStmt(2170882);
  {
    bbDBLoop db_loop;
    while((l_i<this->m__0length)){
      bbDBBlock db_blk;
      bbDBStmt(2174979);
      if((this->m__0data->at(l_i)==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2174997);
        return l_i;
      }
      bbDBStmt(2179075);
      l_i+=1;
    }
  }
  bbDBStmt(2187266);
  return -1;
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Erase(bbInt l_index1,bbInt l_index2){
  bbDBFrame db_f{"Erase:Void(index1:Int,index2:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index1",&l_index1);
  bbDBLocal("index2",&l_index2);
  bbDBStmt(1589250);
  bbDebugAssert((((((l_index1>=bbInt(0))&&(l_index1<=this->m__0length))&&(l_index2>=bbInt(0)))&&(l_index2<=this->m__0length))&&(l_index1<=l_index2)),BB_T("Debug assert failed"));
  bbDBStmt(1597442);
  if((l_index1==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1597460);
    return;
  }
  bbDBStmt(1601538);
  this->m__0data->copyTo(this->m__0data,l_index2,l_index1,(this->m__0length-l_index2));
  bbDBStmt(1605634);
  this->m_Resize(((this->m__0length-l_index2)+l_index1));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Erase(bbInt l_index){
  bbDBFrame db_f{"Erase:Void(index:Int)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(1511426);
  bbDebugAssert(((l_index>=bbInt(0))&&(l_index<=this->m__0length)),BB_T("Debug assert failed"));
  bbDBStmt(1515522);
  if((l_index==this->m__0length)){
    bbDBBlock db_blk;
    bbDBStmt(1515539);
    return;
  }
  bbDBStmt(1523714);
  this->m__0data->copyTo(this->m__0data,(l_index+1),l_index,((this->m__0length-l_index)-1));
  bbDBStmt(1527810);
  this->m_Resize((this->m__0length-1));
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return (this->m__0length==bbInt(0));
}

bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Data(){
  bbDBFrame db_f{"Data:mojo.graphics.Uniform[]()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1150978);
  return this->m__0data;
}

bbBool t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Contains(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Contains:Bool(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2322434);
  return (this->m_FindIndex(l_value,bbInt(0))!=-1);
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1458178);
  this->m_Resize(bbInt(0));
}

bbInt t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Capacity(){
  bbDBFrame db_f{"Capacity:Int()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1253378);
  return this->m__0data->length();
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.Stack<mojo.graphics.Uniform>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1069058);
  return t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_BackwardsIterator(this,(this->m__0length-1));
}

t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_All(){
  bbDBFrame db_f{"All:std.collections.Stack<mojo.graphics.Uniform>.Iterator()","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1024002);
  return t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator(this,bbInt(0));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_AddAll(bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.graphics.Uniform[])","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2015234);
  this->m_Reserve((this->m__0length+l_values->length()));
  bbDBStmt(2019330);
  l_values->copyTo(this->m__0data,bbInt(0),this->m__0length,l_values->length());
  bbDBStmt(2023426);
  this->m_Resize((this->m__0length+l_values->length()));
}

void t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2::m_Add(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/stack.monkey2"};
  t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966082);
  this->m_Reserve((this->m__0length+1));
  bbDBStmt(1970178);
  this->m__0data->at(this->m__0length)=l_value;
  bbDBStmt(1974274);
  this->m__0length+=1;
  bbDBStmt(1978370);
  this->m__0seq+=1;
}
bbString bbDBType(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2**){
  return "std.collections.Stack<mojo.graphics.Uniform>";
}
bbString bbDBValue(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_std_collections_2stack_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_collections_2stack_init_v("mojo_std_collections_2stack",&mx2_mojo_std_collections_2stack_init);
