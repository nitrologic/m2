
#include "../../desktop_debug_pi/mojo_std_collections_2list.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2view.h"
#include "../../desktop_debug_pi/mojo_app_2window.h"
#include "../../desktop_debug_pi/mojo_audio_2audio.h"
#include "../../desktop_debug_pi/mojo_graphics_2canvas.h"
#include "../../desktop_debug_pi/mojo_graphics_2shader.h"
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"

// ***** Internal *****

void g_std_collections_List_1Tt_mojo_app_Window_2_AddAll_1Tt_std_collections_List_1Tt_mojo_app_Window_2_2(t_std_collections_List_1Tt_mojo_app_Window_2* l_self,t_std_collections_List_1Tt_mojo_app_Window_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.app.Window>>:Void(values:std.collections.List<mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_app_Window_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_app_Window_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_app_Window_2_2(t_std_collections_List_1Tt_mojo_app_Window_2* l_self,t_std_collections_Stack_1Tt_mojo_app_Window_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<mojo.app.Window>>:Void(values:std.collections.Stack<mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_Window_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_app_View_2_AddAll_1Tt_std_collections_List_1Tt_mojo_app_View_2_2(t_std_collections_List_1Tt_mojo_app_View_2* l_self,t_std_collections_List_1Tt_mojo_app_View_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.app.View>>:Void(values:std.collections.List<mojo.app.View>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_app_View_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_app_View_2_2(t_std_collections_List_1Tt_mojo_app_View_2* l_self,t_std_collections_Stack_1Tt_mojo_app_View_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<mojo.app.View>>:Void(values:std.collections.Stack<mojo.app.View>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_app_View_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_2(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_self,t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.graphics.Vertex2f>>:Void(values:std.collections.List<mojo.graphics.Vertex2f>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_mojo_graphics_Vertex2f l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_2(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_self,t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<mojo.graphics.Vertex2f>>:Void(values:std.collections.Stack<mojo.graphics.Vertex2f>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_mojo_graphics_Vertex2f l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(l_value);
    }
  }
}

void g_std_collections_List_1Tt_std_geom_Rect_1i_2_AddAll_1Tt_std_collections_List_1Tt_std_geom_Rect_1i_2_2(t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_self,t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<Recti:std.geom.Rect<Int>>>:Void(values:std.collections.List<Recti:std.geom.Rect<Int>>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_std_geom_Rect_1i l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(l_value);
    }
  }
}

void g_std_collections_List_1Tt_std_geom_Rect_1i_2_AddAll_1Tt_std_collections_Stack_1Tt_std_geom_Rect_1i_2_2(t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_self,t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<Recti:std.geom.Rect<Int>>>:Void(values:std.collections.Stack<Recti:std.geom.Rect<Int>>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_std_geom_Rect_1i_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_std_geom_Rect_1i l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_graphics_DrawOp_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_DrawOp_2_2(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_self,t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.graphics.DrawOp>>:Void(values:std.collections.List<mojo.graphics.DrawOp>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_DrawOp* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_graphics_DrawOp_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_2(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_self,t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<mojo.graphics.DrawOp>>:Void(values:std.collections.Stack<mojo.graphics.DrawOp>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_DrawOp* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_AddAll_1Tt_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_2(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_self,t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>>:Void(values:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_std_geom_AffineMat3_1f l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(l_value);
    }
  }
}

void g_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_AddAll_1Tt_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_2(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_self,t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>>:Void(values:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      t_std_geom_AffineMat3_1f l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_graphics_Uniform_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_Uniform_2_2(t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_self,t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.graphics.Uniform>>:Void(values:std.collections.List<mojo.graphics.Uniform>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_Uniform* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_graphics_Uniform_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_2(t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_self,t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<mojo.graphics.Uniform>>:Void(values:std.collections.Stack<mojo.graphics.Uniform>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_Uniform* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1j_AddAll_1Tt_std_collections_List_1j_2(t_std_collections_List_1j* l_self,t_std_collections_List_1j* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<ALuint:Uint>>:Void(values:std.collections.List<ALuint:Uint>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1j_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      bbUInt l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(l_value);
    }
  }
}

void g_std_collections_List_1j_AddAll_1Tt_std_collections_Stack_1j_2(t_std_collections_List_1j* l_self,t_std_collections_Stack_1j* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<ALuint:Uint>>:Void(values:std.collections.Stack<ALuint:Uint>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1j_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      bbUInt l_value=f1.l_0.m_Current();
      bbDBLocal("value",&l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_audio_Channel_2_AddAll_1Tt_std_collections_List_1Tt_mojo_audio_Channel_2_2(t_std_collections_List_1Tt_mojo_audio_Channel_2* l_self,t_std_collections_List_1Tt_mojo_audio_Channel_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.List<mojo.audio.Channel>>:Void(values:std.collections.List<mojo.audio.Channel>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_audio_Channel* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void g_std_collections_List_1Tt_mojo_audio_Channel_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_audio_Channel_2_2(t_std_collections_List_1Tt_mojo_audio_Channel_2* l_self,t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_values){
  bbDBFrame db_f{"AddAll<std.collections.Stack<mojo.audio.Channel>>:Void(values:std.collections.Stack<mojo.audio.Channel>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=l_self;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2318338);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1Tt_mojo_audio_Channel_2_Iterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=l_values->m_All();
    bbDBLocal("0",&f1.l_0);
    for(;!f1.l_0.m_AtEnd();f1.l_0.m_Bump()){
      struct f2_t : public bbGCFrame{
        t_mojo_audio_Channel* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=f1.l_0.m_Current();
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2322435);
      l_self->m_AddLast(f2.l_value);
    }
  }
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
  bbGCMark(m__0value);
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::t_std_collections_List_1Tt_mojo_audio_Channel_2_Node(t_mojo_audio_Channel* l_value,t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:mojo.audio.Channel,succ:std.collections.List<mojo.audio.Channel>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::t_std_collections_List_1Tt_mojo_audio_Channel_2_Node(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"new:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::m_Value(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Value:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

t_mojo_audio_Channel* t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<mojo.audio.Channel>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<mojo.audio.Channel>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::m_InsertBefore(t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<mojo.audio.Channel>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Node::m_InsertAfter(t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<mojo.audio.Channel>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_audio_Channel_2_Node**){
  return "std.collections.List<mojo.audio.Channel>.Node";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_audio_Channel_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::dbEmit(t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator(t_std_collections_List_1Tt_mojo_audio_Channel_2* l_list,t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.audio.Channel>,node:std.collections.List<mojo.audio.Channel>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::m_Insert(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_audio_Channel_2_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::m_Current(t_mojo_audio_Channel* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_audio_Channel* t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*){
  return "std.collections.List<mojo.audio.Channel>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator&x,const t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::dbEmit(t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator(t_std_collections_List_1Tt_mojo_audio_Channel_2* l_list,t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.audio.Channel>,node:std.collections.List<mojo.audio.Channel>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Insert(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_audio_Channel_2_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Current(t_mojo_audio_Channel* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_audio_Channel* t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*){
  return "std.collections.List<mojo.audio.Channel>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator&x,const t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2::t_std_collections_List_1Tt_mojo_audio_Channel_2(t_std_collections_List_1Tt_mojo_audio_Channel_2* l_values):t_std_collections_List_1Tt_mojo_audio_Channel_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.audio.Channel>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1Tt_mojo_audio_Channel_2_AddAll_1Tt_std_collections_List_1Tt_mojo_audio_Channel_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2::t_std_collections_List_1Tt_mojo_audio_Channel_2(t_std_collections_Stack_1Tt_mojo_audio_Channel_2* l_values):t_std_collections_List_1Tt_mojo_audio_Channel_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.audio.Channel>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1Tt_mojo_audio_Channel_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_audio_Channel_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2::t_std_collections_List_1Tt_mojo_audio_Channel_2(bbArray<bbGCVar<t_mojo_audio_Channel>>* l_values):t_std_collections_List_1Tt_mojo_audio_Channel_2(){
  bbDBFrame db_f{"new:Void(values:mojo.audio.Channel[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2::t_std_collections_List_1Tt_mojo_audio_Channel_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1Tt_mojo_audio_Channel_2_Node>(((t_mojo_audio_Channel*)0));
}

bbArray<bbGCVar<t_mojo_audio_Channel>>* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_audio_Channel>>* l_data{};
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:mojo.audio.Channel[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<bbGCVar<t_mojo_audio_Channel>>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Sort(bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.audio.Channel,mojo.audio.Channel))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_p{};
        t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda0 : public bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)>::Rep{
      t_std_collections_List_1Tt_mojo_audio_Channel_2* l_self;
      lambda0(t_std_collections_List_1Tt_mojo_audio_Channel_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_audio_Channel* l_x,t_mojo_audio_Channel* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.audio.Channel,y:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)>(new lambda0(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda1 : public bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)>::Rep{
      t_std_collections_List_1Tt_mojo_audio_Channel_2* l_self;
      lambda1(t_std_collections_List_1Tt_mojo_audio_Channel_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_audio_Channel* l_x,t_mojo_audio_Channel* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.audio.Channel,y:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_audio_Channel*,t_mojo_audio_Channel*)>(new lambda1(this)));
  }
}

t_mojo_audio_Channel* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_RemoveLast(){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  f0.l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return f0.l_value;
}

bbBool t_std_collections_List_1Tt_mojo_audio_Channel_2::m_RemoveLast(t_mojo_audio_Channel* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

t_mojo_audio_Channel* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_RemoveFirst(){
  struct f0_t : public bbGCFrame{
    t_mojo_audio_Channel* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveFirst:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  f0.l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return f0.l_value;
}

bbInt t_std_collections_List_1Tt_mojo_audio_Channel_2::m_RemoveEach(t_mojo_audio_Channel* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Remove(t_mojo_audio_Channel* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<mojo.audio.Channel>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*)0);
}

t_mojo_audio_Channel* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Last(){
  bbDBFrame db_f{"Last:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<mojo.audio.Channel>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<mojo.audio.Channel>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*)0);
}

t_mojo_audio_Channel* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_First(){
  bbDBFrame db_f{"First:mojo.audio.Channel()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_FindNode(t_mojo_audio_Channel* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<mojo.audio.Channel>.Node(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*)0);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_FindLastNode(t_mojo_audio_Channel* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<mojo.audio.Channel>.Node(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1Tt_mojo_audio_Channel_2_Node*)0);
}

bbBool t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<mojo.audio.Channel>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1Tt_mojo_audio_Channel_2_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator t_std_collections_List_1Tt_mojo_audio_Channel_2::m_All(){
  bbDBFrame db_f{"All:std.collections.List<mojo.audio.Channel>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1Tt_mojo_audio_Channel_2_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_AddLast(t_mojo_audio_Channel* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<mojo.audio.Channel>.Node(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_audio_Channel_2_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* t_std_collections_List_1Tt_mojo_audio_Channel_2::m_AddFirst(t_mojo_audio_Channel* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_audio_Channel_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<mojo.audio.Channel>.Node(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_audio_Channel_2_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2::m_AddAll(bbArray<bbGCVar<t_mojo_audio_Channel>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.audio.Channel[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_audio_Channel* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=l_values->at(l_0);
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2297859);
      this->m_AddLast(f2.l_value);
    }
  }
}

void t_std_collections_List_1Tt_mojo_audio_Channel_2::m_Add(t_mojo_audio_Channel* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.audio.Channel)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_audio_Channel_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_audio_Channel_2**){
  return "std.collections.List<mojo.audio.Channel>";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_audio_Channel_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1j_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
}

void t_std_collections_List_1j_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1j_Node::t_std_collections_List_1j_Node(bbUInt l_value,t_std_collections_List_1j_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:ALuint:Uint,succ:std.collections.List<ALuint:Uint>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1j_Node::t_std_collections_List_1j_Node(bbUInt l_value){
  bbDBFrame db_f{"new:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1j_Node::m_Value(bbUInt l_value){
  bbDBFrame db_f{"Value:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

bbUInt t_std_collections_List_1j_Node::m_Value(){
  bbDBFrame db_f{"Value:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1j_Node* t_std_collections_List_1j_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<ALuint:Uint>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1j_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1j_Node* t_std_collections_List_1j_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<ALuint:Uint>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1j_Node::m_InsertBefore(t_std_collections_List_1j_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<ALuint:Uint>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1j_Node::m_InsertAfter(t_std_collections_List_1j_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<ALuint:Uint>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1j_Node**){
  return "std.collections.List<ALuint:Uint>.Node";
}
bbString bbDBValue(t_std_collections_List_1j_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1j_Iterator::dbEmit(t_std_collections_List_1j_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1j_Iterator::t_std_collections_List_1j_Iterator(t_std_collections_List_1j* l_list,t_std_collections_List_1j_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<ALuint:Uint>,node:std.collections.List<ALuint:Uint>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1j_Iterator::m_Insert(bbUInt l_value){
  bbDBFrame db_f{"Insert:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1j_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1j_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1j_Iterator::m_Current(bbUInt l_current){
  bbDBFrame db_f{"Current:Void(current:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

bbUInt t_std_collections_List_1j_Iterator::m_Current(){
  bbDBFrame db_f{"Current:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1j_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1j_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1j_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1j_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1j_Iterator*){
  return "std.collections.List<ALuint:Uint>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1j_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1j_Iterator&x,const t_std_collections_List_1j_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1j_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1j_BackwardsIterator::dbEmit(t_std_collections_List_1j_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1j_BackwardsIterator::t_std_collections_List_1j_BackwardsIterator(t_std_collections_List_1j* l_list,t_std_collections_List_1j_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<ALuint:Uint>,node:std.collections.List<ALuint:Uint>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1j_BackwardsIterator::m_Insert(bbUInt l_value){
  bbDBFrame db_f{"Insert:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1j_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1j_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1j_BackwardsIterator::m_Current(bbUInt l_current){
  bbDBFrame db_f{"Current:Void(current:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

bbUInt t_std_collections_List_1j_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1j_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1j_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1j_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1j_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1j_BackwardsIterator*){
  return "std.collections.List<ALuint:Uint>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1j_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1j_BackwardsIterator&x,const t_std_collections_List_1j_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1j_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1j::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1j::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1j::t_std_collections_List_1j(t_std_collections_List_1j* l_values):t_std_collections_List_1j(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<ALuint:Uint>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1j_AddAll_1Tt_std_collections_List_1j_2(this,l_values);
}

t_std_collections_List_1j::t_std_collections_List_1j(t_std_collections_Stack_1j* l_values):t_std_collections_List_1j(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<ALuint:Uint>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1j_AddAll_1Tt_std_collections_Stack_1j_2(this,l_values);
}

t_std_collections_List_1j::t_std_collections_List_1j(bbArray<bbUInt>* l_values):t_std_collections_List_1j(){
  bbDBFrame db_f{"new:Void(values:ALuint:Uint[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1j::t_std_collections_List_1j(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1j_Node>(0);
}

bbArray<bbUInt>* t_std_collections_List_1j::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<bbUInt>* l_data{};
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:ALuint:Uint[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<bbUInt>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1j::m_Sort(bbFunction<bbInt(bbUInt,bbUInt)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(ALuint:Uint,ALuint:Uint))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1j_Node* l_p{};
        t_std_collections_List_1j_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1j_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1j_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1j::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda2 : public bbFunction<bbInt(bbUInt,bbUInt)>::Rep{
      t_std_collections_List_1j* l_self;
      lambda2(t_std_collections_List_1j* l_self):l_self(l_self){
      }
      bbInt invoke(bbUInt l_x,bbUInt l_y){
        bbDBFrame db_f{"?????:Int(x:ALuint:Uint,y:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(bbUInt,bbUInt)>(new lambda2(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda3 : public bbFunction<bbInt(bbUInt,bbUInt)>::Rep{
      t_std_collections_List_1j* l_self;
      lambda3(t_std_collections_List_1j* l_self):l_self(l_self){
      }
      bbInt invoke(bbUInt l_x,bbUInt l_y){
        bbDBFrame db_f{"?????:Int(x:ALuint:Uint,y:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(bbUInt,bbUInt)>(new lambda3(this)));
  }
}

bbUInt t_std_collections_List_1j::m_RemoveLast(){
  bbDBFrame db_f{"RemoveLast:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  bbUInt l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return l_value;
}

bbBool t_std_collections_List_1j::m_RemoveLast(bbUInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

bbUInt t_std_collections_List_1j::m_RemoveFirst(){
  bbDBFrame db_f{"RemoveFirst:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  bbUInt l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return l_value;
}

bbInt t_std_collections_List_1j::m_RemoveEach(bbUInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1j::m_Remove(bbUInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1j_Node* t_std_collections_List_1j::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<ALuint:Uint>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1j_Node*)0);
}

bbUInt t_std_collections_List_1j::m_Last(){
  bbDBFrame db_f{"Last:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1j_Node* t_std_collections_List_1j::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<ALuint:Uint>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1j_Node* t_std_collections_List_1j::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<ALuint:Uint>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1j_Node*)0);
}

bbUInt t_std_collections_List_1j::m_First(){
  bbDBFrame db_f{"First:ALuint:Uint()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1j_Node* t_std_collections_List_1j::m_FindNode(bbUInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<ALuint:Uint>.Node(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1j_Node*)0);
}

t_std_collections_List_1j_Node* t_std_collections_List_1j::m_FindLastNode(bbUInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<ALuint:Uint>.Node(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1j_Node*)0);
}

bbBool t_std_collections_List_1j::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1j::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1j::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1j_BackwardsIterator t_std_collections_List_1j::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<ALuint:Uint>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1j_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1j_Iterator t_std_collections_List_1j::m_All(){
  bbDBFrame db_f{"All:std.collections.List<ALuint:Uint>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1j_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1j_Node* t_std_collections_List_1j::m_AddLast(bbUInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<ALuint:Uint>.Node(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1j_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1j_Node* t_std_collections_List_1j::m_AddFirst(bbUInt l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1j_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<ALuint:Uint>.Node(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1j_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1j::m_AddAll(bbArray<bbUInt>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:ALuint:Uint[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      bbDBBlock db_blk;
      bbUInt l_value=l_values->at(l_0);
      bbDBLocal("value",&l_value);
      bbDBStmt(2297859);
      this->m_AddLast(l_value);
    }
  }
}

void t_std_collections_List_1j::m_Add(bbUInt l_value){
  bbDBFrame db_f{"Add:Void(value:ALuint:Uint)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1j*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1j**){
  return "std.collections.List<ALuint:Uint>";
}
bbString bbDBValue(t_std_collections_List_1j**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node(t_std_geom_AffineMat3_1f l_value,t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:AffineMat3f:std.geom.AffineMat3<Float>,succ:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"new:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::m_Value(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Value:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

t_std_geom_AffineMat3_1f t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::m_Value(){
  bbDBFrame db_f{"Value:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::m_InsertBefore(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node::m_InsertAfter(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node**){
  return "std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node";
}
bbString bbDBValue(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::dbEmit(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_list,t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>,node:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Insert(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Insert:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Current(t_std_geom_AffineMat3_1f l_current){
  bbDBFrame db_f{"Current:Void(current:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

t_std_geom_AffineMat3_1f t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*){
  return "std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator&x,const t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::dbEmit(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_list,t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>,node:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Insert(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Insert:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Current(t_std_geom_AffineMat3_1f l_current){
  bbDBFrame db_f{"Current:Void(current:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

t_std_geom_AffineMat3_1f t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*){
  return "std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator&x,const t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_values):t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_AddAll_1Tt_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_2(this,l_values);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2(t_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2* l_values):t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<AffineMat3f:std.geom.AffineMat3<Float>>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_AddAll_1Tt_std_collections_Stack_1Tt_std_geom_AffineMat3_1f_2_2(this,l_values);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2(bbArray<t_std_geom_AffineMat3_1f>* l_values):t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2(){
  bbDBFrame db_f{"new:Void(values:AffineMat3f:std.geom.AffineMat3<Float>[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node>(t_std_geom_AffineMat3_1f{});
}

bbArray<t_std_geom_AffineMat3_1f>* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<t_std_geom_AffineMat3_1f>* l_data{};
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:AffineMat3f:std.geom.AffineMat3<Float>[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<t_std_geom_AffineMat3_1f>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Sort(bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(AffineMat3f:std.geom.AffineMat3<Float>,AffineMat3f:std.geom.AffineMat3<Float>))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_p{};
        t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda4 : public bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)>::Rep{
      t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_self;
      lambda4(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_std_geom_AffineMat3_1f l_x,t_std_geom_AffineMat3_1f l_y){
        bbDBFrame db_f{"?????:Int(x:AffineMat3f:std.geom.AffineMat3<Float>,y:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)>(new lambda4(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda5 : public bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)>::Rep{
      t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_self;
      lambda5(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_std_geom_AffineMat3_1f l_x,t_std_geom_AffineMat3_1f l_y){
        bbDBFrame db_f{"?????:Int(x:AffineMat3f:std.geom.AffineMat3<Float>,y:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_std_geom_AffineMat3_1f,t_std_geom_AffineMat3_1f)>(new lambda5(this)));
  }
}

t_std_geom_AffineMat3_1f t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_RemoveLast(){
  bbDBFrame db_f{"RemoveLast:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  t_std_geom_AffineMat3_1f l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return l_value;
}

bbBool t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_RemoveLast(t_std_geom_AffineMat3_1f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

t_std_geom_AffineMat3_1f t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_RemoveFirst(){
  bbDBFrame db_f{"RemoveFirst:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  t_std_geom_AffineMat3_1f l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return l_value;
}

bbInt t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_RemoveEach(t_std_geom_AffineMat3_1f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Remove(t_std_geom_AffineMat3_1f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*)0);
}

t_std_geom_AffineMat3_1f t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Last(){
  bbDBFrame db_f{"Last:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*)0);
}

t_std_geom_AffineMat3_1f t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_First(){
  bbDBFrame db_f{"First:AffineMat3f:std.geom.AffineMat3<Float>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_FindNode(t_std_geom_AffineMat3_1f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*)0);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_FindLastNode(t_std_geom_AffineMat3_1f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node*)0);
}

bbBool t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_All(){
  bbDBFrame db_f{"All:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_AddLast(t_std_geom_AffineMat3_1f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_AddFirst(t_std_geom_AffineMat3_1f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>.Node(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_AddAll(bbArray<t_std_geom_AffineMat3_1f>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:AffineMat3f:std.geom.AffineMat3<Float>[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      bbDBBlock db_blk;
      t_std_geom_AffineMat3_1f l_value=l_values->at(l_0);
      bbDBLocal("value",&l_value);
      bbDBStmt(2297859);
      this->m_AddLast(l_value);
    }
  }
}

void t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2::m_Add(t_std_geom_AffineMat3_1f l_value){
  bbDBFrame db_f{"Add:Void(value:AffineMat3f:std.geom.AffineMat3<Float>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2**){
  return "std.collections.List<AffineMat3f:std.geom.AffineMat3<Float>>";
}
bbString bbDBValue(t_std_collections_List_1Tt_std_geom_AffineMat3_1f_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
  bbGCMark(m__0value);
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node(t_mojo_graphics_DrawOp* l_value,t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:mojo.graphics.DrawOp,succ:std.collections.List<mojo.graphics.DrawOp>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"new:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::m_Value(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Value:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

t_mojo_graphics_DrawOp* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<mojo.graphics.DrawOp>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<mojo.graphics.DrawOp>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::m_InsertBefore(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<mojo.graphics.DrawOp>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node::m_InsertAfter(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<mojo.graphics.DrawOp>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node**){
  return "std.collections.List<mojo.graphics.DrawOp>.Node";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::dbEmit(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_list,t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.graphics.DrawOp>,node:std.collections.List<mojo.graphics.DrawOp>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Insert(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Current(t_mojo_graphics_DrawOp* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_graphics_DrawOp* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*){
  return "std.collections.List<mojo.graphics.DrawOp>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator&x,const t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::dbEmit(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_list,t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.graphics.DrawOp>,node:std.collections.List<mojo.graphics.DrawOp>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Insert(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Current(t_mojo_graphics_DrawOp* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_graphics_DrawOp* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*){
  return "std.collections.List<mojo.graphics.DrawOp>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator&x,const t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::t_std_collections_List_1Tt_mojo_graphics_DrawOp_2(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_values):t_std_collections_List_1Tt_mojo_graphics_DrawOp_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.graphics.DrawOp>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1Tt_mojo_graphics_DrawOp_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_DrawOp_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::t_std_collections_List_1Tt_mojo_graphics_DrawOp_2(t_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2* l_values):t_std_collections_List_1Tt_mojo_graphics_DrawOp_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.graphics.DrawOp>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1Tt_mojo_graphics_DrawOp_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_graphics_DrawOp_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::t_std_collections_List_1Tt_mojo_graphics_DrawOp_2(bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* l_values):t_std_collections_List_1Tt_mojo_graphics_DrawOp_2(){
  bbDBFrame db_f{"new:Void(values:mojo.graphics.DrawOp[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::t_std_collections_List_1Tt_mojo_graphics_DrawOp_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node>(((t_mojo_graphics_DrawOp*)0));
}

bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* l_data{};
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:mojo.graphics.DrawOp[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<bbGCVar<t_mojo_graphics_DrawOp>>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.DrawOp,mojo.graphics.DrawOp))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_p{};
        t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda6 : public bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)>::Rep{
      t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_self;
      lambda6(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_DrawOp* l_x,t_mojo_graphics_DrawOp* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.DrawOp,y:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)>(new lambda6(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda7 : public bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)>::Rep{
      t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_self;
      lambda7(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_DrawOp* l_x,t_mojo_graphics_DrawOp* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.DrawOp,y:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_DrawOp*,t_mojo_graphics_DrawOp*)>(new lambda7(this)));
  }
}

t_mojo_graphics_DrawOp* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_RemoveLast(){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_DrawOp* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  f0.l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return f0.l_value;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_RemoveLast(t_mojo_graphics_DrawOp* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

t_mojo_graphics_DrawOp* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_RemoveFirst(){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_DrawOp* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveFirst:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  f0.l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return f0.l_value;
}

bbInt t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_RemoveEach(t_mojo_graphics_DrawOp* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Remove(t_mojo_graphics_DrawOp* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<mojo.graphics.DrawOp>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*)0);
}

t_mojo_graphics_DrawOp* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Last(){
  bbDBFrame db_f{"Last:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<mojo.graphics.DrawOp>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<mojo.graphics.DrawOp>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*)0);
}

t_mojo_graphics_DrawOp* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_First(){
  bbDBFrame db_f{"First:mojo.graphics.DrawOp()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_FindNode(t_mojo_graphics_DrawOp* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<mojo.graphics.DrawOp>.Node(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*)0);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_FindLastNode(t_mojo_graphics_DrawOp* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<mojo.graphics.DrawOp>.Node(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node*)0);
}

bbBool t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<mojo.graphics.DrawOp>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_All(){
  bbDBFrame db_f{"All:std.collections.List<mojo.graphics.DrawOp>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_AddLast(t_mojo_graphics_DrawOp* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<mojo.graphics.DrawOp>.Node(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_AddFirst(t_mojo_graphics_DrawOp* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<mojo.graphics.DrawOp>.Node(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_DrawOp_2_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_AddAll(bbArray<bbGCVar<t_mojo_graphics_DrawOp>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.graphics.DrawOp[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_DrawOp* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=l_values->at(l_0);
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2297859);
      this->m_AddLast(f2.l_value);
    }
  }
}

void t_std_collections_List_1Tt_mojo_graphics_DrawOp_2::m_Add(t_mojo_graphics_DrawOp* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.graphics.DrawOp)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_DrawOp_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2**){
  return "std.collections.List<mojo.graphics.DrawOp>";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_DrawOp_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node(t_std_geom_Rect_1i l_value,t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:Recti:std.geom.Rect<Int>,succ:std.collections.List<Recti:std.geom.Rect<Int>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"new:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::m_Value(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Value:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

t_std_geom_Rect_1i t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::m_Value(){
  bbDBFrame db_f{"Value:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<Recti:std.geom.Rect<Int>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<Recti:std.geom.Rect<Int>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::m_InsertBefore(t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<Recti:std.geom.Rect<Int>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node::m_InsertAfter(t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<Recti:std.geom.Rect<Int>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node**){
  return "std.collections.List<Recti:std.geom.Rect<Int>>.Node";
}
bbString bbDBValue(t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::dbEmit(t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator(t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_list,t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<Recti:std.geom.Rect<Int>>,node:std.collections.List<Recti:std.geom.Rect<Int>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::m_Insert(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Insert:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::m_Current(t_std_geom_Rect_1i l_current){
  bbDBFrame db_f{"Current:Void(current:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

t_std_geom_Rect_1i t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*){
  return "std.collections.List<Recti:std.geom.Rect<Int>>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator&x,const t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::dbEmit(t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator(t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_list,t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<Recti:std.geom.Rect<Int>>,node:std.collections.List<Recti:std.geom.Rect<Int>>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Insert(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Insert:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Current(t_std_geom_Rect_1i l_current){
  bbDBFrame db_f{"Current:Void(current:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

t_std_geom_Rect_1i t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*){
  return "std.collections.List<Recti:std.geom.Rect<Int>>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator&x,const t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2::t_std_collections_List_1Tt_std_geom_Rect_1i_2(t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_values):t_std_collections_List_1Tt_std_geom_Rect_1i_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<Recti:std.geom.Rect<Int>>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1Tt_std_geom_Rect_1i_2_AddAll_1Tt_std_collections_List_1Tt_std_geom_Rect_1i_2_2(this,l_values);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2::t_std_collections_List_1Tt_std_geom_Rect_1i_2(t_std_collections_Stack_1Tt_std_geom_Rect_1i_2* l_values):t_std_collections_List_1Tt_std_geom_Rect_1i_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<Recti:std.geom.Rect<Int>>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1Tt_std_geom_Rect_1i_2_AddAll_1Tt_std_collections_Stack_1Tt_std_geom_Rect_1i_2_2(this,l_values);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2::t_std_collections_List_1Tt_std_geom_Rect_1i_2(bbArray<t_std_geom_Rect_1i>* l_values):t_std_collections_List_1Tt_std_geom_Rect_1i_2(){
  bbDBFrame db_f{"new:Void(values:Recti:std.geom.Rect<Int>[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2::t_std_collections_List_1Tt_std_geom_Rect_1i_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node>(t_std_geom_Rect_1i{});
}

bbArray<t_std_geom_Rect_1i>* t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<t_std_geom_Rect_1i>* l_data{};
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:Recti:std.geom.Rect<Int>[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<t_std_geom_Rect_1i>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Sort(bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(Recti:std.geom.Rect<Int>,Recti:std.geom.Rect<Int>))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_p{};
        t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda8 : public bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)>::Rep{
      t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_self;
      lambda8(t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_std_geom_Rect_1i l_x,t_std_geom_Rect_1i l_y){
        bbDBFrame db_f{"?????:Int(x:Recti:std.geom.Rect<Int>,y:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)>(new lambda8(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda9 : public bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)>::Rep{
      t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_self;
      lambda9(t_std_collections_List_1Tt_std_geom_Rect_1i_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_std_geom_Rect_1i l_x,t_std_geom_Rect_1i l_y){
        bbDBFrame db_f{"?????:Int(x:Recti:std.geom.Rect<Int>,y:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_std_geom_Rect_1i,t_std_geom_Rect_1i)>(new lambda9(this)));
  }
}

t_std_geom_Rect_1i t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_RemoveLast(){
  bbDBFrame db_f{"RemoveLast:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  t_std_geom_Rect_1i l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return l_value;
}

bbBool t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_RemoveLast(t_std_geom_Rect_1i l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

t_std_geom_Rect_1i t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_RemoveFirst(){
  bbDBFrame db_f{"RemoveFirst:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  t_std_geom_Rect_1i l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return l_value;
}

bbInt t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_RemoveEach(t_std_geom_Rect_1i l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Remove(t_std_geom_Rect_1i l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<Recti:std.geom.Rect<Int>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*)0);
}

t_std_geom_Rect_1i t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Last(){
  bbDBFrame db_f{"Last:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<Recti:std.geom.Rect<Int>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<Recti:std.geom.Rect<Int>>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*)0);
}

t_std_geom_Rect_1i t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_First(){
  bbDBFrame db_f{"First:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_FindNode(t_std_geom_Rect_1i l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<Recti:std.geom.Rect<Int>>.Node(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*)0);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_FindLastNode(t_std_geom_Rect_1i l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<Recti:std.geom.Rect<Int>>.Node(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node*)0);
}

bbBool t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<Recti:std.geom.Rect<Int>>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1Tt_std_geom_Rect_1i_2_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_All(){
  bbDBFrame db_f{"All:std.collections.List<Recti:std.geom.Rect<Int>>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1Tt_std_geom_Rect_1i_2_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_AddLast(t_std_geom_Rect_1i l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<Recti:std.geom.Rect<Int>>.Node(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_AddFirst(t_std_geom_Rect_1i l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<Recti:std.geom.Rect<Int>>.Node(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_std_geom_Rect_1i_2_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_AddAll(bbArray<t_std_geom_Rect_1i>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:Recti:std.geom.Rect<Int>[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      bbDBBlock db_blk;
      t_std_geom_Rect_1i l_value=l_values->at(l_0);
      bbDBLocal("value",&l_value);
      bbDBStmt(2297859);
      this->m_AddLast(l_value);
    }
  }
}

void t_std_collections_List_1Tt_std_geom_Rect_1i_2::m_Add(t_std_geom_Rect_1i l_value){
  bbDBFrame db_f{"Add:Void(value:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_std_geom_Rect_1i_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1Tt_std_geom_Rect_1i_2**){
  return "std.collections.List<Recti:std.geom.Rect<Int>>";
}
bbString bbDBValue(t_std_collections_List_1Tt_std_geom_Rect_1i_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node(t_mojo_graphics_Vertex2f l_value,t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:mojo.graphics.Vertex2f,succ:std.collections.List<mojo.graphics.Vertex2f>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"new:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::m_Value(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Value:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

t_mojo_graphics_Vertex2f t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<mojo.graphics.Vertex2f>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<mojo.graphics.Vertex2f>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::m_InsertBefore(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<mojo.graphics.Vertex2f>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node::m_InsertAfter(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<mojo.graphics.Vertex2f>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node**){
  return "std.collections.List<mojo.graphics.Vertex2f>.Node";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::dbEmit(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_list,t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.graphics.Vertex2f>,node:std.collections.List<mojo.graphics.Vertex2f>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Insert(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Current(t_mojo_graphics_Vertex2f l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_graphics_Vertex2f t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*){
  return "std.collections.List<mojo.graphics.Vertex2f>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator&x,const t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::dbEmit(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_list,t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.graphics.Vertex2f>,node:std.collections.List<mojo.graphics.Vertex2f>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Insert(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Current(t_mojo_graphics_Vertex2f l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_graphics_Vertex2f t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*){
  return "std.collections.List<mojo.graphics.Vertex2f>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator&x,const t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_values):t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.graphics.Vertex2f>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2(t_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2* l_values):t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.graphics.Vertex2f>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_graphics_Vertex2f_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2(bbArray<t_mojo_graphics_Vertex2f>* l_values):t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2(){
  bbDBFrame db_f{"new:Void(values:mojo.graphics.Vertex2f[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node>(t_mojo_graphics_Vertex2f{});
}

bbArray<t_mojo_graphics_Vertex2f>* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<t_mojo_graphics_Vertex2f>* l_data{};
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:mojo.graphics.Vertex2f[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<t_mojo_graphics_Vertex2f>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.Vertex2f,mojo.graphics.Vertex2f))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_p{};
        t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda10 : public bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)>::Rep{
      t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_self;
      lambda10(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_Vertex2f l_x,t_mojo_graphics_Vertex2f l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.Vertex2f,y:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)>(new lambda10(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda11 : public bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)>::Rep{
      t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_self;
      lambda11(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_Vertex2f l_x,t_mojo_graphics_Vertex2f l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.Vertex2f,y:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_Vertex2f,t_mojo_graphics_Vertex2f)>(new lambda11(this)));
  }
}

t_mojo_graphics_Vertex2f t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_RemoveLast(){
  bbDBFrame db_f{"RemoveLast:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  t_mojo_graphics_Vertex2f l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return l_value;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_RemoveLast(t_mojo_graphics_Vertex2f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

t_mojo_graphics_Vertex2f t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_RemoveFirst(){
  bbDBFrame db_f{"RemoveFirst:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  t_mojo_graphics_Vertex2f l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return l_value;
}

bbInt t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_RemoveEach(t_mojo_graphics_Vertex2f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Remove(t_mojo_graphics_Vertex2f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<mojo.graphics.Vertex2f>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*)0);
}

t_mojo_graphics_Vertex2f t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Last(){
  bbDBFrame db_f{"Last:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<mojo.graphics.Vertex2f>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<mojo.graphics.Vertex2f>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*)0);
}

t_mojo_graphics_Vertex2f t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_First(){
  bbDBFrame db_f{"First:mojo.graphics.Vertex2f()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_FindNode(t_mojo_graphics_Vertex2f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<mojo.graphics.Vertex2f>.Node(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*)0);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_FindLastNode(t_mojo_graphics_Vertex2f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<mojo.graphics.Vertex2f>.Node(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((bbCompare(f0.l_node->m__0value,l_value)==0)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node*)0);
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<mojo.graphics.Vertex2f>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_All(){
  bbDBFrame db_f{"All:std.collections.List<mojo.graphics.Vertex2f>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_AddLast(t_mojo_graphics_Vertex2f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<mojo.graphics.Vertex2f>.Node(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_AddFirst(t_mojo_graphics_Vertex2f l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<mojo.graphics.Vertex2f>.Node(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_AddAll(bbArray<t_mojo_graphics_Vertex2f>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.graphics.Vertex2f[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      bbDBBlock db_blk;
      t_mojo_graphics_Vertex2f l_value=l_values->at(l_0);
      bbDBLocal("value",&l_value);
      bbDBStmt(2297859);
      this->m_AddLast(l_value);
    }
  }
}

void t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2::m_Add(t_mojo_graphics_Vertex2f l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.graphics.Vertex2f)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2**){
  return "std.collections.List<mojo.graphics.Vertex2f>";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_Vertex2f_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_app_View_2_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
  bbGCMark(m__0value);
}

void t_std_collections_List_1Tt_mojo_app_View_2_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1Tt_mojo_app_View_2_Node::t_std_collections_List_1Tt_mojo_app_View_2_Node(t_mojo_app_View* l_value,t_std_collections_List_1Tt_mojo_app_View_2_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:mojo.app.View,succ:std.collections.List<mojo.app.View>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1Tt_mojo_app_View_2_Node::t_std_collections_List_1Tt_mojo_app_View_2_Node(t_mojo_app_View* l_value){
  bbDBFrame db_f{"new:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_app_View_2_Node::m_Value(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Value:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

t_mojo_app_View* t_std_collections_List_1Tt_mojo_app_View_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.app.View()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<mojo.app.View>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1Tt_mojo_app_View_2_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<mojo.app.View>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1Tt_mojo_app_View_2_Node::m_InsertBefore(t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<mojo.app.View>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_app_View_2_Node::m_InsertAfter(t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<mojo.app.View>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_app_View_2_Node**){
  return "std.collections.List<mojo.app.View>.Node";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_app_View_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_app_View_2_Iterator::dbEmit(t_std_collections_List_1Tt_mojo_app_View_2_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_app_View_2_Iterator::t_std_collections_List_1Tt_mojo_app_View_2_Iterator(t_std_collections_List_1Tt_mojo_app_View_2* l_list,t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.app.View>,node:std.collections.List<mojo.app.View>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_View_2_Iterator::m_Insert(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_app_View_2_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_View_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_View_2_Iterator::m_Current(t_mojo_app_View* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_app_View* t_std_collections_List_1Tt_mojo_app_View_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.View()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_app_View_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1Tt_mojo_app_View_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_app_View_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_app_View_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_app_View_2_Iterator*){
  return "std.collections.List<mojo.app.View>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_app_View_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_app_View_2_Iterator&x,const t_std_collections_List_1Tt_mojo_app_View_2_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_app_View_2_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::dbEmit(t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator(t_std_collections_List_1Tt_mojo_app_View_2* l_list,t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.app.View>,node:std.collections.List<mojo.app.View>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::m_Insert(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_app_View_2_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::m_Current(t_mojo_app_View* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_app_View* t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.View()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*){
  return "std.collections.List<mojo.app.View>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator&x,const t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_app_View_2::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1Tt_mojo_app_View_2::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1Tt_mojo_app_View_2::t_std_collections_List_1Tt_mojo_app_View_2(t_std_collections_List_1Tt_mojo_app_View_2* l_values):t_std_collections_List_1Tt_mojo_app_View_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.app.View>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1Tt_mojo_app_View_2_AddAll_1Tt_std_collections_List_1Tt_mojo_app_View_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_app_View_2::t_std_collections_List_1Tt_mojo_app_View_2(t_std_collections_Stack_1Tt_mojo_app_View_2* l_values):t_std_collections_List_1Tt_mojo_app_View_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.app.View>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1Tt_mojo_app_View_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_app_View_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_app_View_2::t_std_collections_List_1Tt_mojo_app_View_2(bbArray<bbGCVar<t_mojo_app_View>>* l_values):t_std_collections_List_1Tt_mojo_app_View_2(){
  bbDBFrame db_f{"new:Void(values:mojo.app.View[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1Tt_mojo_app_View_2::t_std_collections_List_1Tt_mojo_app_View_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1Tt_mojo_app_View_2_Node>(((t_mojo_app_View*)0));
}

bbArray<bbGCVar<t_mojo_app_View>>* t_std_collections_List_1Tt_mojo_app_View_2::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_app_View>>* l_data{};
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:mojo.app.View[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<bbGCVar<t_mojo_app_View>>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1Tt_mojo_app_View_2::m_Sort(bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.app.View,mojo.app.View))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1Tt_mojo_app_View_2_Node* l_p{};
        t_std_collections_List_1Tt_mojo_app_View_2_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1Tt_mojo_app_View_2_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1Tt_mojo_app_View_2_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1Tt_mojo_app_View_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda12 : public bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)>::Rep{
      t_std_collections_List_1Tt_mojo_app_View_2* l_self;
      lambda12(t_std_collections_List_1Tt_mojo_app_View_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_app_View* l_x,t_mojo_app_View* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.app.View,y:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)>(new lambda12(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda13 : public bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)>::Rep{
      t_std_collections_List_1Tt_mojo_app_View_2* l_self;
      lambda13(t_std_collections_List_1Tt_mojo_app_View_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_app_View* l_x,t_mojo_app_View* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.app.View,y:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_app_View*,t_mojo_app_View*)>(new lambda13(this)));
  }
}

t_mojo_app_View* t_std_collections_List_1Tt_mojo_app_View_2::m_RemoveLast(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_View* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:mojo.app.View()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  f0.l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return f0.l_value;
}

bbBool t_std_collections_List_1Tt_mojo_app_View_2::m_RemoveLast(t_mojo_app_View* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

t_mojo_app_View* t_std_collections_List_1Tt_mojo_app_View_2::m_RemoveFirst(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_View* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveFirst:mojo.app.View()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  f0.l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return f0.l_value;
}

bbInt t_std_collections_List_1Tt_mojo_app_View_2::m_RemoveEach(t_mojo_app_View* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1Tt_mojo_app_View_2::m_Remove(t_mojo_app_View* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<mojo.app.View>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1Tt_mojo_app_View_2_Node*)0);
}

t_mojo_app_View* t_std_collections_List_1Tt_mojo_app_View_2::m_Last(){
  bbDBFrame db_f{"Last:mojo.app.View()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<mojo.app.View>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<mojo.app.View>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1Tt_mojo_app_View_2_Node*)0);
}

t_mojo_app_View* t_std_collections_List_1Tt_mojo_app_View_2::m_First(){
  bbDBFrame db_f{"First:mojo.app.View()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2::m_FindNode(t_mojo_app_View* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<mojo.app.View>.Node(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1Tt_mojo_app_View_2_Node*)0);
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2::m_FindLastNode(t_mojo_app_View* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<mojo.app.View>.Node(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1Tt_mojo_app_View_2_Node*)0);
}

bbBool t_std_collections_List_1Tt_mojo_app_View_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1Tt_mojo_app_View_2::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1Tt_mojo_app_View_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator t_std_collections_List_1Tt_mojo_app_View_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<mojo.app.View>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1Tt_mojo_app_View_2_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1Tt_mojo_app_View_2_Iterator t_std_collections_List_1Tt_mojo_app_View_2::m_All(){
  bbDBFrame db_f{"All:std.collections.List<mojo.app.View>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1Tt_mojo_app_View_2_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2::m_AddLast(t_mojo_app_View* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<mojo.app.View>.Node(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_app_View_2_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1Tt_mojo_app_View_2_Node* t_std_collections_List_1Tt_mojo_app_View_2::m_AddFirst(t_mojo_app_View* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_View_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<mojo.app.View>.Node(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_app_View_2_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1Tt_mojo_app_View_2::m_AddAll(bbArray<bbGCVar<t_mojo_app_View>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.app.View[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_View* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=l_values->at(l_0);
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2297859);
      this->m_AddLast(f2.l_value);
    }
  }
}

void t_std_collections_List_1Tt_mojo_app_View_2::m_Add(t_mojo_app_View* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.app.View)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_View_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_app_View_2**){
  return "std.collections.List<mojo.app.View>";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_app_View_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
  bbGCMark(m__0value);
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node::t_std_collections_List_1Tt_mojo_app_Window_2_Node(t_mojo_app_Window* l_value,t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:mojo.app.Window,succ:std.collections.List<mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node::t_std_collections_List_1Tt_mojo_app_Window_2_Node(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"new:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Node::m_Value(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Value:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

t_mojo_app_Window* t_std_collections_List_1Tt_mojo_app_Window_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Node::m_InsertBefore(t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Node::m_InsertAfter(t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_app_Window_2_Node**){
  return "std.collections.List<mojo.app.Window>.Node";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_app_Window_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::dbEmit(t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::t_std_collections_List_1Tt_mojo_app_Window_2_Iterator(t_std_collections_List_1Tt_mojo_app_Window_2* l_list,t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.app.Window>,node:std.collections.List<mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::m_Insert(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_app_Window_2_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::m_Current(t_mojo_app_Window* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_app_Window* t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_app_Window_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*){
  return "std.collections.List<mojo.app.Window>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_app_Window_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_app_Window_2_Iterator&x,const t_std_collections_List_1Tt_mojo_app_Window_2_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_app_Window_2_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::dbEmit(t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator(t_std_collections_List_1Tt_mojo_app_Window_2* l_list,t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.app.Window>,node:std.collections.List<mojo.app.Window>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::m_Insert(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_app_Window_2_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::m_Current(t_mojo_app_Window* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_app_Window* t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*){
  return "std.collections.List<mojo.app.Window>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator&x,const t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_app_Window_2::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1Tt_mojo_app_Window_2::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1Tt_mojo_app_Window_2::t_std_collections_List_1Tt_mojo_app_Window_2(t_std_collections_List_1Tt_mojo_app_Window_2* l_values):t_std_collections_List_1Tt_mojo_app_Window_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1Tt_mojo_app_Window_2_AddAll_1Tt_std_collections_List_1Tt_mojo_app_Window_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_app_Window_2::t_std_collections_List_1Tt_mojo_app_Window_2(t_std_collections_Stack_1Tt_mojo_app_Window_2* l_values):t_std_collections_List_1Tt_mojo_app_Window_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.app.Window>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1Tt_mojo_app_Window_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_app_Window_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_app_Window_2::t_std_collections_List_1Tt_mojo_app_Window_2(bbArray<bbGCVar<t_mojo_app_Window>>* l_values):t_std_collections_List_1Tt_mojo_app_Window_2(){
  bbDBFrame db_f{"new:Void(values:mojo.app.Window[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1Tt_mojo_app_Window_2::t_std_collections_List_1Tt_mojo_app_Window_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1Tt_mojo_app_Window_2_Node>(((t_mojo_app_Window*)0));
}

bbArray<bbGCVar<t_mojo_app_Window>>* t_std_collections_List_1Tt_mojo_app_Window_2::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_app_Window>>* l_data{};
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:mojo.app.Window[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<bbGCVar<t_mojo_app_Window>>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1Tt_mojo_app_Window_2::m_Sort(bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.app.Window,mojo.app.Window))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_p{};
        t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1Tt_mojo_app_Window_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda14 : public bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)>::Rep{
      t_std_collections_List_1Tt_mojo_app_Window_2* l_self;
      lambda14(t_std_collections_List_1Tt_mojo_app_Window_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_app_Window* l_x,t_mojo_app_Window* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.app.Window,y:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)>(new lambda14(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda15 : public bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)>::Rep{
      t_std_collections_List_1Tt_mojo_app_Window_2* l_self;
      lambda15(t_std_collections_List_1Tt_mojo_app_Window_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_app_Window* l_x,t_mojo_app_Window* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.app.Window,y:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_app_Window*,t_mojo_app_Window*)>(new lambda15(this)));
  }
}

t_mojo_app_Window* t_std_collections_List_1Tt_mojo_app_Window_2::m_RemoveLast(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  f0.l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return f0.l_value;
}

bbBool t_std_collections_List_1Tt_mojo_app_Window_2::m_RemoveLast(t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

t_mojo_app_Window* t_std_collections_List_1Tt_mojo_app_Window_2::m_RemoveFirst(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Window* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveFirst:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  f0.l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return f0.l_value;
}

bbInt t_std_collections_List_1Tt_mojo_app_Window_2::m_RemoveEach(t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1Tt_mojo_app_Window_2::m_Remove(t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1Tt_mojo_app_Window_2_Node*)0);
}

t_mojo_app_Window* t_std_collections_List_1Tt_mojo_app_Window_2::m_Last(){
  bbDBFrame db_f{"Last:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<mojo.app.Window>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1Tt_mojo_app_Window_2_Node*)0);
}

t_mojo_app_Window* t_std_collections_List_1Tt_mojo_app_Window_2::m_First(){
  bbDBFrame db_f{"First:mojo.app.Window()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2::m_FindNode(t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<mojo.app.Window>.Node(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1Tt_mojo_app_Window_2_Node*)0);
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2::m_FindLastNode(t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<mojo.app.Window>.Node(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1Tt_mojo_app_Window_2_Node*)0);
}

bbBool t_std_collections_List_1Tt_mojo_app_Window_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1Tt_mojo_app_Window_2::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1Tt_mojo_app_Window_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator t_std_collections_List_1Tt_mojo_app_Window_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<mojo.app.Window>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1Tt_mojo_app_Window_2_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1Tt_mojo_app_Window_2_Iterator t_std_collections_List_1Tt_mojo_app_Window_2::m_All(){
  bbDBFrame db_f{"All:std.collections.List<mojo.app.Window>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1Tt_mojo_app_Window_2_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2::m_AddLast(t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<mojo.app.Window>.Node(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_app_Window_2_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1Tt_mojo_app_Window_2_Node* t_std_collections_List_1Tt_mojo_app_Window_2::m_AddFirst(t_mojo_app_Window* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_app_Window_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<mojo.app.Window>.Node(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_app_Window_2_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1Tt_mojo_app_Window_2::m_AddAll(bbArray<bbGCVar<t_mojo_app_Window>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.app.Window[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_app_Window* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=l_values->at(l_0);
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2297859);
      this->m_AddLast(f2.l_value);
    }
  }
}

void t_std_collections_List_1Tt_mojo_app_Window_2::m_Add(t_mojo_app_Window* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.app.Window)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_app_Window_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_app_Window_2**){
  return "std.collections.List<mojo.app.Window>";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_app_Window_2**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::gcMark(){
  bbGCMark(m__0succ);
  bbGCMark(m__0pred);
  bbGCMark(m__0value);
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::dbEmit(){
  bbDBEmit("_succ",&m__0succ);
  bbDBEmit("_pred",&m__0pred);
  bbDBEmit("_value",&m__0value);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node(t_mojo_graphics_Uniform* l_value,t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_succ){
  bbDBFrame db_f{"new:Void(value:mojo.graphics.Uniform,succ:std.collections.List<mojo.graphics.Uniform>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("succ",&l_succ);
  bbDBStmt(245763);
  this->m__0value=l_value;
  bbDBStmt(249859);
  this->m__0succ=l_succ;
  bbDBStmt(253955);
  this->m__0pred=l_succ->m__0pred;
  bbDBStmt(258051);
  this->m__0pred->m__0succ=this;
  bbDBStmt(262147);
  l_succ->m__0pred=this;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"new:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBStmt(192515);
  this->m__0value=l_value;
  bbDBStmt(196611);
  this->m__0succ=this;
  bbDBStmt(200707);
  this->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::m_Value(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Value:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(344067);
  this->m__0value=l_value;
}

t_mojo_graphics_Uniform* t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::m_Value(){
  bbDBFrame db_f{"Value:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(335875);
  return this->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::m_Succ(){
  bbDBFrame db_f{"Succ:std.collections.List<mojo.graphics.Uniform>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286723);
  return this->m__0succ;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::m_Remove(){
  bbDBFrame db_f{"Remove:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(503811);
  this->m__0succ->m__0pred=this->m__0pred;
  bbDBStmt(507907);
  this->m__0pred->m__0succ=this->m__0succ;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::m_Pred(){
  bbDBFrame db_f{"Pred:std.collections.List<mojo.graphics.Uniform>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(311299);
  return this->m__0pred;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::m_InsertBefore(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node){
  bbDBFrame db_f{"InsertBefore:Void(node:std.collections.List<mojo.graphics.Uniform>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(389123);
  this->m__0succ=l_node;
  bbDBStmt(393219);
  this->m__0pred=l_node->m__0pred;
  bbDBStmt(397315);
  this->m__0pred->m__0succ=this;
  bbDBStmt(401411);
  l_node->m__0pred=this;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node::m_InsertAfter(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node){
  bbDBFrame db_f{"InsertAfter:Void(node:std.collections.List<mojo.graphics.Uniform>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("node",&l_node);
  bbDBStmt(446467);
  this->m__0pred=l_node;
  bbDBStmt(450563);
  this->m__0succ=l_node->m__0succ;
  bbDBStmt(454659);
  this->m__0succ->m__0pred=this;
  bbDBStmt(458755);
  l_node->m__0succ=this;
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node**){
  return "std.collections.List<mojo.graphics.Uniform>.Node";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node**p){
  return bbDBObjectValue(*p);
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::dbEmit(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator(t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_list,t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.graphics.Uniform>,node:std.collections.List<mojo.graphics.Uniform>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(622595);
  (*this).m__0list=l_list;
  bbDBStmt(626691);
  (*this).m__0node=l_node;
  bbDBStmt(630787);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::m_Insert(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(835587);
  (*this).m_AssertSeq();
  bbDBStmt(839683);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node>(l_value,(*this).m__0node);
  bbDBStmt(843779);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(847875);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(782339);
  (*this).m_AssertCurrent();
  bbDBStmt(786435);
  (*this).m__0node=(*this).m__0node->m__0succ;
  bbDBStmt(790531);
  (*this).m__0node->m__0pred->m_Remove();
  bbDBStmt(794627);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(798723);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::m_Current(t_mojo_graphics_Uniform* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(700419);
  (*this).m_AssertCurrent();
  bbDBStmt(704515);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_graphics_Uniform* t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(684035);
  (*this).m_AssertCurrent();
  bbDBStmt(688131);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(729091);
  (*this).m_AssertCurrent();
  bbDBStmt(733187);
  (*this).m__0node=(*this).m__0node->m__0succ;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(655363);
  (*this).m_AssertSeq();
  bbDBStmt(659459);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(573443);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(589827);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*){
  return "std.collections.List<mojo.graphics.Uniform>.Iterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator&x,const t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::dbEmit(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*p){
  bbDBEmit("_list",&p->m__0list);
  bbDBEmit("_node",&p->m__0node);
  bbDBEmit("_seq",&p->m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator(t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_list,t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node){
  bbDBFrame db_f{"new:Void(list:std.collections.List<mojo.graphics.Uniform>,node:std.collections.List<mojo.graphics.Uniform>.Node)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("list",&l_list);
  bbDBLocal("node",&l_node);
  bbDBStmt(958467);
  (*this).m__0list=l_list;
  bbDBStmt(962563);
  (*this).m__0node=l_node;
  bbDBStmt(966659);
  (*this).m__0seq=l_list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Insert(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Insert:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1171459);
  (*this).m_AssertSeq();
  bbDBStmt(1175555);
  (*this).m__0node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node>(l_value,(*this).m__0node->m__0succ);
  bbDBStmt(1179651);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1183747);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Erase(){
  bbDBFrame db_f{"Erase:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1118211);
  (*this).m_AssertCurrent();
  bbDBStmt(1122307);
  (*this).m__0node=(*this).m__0node->m__0pred;
  bbDBStmt(1126403);
  (*this).m__0node->m__0succ->m_Remove();
  bbDBStmt(1130499);
  (*this).m__0list->m__0seq+=1;
  bbDBStmt(1134595);
  (*this).m__0seq=(*this).m__0list->m__0seq;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Current(t_mojo_graphics_Uniform* l_current){
  bbDBFrame db_f{"Current:Void(current:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBLocal("current",&l_current);
  bbDBStmt(1036291);
  (*this).m_AssertCurrent();
  bbDBStmt(1040387);
  (*this).m__0node->m__0value=l_current;
}

t_mojo_graphics_Uniform* t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Current(){
  bbDBFrame db_f{"Current:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1019907);
  (*this).m_AssertCurrent();
  bbDBStmt(1024003);
  return (*this).m__0node->m__0value;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_Bump(){
  bbDBFrame db_f{"Bump:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(1064963);
  (*this).m_AssertCurrent();
  bbDBStmt(1069059);
  (*this).m__0node=(*this).m__0node->m__0pred;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_AtEnd(){
  bbDBFrame db_f{"AtEnd:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(991235);
  (*this).m_AssertSeq();
  bbDBStmt(995331);
  return ((*this).m__0node==(*this).m__0list->m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_AssertSeq(){
  bbDBFrame db_f{"AssertSeq:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(909315);
  bbDebugAssert(((*this).m__0seq==(*this).m__0list->m__0seq),BB_T("Concurrent list modification"));
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator::m_AssertCurrent(){
  bbDBFrame db_f{"AssertCurrent:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*self=&(*this);
  bbDBLocal("Self",self);
  bbDBStmt(925699);
  bbDebugAssert(!(*this).m_AtEnd(),BB_T("Invalid list iterator"));
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*){
  return "std.collections.List<mojo.graphics.Uniform>.BackwardsIterator";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator*p){
  return bbDBStructValue(p);
}

int bbCompare(const t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator&x,const t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator&y){
  if(int t=bbCompare(x.m__0list,y.m__0list)) return t;
  if(int t=bbCompare(x.m__0node,y.m__0node)) return t;
  if(int t=bbCompare(x.m__0seq,y.m__0seq)) return t;
  return 0;
}

void bbGCMark(const t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator&t){
  bbGCMark(t.m__0list);
  bbGCMark(t.m__0node);
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2::gcMark(){
  bbGCMark(m__0head);
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2::dbEmit(){
  bbDBEmit("_head",&m__0head);
  bbDBEmit("_seq",&m__0seq);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2::t_std_collections_List_1Tt_mojo_graphics_Uniform_2(t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_values):t_std_collections_List_1Tt_mojo_graphics_Uniform_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.List<mojo.graphics.Uniform>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1351682);
  g_std_collections_List_1Tt_mojo_graphics_Uniform_2_AddAll_1Tt_std_collections_List_1Tt_mojo_graphics_Uniform_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2::t_std_collections_List_1Tt_mojo_graphics_Uniform_2(t_std_collections_Stack_1Tt_mojo_graphics_Uniform_2* l_values):t_std_collections_List_1Tt_mojo_graphics_Uniform_2(){
  bbDBFrame db_f{"new:Void(values:std.collections.Stack<mojo.graphics.Uniform>)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1331202);
  g_std_collections_List_1Tt_mojo_graphics_Uniform_2_AddAll_1Tt_std_collections_Stack_1Tt_mojo_graphics_Uniform_2_2(this,l_values);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2::t_std_collections_List_1Tt_mojo_graphics_Uniform_2(bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_values):t_std_collections_List_1Tt_mojo_graphics_Uniform_2(){
  bbDBFrame db_f{"new:Void(values:mojo.graphics.Uniform[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBLocal("values",&l_values);
  bbDBStmt(1310722);
  this->m_AddAll(l_values);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2::t_std_collections_List_1Tt_mojo_graphics_Uniform_2(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  bbDBStmt(1290242);
  this->m__0head=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node>(((t_mojo_graphics_Uniform*)0));
}

bbArray<bbGCVar<t_mojo_graphics_Uniform>>* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_ToArray(){
  struct f0_t : public bbGCFrame{
    bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_data{};
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_data);
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"ToArray:mojo.graphics.Uniform[]()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1585160);
  bbInt l_n=this->m_Count();
  bbDBLocal("n",&l_n);
  bbDBStmt(1589256);
  f0.l_data=bbArray<bbGCVar<t_mojo_graphics_Uniform>>::create(l_n);
  bbDBLocal("data",&f0.l_data);
  bbDBStmt(1589271);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1593346);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(1593346);
    for(;(l_i<l_n);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(1597443);
      f0.l_data->at(l_i)=f0.l_node->m__0value;
      bbDBStmt(1601539);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(1609730);
  return f0.l_data;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Sort(bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)> l_compareFunc){
  bbDBFrame db_f{"Sort:Void(compareFunc:Int(mojo.graphics.Uniform,mojo.graphics.Uniform))","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("compareFunc",&l_compareFunc);
  bbDBStmt(2428936);
  bbInt l_insize=1;
  bbDBLocal("insize",&l_insize);
  bbDBStmt(2437122);
  {
    bbDBLoop db_loop;
    for(;;){
      struct f1_t : public bbGCFrame{
        t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_p{};
        t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_tail{};
        void gcMark(){
          bbGCMarkPtr(l_p);
          bbGCMarkPtr(l_tail);
        }
      }f1{};
      bbDBBlock db_blk;
      bbDBStmt(2445321);
      bbInt l_merges=bbInt(0);
      bbDBLocal("merges",&l_merges);
      bbDBStmt(2449417);
      f1.l_tail=this->m__0head;
      bbDBLocal("tail",&f1.l_tail);
      bbDBStmt(2453513);
      f1.l_p=this->m__0head->m__0succ;
      bbDBLocal("p",&f1.l_p);
      bbDBStmt(2461699);
      {
        bbDBLoop db_loop;
        while((f1.l_p!=this->m__0head)){
          struct f2_t : public bbGCFrame{
            t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_q{};
            void gcMark(){
              bbGCMarkPtr(l_q);
            }
          }f2{};
          bbDBBlock db_blk;
          bbDBStmt(2465796);
          l_merges+=1;
          bbDBStmt(2469898);
          f2.l_q=f1.l_p->m__0succ;
          bbDBLocal("q",&f2.l_q);
          bbDBStmt(2469909);
          bbInt l_qsize=l_insize;
          bbDBLocal("qsize",&l_qsize);
          bbDBStmt(2469923);
          bbInt l_psize=1;
          bbDBLocal("psize",&l_psize);
          bbDBStmt(2478084);
          {
            bbDBLoop db_loop;
            while(((l_psize<l_insize)&&(f2.l_q!=this->m__0head))){
              bbDBBlock db_blk;
              bbDBStmt(2482181);
              l_psize+=1;
              bbDBStmt(2486277);
              f2.l_q=f2.l_q->m__0succ;
            }
          }
          bbDBStmt(2498564);
          {
            bbDBLoop db_loop;
            for(;;){
              struct f3_t : public bbGCFrame{
                t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_t{};
                void gcMark(){
                  bbGCMarkPtr(l_t);
                }
              }f3{};
              bbDBBlock db_blk;
              bbDBStmt(2502667);
              bbDBLocal("t",&f3.l_t);
              bbDBStmt(2506757);
              if(((bbBool(l_psize)&&bbBool(l_qsize))&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2510860);
                bbInt l_cc=l_compareFunc(f1.l_p->m__0value,f2.l_q->m__0value);
                bbDBLocal("cc",&l_cc);
                bbDBStmt(2514950);
                if((l_cc<=bbInt(0))){
                  bbDBBlock db_blk;
                  bbDBStmt(2519047);
                  f3.l_t=f1.l_p;
                  bbDBStmt(2523143);
                  f1.l_p=f1.l_p->m__0succ;
                  bbDBStmt(2527239);
                  l_psize-=1;
                }else{
                  bbDBStmt(2531334);
                  bbDBBlock db_blk;
                  bbDBStmt(2535431);
                  f3.l_t=f2.l_q;
                  bbDBStmt(2539527);
                  f2.l_q=f2.l_q->m__0succ;
                  bbDBStmt(2543623);
                  l_qsize-=1;
                }
              }else if(bbDBStmt(2551813),bbBool(l_psize)){
                bbDBBlock db_blk;
                bbDBStmt(2555910);
                f3.l_t=f1.l_p;
                bbDBStmt(2560006);
                f1.l_p=f1.l_p->m__0succ;
                bbDBStmt(2564102);
                l_psize-=1;
              }else if(bbDBStmt(2568197),(bbBool(l_qsize)&&(f2.l_q!=this->m__0head))){
                bbDBBlock db_blk;
                bbDBStmt(2572294);
                f3.l_t=f2.l_q;
                bbDBStmt(2576390);
                f2.l_q=f2.l_q->m__0succ;
                bbDBStmt(2580486);
                l_qsize-=1;
              }else{
                bbDBStmt(2584581);
                bbDBBlock db_blk;
                bbDBStmt(2588678);
                break;
              }
              bbDBStmt(2596869);
              f3.l_t->m__0pred=f1.l_tail;
              bbDBStmt(2600965);
              f1.l_tail->m__0succ=f3.l_t;
              bbDBStmt(2605061);
              f1.l_tail=f3.l_t;
            }
          }
          bbDBStmt(2613252);
          f1.l_p=f2.l_q;
        }
      }
      bbDBStmt(2621443);
      f1.l_tail->m__0succ=this->m__0head;
      bbDBStmt(2625539);
      this->m__0head->m__0pred=f1.l_tail;
      bbDBStmt(2633731);
      if((l_merges<=1)){
        bbDBBlock db_blk;
        bbDBStmt(2633744);
        return;
      }
      bbDBStmt(2641923);
      l_insize*=2;
    }
  }
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Sort(bbInt l_ascending){
  bbDBFrame db_f{"Sort:Void(ascending:Int)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("ascending",&l_ascending);
  bbDBStmt(2375682);
  if(bbBool(l_ascending)){
    bbDBBlock db_blk;
    bbDBStmt(2379779);
    struct lambda16 : public bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)>::Rep{
      t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_self;
      lambda16(t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_Uniform* l_x,t_mojo_graphics_Uniform* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.Uniform,y:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2383876);
        return bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)>(new lambda16(this)));
  }else{
    bbDBStmt(2392066);
    bbDBBlock db_blk;
    bbDBStmt(2396163);
    struct lambda17 : public bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)>::Rep{
      t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_self;
      lambda17(t_std_collections_List_1Tt_mojo_graphics_Uniform_2* l_self):l_self(l_self){
      }
      bbInt invoke(t_mojo_graphics_Uniform* l_x,t_mojo_graphics_Uniform* l_y){
        bbDBFrame db_f{"?????:Int(x:mojo.graphics.Uniform,y:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
        bbDBLocal("x",&l_x);
        bbDBLocal("y",&l_y);
        bbDBStmt(2400260);
        return -bbCompare(l_x,l_y);
      }
      void gcMark(){
        bbGCMarkPtr(l_self);
      }
    };
    this->m_Sort(bbFunction<bbInt(t_mojo_graphics_Uniform*,t_mojo_graphics_Uniform*)>(new lambda17(this)));
  }
}

t_mojo_graphics_Uniform* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_RemoveLast(){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Uniform* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2183170);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2191368);
  f0.l_value=this->m__0head->m__0pred->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2195458);
  this->m__0head->m__0pred->m_Remove();
  bbDBStmt(2199554);
  this->m__0seq+=1;
  bbDBStmt(2203650);
  return f0.l_value;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_RemoveLast(t_mojo_graphics_Uniform* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveLast:Bool(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1966088);
  f0.l_node=this->m_FindLastNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1970178);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1970190);
    return false;
  }
  bbDBStmt(1974274);
  f0.l_node->m_Remove();
  bbDBStmt(1978370);
  this->m__0seq+=1;
  bbDBStmt(1982466);
  return true;
}

t_mojo_graphics_Uniform* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_RemoveFirst(){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Uniform* l_value{};
    void gcMark(){
      bbGCMarkPtr(l_value);
    }
  }f0{};
  bbDBFrame db_f{"RemoveFirst:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2117634);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(2125832);
  f0.l_value=this->m__0head->m__0succ->m__0value;
  bbDBLocal("value",&f0.l_value);
  bbDBStmt(2129922);
  this->m__0head->m__0succ->m_Remove();
  bbDBStmt(2134018);
  this->m__0seq+=1;
  bbDBStmt(2138114);
  return f0.l_value;
}

bbInt t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_RemoveEach(t_mojo_graphics_Uniform* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"RemoveEach:Int(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2027528);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2027546);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(2031618);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2035715);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2039812);
        f0.l_node=f0.l_node->m__0succ;
        bbDBStmt(2043908);
        f0.l_node->m__0pred->m_Remove();
        bbDBStmt(2048004);
        l_n+=1;
      }else{
        bbDBStmt(2052099);
        bbDBBlock db_blk;
        bbDBStmt(2056196);
        f0.l_node=f0.l_node->m__0succ;
      }
    }
  }
  bbDBStmt(2068482);
  if(bbBool(l_n)){
    bbDBBlock db_blk;
    bbDBStmt(2068487);
    this->m__0seq+=1;
  }
  bbDBStmt(2072578);
  return l_n;
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Remove(t_mojo_graphics_Uniform* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Remove:Bool(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1904648);
  f0.l_node=this->m_FindNode(l_value);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1908738);
  if(!bbBool(f0.l_node)){
    bbDBBlock db_blk;
    bbDBStmt(1908750);
    return false;
  }
  bbDBStmt(1912834);
  f0.l_node->m_Remove();
  bbDBStmt(1916930);
  this->m__0seq+=1;
  bbDBStmt(1921026);
  return true;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_LastNode(){
  bbDBFrame db_f{"LastNode:std.collections.List<mojo.graphics.Uniform>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2797570);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2797583);
    return this->m__0head->m__0pred;
  }
  bbDBStmt(2801666);
  return ((t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*)0);
}

t_mojo_graphics_Uniform* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Last(){
  bbDBFrame db_f{"Last:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1708034);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1716226);
  return this->m__0head->m__0pred->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_HeadNode(){
  bbDBFrame db_f{"HeadNode:std.collections.List<mojo.graphics.Uniform>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2719746);
  return this->m__0head;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_FirstNode(){
  bbDBFrame db_f{"FirstNode:std.collections.List<mojo.graphics.Uniform>.Node()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(2756610);
  if(!this->m_Empty()){
    bbDBBlock db_blk;
    bbDBStmt(2756623);
    return this->m__0head->m__0succ;
  }
  bbDBStmt(2760706);
  return ((t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*)0);
}

t_mojo_graphics_Uniform* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_First(){
  bbDBFrame db_f{"First:mojo.graphics.Uniform()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1654786);
  bbDebugAssert(!this->m_Empty(),BB_T("Debug assert failed"));
  bbDBStmt(1662978);
  return this->m__0head->m__0succ->m__0value;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_FindNode(t_mojo_graphics_Uniform* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindNode:std.collections.List<mojo.graphics.Uniform>.Node(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2846728);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2850818);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2854915);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2854936);
        return f0.l_node;
      }
      bbDBStmt(2859011);
      f0.l_node=f0.l_node->m__0succ;
    }
  }
  bbDBStmt(2867202);
  return ((t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*)0);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_FindLastNode(t_mojo_graphics_Uniform* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"FindLastNode:std.collections.List<mojo.graphics.Uniform>.Node(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2912264);
  f0.l_node=this->m__0head->m__0pred;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(2916354);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(2920451);
      if((f0.l_node->m__0value==l_value)){
        bbDBBlock db_blk;
        bbDBStmt(2920472);
        return f0.l_node;
      }
      bbDBStmt(2924547);
      f0.l_node=f0.l_node->m__0pred;
    }
  }
  bbDBStmt(2932738);
  return ((t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node*)0);
}

bbBool t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Empty(){
  bbDBFrame db_f{"Empty:Bool()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1478658);
  return (this->m__0head->m__0succ==this->m__0head);
}

bbInt t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Count(){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"Count:Int()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1527816);
  f0.l_node=this->m__0head->m__0succ;
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1527834);
  bbInt l_n=bbInt(0);
  bbDBLocal("n",&l_n);
  bbDBStmt(1531906);
  {
    bbDBLoop db_loop;
    while((f0.l_node!=this->m__0head)){
      bbDBBlock db_blk;
      bbDBStmt(1536003);
      f0.l_node=f0.l_node->m__0succ;
      bbDBStmt(1540099);
      l_n+=1;
    }
  }
  bbDBStmt(1548290);
  return l_n;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Clear(){
  bbDBFrame db_f{"Clear:Void()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1744898);
  this->m__0head->m__0succ=this->m__0head;
  bbDBStmt(1748994);
  this->m__0head->m__0pred=this->m__0head;
  bbDBStmt(1753090);
  this->m__0seq+=1;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Backwards(){
  bbDBFrame db_f{"Backwards:std.collections.List<mojo.graphics.Uniform>.BackwardsIterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1441794);
  return t_std_collections_List_1Tt_mojo_graphics_Uniform_2_BackwardsIterator(this,this->m__0head->m__0pred);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_All(){
  bbDBFrame db_f{"All:std.collections.List<mojo.graphics.Uniform>.Iterator()","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1396738);
  return t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Iterator(this,this->m__0head->m__0succ);
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_AddLast(t_mojo_graphics_Uniform* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddLast:std.collections.List<mojo.graphics.Uniform>.Node(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1851400);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node>(l_value,this->m__0head);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1855490);
  this->m__0seq+=1;
  bbDBStmt(1859586);
  return f0.l_node;
}

t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_AddFirst(t_mojo_graphics_Uniform* l_value){
  struct f0_t : public bbGCFrame{
    t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node* l_node{};
    void gcMark(){
      bbGCMarkPtr(l_node);
    }
  }f0{};
  bbDBFrame db_f{"AddFirst:std.collections.List<mojo.graphics.Uniform>.Node(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(1798152);
  f0.l_node=bbGCNew<t_std_collections_List_1Tt_mojo_graphics_Uniform_2_Node>(l_value,this->m__0head->m__0succ);
  bbDBLocal("node",&f0.l_node);
  bbDBStmt(1802242);
  this->m__0seq+=1;
  bbDBStmt(1806338);
  return f0.l_node;
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_AddAll(bbArray<bbGCVar<t_mojo_graphics_Uniform>>* l_values){
  bbDBFrame db_f{"AddAll:Void(values:mojo.graphics.Uniform[])","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("values",&l_values);
  bbDBStmt(2293762);
  {
    bbDBLoop db_loop;
    bbInt l_0=bbInt(0);
    bbDBLocal("0",&l_0);
    bbInt l_1=l_values->length();
    bbDBLocal("1",&l_1);
    for(;(l_0<l_1);l_0+=1){
      struct f2_t : public bbGCFrame{
        t_mojo_graphics_Uniform* l_value{};
        void gcMark(){
          bbGCMarkPtr(l_value);
        }
      }f2{};
      bbDBBlock db_blk;
      f2.l_value=l_values->at(l_0);
      bbDBLocal("value",&f2.l_value);
      bbDBStmt(2297859);
      this->m_AddLast(f2.l_value);
    }
  }
}

void t_std_collections_List_1Tt_mojo_graphics_Uniform_2::m_Add(t_mojo_graphics_Uniform* l_value){
  bbDBFrame db_f{"Add:Void(value:mojo.graphics.Uniform)","/home/pi/monkey2/modules/std/collections/list.monkey2"};
  t_std_collections_List_1Tt_mojo_graphics_Uniform_2*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("value",&l_value);
  bbDBStmt(2248706);
  this->m_AddLast(l_value);
}
bbString bbDBType(t_std_collections_List_1Tt_mojo_graphics_Uniform_2**){
  return "std.collections.List<mojo.graphics.Uniform>";
}
bbString bbDBValue(t_std_collections_List_1Tt_mojo_graphics_Uniform_2**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_std_collections_2list_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_std_collections_2list_init_v("mojo_std_collections_2list",&mx2_mojo_std_collections_2list_init);
