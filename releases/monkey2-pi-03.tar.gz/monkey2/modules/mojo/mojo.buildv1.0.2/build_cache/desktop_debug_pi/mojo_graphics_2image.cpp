
#include "../../desktop_debug_pi/mojo_graphics_2image.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_graphics_2material.h"
#include "../../desktop_debug_pi/mojo_graphics_2shader.h"
#include "../../desktop_debug_pi/mojo_graphics_2texture.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_math.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_graphics_2color.h"

enum class t_std_graphics_PixelFormat;

extern bbString g_std_filesystem_StripExt(bbString l_path);
extern bbString g_std_filesystem_ExtractExt(bbString l_path);
extern bbFloat g_monkey_math_Min_1f(bbFloat l_x,bbFloat l_y);
extern bbFloat g_monkey_math_Max_1f(bbFloat l_x,bbFloat l_y);

// ***** Internal *****

t_mojo_graphics_Image* g_mojo_graphics_Image_Load(bbString l_path,t_mojo_graphics_TextureFlags l_textureFlags,t_mojo_graphics_Shader* l_shader){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* l_diffuse{};
    t_mojo_graphics_Image* l_image{};
    t_mojo_graphics_Material* l_material{};
    t_mojo_graphics_Texture* l_normal{};
    t_mojo_graphics_Shader* l_shader{};
    t_mojo_graphics_Texture* l_specular{};
    f0_t(t_mojo_graphics_Shader* l_shader):l_shader(l_shader){
    }
    void gcMark(){
      bbGCMarkPtr(l_diffuse);
      bbGCMarkPtr(l_image);
      bbGCMarkPtr(l_material);
      bbGCMarkPtr(l_normal);
      bbGCMarkPtr(l_shader);
      bbGCMarkPtr(l_specular);
    }
  }f0{l_shader};
  bbDBFrame db_f{"Load:mojo.graphics.Image(path:String,textureFlags:mojo.graphics.TextureFlags,shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  bbDBLocal("path",&l_path);
  bbDBLocal("textureFlags",&l_textureFlags);
  bbDBLocal("shader",&f0.l_shader);
  bbDBStmt(1040392);
  f0.l_diffuse=g_mojo_graphics_Texture_Load(l_path,l_textureFlags);
  bbDBLocal("diffuse",&f0.l_diffuse);
  bbDBStmt(1044482);
  if(!bbBool(f0.l_diffuse)){
    bbDBBlock db_blk;
    bbDBStmt(1044497);
    return ((t_mojo_graphics_Image*)0);
  }
  bbDBStmt(1052680);
  bbString l_file=g_std_filesystem_StripExt(l_path);
  bbDBLocal("file",&l_file);
  bbDBStmt(1056776);
  bbString l_ext=g_std_filesystem_ExtractExt(l_path);
  bbDBLocal("ext",&l_ext);
  bbDBStmt(1064968);
  f0.l_specular=g_mojo_graphics_Texture_Load(((l_file+BB_T("_SPECULAR"))+l_ext),l_textureFlags);
  bbDBLocal("specular",&f0.l_specular);
  bbDBStmt(1069064);
  f0.l_normal=g_mojo_graphics_Texture_Load(((l_file+BB_T("_NORMALS"))+l_ext),l_textureFlags);
  bbDBLocal("normal",&f0.l_normal);
  bbDBStmt(1077250);
  if((bbBool(f0.l_specular)||bbBool(f0.l_normal))){
    bbDBBlock db_blk;
    bbDBStmt(1081347);
    if(!bbBool(f0.l_specular)){
      bbDBBlock db_blk;
      bbDBStmt(1081363);
      f0.l_specular=g_mojo_graphics_Texture_ColorTexture(g_std_graphics_Color_Black);
    }
    bbDBStmt(1085443);
    if(!bbBool(f0.l_normal)){
      bbDBBlock db_blk;
      bbDBStmt(1085457);
      f0.l_normal=g_mojo_graphics_Texture_ColorTexture(t_std_graphics_Color(.5f,.5f,.5f,1.0f));
    }
  }
  bbDBStmt(1097730);
  if(!bbBool(f0.l_shader)){
    bbDBBlock db_blk;
    bbDBStmt(1101827);
    if((bbBool(f0.l_specular)||bbBool(f0.l_normal))){
      bbDBBlock db_blk;
      bbDBStmt(1105924);
      f0.l_shader=g_mojo_graphics_Shader_GetShader(BB_T("phong"));
    }else{
      bbDBStmt(1110019);
      bbDBBlock db_blk;
      bbDBStmt(1114116);
      f0.l_shader=g_mojo_graphics_Shader_GetShader(BB_T("sprite"));
    }
  }
  bbDBStmt(1130504);
  f0.l_material=bbGCNew<t_mojo_graphics_Material>(f0.l_shader);
  bbDBLocal("material",&f0.l_material);
  bbDBStmt(1138690);
  if(bbBool(f0.l_diffuse)){
    bbDBBlock db_blk;
    bbDBStmt(1138701);
    f0.l_material->m_SetTexture(BB_T("DiffuseTexture"),f0.l_diffuse);
  }
  bbDBStmt(1142786);
  if(bbBool(f0.l_specular)){
    bbDBBlock db_blk;
    bbDBStmt(1142798);
    f0.l_material->m_SetTexture(BB_T("SpecularTexture"),f0.l_specular);
  }
  bbDBStmt(1146882);
  if(bbBool(f0.l_normal)){
    bbDBBlock db_blk;
    bbDBStmt(1146892);
    f0.l_material->m_SetTexture(BB_T("NormalTexture"),f0.l_normal);
  }
  bbDBStmt(1155080);
  f0.l_image=bbGCNew<t_mojo_graphics_Image>(f0.l_material,f0.l_diffuse,f0.l_diffuse->m_Rect());
  bbDBLocal("image",&f0.l_image);
  bbDBStmt(1163266);
  struct lambda0 : public bbFunction<void()>::Rep{
    t_mojo_graphics_Texture* l_diffuse;
    t_mojo_graphics_Texture* l_specular;
    t_mojo_graphics_Texture* l_normal;
    lambda0(t_mojo_graphics_Texture* l_diffuse,t_mojo_graphics_Texture* l_specular,t_mojo_graphics_Texture* l_normal):l_diffuse(l_diffuse),l_specular(l_specular),l_normal(l_normal){
    }
    void invoke(){
      bbDBFrame db_f{"?????:Void()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
      bbDBStmt(1167363);
      if(bbBool(l_diffuse)){
        bbDBBlock db_blk;
        bbDBStmt(1167374);
        l_diffuse->m_Discard();
      }
      bbDBStmt(1171459);
      if(bbBool(l_specular)){
        bbDBBlock db_blk;
        bbDBStmt(1171471);
        l_specular->m_Discard();
      }
      bbDBStmt(1175555);
      if(bbBool(l_normal)){
        bbDBBlock db_blk;
        bbDBStmt(1175565);
        l_normal->m_Discard();
      }
    }
    void gcMark(){
      bbGCMarkPtr(l_diffuse);
      bbGCMarkPtr(l_specular);
      bbGCMarkPtr(l_normal);
    }
  };
  f0.l_image->m_OnDiscarded+=bbFunction<void()>(new lambda0(f0.l_diffuse,f0.l_specular,f0.l_normal));
  bbDBStmt(1187842);
  return f0.l_image;
}

void t_mojo_graphics_Image::init(){
  m__0handle=t_std_geom_Vec2_1f(0.0f,0.0f);
  m__0scale=t_std_geom_Vec2_1f(1.0f,1.0f);
}

void t_mojo_graphics_Image::gcMark(){
  bbGCMark(m_OnDiscarded);
  bbGCMark(m__0material);
  bbGCMark(m__0texture);
}

void t_mojo_graphics_Image::dbEmit(){
  bbDBEmit("OnDiscarded",&m_OnDiscarded);
  bbDBEmit("_material",&m__0material);
  bbDBEmit("_texture",&m__0texture);
  bbDBEmit("_rect",&m__0rect);
  bbDBEmit("_discarded",&m__0discarded);
  bbDBEmit("_handle",&m__0handle);
  bbDBEmit("_scale",&m__0scale);
  bbDBEmit("_vertices",&m__0vertices);
  bbDBEmit("_texCoords",&m__0texCoords);
  bbDBEmit("_bounds",&m__0bounds);
  bbDBEmit("_radius",&m__0radius);
}

t_mojo_graphics_Image::t_mojo_graphics_Image(t_mojo_graphics_Material* l_material,t_mojo_graphics_Texture* l_texture,t_std_geom_Rect_1i l_rect){
  init();
  bbDBFrame db_f{"new:Void(material:mojo.graphics.Material,texture:mojo.graphics.Texture,rect:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  bbDBLocal("material",&l_material);
  bbDBLocal("texture",&l_texture);
  bbDBLocal("rect",&l_rect);
  bbDBStmt(540674);
  this->m_Init(l_material,l_texture,l_rect,((t_mojo_graphics_Shader*)0));
}

t_mojo_graphics_Image::t_mojo_graphics_Image(t_mojo_graphics_Texture* l_texture,t_mojo_graphics_Shader* l_shader){
  init();
  bbDBFrame db_f{"new:Void(texture:mojo.graphics.Texture,shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  bbDBLocal("texture",&l_texture);
  bbDBLocal("shader",&l_shader);
  bbDBStmt(512002);
  this->m_Init(((t_mojo_graphics_Material*)0),l_texture,l_texture->m_Rect(),l_shader);
}

t_mojo_graphics_Image::t_mojo_graphics_Image(t_mojo_graphics_Image* l_image,t_std_geom_Rect_1i l_rect){
  init();
  bbDBFrame db_f{"new:Void(image:mojo.graphics.Image,rect:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  bbDBLocal("image",&l_image);
  bbDBLocal("rect",&l_rect);
  bbDBStmt(483330);
  this->m_Init(l_image->m__0material,l_image->m__0texture,l_rect,((t_mojo_graphics_Shader*)0));
}

t_mojo_graphics_Image::t_mojo_graphics_Image(bbInt l_width,bbInt l_height,t_mojo_graphics_TextureFlags l_textureFlags,t_mojo_graphics_Shader* l_shader){
  init();
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* l_texture{};
    void gcMark(){
      bbGCMarkPtr(l_texture);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(width:Int,height:Int,textureFlags:mojo.graphics.TextureFlags,shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBLocal("textureFlags",&l_textureFlags);
  bbDBLocal("shader",&l_shader);
  bbDBStmt(425992);
  t_std_graphics_PixelFormat l_textureFormat=t_std_graphics_PixelFormat(5);
  bbDBLocal("textureFormat",&l_textureFormat);
  bbDBStmt(434184);
  f0.l_texture=bbGCNew<t_mojo_graphics_Texture>(l_width,l_height,l_textureFormat,l_textureFlags);
  bbDBLocal("texture",&f0.l_texture);
  bbDBStmt(442370);
  this->m_Init(((t_mojo_graphics_Material*)0),f0.l_texture,f0.l_texture->m_Rect(),l_shader);
  bbDBStmt(450562);
  struct lambda1 : public bbFunction<void()>::Rep{
    t_mojo_graphics_Image* l_self;
    t_mojo_graphics_Texture* l_texture;
    lambda1(t_mojo_graphics_Image* l_self,t_mojo_graphics_Texture* l_texture):l_self(l_self),l_texture(l_texture){
    }
    void invoke(){
      bbDBFrame db_f{"?????:Void()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
      bbDBStmt(454659);
      l_texture->m_Discard();
    }
    void gcMark(){
      bbGCMarkPtr(l_self);
      bbGCMarkPtr(l_texture);
    }
  };
  this->m_OnDiscarded+=bbFunction<void()>(new lambda1(this,f0.l_texture));
}

t_mojo_graphics_Image::t_mojo_graphics_Image(t_std_graphics_Pixmap* l_pixmap,t_mojo_graphics_TextureFlags l_textureFlags,t_mojo_graphics_Shader* l_shader){
  init();
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Texture* l_texture{};
    void gcMark(){
      bbGCMarkPtr(l_texture);
    }
  }f0{};
  bbDBFrame db_f{"new:Void(pixmap:std.graphics.Pixmap,textureFlags:mojo.graphics.TextureFlags,shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  bbDBLocal("pixmap",&l_pixmap);
  bbDBLocal("textureFlags",&l_textureFlags);
  bbDBLocal("shader",&l_shader);
  bbDBStmt(380936);
  f0.l_texture=bbGCNew<t_mojo_graphics_Texture>(l_pixmap,l_textureFlags);
  bbDBLocal("texture",&f0.l_texture);
  bbDBStmt(389122);
  this->m_Init(((t_mojo_graphics_Material*)0),f0.l_texture,f0.l_texture->m_Rect(),l_shader);
  bbDBStmt(397314);
  struct lambda2 : public bbFunction<void()>::Rep{
    t_mojo_graphics_Image* l_self;
    t_mojo_graphics_Texture* l_texture;
    lambda2(t_mojo_graphics_Image* l_self,t_mojo_graphics_Texture* l_texture):l_self(l_self),l_texture(l_texture){
    }
    void invoke(){
      bbDBFrame db_f{"?????:Void()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
      bbDBStmt(401411);
      l_texture->m_Discard();
    }
    void gcMark(){
      bbGCMarkPtr(l_self);
      bbGCMarkPtr(l_texture);
    }
  };
  this->m_OnDiscarded+=bbFunction<void()>(new lambda2(this,f0.l_texture));
}

bbInt t_mojo_graphics_Image::m_Width(){
  bbDBFrame db_f{"Width:Int()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(655362);
  return this->m__0rect.m_Width();
}

t_std_geom_Rect_1f t_mojo_graphics_Image::m_Vertices(){
  bbDBFrame db_f{"Vertices:Rectf:std.geom.Rect<Float>()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(950274);
  return this->m__0vertices;
}

void t_mojo_graphics_Image::m_UpdateVertices(){
  bbDBFrame db_f{"UpdateVertices:Void()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1323010);
  this->m__0vertices.m_min.m_x=((bbFloat(this->m__0rect.m_Width())*(0.0f-this->m__0handle.m_x))*this->m__0scale.m_x);
  bbDBStmt(1327106);
  this->m__0vertices.m_min.m_y=((bbFloat(this->m__0rect.m_Height())*(0.0f-this->m__0handle.m_y))*this->m__0scale.m_y);
  bbDBStmt(1331202);
  this->m__0vertices.m_max.m_x=((bbFloat(this->m__0rect.m_Width())*(1.0f-this->m__0handle.m_x))*this->m__0scale.m_x);
  bbDBStmt(1335298);
  this->m__0vertices.m_max.m_y=((bbFloat(this->m__0rect.m_Height())*(1.0f-this->m__0handle.m_y))*this->m__0scale.m_y);
  bbDBStmt(1339394);
  this->m__0bounds.m_min.m_x=g_monkey_math_Min_1f(this->m__0vertices.m_min.m_x,this->m__0vertices.m_max.m_x);
  bbDBStmt(1343490);
  this->m__0bounds.m_max.m_x=g_monkey_math_Max_1f(this->m__0vertices.m_min.m_x,this->m__0vertices.m_max.m_x);
  bbDBStmt(1347586);
  this->m__0bounds.m_min.m_y=g_monkey_math_Min_1f(this->m__0vertices.m_min.m_y,this->m__0vertices.m_max.m_y);
  bbDBStmt(1351682);
  this->m__0bounds.m_max.m_y=g_monkey_math_Max_1f(this->m__0vertices.m_min.m_y,this->m__0vertices.m_max.m_y);
  bbDBStmt(1355778);
  this->m__0radius=((this->m__0bounds.m_min.m_x*this->m__0bounds.m_min.m_x)+(this->m__0bounds.m_min.m_y*this->m__0bounds.m_min.m_y));
  bbDBStmt(1359874);
  this->m__0radius=g_monkey_math_Max_1f(this->m__0radius,((this->m__0bounds.m_max.m_x*this->m__0bounds.m_max.m_x)+(this->m__0bounds.m_min.m_y*this->m__0bounds.m_min.m_y)));
  bbDBStmt(1363970);
  this->m__0radius=g_monkey_math_Max_1f(this->m__0radius,((this->m__0bounds.m_max.m_x*this->m__0bounds.m_max.m_x)+(this->m__0bounds.m_max.m_y*this->m__0bounds.m_max.m_y)));
  bbDBStmt(1368066);
  this->m__0radius=g_monkey_math_Max_1f(this->m__0radius,((this->m__0bounds.m_min.m_x*this->m__0bounds.m_min.m_x)+(this->m__0bounds.m_max.m_y*this->m__0bounds.m_max.m_y)));
  bbDBStmt(1372162);
  this->m__0radius=bbFloat(std::sqrt(bbDouble(this->m__0radius)));
}

void t_mojo_graphics_Image::m_UpdateTexCoords(){
  bbDBFrame db_f{"UpdateTexCoords:Void()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1388546);
  this->m__0texCoords.m_min.m_x=(bbFloat(this->m__0rect.m_min.m_x)/bbFloat(this->m__0texture->m_Width()));
  bbDBStmt(1392642);
  this->m__0texCoords.m_min.m_y=(bbFloat(this->m__0rect.m_min.m_y)/bbFloat(this->m__0texture->m_Height()));
  bbDBStmt(1396738);
  this->m__0texCoords.m_max.m_x=(bbFloat(this->m__0rect.m_max.m_x)/bbFloat(this->m__0texture->m_Width()));
  bbDBStmt(1400834);
  this->m__0texCoords.m_max.m_y=(bbFloat(this->m__0rect.m_max.m_y)/bbFloat(this->m__0texture->m_Height()));
}

t_mojo_graphics_Texture* t_mojo_graphics_Image::m_Texture(){
  bbDBFrame db_f{"Texture:mojo.graphics.Texture()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(598018);
  return this->m__0texture;
}

t_std_geom_Rect_1f t_mojo_graphics_Image::m_TexCoords(){
  bbDBFrame db_f{"TexCoords:Rectf:std.geom.Rect<Float>()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(978946);
  return this->m__0texCoords;
}

void t_mojo_graphics_Image::m_Scale(t_std_geom_Vec2_1f l_scale){
  bbDBFrame db_f{"Scale:Void(scale:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("scale",&l_scale);
  bbDBStmt(815106);
  this->m__0scale=l_scale;
  bbDBStmt(823298);
  this->m_UpdateVertices();
}

t_std_geom_Vec2_1f t_mojo_graphics_Image::m_Scale(){
  bbDBFrame db_f{"Scale:Vec2f:std.geom.Vec2<Float>()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(798722);
  return this->m__0scale;
}

t_std_geom_Rect_1i t_mojo_graphics_Image::m_Rect(){
  bbDBFrame db_f{"Rect:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(626690);
  return this->m__0rect;
}

bbFloat t_mojo_graphics_Image::m_Radius(){
  bbDBFrame db_f{"Radius:Float()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(921602);
  return this->m__0radius;
}

t_mojo_graphics_Material* t_mojo_graphics_Image::m_Material(){
  bbDBFrame db_f{"Material:mojo.graphics.Material()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(569346);
  return this->m__0material;
}

void t_mojo_graphics_Image::m_Init(t_mojo_graphics_Material* l_material,t_mojo_graphics_Texture* l_texture,t_std_geom_Rect_1i l_rect,t_mojo_graphics_Shader* l_shader){
  struct f0_t : public bbGCFrame{
    t_mojo_graphics_Material* l_material{};
    t_mojo_graphics_Shader* l_shader{};
    f0_t(t_mojo_graphics_Material* l_material,t_mojo_graphics_Shader* l_shader):l_material(l_material),l_shader(l_shader){
    }
    void gcMark(){
      bbGCMarkPtr(l_material);
      bbGCMarkPtr(l_shader);
    }
  }f0{l_material,l_shader};
  bbDBFrame db_f{"Init:Void(material:mojo.graphics.Material,texture:mojo.graphics.Texture,rect:Recti:std.geom.Rect<Int>,shader:mojo.graphics.Shader)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("material",&f0.l_material);
  bbDBLocal("texture",&l_texture);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("shader",&f0.l_shader);
  bbDBStmt(1261570);
  if(!bbBool(f0.l_material)){
    bbDBBlock db_blk;
    bbDBStmt(1265667);
    if(!bbBool(f0.l_shader)){
      bbDBBlock db_blk;
      bbDBStmt(1265681);
      f0.l_shader=g_mojo_graphics_Shader_GetShader(BB_T("sprite"));
    }
    bbDBStmt(1269763);
    f0.l_material=bbGCNew<t_mojo_graphics_Material>(f0.l_shader);
    bbDBStmt(1273859);
    f0.l_material->m_SetTexture(BB_T("DiffuseTexture"),l_texture);
  }
  bbDBStmt(1286146);
  this->m__0material=f0.l_material;
  bbDBStmt(1290242);
  this->m__0texture=l_texture;
  bbDBStmt(1294338);
  this->m__0rect=l_rect;
  bbDBStmt(1302530);
  this->m_UpdateVertices();
  bbDBStmt(1306626);
  this->m_UpdateTexCoords();
}

bbInt t_mojo_graphics_Image::m_Height(){
  bbDBFrame db_f{"Height:Int()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(684034);
  return this->m__0rect.m_Height();
}

void t_mojo_graphics_Image::m_Handle(t_std_geom_Vec2_1f l_handle){
  bbDBFrame db_f{"Handle:Void(handle:Vec2f:std.geom.Vec2<Float>)","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("handle",&l_handle);
  bbDBStmt(741378);
  this->m__0handle=l_handle;
  bbDBStmt(749570);
  this->m_UpdateVertices();
}

t_std_geom_Vec2_1f t_mojo_graphics_Image::m_Handle(){
  bbDBFrame db_f{"Handle:Vec2f:std.geom.Vec2<Float>()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(724994);
  return this->m__0handle;
}

void t_mojo_graphics_Image::m_Discard(){
  bbDBFrame db_f{"Discard:Void()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1003522);
  if(this->m__0discarded){
    bbDBBlock db_blk;
    bbDBStmt(1003536);
    return;
  }
  bbDBStmt(1007618);
  this->m__0discarded=true;
  bbDBStmt(1011714);
  this->m_OnDiscarded();
}

t_std_geom_Rect_1f t_mojo_graphics_Image::m_Bounds(){
  bbDBFrame db_f{"Bounds:Rectf:std.geom.Rect<Float>()","/home/pi/monkey2/modules/mojo/graphics/image.monkey2"};
  t_mojo_graphics_Image*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(872450);
  return this->m__0bounds;
}
bbString bbDBType(t_mojo_graphics_Image**){
  return "mojo.graphics.Image";
}
bbString bbDBValue(t_mojo_graphics_Image**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_graphics_2image_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_graphics_2image_init_v("mojo_graphics_2image",&mx2_mojo_graphics_2image_init);
