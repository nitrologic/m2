
#include "../../desktop_debug_pi/mojo_input_2keyboard.h"

// ***** External *****

#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"

// ***** Internal *****

bbGCRootVar<t_mojo_input_KeyboardDevice> g_mojo_input_Keyboard;

bbInt g_mojo_input_KeyboardDevice__0EventFilter(void* l_userData,SDL_Event* l_event){
  bbDBFrame db_f{"_EventFilter:Int(userData:Void Ptr,event:sdl2.SDL_Event Ptr)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  bbDBLocal("userData",&l_userData);
  bbDBLocal("event",&l_event);
  bbDBStmt(958466);
  if(!bbBool(l_event)){
    bbDBBlock db_blk;
    bbDBStmt(958479);
    return bbInt(0);
  }
  bbDBStmt(962562);
  return g_mojo_input_Keyboard->m_EventFilter(l_userData,l_event);
}

void t_mojo_input_KeyboardDevice::init(){
  m__0matrix=bbArray<bbBool>::create(512);
  m__0pressed=bbArray<bbBool>::create(512);
  m__0released=bbArray<bbBool>::create(512);
  m__0names=bbArray<bbString>::create(512);
  m__0raw2scan=bbArray<bbInt>::create(512);
  m__0scan2raw=bbArray<t_mojo_input_Key>::create(512);
  m__0key2scan=bbArray<bbInt>::create(512);
  m__0scan2key=bbArray<bbInt>::create(512);
}

void t_mojo_input_KeyboardDevice::gcMark(){
  t_mojo_input_InputDevice::gcMark();
  bbGCMark(m__0matrix);
  bbGCMark(m__0pressed);
  bbGCMark(m__0released);
  bbGCMark(m__0names);
  bbGCMark(m__0raw2scan);
  bbGCMark(m__0scan2raw);
  bbGCMark(m__0key2scan);
  bbGCMark(m__0scan2key);
}

void t_mojo_input_KeyboardDevice::dbEmit(){
  t_mojo_input_InputDevice::dbEmit();
  bbDBEmit("_init",&m__0init);
  bbDBEmit("_modifiers",&m__0modifiers);
  bbDBEmit("_matrix",&m__0matrix);
  bbDBEmit("_pressed",&m__0pressed);
  bbDBEmit("_released",&m__0released);
  bbDBEmit("_names",&m__0names);
  bbDBEmit("_raw2scan",&m__0raw2scan);
  bbDBEmit("_scan2raw",&m__0scan2raw);
  bbDBEmit("_key2scan",&m__0key2scan);
  bbDBEmit("_scan2key",&m__0scan2key);
}

t_mojo_input_KeyboardDevice::t_mojo_input_KeyboardDevice(){
  init();
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
}

t_mojo_input_Key t_mojo_input_KeyboardDevice::m_TranslateKey(t_mojo_input_Key l_key){
  bbDBFrame db_f{"TranslateKey:mojo.input.Key(key:mojo.input.Key)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(270338);
  if(bbBool(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(65536)))))){
    bbDBBlock db_blk;
    bbDBStmt(286729);
    bbInt l_keyCode=SDL_GetKeyFromScancode(((SDL_Scancode)(this->m__0raw2scan->at(bbInt(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(~int(t_mojo_input_Key(65536)))))))))));
    bbDBLocal("keyCode",&l_keyCode);
    bbDBStmt(290819);
    return this->m_KeyCodeToKey(l_keyCode);
  }else{
    bbDBStmt(299010);
    bbDBBlock db_blk;
    bbDBStmt(303113);
    bbInt l_scanCode=this->m__0key2scan->at(bbInt(l_key));
    bbDBLocal("scanCode",&l_scanCode);
    bbDBStmt(307203);
    return this->m__0scan2raw->at(l_scanCode);
  }
}

t_mojo_input_Key t_mojo_input_KeyboardDevice::m_ScanCodeToRawKey(bbInt l_scanCode){
  bbDBFrame db_f{"ScanCodeToRawKey:mojo.input.Key(scanCode:Int)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("scanCode",&l_scanCode);
  bbDBStmt(733186);
  return this->m__0scan2raw->at(l_scanCode);
}

bbInt t_mojo_input_KeyboardDevice::m_ScanCode(t_mojo_input_Key l_key){
  bbDBFrame db_f{"ScanCode:Int(key:mojo.input.Key)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(675842);
  if(bbBool(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(65536)))))){
    bbDBBlock db_blk;
    bbDBStmt(675859);
    return this->m__0raw2scan->at(bbInt(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(~int(t_mojo_input_Key(65536))))))));
  }
  bbDBStmt(679938);
  return this->m__0key2scan->at(bbInt(l_key));
}

void t_mojo_input_KeyboardDevice::m_Reset(){
  bbDBFrame db_f{"Reset:Void()","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(630786);
  {
    bbDBLoop db_loop;
    bbInt l_i=bbInt(0);
    bbDBLocal("i",&l_i);
    bbDBStmt(630786);
    for(;(l_i<512);l_i+=1){
      bbDBBlock db_blk;
      bbDBStmt(634883);
      this->m__0matrix->at(l_i)=false;
      bbDBStmt(638979);
      this->m__0pressed->at(l_i)=true;
      bbDBStmt(643075);
      this->m__0released->at(l_i)=true;
    }
  }
  bbDBStmt(651266);
  this->m__0modifiers=t_mojo_input_Modifier(0);
}

t_mojo_input_Modifier t_mojo_input_KeyboardDevice::m_Modifiers(){
  bbDBFrame db_f{"Modifiers:mojo.input.Modifier()","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(176130);
  return this->m__0modifiers;
}

bbBool t_mojo_input_KeyboardDevice::m_KeyReleased(t_mojo_input_Key l_key){
  bbDBFrame db_f{"KeyReleased:Bool(key:mojo.input.Key)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(532488);
  bbInt l_scode=this->m_ScanCode(l_key);
  bbDBLocal("scode",&l_scode);
  bbDBStmt(540674);
  if(!this->m__0matrix->at(l_scode)){
    bbDBBlock db_blk;
    bbDBStmt(544771);
    if(this->m__0released->at(l_scode)){
      bbDBBlock db_blk;
      bbDBStmt(544791);
      return false;
    }
    bbDBStmt(548867);
    this->m__0released->at(l_scode)=true;
    bbDBStmt(552963);
    return true;
  }
  bbDBStmt(565250);
  this->m__0released->at(l_scode)=false;
  bbDBStmt(569346);
  return false;
}

bbBool t_mojo_input_KeyboardDevice::m_KeyPressed(t_mojo_input_Key l_key){
  bbDBFrame db_f{"KeyPressed:Bool(key:mojo.input.Key)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(438280);
  bbInt l_scode=this->m_ScanCode(l_key);
  bbDBLocal("scode",&l_scode);
  bbDBStmt(446466);
  if(this->m__0matrix->at(l_scode)){
    bbDBBlock db_blk;
    bbDBStmt(450563);
    if(this->m__0pressed->at(l_scode)){
      bbDBBlock db_blk;
      bbDBStmt(450582);
      return false;
    }
    bbDBStmt(454659);
    this->m__0pressed->at(l_scode)=true;
    bbDBStmt(458755);
    return true;
  }
  bbDBStmt(471042);
  this->m__0pressed->at(l_scode)=false;
  bbDBStmt(475138);
  return false;
}

bbString t_mojo_input_KeyboardDevice::m_KeyName(t_mojo_input_Key l_key){
  bbDBFrame db_f{"KeyName:String(key:mojo.input.Key)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(221186);
  if(bbBool(t_mojo_input_Key((int(l_key)&int(t_mojo_input_Key(65536)))))){
    bbDBBlock db_blk;
    bbDBStmt(221203);
    l_key=this->m_TranslateKey(l_key);
  }
  bbDBStmt(225282);
  return this->m__0names->at(bbInt(l_key));
}

bbBool t_mojo_input_KeyboardDevice::m_KeyHit(t_mojo_input_Key l_key){
  bbDBFrame db_f{"KeyHit:Bool(key:mojo.input.Key)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(598018);
  return this->m_KeyPressed(l_key);
}

bbBool t_mojo_input_KeyboardDevice::m_KeyDown(t_mojo_input_Key l_key){
  bbDBFrame db_f{"KeyDown:Bool(key:mojo.input.Key)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("key",&l_key);
  bbDBStmt(372744);
  bbInt l_scode=this->m_ScanCode(l_key);
  bbDBLocal("scode",&l_scode);
  bbDBStmt(380930);
  return this->m__0matrix->at(l_scode);
}

t_mojo_input_Key t_mojo_input_KeyboardDevice::m_KeyCodeToKey(bbInt l_keyCode){
  bbDBFrame db_f{"KeyCodeToKey:mojo.input.Key(keyCode:Int)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("keyCode",&l_keyCode);
  bbDBStmt(704514);
  if(bbBool((l_keyCode&1073741824))){
    bbDBBlock db_blk;
    bbDBStmt(704539);
    l_keyCode=((l_keyCode&~1073741824)+128);
  }
  bbDBStmt(708610);
  return ((t_mojo_input_Key)(l_keyCode));
}

void t_mojo_input_KeyboardDevice::m_Init(){
  bbDBFrame db_f{"Init:Void()","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(757762);
  if(this->m__0init){
    bbDBBlock db_blk;
    bbDBStmt(757771);
    return;
  }
  bbDBStmt(761858);
  this->m__0init=true;
  bbDBStmt(770056);
  bbKeyInfo* l_p=bbKeyInfos;
  bbDBLocal("p",&l_p);
  bbDBStmt(778242);
  {
    bbDBLoop db_loop;
    while(bbBool(l_p[bbInt(0)].name)){
      bbDBBlock db_blk;
      bbDBStmt(786441);
      bbString l_name=bbString::fromCString(l_p[bbInt(0)].name);
      bbDBLocal("name",&l_name);
      bbDBStmt(790537);
      bbInt l_scanCode=l_p[bbInt(0)].scanCode;
      bbDBLocal("scanCode",&l_scanCode);
      bbDBStmt(794633);
      bbInt l_keyCode=l_p[bbInt(0)].keyCode;
      bbDBLocal("keyCode",&l_keyCode);
      bbDBStmt(802825);
      t_mojo_input_Key l_key=this->m_KeyCodeToKey(l_keyCode);
      bbDBLocal("key",&l_key);
      bbDBStmt(811011);
      this->m__0names->at(bbInt(l_key))=l_name;
      bbDBStmt(815107);
      this->m__0raw2scan->at(bbInt(l_key))=l_scanCode;
      bbDBStmt(819203);
      this->m__0scan2raw->at(l_scanCode)=t_mojo_input_Key((int(l_key)|int(t_mojo_input_Key(65536))));
      bbDBStmt(835587);
      this->m__0key2scan->at(bbInt(l_key))=bbInt(SDL_GetScancodeFromKey(l_keyCode));
      bbDBStmt(843779);
      this->m__0scan2key->at(this->m__0key2scan->at(bbInt(l_key)))=l_scanCode;
      bbDBStmt(851971);
      l_p=(l_p+1);
    }
  }
  bbDBStmt(864258);
  SDL_AddEventWatch(g_mojo_input_KeyboardDevice__0EventFilter,((void*)0));
  bbDBStmt(872450);
  this->m_Reset();
}

bbInt t_mojo_input_KeyboardDevice::m_EventFilter(void* l_userData,SDL_Event* l_event){
  bbDBFrame db_f{"EventFilter:Int(userData:Void Ptr,event:sdl2.SDL_Event Ptr)","/home/pi/monkey2/modules/mojo/input/keyboard.monkey2"};
  t_mojo_input_KeyboardDevice*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("userData",&l_userData);
  bbDBLocal("event",&l_event);
  bbDBStmt(983042);
  if(l_event[bbInt(0)].type==bbInt(SDL_KEYDOWN)){
    bbDBBlock db_blk;
    bbDBStmt(999433);
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    bbDBLocal("kevent",&l_kevent);
    bbDBStmt(1007619);
    this->m__0matrix->at(bbInt(l_kevent[bbInt(0)].keysym.scancode))=true;
    bbDBStmt(1015811);
    if(l_kevent[bbInt(0)].keysym.sym==1073742048){
      bbDBBlock db_blk;
      bbDBStmt(1019922);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(64))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742049){
      bbDBBlock db_blk;
      bbDBStmt(1024018);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(1))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742050){
      bbDBBlock db_blk;
      bbDBStmt(1028114);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(256))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742051){
      bbDBBlock db_blk;
      bbDBStmt(1032210);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(1024))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742052){
      bbDBBlock db_blk;
      bbDBStmt(1036306);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(128))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742053){
      bbDBBlock db_blk;
      bbDBStmt(1040402);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(2))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742054){
      bbDBBlock db_blk;
      bbDBStmt(1044498);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(512))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742055){
      bbDBBlock db_blk;
      bbDBStmt(1048594);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)|int(t_mojo_input_Modifier(2048))));
    }
  }else if(l_event[bbInt(0)].type==bbInt(SDL_KEYUP)){
    bbDBBlock db_blk;
    bbDBStmt(1069065);
    SDL_KeyboardEvent* l_kevent=((SDL_KeyboardEvent*)(l_event));
    bbDBLocal("kevent",&l_kevent);
    bbDBStmt(1077251);
    this->m__0matrix->at(bbInt(l_kevent[bbInt(0)].keysym.scancode))=false;
    bbDBStmt(1085443);
    if(l_kevent[bbInt(0)].keysym.sym==1073742048){
      bbDBBlock db_blk;
      bbDBStmt(1089554);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(64))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742049){
      bbDBBlock db_blk;
      bbDBStmt(1093650);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(1))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742050){
      bbDBBlock db_blk;
      bbDBStmt(1097746);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(256))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742051){
      bbDBBlock db_blk;
      bbDBStmt(1101842);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(1024))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742052){
      bbDBBlock db_blk;
      bbDBStmt(1105938);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(128))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742053){
      bbDBBlock db_blk;
      bbDBStmt(1110034);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(2))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742054){
      bbDBBlock db_blk;
      bbDBStmt(1114130);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(512))))));
    }else if(l_kevent[bbInt(0)].keysym.sym==1073742055){
      bbDBBlock db_blk;
      bbDBStmt(1118226);
      this->m__0modifiers=t_mojo_input_Modifier((int(this->m__0modifiers)&int(t_mojo_input_Modifier(~int(t_mojo_input_Modifier(2048))))));
    }
  }
  bbDBStmt(1138690);
  return 1;
}
bbString bbDBType(t_mojo_input_KeyboardDevice**){
  return "mojo.input.KeyboardDevice";
}
bbString bbDBValue(t_mojo_input_KeyboardDevice**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_input_2keyboard_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_input_Keyboard=bbGCNew<t_mojo_input_KeyboardDevice>();
}

bbInit mx2_mojo_input_2keyboard_init_v("mojo_input_2keyboard",&mx2_mojo_input_2keyboard_init);
