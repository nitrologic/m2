
#include "../../desktop_debug_pi/mojo_app_2event.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2view.h"
#include "../../desktop_debug_pi/mojo_app_2window.h"

// ***** Internal *****

void t_mojo_app_Event::gcMark(){
  bbGCMark(m__0view);
}

void t_mojo_app_Event::dbEmit(){
  bbDBEmit("_type",&m__0type);
  bbDBEmit("_view",&m__0view);
}

t_mojo_app_Event::t_mojo_app_Event(t_mojo_app_EventType l_type,t_mojo_app_View* l_view){
  bbDBFrame db_f{"new:Void(type:mojo.app.EventType,view:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  bbDBLocal("type",&l_type);
  bbDBLocal("view",&l_view);
  bbDBStmt(368642);
  this->m__0type=l_type;
  bbDBStmt(372738);
  this->m__0view=l_view;
}

t_mojo_app_View* t_mojo_app_Event::m_View(){
  bbDBFrame db_f{"View:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_Event*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(249858);
  return this->m__0view;
}

t_mojo_app_EventType t_mojo_app_Event::m_Type(){
  bbDBFrame db_f{"Type:mojo.app.EventType()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_Event*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(225282);
  return this->m__0type;
}

bbBool t_mojo_app_Event::m_Eaten(){
  bbDBFrame db_f{"Eaten:Bool()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_Event*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(278530);
  return (t_mojo_app_EventType((int(this->m__0type)&int(t_mojo_app_EventType(2147483647))))==t_mojo_app_EventType(2147483647));
}

void t_mojo_app_Event::m_Eat(){
  bbDBFrame db_f{"Eat:Void()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_Event*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(303106);
  this->m__0type=t_mojo_app_EventType((int(this->m__0type)|int(t_mojo_app_EventType(2147483647))));
}
bbString bbDBType(t_mojo_app_Event**){
  return "mojo.app.Event";
}
bbString bbDBValue(t_mojo_app_Event**p){
  return bbDBObjectValue(*p);
}

void t_mojo_app_KeyEvent::dbEmit(){
  t_mojo_app_Event::dbEmit();
  bbDBEmit("_key",&m__0key);
  bbDBEmit("_rawKey",&m__0rawKey);
  bbDBEmit("_modifiers",&m__0modifiers);
  bbDBEmit("_text",&m__0text);
}

t_mojo_app_KeyEvent::t_mojo_app_KeyEvent(t_mojo_app_EventType l_type,t_mojo_app_View* l_view,t_mojo_input_Key l_key,t_mojo_input_Key l_rawKey,t_mojo_input_Modifier l_modifiers,bbString l_text):t_mojo_app_Event(l_type,l_view){
  bbDBFrame db_f{"new:Void(type:mojo.app.EventType,view:mojo.app.View,key:mojo.input.Key,rawKey:mojo.input.Key,modifiers:mojo.input.Modifier,text:String)","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  bbDBLocal("type",&l_type);
  bbDBLocal("view",&l_view);
  bbDBLocal("key",&l_key);
  bbDBLocal("rawKey",&l_rawKey);
  bbDBLocal("modifiers",&l_modifiers);
  bbDBLocal("text",&l_text);
  bbDBStmt(421890);
  this->m__0key=l_key;
  bbDBStmt(425986);
  this->m__0rawKey=l_rawKey;
  bbDBStmt(430082);
  this->m__0modifiers=l_modifiers;
  bbDBStmt(434178);
  this->m__0text=l_text;
}

bbString t_mojo_app_KeyEvent::m_Text(){
  bbDBFrame db_f{"Text:String()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_KeyEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(532482);
  return this->m__0text;
}

t_mojo_input_Key t_mojo_app_KeyEvent::m_RawKey(){
  bbDBFrame db_f{"RawKey:mojo.input.Key()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_KeyEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(483330);
  return this->m__0rawKey;
}

t_mojo_input_Modifier t_mojo_app_KeyEvent::m_Modifiers(){
  bbDBFrame db_f{"Modifiers:mojo.input.Modifier()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_KeyEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(507906);
  return this->m__0modifiers;
}

t_mojo_input_Key t_mojo_app_KeyEvent::m_Key(){
  bbDBFrame db_f{"Key:mojo.input.Key()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_KeyEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(458754);
  return this->m__0key;
}
bbString bbDBType(t_mojo_app_KeyEvent**){
  return "mojo.app.KeyEvent";
}
bbString bbDBValue(t_mojo_app_KeyEvent**p){
  return bbDBObjectValue(*p);
}

void t_mojo_app_MouseEvent::dbEmit(){
  t_mojo_app_Event::dbEmit();
  bbDBEmit("_location",&m__0location);
  bbDBEmit("_button",&m__0button);
  bbDBEmit("_wheel",&m__0wheel);
  bbDBEmit("_modifiers",&m__0modifiers);
}

t_mojo_app_MouseEvent::t_mojo_app_MouseEvent(t_mojo_app_EventType l_type,t_mojo_app_View* l_view,t_std_geom_Vec2_1i l_location,t_mojo_input_MouseButton l_button,t_std_geom_Vec2_1i l_wheel,t_mojo_input_Modifier l_modifiers):t_mojo_app_Event(l_type,l_view){
  bbDBFrame db_f{"new:Void(type:mojo.app.EventType,view:mojo.app.View,location:Vec2i:std.geom.Vec2<Int>,button:mojo.input.MouseButton,wheel:Vec2i:std.geom.Vec2<Int>,modifiers:mojo.input.Modifier)","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  bbDBLocal("type",&l_type);
  bbDBLocal("view",&l_view);
  bbDBLocal("location",&l_location);
  bbDBLocal("button",&l_button);
  bbDBLocal("wheel",&l_wheel);
  bbDBLocal("modifiers",&l_modifiers);
  bbDBStmt(614402);
  this->m__0location=l_location;
  bbDBStmt(618498);
  this->m__0button=l_button;
  bbDBStmt(622594);
  this->m__0wheel=l_wheel;
  bbDBStmt(626690);
  this->m__0modifiers=l_modifiers;
}

t_std_geom_Vec2_1i t_mojo_app_MouseEvent::m_Wheel(){
  bbDBFrame db_f{"Wheel:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_MouseEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(700418);
  return this->m__0wheel;
}

t_mojo_input_Modifier t_mojo_app_MouseEvent::m_Modifiers(){
  bbDBFrame db_f{"Modifiers:mojo.input.Modifier()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_MouseEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(724994);
  return this->m__0modifiers;
}

t_std_geom_Vec2_1i t_mojo_app_MouseEvent::m_Location(){
  bbDBFrame db_f{"Location:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_MouseEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(651266);
  return this->m__0location;
}

t_mojo_input_MouseButton t_mojo_app_MouseEvent::m_Button(){
  bbDBFrame db_f{"Button:mojo.input.MouseButton()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_MouseEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(675842);
  return this->m__0button;
}
bbString bbDBType(t_mojo_app_MouseEvent**){
  return "mojo.app.MouseEvent";
}
bbString bbDBValue(t_mojo_app_MouseEvent**p){
  return bbDBObjectValue(*p);
}

void t_mojo_app_WindowEvent::gcMark(){
  t_mojo_app_Event::gcMark();
  bbGCMark(m__0window);
}

void t_mojo_app_WindowEvent::dbEmit(){
  t_mojo_app_Event::dbEmit();
  bbDBEmit("_window",&m__0window);
}

t_mojo_app_WindowEvent::t_mojo_app_WindowEvent(t_mojo_app_EventType l_type,t_mojo_app_Window* l_window):t_mojo_app_Event(l_type,((t_mojo_app_View*)(l_window))){
  bbDBFrame db_f{"new:Void(type:mojo.app.EventType,window:mojo.app.Window)","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  bbDBLocal("type",&l_type);
  bbDBLocal("window",&l_window);
  bbDBStmt(806914);
  this->m__0window=l_window;
}

t_mojo_app_Window* t_mojo_app_WindowEvent::m_Window(){
  bbDBFrame db_f{"Window:mojo.app.Window()","/home/pi/monkey2/modules/mojo/app/event.monkey2"};
  t_mojo_app_WindowEvent*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(831490);
  return this->m__0window;
}
bbString bbDBType(t_mojo_app_WindowEvent**){
  return "mojo.app.WindowEvent";
}
bbString bbDBValue(t_mojo_app_WindowEvent**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_app_2event_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_app_2event_init_v("mojo_app_2event",&mx2_mojo_app_2event_init);
