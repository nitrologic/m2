
#include "../../desktop_debug_pi/mojo_monkey_math.h"

// ***** External *****

// ***** Internal *****

bbFloat g_monkey_math_Clamp_1f(bbFloat l_value,bbFloat l_min,bbFloat l_max){
  bbDBFrame db_f{"Clamp<Float>:Float(value:Float,min:Float,max:Float)","/home/pi/monkey2/modules/monkey/math.monkey2"};
  bbDBLocal("value",&l_value);
  bbDBLocal("min",&l_min);
  bbDBLocal("max",&l_max);
  bbDBStmt(823297);
  if((l_value<=l_min)){
    bbDBBlock db_blk;
    bbDBStmt(823311);
    return l_min;
  }
  bbDBStmt(827393);
  if((l_value>=l_max)){
    bbDBBlock db_blk;
    bbDBStmt(827407);
    return l_max;
  }
  bbDBStmt(831489);
  return l_value;
}

void mx2_mojo_monkey_math_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_monkey_math_init_v("mojo_monkey_math",&mx2_mojo_monkey_math_init);
