
#include "../../desktop_debug_pi/mojo_process_2process.h"

// ***** External *****

// ***** Internal *****

void mx2_mojo_process_2process_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_mojo_process_2process_init_v("mojo_process_2process",&mx2_mojo_process_2process_init);
