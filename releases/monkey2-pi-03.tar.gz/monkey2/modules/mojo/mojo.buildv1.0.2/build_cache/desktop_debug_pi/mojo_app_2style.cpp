
#include "../../desktop_debug_pi/mojo_app_2style.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2skin.h"
#include "../../desktop_debug_pi/mojo_graphics_2canvas.h"
#include "../../desktop_debug_pi/mojo_graphics_2font.h"
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2vec2.h"

// ***** Internal *****

bbGCRootVar<t_mojo_app_Style> g_mojo_app_Style__0defaultStyle;
bbGCRootVar<t_std_collections_Map_1sTt_mojo_app_Style_2> g_mojo_app_Style__0styles;

t_mojo_app_Style* g_mojo_app_Style_GetStyle(bbString l_name){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    void gcMark(){
      bbGCMarkPtr(l_style);
    }
  }f0{};
  bbDBFrame db_f{"GetStyle:mojo.app.Style(name:String)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  bbDBLocal("name",&l_name);
  bbDBStmt(802824);
  f0.l_style=g_mojo_app_Style__0styles->m__idx(l_name);
  bbDBLocal("style",&f0.l_style);
  bbDBStmt(806914);
  if(bbBool(f0.l_style)){
    bbDBBlock db_blk;
    bbDBStmt(806923);
    return f0.l_style;
  }
  bbDBStmt(815112);
  bbInt l_i=l_name.find(BB_T(":"),bbInt(0));
  bbDBLocal("i",&l_i);
  bbDBStmt(819202);
  if((l_i!=-1)){
    bbDBBlock db_blk;
    bbDBStmt(819211);
    return g_mojo_app_Style_GetStyle(l_name.slice(bbInt(0),l_i));
  }
  bbDBStmt(827394);
  if(!bbBool(g_mojo_app_Style__0defaultStyle)){
    bbDBBlock db_blk;
    bbDBStmt(827415);
    g_mojo_app_Style__0defaultStyle=bbGCNew<t_mojo_app_Style>();
  }
  bbDBStmt(831490);
  return g_mojo_app_Style__0defaultStyle;
}

void t_mojo_app_Style::init(){
  m__0states=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2>();
  m__0images=bbGCNew<t_std_collections_Map_1sTt_mojo_graphics_Image_2>();
}

void t_mojo_app_Style::gcMark(){
  bbGCMark(m__0states);
  bbGCMark(m__0skin);
  bbGCMark(m__0font);
  bbGCMark(m__0images);
}

void t_mojo_app_Style::dbEmit(){
  bbDBEmit("_states",&m__0states);
  bbDBEmit("_bgcolor",&m__0bgcolor);
  bbDBEmit("_padding",&m__0padding);
  bbDBEmit("_skin",&m__0skin);
  bbDBEmit("_skcolor",&m__0skcolor);
  bbDBEmit("_border",&m__0border);
  bbDBEmit("_bdcolor",&m__0bdcolor);
  bbDBEmit("_margin",&m__0margin);
  bbDBEmit("_color",&m__0color);
  bbDBEmit("_font",&m__0font);
  bbDBEmit("_images",&m__0images);
}

t_mojo_app_Style::t_mojo_app_Style(bbString l_name,t_mojo_app_Style* l_style){
  init();
  bbDBFrame db_f{"new:Void(name:String,style:mojo.app.Style)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  bbDBLocal("name",&l_name);
  bbDBLocal("style",&l_style);
  bbDBStmt(102402);
  this->m_Init(l_name,l_style,true);
}

t_mojo_app_Style::t_mojo_app_Style(bbString l_name){
  init();
  bbDBFrame db_f{"new:Void(name:String)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  bbDBLocal("name",&l_name);
  bbDBStmt(77826);
  this->m_Init(l_name,((t_mojo_app_Style*)0),false);
}

t_mojo_app_Style::t_mojo_app_Style(t_mojo_app_Style* l_style){
  init();
  bbDBFrame db_f{"new:Void(style:mojo.app.Style)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  bbDBLocal("style",&l_style);
  bbDBStmt(53250);
  this->m_Init(bbString{},l_style,true);
}

t_mojo_app_Style::t_mojo_app_Style(){
  init();
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  bbDBStmt(36866);
  this->m_Init(bbString{},((t_mojo_app_Style*)0),false);
}

void t_mojo_app_Style::m_SkinColor(t_std_graphics_Color l_skinColor){
  bbDBFrame db_f{"SkinColor:Void(skinColor:std.graphics.Color)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("skinColor",&l_skinColor);
  bbDBStmt(327682);
  this->m__0skcolor=l_skinColor;
}

t_std_graphics_Color t_mojo_app_Style::m_SkinColor(){
  bbDBFrame db_f{"SkinColor:std.graphics.Color()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(319490);
  return this->m__0skcolor;
}

void t_mojo_app_Style::m_Skin(t_mojo_app_Skin* l_skin){
  bbDBFrame db_f{"Skin:Void(skin:mojo.app.Skin)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("skin",&l_skin);
  bbDBStmt(294914);
  this->m__0skin=l_skin;
}

t_mojo_app_Skin* t_mojo_app_Style::m_Skin(){
  bbDBFrame db_f{"Skin:mojo.app.Skin()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(286722);
  return this->m__0skin;
}

void t_mojo_app_Style::m_SetImage(bbString l_name,t_mojo_graphics_Image* l_image){
  bbDBFrame db_f{"SetImage:Void(name:String,image:mojo.graphics.Image)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("image",&l_image);
  bbDBStmt(516098);
  this->m__0images->m__idxeq(l_name,l_image);
}

void t_mojo_app_Style::m_Render(t_mojo_graphics_Canvas* l_canvas,t_std_geom_Rect_1i l_bounds){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Skin* l_skin{};
    void gcMark(){
      bbGCMarkPtr(l_skin);
    }
  }f0{};
  bbDBFrame db_f{"Render:Void(canvas:mojo.graphics.Canvas,bounds:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("canvas",&l_canvas);
  bbDBLocal("bounds",&l_bounds);
  bbDBStmt(614402);
  l_bounds.m__subeq(this->m_Margin());
  bbDBStmt(622600);
  t_std_geom_Rect_1i l_border=this->m_Border();
  bbDBLocal("border",&l_border);
  bbDBStmt(626696);
  t_std_graphics_Color l_bdcolor=this->m_BorderColor();
  bbDBLocal("bdcolor",&l_bdcolor);
  bbDBStmt(634882);
  if(((bbBool(l_border.m_Width())||bbBool(l_border.m_Height()))&&bbBool(l_bdcolor.m_a))){
    bbDBBlock db_blk;
    bbDBStmt(643075);
    l_canvas->m_Color(l_bdcolor);
    bbDBStmt(651273);
    bbInt l_x=l_bounds.m_X();
    bbDBLocal("x",&l_x);
    bbDBStmt(651285);
    bbInt l_y=l_bounds.m_Y();
    bbDBLocal("y",&l_y);
    bbDBStmt(655369);
    bbInt l_w=l_bounds.m_Width();
    bbDBLocal("w",&l_w);
    bbDBStmt(655385);
    bbInt l_h=l_bounds.m_Height();
    bbDBLocal("h",&l_h);
    bbDBStmt(659465);
    bbInt l_l=-l_border.m_min.m_x;
    bbDBLocal("l",&l_l);
    bbDBStmt(659482);
    bbInt l_r=l_border.m_max.m_x;
    bbDBLocal("r",&l_r);
    bbDBStmt(663561);
    bbInt l_t=-l_border.m_min.m_y;
    bbDBLocal("t",&l_t);
    bbDBStmt(663578);
    bbInt l_b=l_border.m_max.m_y;
    bbDBLocal("b",&l_b);
    bbDBStmt(671747);
    l_canvas->m_DrawRect(bbFloat(l_x),bbFloat(l_y),bbFloat(l_l),bbFloat((l_h-l_b)));
    bbDBStmt(675843);
    l_canvas->m_DrawRect(bbFloat((l_x+l_l)),bbFloat(l_y),bbFloat((l_w-l_l)),bbFloat(l_t));
    bbDBStmt(679939);
    l_canvas->m_DrawRect(bbFloat(((l_x+l_w)-l_r)),bbFloat((l_y+l_t)),bbFloat(l_r),bbFloat((l_h-l_t)));
    bbDBStmt(684035);
    l_canvas->m_DrawRect(bbFloat(l_x),bbFloat(((l_y+l_h)-l_b)),bbFloat((l_w-l_r)),bbFloat(l_b));
  }
  bbDBStmt(700418);
  l_bounds.m__subeq(l_border);
  bbDBStmt(708616);
  t_std_graphics_Color l_bgcolor=this->m_BackgroundColor();
  bbDBLocal("bgcolor",&l_bgcolor);
  bbDBStmt(712706);
  if(bbBool(l_bgcolor.m_a)){
    bbDBBlock db_blk;
    bbDBStmt(716803);
    l_canvas->m_Color(l_bgcolor);
    bbDBStmt(720899);
    l_canvas->m_DrawRect(bbFloat(l_bounds.m_X()),bbFloat(l_bounds.m_Y()),bbFloat(l_bounds.m_Width()),bbFloat(l_bounds.m_Height()));
  }
  bbDBStmt(733192);
  f0.l_skin=this->m_Skin();
  bbDBLocal("skin",&f0.l_skin);
  bbDBStmt(737288);
  t_std_graphics_Color l_skcolor=this->m_SkinColor();
  bbDBLocal("skcolor",&l_skcolor);
  bbDBStmt(745474);
  if((bbBool(f0.l_skin)&&bbBool(l_skcolor.m_a))){
    bbDBBlock db_blk;
    bbDBStmt(749571);
    l_canvas->m_Color(l_skcolor);
    bbDBStmt(753667);
    f0.l_skin->m_Draw(l_canvas,l_bounds);
  }
  bbDBStmt(765954);
  l_canvas->m_Font(this->m__0font);
  bbDBStmt(770050);
  l_canvas->m_Color(this->m__0color);
}

void t_mojo_app_Style::m_Padding(t_std_geom_Rect_1i l_padding){
  bbDBFrame db_f{"Padding:Void(padding:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("padding",&l_padding);
  bbDBStmt(262146);
  this->m__0padding=l_padding;
}

t_std_geom_Rect_1i t_mojo_app_Style::m_Padding(){
  bbDBFrame db_f{"Padding:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(253954);
  return this->m__0padding;
}

void t_mojo_app_Style::m_Margin(t_std_geom_Rect_1i l_margin){
  bbDBFrame db_f{"Margin:Void(margin:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("margin",&l_margin);
  bbDBStmt(425986);
  this->m__0margin=l_margin;
}

t_std_geom_Rect_1i t_mojo_app_Style::m_Margin(){
  bbDBFrame db_f{"Margin:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(417794);
  return this->m__0margin;
}

void t_mojo_app_Style::m_Init(bbString l_name,t_mojo_app_Style* l_style,bbBool l_copyStates){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    f0_t(t_mojo_app_Style* l_style):l_style(l_style){
    }
    void gcMark(){
      bbGCMarkPtr(l_style);
    }
  }f0{l_style};
  bbDBFrame db_f{"Init:Void(name:String,style:mojo.app.Style,copyStates:Bool)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBLocal("style",&f0.l_style);
  bbDBLocal("copyStates",&l_copyStates);
  bbDBStmt(925698);
  if(!bbBool(f0.l_style)){
    bbDBBlock db_blk;
    bbDBStmt(925711);
    f0.l_style=g_mojo_app_Style__0defaultStyle;
  }
  bbDBStmt(933890);
  if(bbBool(f0.l_style)){
    bbDBBlock db_blk;
    bbDBStmt(937987);
    this->m__0bgcolor=f0.l_style->m__0bgcolor;
    bbDBStmt(942083);
    this->m__0padding=f0.l_style->m__0padding;
    bbDBStmt(946179);
    this->m__0skin=f0.l_style->m__0skin;
    bbDBStmt(950275);
    this->m__0skcolor=f0.l_style->m__0skcolor;
    bbDBStmt(954371);
    this->m__0border=f0.l_style->m__0border;
    bbDBStmt(958467);
    this->m__0bdcolor=f0.l_style->m__0bdcolor;
    bbDBStmt(962563);
    this->m__0margin=f0.l_style->m__0margin;
    bbDBStmt(966659);
    this->m__0color=f0.l_style->m__0color;
    bbDBStmt(970755);
    this->m__0font=f0.l_style->m__0font;
    bbDBStmt(974851);
    this->m__0images=f0.l_style->m__0images->m_Copy();
    bbDBStmt(983043);
    if(l_copyStates){
      bbDBBlock db_blk;
      bbDBStmt(987140);
      {
        struct f3_t : public bbGCFrame{
          t_std_collections_Map_1sTt_mojo_app_Style_2_Iterator l_0{};
          void gcMark(){
            bbGCMark(l_0);
          }
        }f3{};
        bbDBLoop db_loop;
        f3.l_0=f0.l_style->m__0states->m_All();
        bbDBLocal("0",&f3.l_0);
        for(;f3.l_0.m_Valid();f3.l_0.m_Bump()){
          struct f4_t : public bbGCFrame{
            t_std_collections_Map_1sTt_mojo_app_Style_2_Node* l_it{};
            t_mojo_app_Style* t0{};
            t_mojo_app_Style* t1{};
            void gcMark(){
              bbGCMarkPtr(l_it);
              bbGCMarkPtr(t0);
              bbGCMarkPtr(t1);
            }
          }f4{};
          bbDBBlock db_blk;
          f4.l_it=f3.l_0.m_Current();
          bbDBLocal("it",&f4.l_it);
          bbDBStmt(991237);
          this->m__0states->m__idxeq(f4.l_it->m_Key(),f4.t1=bbGCNew<t_mojo_app_Style>(f4.t0=f4.l_it->m_Value()));
        }
      }
    }
  }
  bbDBStmt(1011714);
  if(bbBool(l_name)){
    bbDBBlock db_blk;
    bbDBStmt(1015811);
    g_mojo_app_Style__0styles->m__idxeq(l_name,this);
  }
}

t_mojo_app_Style* t_mojo_app_Style::m_GetState(bbString l_state){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    void gcMark(){
      bbGCMarkPtr(l_style);
    }
  }f0{};
  bbDBFrame db_f{"GetState:mojo.app.Style(state:String)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("state",&l_state);
  bbDBStmt(184328);
  f0.l_style=this->m__0states->m__idx(l_state);
  bbDBLocal("style",&f0.l_style);
  bbDBStmt(188418);
  if(bbBool(f0.l_style)){
    bbDBBlock db_blk;
    bbDBStmt(188427);
    return f0.l_style;
  }
  bbDBStmt(196610);
  return this;
}

t_mojo_graphics_Image* t_mojo_app_Style::m_GetImage(bbString l_name){
  bbDBFrame db_f{"GetImage:mojo.graphics.Image(name:String)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("name",&l_name);
  bbDBStmt(540674);
  return this->m__0images->m__idx(l_name);
}

void t_mojo_app_Style::m_DefaultFont(t_mojo_graphics_Font* l_font){
  bbDBFrame db_f{"DefaultFont:Void(font:mojo.graphics.Font)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("font",&l_font);
  bbDBStmt(491522);
  this->m__0font=l_font;
}

t_mojo_graphics_Font* t_mojo_app_Style::m_DefaultFont(){
  bbDBFrame db_f{"DefaultFont:mojo.graphics.Font()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(483330);
  return this->m__0font;
}

void t_mojo_app_Style::m_DefaultColor(t_std_graphics_Color l_color){
  bbDBFrame db_f{"DefaultColor:Void(color:std.graphics.Color)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("color",&l_color);
  bbDBStmt(458754);
  this->m__0color=l_color;
}

t_std_graphics_Color t_mojo_app_Style::m_DefaultColor(){
  bbDBFrame db_f{"DefaultColor:std.graphics.Color()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(450562);
  return this->m__0color;
}

t_std_geom_Rect_1i t_mojo_app_Style::m_Bounds(){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Skin* l_skin{};
    void gcMark(){
      bbGCMarkPtr(l_skin);
    }
  }f0{};
  bbDBFrame db_f{"Bounds:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(565256);
  t_std_geom_Rect_1i l_bounds=this->m_Padding();
  bbDBLocal("bounds",&l_bounds);
  bbDBStmt(569352);
  f0.l_skin=this->m_Skin();
  bbDBLocal("skin",&f0.l_skin);
  bbDBStmt(573442);
  if(bbBool(f0.l_skin)){
    struct f1_t : public bbGCFrame{
      t_mojo_app_Skin* t0{};
      void gcMark(){
        bbGCMarkPtr(t0);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(573450);
    l_bounds.m__addeq((f1.t0=this->m_Skin())->m_Bounds());
  }
  bbDBStmt(577538);
  l_bounds.m__addeq(this->m_Border());
  bbDBStmt(581634);
  l_bounds.m__addeq(this->m_Margin());
  bbDBStmt(585730);
  return l_bounds;
}

void t_mojo_app_Style::m_BorderColor(t_std_graphics_Color l_borderColor){
  bbDBFrame db_f{"BorderColor:Void(borderColor:std.graphics.Color)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("borderColor",&l_borderColor);
  bbDBStmt(393218);
  this->m__0bdcolor=l_borderColor;
}

t_std_graphics_Color t_mojo_app_Style::m_BorderColor(){
  bbDBFrame db_f{"BorderColor:std.graphics.Color()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(385026);
  return this->m__0bdcolor;
}

void t_mojo_app_Style::m_Border(t_std_geom_Rect_1i l_border){
  bbDBFrame db_f{"Border:Void(border:Recti:std.geom.Rect<Int>)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("border",&l_border);
  bbDBStmt(360450);
  this->m__0border=l_border;
}

t_std_geom_Rect_1i t_mojo_app_Style::m_Border(){
  bbDBFrame db_f{"Border:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(352258);
  return this->m__0border;
}

void t_mojo_app_Style::m_BackgroundColor(t_std_graphics_Color l_backgroundColor){
  bbDBFrame db_f{"BackgroundColor:Void(backgroundColor:std.graphics.Color)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("backgroundColor",&l_backgroundColor);
  bbDBStmt(229378);
  this->m__0bgcolor=l_backgroundColor;
}

t_std_graphics_Color t_mojo_app_Style::m_BackgroundColor(){
  bbDBFrame db_f{"BackgroundColor:std.graphics.Color()","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(221186);
  return this->m__0bgcolor;
}

t_mojo_app_Style* t_mojo_app_Style::m_AddState(bbString l_state,bbString l_srcState){
  struct f0_t : public bbGCFrame{
    t_mojo_app_Style* l_style{};
    t_mojo_app_Style* t0{};
    void gcMark(){
      bbGCMarkPtr(l_style);
      bbGCMarkPtr(t0);
    }
  }f0{};
  bbDBFrame db_f{"AddState:mojo.app.Style(state:String,srcState:String)","/home/pi/monkey2/modules/mojo/app/style.monkey2"};
  t_mojo_app_Style*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("state",&l_state);
  bbDBLocal("srcState",&l_srcState);
  bbDBStmt(131080);
  f0.l_style=bbGCNew<t_mojo_app_Style>();
  bbDBLocal("style",&f0.l_style);
  bbDBStmt(139266);
  f0.l_style->m_Init(bbString{},f0.t0=this->m_GetState(l_srcState),false);
  bbDBStmt(147458);
  this->m__0states->m__idxeq(l_state,f0.l_style);
  bbDBStmt(155650);
  return f0.l_style;
}
bbString bbDBType(t_mojo_app_Style**){
  return "mojo.app.Style";
}
bbString bbDBValue(t_mojo_app_Style**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_app_2style_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_app_Style__0styles=bbGCNew<t_std_collections_Map_1sTt_mojo_app_Style_2>();
}

bbInit mx2_mojo_app_2style_init_v("mojo_app_2style",&mx2_mojo_app_2style_init);
