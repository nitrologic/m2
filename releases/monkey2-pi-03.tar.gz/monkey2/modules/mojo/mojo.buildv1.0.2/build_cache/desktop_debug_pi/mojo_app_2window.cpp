
#include "../../desktop_debug_pi/mojo_app_2window.h"

// ***** External *****

#include "../../desktop_debug_pi/mojo_app_2app.h"
#include "../../desktop_debug_pi/mojo_app_2event.h"
#include "../../desktop_debug_pi/mojo_graphics_2canvas.h"
#include "../../desktop_debug_pi/mojo_std_collections_2map.h"
#include "../../desktop_debug_pi/mojo_std_collections_2stack.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_geom_2affinemat3.h"

// ***** Internal *****

bbGCRootVar<t_std_collections_Stack_1Tt_mojo_app_Window_2> g_mojo_app_Window__0allWindows;
bbGCRootVar<t_std_collections_Stack_1Tt_mojo_app_Window_2> g_mojo_app_Window__0visibleWindows;
bbGCRootVar<t_std_collections_Map_1jTt_mojo_app_Window_2> g_mojo_app_Window__0windowsByID;

t_mojo_app_Window* g_mojo_app_Window_WindowForID(bbUInt l_id){
  bbDBFrame db_f{"WindowForID:mojo.app.Window(id:Uint)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBLocal("id",&l_id);
  bbDBStmt(897026);
  return g_mojo_app_Window__0windowsByID->m__idx(l_id);
}

bbArray<bbGCVar<t_mojo_app_Window>>* g_mojo_app_Window_VisibleWindows(){
  bbDBFrame db_f{"VisibleWindows:mojo.app.Window[]()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBStmt(868354);
  return g_mojo_app_Window__0visibleWindows->m_ToArray();
}

bbArray<bbGCVar<t_mojo_app_Window>>* g_mojo_app_Window_AllWindows(){
  bbDBFrame db_f{"AllWindows:mojo.app.Window[]()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBStmt(839682);
  return g_mojo_app_Window__0allWindows->m_ToArray();
}

void t_mojo_app_Window::gcMark(){
  t_mojo_app_View::gcMark();
  bbGCMark(m__0canvas);
  bbGCMark(m__0keyView);
}

void t_mojo_app_Window::dbEmit(){
  t_mojo_app_View::dbEmit();
  bbDBEmit("_sdlWindow",&m__0sdlWindow);
  bbDBEmit("_sdlGLContext",&m__0sdlGLContext);
  bbDBEmit("_flags",&m__0flags);
  bbDBEmit("_fullscreen",&m__0fullscreen);
  bbDBEmit("_swapInterval",&m__0swapInterval);
  bbDBEmit("_canvas",&m__0canvas);
  bbDBEmit("_clearColor",&m__0clearColor);
  bbDBEmit("_clearEnabled",&m__0clearEnabled);
  bbDBEmit("_keyView",&m__0keyView);
  bbDBEmit("_minSize",&m__0minSize);
  bbDBEmit("_maxSize",&m__0maxSize);
  bbDBEmit("_frame",&m__0frame);
  bbDBEmit("_weirdHack",&m__0weirdHack);
}

t_mojo_app_Window::t_mojo_app_Window(bbString l_title,t_mojo_app_AppInstance* l_app){
  bbDBFrame db_f{"new:Void(title:String,app:mojo.app.AppInstance)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBLocal("title",&l_title);
  bbDBLocal("app",&l_app);
  bbDBStmt(1048578);
  this->m__0sdlWindow=SDL_CreateWindow(bbUtf8String(l_title),bbInt(0),bbInt(0),bbInt(0),bbInt(0),bbInt(SDL_WindowFlags((int(SDL_WINDOW_HIDDEN)|int(SDL_WINDOW_OPENGL)))));
  bbDBStmt(1052674);
  bbAssert(bbBool(this->m__0sdlWindow),BB_T("FATAL ERROR: SDL_CreateWindow failed"));
  bbDBStmt(1060866);
  this->m__0sdlGLContext=SDL_GL_CreateContext(this->m__0sdlWindow);
  bbDBStmt(1064962);
  bbAssert(bbBool(this->m__0sdlGLContext),BB_T("FATAL ERROR: SDL_GL_CreateContext failed"));
  bbDBStmt(1069058);
  SDL_GL_MakeCurrent(this->m__0sdlWindow,this->m__0sdlGLContext);
}

t_mojo_app_Window::t_mojo_app_Window(bbString l_title,t_std_geom_Rect_1i l_rect,t_mojo_app_WindowFlags l_flags){
  bbDBFrame db_f{"new:Void(title:String,rect:Recti:std.geom.Rect<Int>,flags:mojo.app.WindowFlags)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBLocal("title",&l_title);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(159746);
  this->m_Init(l_title,l_rect,l_flags);
}

t_mojo_app_Window::t_mojo_app_Window(bbString l_title,bbInt l_width,bbInt l_height,t_mojo_app_WindowFlags l_flags){
  bbDBFrame db_f{"new:Void(title:String,width:Int,height:Int,flags:mojo.app.WindowFlags)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBLocal("title",&l_title);
  bbDBLocal("width",&l_width);
  bbDBLocal("height",&l_height);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(143362);
  this->m_Init(l_title,t_std_geom_Rect_1i(bbInt(0),bbInt(0),l_width,l_height),t_mojo_app_WindowFlags((int(l_flags)|int(t_mojo_app_WindowFlags(3)))));
}

t_mojo_app_Window::t_mojo_app_Window(){
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  bbDBStmt(126978);
  this->m_Init(BB_T("Window"),t_std_geom_Rect_1i(bbInt(0),bbInt(0),640,480),t_mojo_app_WindowFlags(3));
}

void t_mojo_app_Window::m_Update(){
  bbDBFrame db_f{"Update:Void()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(507906);
  this->m_Frame(this->m_GetFrame());
  bbDBStmt(606210);
  this->m_Measure();
  bbDBStmt(610306);
  this->m_UpdateLayout();
}

void t_mojo_app_Window::m_Title(bbString l_title){
  bbDBFrame db_f{"Title:Void(title:String)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("title",&l_title);
  bbDBStmt(204802);
  SDL_SetWindowTitle(this->m__0sdlWindow,bbUtf8String(l_title));
}

bbString t_mojo_app_Window::m_Title(){
  bbDBFrame db_f{"Title:String()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(188418);
  return bbString::fromUtf8String(((void*)(SDL_GetWindowTitle(this->m__0sdlWindow))));
}

void t_mojo_app_Window::m_SwapInterval(bbInt l_swapInterval){
  bbDBFrame db_f{"SwapInterval:Void(swapInterval:Int)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("swapInterval",&l_swapInterval);
  bbDBStmt(339970);
  this->m__0swapInterval=l_swapInterval;
}

bbInt t_mojo_app_Window::m_SwapInterval(){
  bbDBFrame db_f{"SwapInterval:Int()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(323586);
  return this->m__0swapInterval;
}

void t_mojo_app_Window::m_SendWindowEvent(t_mojo_app_WindowEvent* l_event){
  bbDBFrame db_f{"SendWindowEvent:Void(event:mojo.app.WindowEvent)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  t_mojo_app_EventType l_0=l_event->m_Type();
  bbDBLocal("0",&l_0);
  bbDBStmt(933890);
  if(l_0==t_mojo_app_EventType(11)||l_0==t_mojo_app_EventType(12)){
    bbDBBlock db_blk;
    bbDBStmt(942083);
    this->m__0frame=this->m_GetFrame();
    bbDBStmt(946179);
    this->m_Frame(this->m__0frame);
    bbDBStmt(950275);
    this->m__0weirdHack=true;
  }
  bbDBStmt(962562);
  this->m_OnWindowEvent(l_event);
}

SDL_Window* t_mojo_app_Window::m_SDLWindow(){
  bbDBFrame db_f{"SDLWindow:sdl2.SDL_Window Ptr()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(786434);
  return this->m__0sdlWindow;
}

void* t_mojo_app_Window::m_SDLGLContext(){
  bbDBFrame db_f{"SDLGLContext:SDL_GLContext:Void Ptr()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(811010);
  return this->m__0sdlGLContext;
}

void t_mojo_app_Window::m_Render(){
  bbDBFrame db_f{"Render:Void()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(638978);
  SDL_GL_MakeCurrent(this->m__0sdlWindow,this->m__0sdlGLContext);
  bbDBStmt(643074);
  SDL_GL_SetSwapInterval(this->m__0swapInterval);
  bbDBStmt(679944);
  t_std_geom_Rect_1i l_bounds=t_std_geom_Rect_1i(bbInt(0),bbInt(0),this->m_Frame().m_Size());
  bbDBLocal("bounds",&l_bounds);
  bbDBStmt(688130);
  this->m__0canvas->m_Resize(l_bounds.m_Size());
  bbDBStmt(696322);
  this->m__0canvas->m_BeginRender(l_bounds,t_std_geom_AffineMat3_1f(bbNullCtor));
  bbDBStmt(704514);
  if(this->m__0clearEnabled){
    bbDBBlock db_blk;
    bbDBStmt(704531);
    this->m__0canvas->m_Clear(this->m__0clearColor);
  }
  bbDBStmt(712706);
  this->m_Render(this->m__0canvas);
  bbDBStmt(720898);
  this->m__0canvas->m_EndRender();
  bbDBStmt(729090);
  SDL_GL_SwapWindow(this->m__0sdlWindow);
}

void t_mojo_app_Window::m_OnWindowEvent(t_mojo_app_WindowEvent* l_event){
  bbDBFrame db_f{"OnWindowEvent:Void(event:mojo.app.WindowEvent)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("event",&l_event);
  t_mojo_app_EventType l_0=l_event->m_Type();
  bbDBLocal("0",&l_0);
  bbDBStmt(1118210);
  if(l_0==t_mojo_app_EventType(10)){
    bbDBBlock db_blk;
    bbDBStmt(1130499);
    g_mojo_app_App->m_Terminate();
  }else if(l_0==t_mojo_app_EventType(11)){
    bbDBBlock db_blk;
  }else if(l_0==t_mojo_app_EventType(12)){
    bbDBBlock db_blk;
    bbDBStmt(1155075);
    g_mojo_app_App->m_RequestRender();
  }else if(l_0==t_mojo_app_EventType(13)){
    bbDBBlock db_blk;
  }else if(l_0==t_mojo_app_EventType(14)){
    bbDBBlock db_blk;
  }
}

void t_mojo_app_Window::m_KeyView(t_mojo_app_View* l_keyView){
  bbDBFrame db_f{"KeyView:Void(keyView:mojo.app.View)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("keyView",&l_keyView);
  bbDBStmt(1007618);
  this->m__0keyView=l_keyView;
}

t_mojo_app_View* t_mojo_app_Window::m_KeyView(){
  bbDBFrame db_f{"KeyView:mojo.app.View()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(991234);
  return this->m__0keyView;
}

void t_mojo_app_Window::m_Init(bbString l_title,t_std_geom_Rect_1i l_rect,t_mojo_app_WindowFlags l_flags){
  bbDBFrame db_f{"Init:Void(title:String,rect:Recti:std.geom.Rect<Int>,flags:mojo.app.WindowFlags)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("title",&l_title);
  bbDBLocal("rect",&l_rect);
  bbDBLocal("flags",&l_flags);
  bbDBStmt(1396738);
  this->m_Layout(BB_T("fill"));
  bbDBStmt(1404936);
  bbInt l_x=(bbBool(t_mojo_app_WindowFlags((int(l_flags)&int(t_mojo_app_WindowFlags(1))))) ? SDL_WINDOWPOS_CENTERED : l_rect.m_X());
  bbDBLocal("x",&l_x);
  bbDBStmt(1409032);
  bbInt l_y=(bbBool(t_mojo_app_WindowFlags((int(l_flags)&int(t_mojo_app_WindowFlags(2))))) ? SDL_WINDOWPOS_CENTERED : l_rect.m_Y());
  bbDBLocal("y",&l_y);
  bbDBStmt(1417224);
  SDL_WindowFlags l_sdlFlags=SDL_WINDOW_OPENGL;
  bbDBLocal("sdlFlags",&l_sdlFlags);
  bbDBStmt(1425410);
  if(bbBool(t_mojo_app_WindowFlags((int(l_flags)&int(t_mojo_app_WindowFlags(4)))))){
    bbDBBlock db_blk;
    bbDBStmt(1425440);
    l_sdlFlags=SDL_WindowFlags((int(l_sdlFlags)|int(SDL_WINDOW_HIDDEN)));
  }
  bbDBStmt(1429506);
  if(bbBool(t_mojo_app_WindowFlags((int(l_flags)&int(t_mojo_app_WindowFlags(8)))))){
    bbDBBlock db_blk;
    bbDBStmt(1429539);
    l_sdlFlags=SDL_WindowFlags((int(l_sdlFlags)|int(SDL_WINDOW_RESIZABLE)));
  }
  bbDBStmt(1433602);
  if(bbBool(t_mojo_app_WindowFlags((int(l_flags)&int(t_mojo_app_WindowFlags(16)))))){
    bbDBBlock db_blk;
    bbDBStmt(1433636);
    l_sdlFlags=SDL_WindowFlags((int(l_sdlFlags)|int(SDL_WINDOW_BORDERLESS)));
  }
  bbDBStmt(1437698);
  if(bbBool(t_mojo_app_WindowFlags((int(l_flags)&int(t_mojo_app_WindowFlags(32)))))){
    bbDBBlock db_blk;
    bbDBStmt(1437732);
    this->m__0fullscreen=true;
    bbDBStmt(1437751);
    l_sdlFlags=SDL_WindowFlags((int(l_sdlFlags)|int(SDL_WINDOW_FULLSCREEN)));
  }
  bbDBStmt(1445890);
  this->m__0flags=l_flags;
  bbDBStmt(1454082);
  this->m__0sdlWindow=SDL_CreateWindow(bbUtf8String(l_title),l_x,l_y,l_rect.m_Width(),l_rect.m_Height(),bbInt(l_sdlFlags));
  bbDBStmt(1458178);
  bbAssert(bbBool(this->m__0sdlWindow),BB_T("FATAL ERROR: SDL_CreateWindow failed"));
  bbDBStmt(1466370);
  g_mojo_app_Window__0allWindows->m_Push(this);
  bbDBStmt(1470466);
  g_mojo_app_Window__0windowsByID->m__idxeq(bbUInt(SDL_GetWindowID(this->m__0sdlWindow)),this);
  bbDBStmt(1474562);
  if(!bbBool(t_mojo_app_WindowFlags((int(l_flags)&int(t_mojo_app_WindowFlags(4)))))){
    bbDBBlock db_blk;
    bbDBStmt(1474598);
    g_mojo_app_Window__0visibleWindows->m_Push(this);
  }
  bbDBStmt(1482754);
  this->m__0minSize=this->m_GetMinSize();
  bbDBStmt(1486850);
  this->m_MinSize(this->m__0minSize);
  bbDBStmt(1495042);
  this->m__0maxSize=this->m_GetMaxSize();
  bbDBStmt(1499138);
  this->m_MaxSize(this->m__0maxSize);
  bbDBStmt(1507330);
  this->m__0frame=this->m_GetFrame();
  bbDBStmt(1511426);
  this->m_Frame(this->m__0frame);
  bbDBStmt(1523714);
  this->m__0sdlGLContext=SDL_GL_CreateContext(this->m__0sdlWindow);
  bbDBStmt(1527810);
  bbAssert(bbBool(this->m__0sdlGLContext),BB_T("FATAL ERROR: SDL_GL_CreateContext failed"));
  bbDBStmt(1531906);
  SDL_GL_MakeCurrent(this->m__0sdlWindow,this->m__0sdlGLContext);
  bbDBStmt(1540098);
  this->m__0canvas=bbGCNew<t_mojo_graphics_Canvas>(this->m__0frame.m_Width(),this->m__0frame.m_Height());
  bbDBStmt(1548290);
  this->m_Update();
}

t_std_geom_Vec2_1i t_mojo_app_Window::m_GetMinSize(){
  bbDBFrame db_f{"GetMinSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1314824);
  bbInt l_w{};
  bbDBLocal("w",&l_w);
  bbDBStmt(1314830);
  bbInt l_h{};
  bbDBLocal("h",&l_h);
  bbDBStmt(1318914);
  SDL_GetWindowMinimumSize(this->m__0sdlWindow,&l_w,&l_h);
  bbDBStmt(1323010);
  return t_std_geom_Vec2_1i(l_w,l_h);
}

t_std_geom_Vec2_1i t_mojo_app_Window::m_GetMaxSize(){
  bbDBFrame db_f{"GetMaxSize:Vec2i:std.geom.Vec2<Int>()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1339400);
  bbInt l_w{};
  bbDBLocal("w",&l_w);
  bbDBStmt(1339406);
  bbInt l_h{};
  bbDBLocal("h",&l_h);
  bbDBStmt(1343490);
  SDL_GetWindowMaximumSize(this->m__0sdlWindow,&l_w,&l_h);
  bbDBStmt(1347586);
  return t_std_geom_Vec2_1i(l_w,l_h);
}

t_std_geom_Rect_1i t_mojo_app_Window::m_GetFrame(){
  bbDBFrame db_f{"GetFrame:Recti:std.geom.Rect<Int>()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(1363976);
  bbInt l_x{};
  bbDBLocal("x",&l_x);
  bbDBStmt(1363982);
  bbInt l_y{};
  bbDBLocal("y",&l_y);
  bbDBStmt(1363988);
  bbInt l_w{};
  bbDBLocal("w",&l_w);
  bbDBStmt(1363994);
  bbInt l_h{};
  bbDBLocal("h",&l_h);
  bbDBStmt(1368066);
  SDL_GetWindowPosition(this->m__0sdlWindow,&l_x,&l_y);
  bbDBStmt(1372162);
  SDL_GetWindowSize(this->m__0sdlWindow,&l_w,&l_h);
  bbDBStmt(1376258);
  return t_std_geom_Rect_1i(l_x,l_y,(l_x+l_w),(l_y+l_h));
}

void t_mojo_app_Window::m_Fullscreen(bbBool l_fullscreen){
  bbDBFrame db_f{"Fullscreen:Void(fullscreen:Bool)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("fullscreen",&l_fullscreen);
  bbDBStmt(385026);
  if((l_fullscreen==this->m__0fullscreen)){
    bbDBBlock db_blk;
    bbDBStmt(385052);
    return;
  }
  bbDBStmt(393218);
  this->m__0fullscreen=l_fullscreen;
  bbDBStmt(401410);
  if(this->m__0fullscreen){
    bbDBBlock db_blk;
    bbDBStmt(405513);
    SDL_DisplayMode l_mode{};
    bbDBLocal("mode",&l_mode);
    bbDBStmt(409603);
    l_mode.w=this->m_Width();
    bbDBStmt(413699);
    l_mode.h=this->m_Height();
    bbDBStmt(417795);
    SDL_SetWindowDisplayMode(this->m__0sdlWindow,&l_mode);
    bbDBStmt(421891);
    SDL_SetWindowFullscreen(this->m__0sdlWindow,bbInt(SDL_WINDOW_FULLSCREEN));
  }else{
    bbDBStmt(425986);
    bbDBBlock db_blk;
    bbDBStmt(430083);
    SDL_SetWindowFullscreen(this->m__0sdlWindow,bbInt(0));
  }
}

bbBool t_mojo_app_Window::m_Fullscreen(){
  bbDBFrame db_f{"Fullscreen:Bool()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(368642);
  return this->m__0fullscreen;
}

t_mojo_app_Window* t_mojo_app_Window::m_FindWindow(){
  bbDBFrame db_f{"FindWindow:mojo.app.Window()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(757762);
  return this;
}

void t_mojo_app_Window::m_ClearEnabled(bbBool l_clearEnabled){
  bbDBFrame db_f{"ClearEnabled:Void(clearEnabled:Bool)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("clearEnabled",&l_clearEnabled);
  bbDBStmt(294914);
  this->m__0clearEnabled=l_clearEnabled;
}

bbBool t_mojo_app_Window::m_ClearEnabled(){
  bbDBFrame db_f{"ClearEnabled:Bool()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(278530);
  return this->m__0clearEnabled;
}

void t_mojo_app_Window::m_ClearColor(t_std_graphics_Color l_clearColor){
  bbDBFrame db_f{"ClearColor:Void(clearColor:std.graphics.Color)","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("clearColor",&l_clearColor);
  bbDBStmt(249858);
  this->m__0clearColor=l_clearColor;
}

t_std_graphics_Color t_mojo_app_Window::m_ClearColor(){
  bbDBFrame db_f{"ClearColor:std.graphics.Color()","/home/pi/monkey2/modules/mojo/app/window.monkey2"};
  t_mojo_app_Window*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(233474);
  return this->m__0clearColor;
}
bbString bbDBType(t_mojo_app_Window**){
  return "mojo.app.Window";
}
bbString bbDBValue(t_mojo_app_Window**p){
  return bbDBObjectValue(*p);
}

void mx2_mojo_app_2window_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_app_Window__0allWindows=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_Window_2>();
  g_mojo_app_Window__0visibleWindows=bbGCNew<t_std_collections_Stack_1Tt_mojo_app_Window_2>();
  g_mojo_app_Window__0windowsByID=bbGCNew<t_std_collections_Map_1jTt_mojo_app_Window_2>();
}

bbInit mx2_mojo_app_2window_init_v("mojo_app_2window",&mx2_mojo_app_2window_init);
