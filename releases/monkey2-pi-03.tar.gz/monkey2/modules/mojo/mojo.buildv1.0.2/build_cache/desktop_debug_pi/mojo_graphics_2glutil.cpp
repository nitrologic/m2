
#include "../../desktop_debug_pi/mojo_graphics_2glutil.h"

// ***** External *****

#include "../../../../gles20/gles20.buildv1.0.2/desktop_debug_pi/gles20_gles20.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_debug.h"
#include "../../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"

// ***** Internal *****

bbInt g_mojo_graphics_glutil_tmpi;
bbInt g_mojo_graphics_glutil_glGraphicsSeq;

void g_mojo_graphics_glutil_glLink(bbInt l_program){
  bbDBFrame db_f{"glLink:Void(program:Int)","/home/pi/monkey2/modules/mojo/graphics/glutil.monkey2"};
  bbDBLocal("program",&l_program);
  bbDBStmt(364545);
  glLinkProgram(bbUInt(l_program));
  bbDBStmt(368641);
  glGetProgramiv(bbUInt(l_program),GL_LINK_STATUS,&g_mojo_graphics_glutil_tmpi);
  bbDBStmt(372737);
  if(!bbBool(g_mojo_graphics_glutil_tmpi)){
    bbDBBlock db_blk;
    bbDBStmt(372749);
    bbAssert(false,(BB_T("Failed to link program:")+g_gles20_glGetProgramInfoLogEx(bbUInt(l_program))));
  }
}

bbInt g_mojo_graphics_glutil_glCompile(bbInt l_type,bbString l_source){
  bbDBFrame db_f{"glCompile:Int(type:Int,source:String)","/home/pi/monkey2/modules/mojo/graphics/glutil.monkey2"};
  bbDBLocal("type",&l_type);
  bbDBLocal("source",&l_source);
  bbDBStmt(290823);
  bbUInt l_shader=glCreateShader(l_type);
  bbDBLocal("shader",&l_shader);
  bbDBStmt(294913);
  g_gles20_glShaderSourceEx(l_shader,l_source);
  bbDBStmt(299009);
  glCompileShader(l_shader);
  bbDBStmt(303105);
  glGetShaderiv(l_shader,GL_COMPILE_STATUS,&g_mojo_graphics_glutil_tmpi);
  bbDBStmt(307201);
  if(!bbBool(g_mojo_graphics_glutil_tmpi)){
    struct f1_t : public bbGCFrame{
      bbArray<bbString>* l_lines{};
      void gcMark(){
        bbGCMarkPtr(l_lines);
      }
    }f1{};
    bbDBBlock db_blk;
    bbDBStmt(311298);
    puts((BB_T("Failed to compile fragment shader:")+g_gles20_glGetShaderInfoLogEx(l_shader)).c_str());fflush( stdout );
    bbDBStmt(315400);
    f1.l_lines=l_source.split(BB_T("\n"));
    bbDBLocal("lines",&f1.l_lines);
    bbDBStmt(319490);
    {
      bbDBLoop db_loop;
      bbInt l_i=bbInt(0);
      bbDBLocal("i",&l_i);
      bbDBStmt(319490);
      for(;(l_i<f1.l_lines->length());l_i+=1){
        bbDBBlock db_blk;
        bbDBStmt(323587);
        puts(((bbString((l_i+1))+BB_T(":\t"))+f1.l_lines->at(l_i)).c_str());fflush( stdout );
      }
    }
    bbDBStmt(331778);
    bbAssert(false,BB_T("Compile fragment shader failed"));
  }
  bbDBStmt(339969);
  return bbInt(l_shader);
}

void g_mojo_graphics_glutil_glPopFramebuffer(){
  bbDBFrame db_f{"glPopFramebuffer:Void()","/home/pi/monkey2/modules/mojo/graphics/glutil.monkey2"};
  bbDBStmt(241665);
  glBindFramebuffer(GL_FRAMEBUFFER,bbUInt(g_mojo_graphics_glutil_tmpi));
}

void g_mojo_graphics_glutil_glPushFramebuffer(bbInt l_framebuf){
  bbDBFrame db_f{"glPushFramebuffer:Void(framebuf:Int)","/home/pi/monkey2/modules/mojo/graphics/glutil.monkey2"};
  bbDBLocal("framebuf",&l_framebuf);
  bbDBStmt(212993);
  glGetIntegerv(GL_FRAMEBUFFER_BINDING,&g_mojo_graphics_glutil_tmpi);
  bbDBStmt(217089);
  glBindFramebuffer(GL_FRAMEBUFFER,bbUInt(l_framebuf));
}

void g_mojo_graphics_glutil_glPopTexture2d(){
  bbDBFrame db_f{"glPopTexture2d:Void()","/home/pi/monkey2/modules/mojo/graphics/glutil.monkey2"};
  bbDBStmt(188417);
  glBindTexture(GL_TEXTURE_2D,bbUInt(g_mojo_graphics_glutil_tmpi));
}

void g_mojo_graphics_glutil_glPushTexture2d(bbInt l_tex){
  bbDBFrame db_f{"glPushTexture2d:Void(tex:Int)","/home/pi/monkey2/modules/mojo/graphics/glutil.monkey2"};
  bbDBLocal("tex",&l_tex);
  bbDBStmt(159745);
  glGetIntegerv(GL_TEXTURE_BINDING_2D,&g_mojo_graphics_glutil_tmpi);
  bbDBStmt(163841);
  glBindTexture(GL_TEXTURE_2D,bbUInt(l_tex));
}

bbInt g_mojo_graphics_glutil_glFormat(t_std_graphics_PixelFormat l_format){
  bbDBFrame db_f{"glFormat:GLenum:Int(format:std.graphics.PixelFormat)","/home/pi/monkey2/modules/mojo/graphics/glutil.monkey2"};
  bbDBLocal("format",&l_format);
  bbDBStmt(102401);
  if(l_format==t_std_graphics_PixelFormat(2)){
    bbDBBlock db_blk;
    bbDBStmt(106517);
    return GL_ALPHA;
  }else if(l_format==t_std_graphics_PixelFormat(1)){
    bbDBBlock db_blk;
    bbDBStmt(110613);
    return GL_LUMINANCE;
  }else if(l_format==t_std_graphics_PixelFormat(3)){
    bbDBBlock db_blk;
    bbDBStmt(114711);
    return GL_LUMINANCE_ALPHA;
  }else if(l_format==t_std_graphics_PixelFormat(4)){
    bbDBBlock db_blk;
    bbDBStmt(118808);
    return GL_RGB;
  }else if(l_format==t_std_graphics_PixelFormat(5)){
    bbDBBlock db_blk;
    bbDBStmt(122905);
    return GL_RGBA;
  }
  bbDBStmt(131073);
  bbAssert(false,BB_T("Invalidate PixelFormat"));
  bbDBStmt(135169);
  return GL_RGBA;
}

void g_mojo_graphics_glutil_glCheck(){
  bbDBFrame db_f{"glCheck:Void()","/home/pi/monkey2/modules/mojo/graphics/glutil.monkey2"};
  bbDBStmt(69639);
  bbInt l_err=glGetError();
  bbDBLocal("err",&l_err);
  bbDBStmt(73729);
  if((l_err==GL_NO_ERROR)){
    bbDBBlock db_blk;
    bbDBStmt(73748);
    return;
  }
  bbDBStmt(77825);
  bbAssert(false,(BB_T("GL ERROR! err=")+bbString(l_err)));
}

void mx2_mojo_graphics_2glutil_init(){
  static bool done;
  if(done) return;
  done=true;
  g_mojo_graphics_glutil_glGraphicsSeq=1;
}

bbInit mx2_mojo_graphics_2glutil_init_v("mojo_graphics_2glutil",&mx2_mojo_graphics_2glutil_init);
