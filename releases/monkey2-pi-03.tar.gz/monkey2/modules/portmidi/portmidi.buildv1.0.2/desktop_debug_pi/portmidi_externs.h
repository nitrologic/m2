
#ifndef MX2_PORTMIDI_EXTERNS_H
#define MX2_PORTMIDI_EXTERNS_H

#include <bbmonkey.h>
#include "../../pm_common/portmidi.h"
#include "../../porttime/porttime.h"
#include "../../mididriver.h"

// ***** External *****

// ***** Internal *****

#endif
