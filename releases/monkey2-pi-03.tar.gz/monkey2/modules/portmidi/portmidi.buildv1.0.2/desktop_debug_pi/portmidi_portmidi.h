
#ifndef MX2_PORTMIDI_PORTMIDI_H
#define MX2_PORTMIDI_PORTMIDI_H

#include <bbmonkey.h>

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"

struct MidiDriver;
struct t_std_collections_Stack_1i;
bbString bbDBType(t_std_collections_Stack_1i**);
bbString bbDBValue(t_std_collections_Stack_1i**);
struct t_std_collections_Map_1ii;
bbString bbDBType(t_std_collections_Map_1ii**);
bbString bbDBValue(t_std_collections_Map_1ii**);

// ***** Internal *****

struct t_portmidi_PortMidi;

struct t_portmidi_PortMidi : public bbObject{

  const char *typeName()const{return "t_portmidi_PortMidi";}

  bbString m_version{};
  bbInt m_deviceCount{};
  MidiDriver* m_driver{};
  bbGCVar<t_std_collections_Stack_1i> m_inputDevices{};
  bbGCVar<t_std_collections_Stack_1i> m_outputDevices{};
  bbGCVar<t_std_collections_Map_1ii> m_openInputs{};
  bbGCVar<t_std_collections_Map_1ii> m_openOutputs{};
  bbGCVar<bbArray<bbByte>> m_sysexBuffer{};

  void init();

  void gcMark();
  void dbEmit();

  t_portmidi_PortMidi();

  void m_Sleep(bbDouble l_seconds);
  void m_SendMessages(bbInt l_index,bbArray<bbInt>* l_data);
  void m_SendMessage(bbInt l_index,bbInt l_data);
  bbString m_OutputName(bbInt l_index);
  void m_OpenOutput(bbInt l_index);
  void m_OpenInput(bbInt l_index);
  bbString m_InputName(bbInt l_index);
  bbInt m_HasEvent();
  bbDouble m_EventTime();
  bbArray<bbUByte>* m_EventDataBytes();
  bbInt m_EventData();
  bbArray<bbByte>* m_EventContent();
  void m_CloseOutput(bbInt l_index);
  void m_CloseInput(bbInt l_index);
  void m_CloseAll();
};
bbString bbDBType(t_portmidi_PortMidi**);
bbString bbDBValue(t_portmidi_PortMidi**);

#endif
