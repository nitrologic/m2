
#ifndef MX2_PORTMIDI_STD_COLLECTIONS_2MAP_H
#define MX2_PORTMIDI_STD_COLLECTIONS_2MAP_H

#include <bbmonkey.h>
#include "../../../std/std.buildv1.0.2/desktop_debug_pi/std_collections_2map.h"

// ***** External *****

#include "../../../monkey/monkey.buildv1.0.2/desktop_debug_pi/monkey_types.h"

enum class t_std_collections_Map_1ii_Node_Color;

// ***** Internal *****

struct t_std_collections_Map_1ii_Node;
struct t_std_collections_Map_1ii_Iterator;
struct t_std_collections_Map_1ii_KeyIterator;
struct t_std_collections_Map_1ii_MapKeys;
struct t_std_collections_Map_1ii_ValueIterator;
struct t_std_collections_Map_1ii_MapValues;
struct t_std_collections_Map_1ii;

struct t_std_collections_Map_1ii_Node : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1ii_Node";}

  bbInt m__0key{};
  bbInt m__0value{};
  t_std_collections_Map_1ii_Node_Color m__0color{};
  bbGCVar<t_std_collections_Map_1ii_Node> m__0left{};
  bbGCVar<t_std_collections_Map_1ii_Node> m__0right{};
  bbGCVar<t_std_collections_Map_1ii_Node> m__0parent{};

  void gcMark();
  void dbEmit();

  t_std_collections_Map_1ii_Node(bbInt l_key,bbInt l_value,t_std_collections_Map_1ii_Node_Color l_color,t_std_collections_Map_1ii_Node* l_parent);

  bbInt m_Value();
  t_std_collections_Map_1ii_Node* m_PrevNode();
  t_std_collections_Map_1ii_Node* m_NextNode();
  bbInt m_Key();
  bbInt m_Count(bbInt l_n);
  t_std_collections_Map_1ii_Node* m_Copy(t_std_collections_Map_1ii_Node* l_parent);

  t_std_collections_Map_1ii_Node(){
  }
};
bbString bbDBType(t_std_collections_Map_1ii_Node**);
bbString bbDBValue(t_std_collections_Map_1ii_Node**);

struct t_std_collections_Map_1ii_Iterator{
  const char *typeName()const{return "t_std_collections_Map_1ii_Iterator";}

  bbGCVar<t_std_collections_Map_1ii_Node> m__0node{};
  static void dbEmit(t_std_collections_Map_1ii_Iterator*);

  t_std_collections_Map_1ii_Iterator(t_std_collections_Map_1ii_Node* l_node);

  bbBool m_Valid();
  t_std_collections_Map_1ii_Node* m_Current();
  void m_Bump();

  t_std_collections_Map_1ii_Iterator(){
  }

  t_std_collections_Map_1ii_Iterator(bbNullCtor_t){
  }
};
bbString bbDBType(t_std_collections_Map_1ii_Iterator*);
bbString bbDBValue(t_std_collections_Map_1ii_Iterator*);

int bbCompare(const t_std_collections_Map_1ii_Iterator&x,const t_std_collections_Map_1ii_Iterator&y);

void bbGCMark(const t_std_collections_Map_1ii_Iterator&);

struct t_std_collections_Map_1ii_KeyIterator{
  const char *typeName()const{return "t_std_collections_Map_1ii_KeyIterator";}

  bbGCVar<t_std_collections_Map_1ii_Node> m__0node{};
  static void dbEmit(t_std_collections_Map_1ii_KeyIterator*);

  t_std_collections_Map_1ii_KeyIterator(t_std_collections_Map_1ii_Node* l_node);

  bbBool m_Valid();
  bbInt m_Current();
  void m_Bump();

  t_std_collections_Map_1ii_KeyIterator(){
  }

  t_std_collections_Map_1ii_KeyIterator(bbNullCtor_t){
  }
};
bbString bbDBType(t_std_collections_Map_1ii_KeyIterator*);
bbString bbDBValue(t_std_collections_Map_1ii_KeyIterator*);

int bbCompare(const t_std_collections_Map_1ii_KeyIterator&x,const t_std_collections_Map_1ii_KeyIterator&y);

void bbGCMark(const t_std_collections_Map_1ii_KeyIterator&);

struct t_std_collections_Map_1ii_MapKeys{
  const char *typeName()const{return "t_std_collections_Map_1ii_MapKeys";}

  bbGCVar<t_std_collections_Map_1ii> m__0map{};
  static void dbEmit(t_std_collections_Map_1ii_MapKeys*);

  t_std_collections_Map_1ii_MapKeys(t_std_collections_Map_1ii* l_map);

  t_std_collections_Map_1ii_KeyIterator m_All();

  t_std_collections_Map_1ii_MapKeys(){
  }

  t_std_collections_Map_1ii_MapKeys(bbNullCtor_t){
  }
};
bbString bbDBType(t_std_collections_Map_1ii_MapKeys*);
bbString bbDBValue(t_std_collections_Map_1ii_MapKeys*);

int bbCompare(const t_std_collections_Map_1ii_MapKeys&x,const t_std_collections_Map_1ii_MapKeys&y);

void bbGCMark(const t_std_collections_Map_1ii_MapKeys&);

struct t_std_collections_Map_1ii_ValueIterator{
  const char *typeName()const{return "t_std_collections_Map_1ii_ValueIterator";}

  bbGCVar<t_std_collections_Map_1ii_Node> m__0node{};
  static void dbEmit(t_std_collections_Map_1ii_ValueIterator*);

  t_std_collections_Map_1ii_ValueIterator(t_std_collections_Map_1ii_Node* l_node);

  bbBool m_Valid();
  bbInt m_Current();
  void m_Bump();

  t_std_collections_Map_1ii_ValueIterator(){
  }

  t_std_collections_Map_1ii_ValueIterator(bbNullCtor_t){
  }
};
bbString bbDBType(t_std_collections_Map_1ii_ValueIterator*);
bbString bbDBValue(t_std_collections_Map_1ii_ValueIterator*);

int bbCompare(const t_std_collections_Map_1ii_ValueIterator&x,const t_std_collections_Map_1ii_ValueIterator&y);

void bbGCMark(const t_std_collections_Map_1ii_ValueIterator&);

struct t_std_collections_Map_1ii_MapValues{
  const char *typeName()const{return "t_std_collections_Map_1ii_MapValues";}

  bbGCVar<t_std_collections_Map_1ii> m__0map{};
  static void dbEmit(t_std_collections_Map_1ii_MapValues*);

  t_std_collections_Map_1ii_MapValues(t_std_collections_Map_1ii* l_map);

  t_std_collections_Map_1ii_ValueIterator m_All();

  t_std_collections_Map_1ii_MapValues(){
  }

  t_std_collections_Map_1ii_MapValues(bbNullCtor_t){
  }
};
bbString bbDBType(t_std_collections_Map_1ii_MapValues*);
bbString bbDBValue(t_std_collections_Map_1ii_MapValues*);

int bbCompare(const t_std_collections_Map_1ii_MapValues&x,const t_std_collections_Map_1ii_MapValues&y);

void bbGCMark(const t_std_collections_Map_1ii_MapValues&);

struct t_std_collections_Map_1ii : public bbObject{

  const char *typeName()const{return "t_std_collections_Map_1ii";}

  bbGCVar<t_std_collections_Map_1ii_Node> m__0root{};

  void gcMark();
  void dbEmit();

  t_std_collections_Map_1ii(t_std_collections_Map_1ii_Node* l_root);
  t_std_collections_Map_1ii();

  void m__idxeq(bbInt l_key,bbInt l_value);
  bbInt m__idx(bbInt l_key);
  t_std_collections_Map_1ii_MapValues m_Values();
  bbBool m_Update(bbInt l_key,bbInt l_value);
  bbBool m_Set(bbInt l_key,bbInt l_value);
  void m_RotateRight(t_std_collections_Map_1ii_Node* l_node);
  void m_RotateLeft(t_std_collections_Map_1ii_Node* l_node);
  void m_RemoveNode(t_std_collections_Map_1ii_Node* l_node);
  bbBool m_Remove(bbInt l_key);
  t_std_collections_Map_1ii_Node* m_LastNode();
  t_std_collections_Map_1ii_MapKeys m_Keys();
  void m_InsertFixup(t_std_collections_Map_1ii_Node* l_node);
  bbInt m_Get(bbInt l_key);
  t_std_collections_Map_1ii_Node* m_FirstNode();
  t_std_collections_Map_1ii_Node* m_FindNode(bbInt l_key);
  bbBool m_Empty();
  void m_DeleteFixup(t_std_collections_Map_1ii_Node* l_node,t_std_collections_Map_1ii_Node* l_parent);
  bbInt m_Count();
  t_std_collections_Map_1ii* m_Copy();
  bbBool m_Contains(bbInt l_key);
  void m_Clear();
  t_std_collections_Map_1ii_Iterator m_All();
  bbBool m_Add(bbInt l_key,bbInt l_value);
};
bbString bbDBType(t_std_collections_Map_1ii**);
bbString bbDBValue(t_std_collections_Map_1ii**);

#endif
