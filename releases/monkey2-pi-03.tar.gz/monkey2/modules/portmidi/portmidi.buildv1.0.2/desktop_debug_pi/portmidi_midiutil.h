
#ifndef MX2_PORTMIDI_MIDIUTIL_H
#define MX2_PORTMIDI_MIDIUTIL_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

extern bbGCRootVar<bbArray<bbString>> g_default_Higit;

extern bbString g_default_Hex2(bbInt l_b);

#endif
