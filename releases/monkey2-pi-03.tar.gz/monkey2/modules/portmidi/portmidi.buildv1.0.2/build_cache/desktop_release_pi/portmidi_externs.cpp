
#include "../../desktop_release_pi/portmidi_externs.h"

// ***** External *****

// ***** Internal *****

void mx2_portmidi_externs_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_portmidi_externs_init_v("portmidi_externs",&mx2_portmidi_externs_init);
