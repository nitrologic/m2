
#include "../../desktop_release_pi/portmidi_portmidi.h"

// ***** External *****

#include "../../desktop_release_pi/portmidi_externs.h"
#include "../../desktop_release_pi/portmidi_std_collections_2map.h"
#include "../../../../std/std.buildv1.0.2/desktop_release_pi/std_collections_2stack.h"

// ***** Internal *****

void t_portmidi_PortMidi::init(){
  m_version=BB_T("0.02");
  m_inputDevices=bbGCNew<t_std_collections_Stack_1i>();
  m_outputDevices=bbGCNew<t_std_collections_Stack_1i>();
  m_openInputs=bbGCNew<t_std_collections_Map_1ii>();
  m_openOutputs=bbGCNew<t_std_collections_Map_1ii>();
  m_sysexBuffer=bbArray<bbByte>::create(65536);
}

void t_portmidi_PortMidi::gcMark(){
  bbGCMark(m_inputDevices);
  bbGCMark(m_outputDevices);
  bbGCMark(m_openInputs);
  bbGCMark(m_openOutputs);
  bbGCMark(m_sysexBuffer);
}

t_portmidi_PortMidi::t_portmidi_PortMidi(){
  init();
  puts(BB_T("PortMidi courtesy github/nitrologic/monkey2/modules").c_str());fflush( stdout );
  this->m_driver=new MidiDriver();
  puts((BB_T("countDevices=")+bbString(this->m_driver->deviceCount)).c_str());fflush( stdout );
  {
    bbInt l_id=bbInt(0);
    for(;(l_id<this->m_driver->deviceCount);l_id+=1){
      this->m_driver->GetInfo(l_id);
      if(bbBool(this->m_driver->info->input)){
        this->m_inputDevices->m_Push(l_id);
      }
      if(bbBool(this->m_driver->info->output)){
        this->m_outputDevices->m_Push(l_id);
      }
    }
  }
}

void t_portmidi_PortMidi::m_Sleep(bbDouble l_seconds){
  this->m_driver->Sleep(l_seconds);
}

void t_portmidi_PortMidi::m_SendMessages(bbInt l_index,bbArray<bbInt>* l_data){
  bbInt l_id=this->m_outputDevices->m_Get(l_index);
  this->m_driver->OutputMessages(l_id,l_data->data(),l_data->length());
}

void t_portmidi_PortMidi::m_SendMessage(bbInt l_index,bbInt l_data){
  bbInt l_id=this->m_outputDevices->m_Get(l_index);
  this->m_driver->OutputMessage(l_id,l_data);
}

bbString t_portmidi_PortMidi::m_OutputName(bbInt l_index){
  bbInt l_id=this->m_inputDevices->m_Get(l_index);
  this->m_driver->GetInfo(l_id);
  bbString l_interf=bbString::fromCString(((void*)(this->m_driver->info->interf)));
  bbString l_name=bbString::fromCString(((void*)(this->m_driver->info->name)));
  return l_name;
}

void t_portmidi_PortMidi::m_OpenOutput(bbInt l_index){
  bbInt l_id=this->m_outputDevices->m_Get(l_index);
  bbInt l_output=this->m_driver->OpenOutput(l_id);
  puts((((((BB_T("PortMidi Open output")+bbString(l_index))+BB_T("@"))+bbString(l_id))+BB_T("="))+bbString(l_output)).c_str());fflush( stdout );
  this->m_openOutputs->m__idxeq(l_index,l_id);
}

void t_portmidi_PortMidi::m_OpenInput(bbInt l_index){
  bbInt l_id=this->m_inputDevices->m_Get(l_index);
  bbInt l_input=this->m_driver->OpenInput(l_id);
  puts((((((BB_T("PortMidi Open input")+bbString(l_index))+BB_T("@"))+bbString(l_id))+BB_T("="))+bbString(l_input)).c_str());fflush( stdout );
  this->m_openInputs->m__idxeq(l_index,l_id);
}

bbString t_portmidi_PortMidi::m_InputName(bbInt l_index){
  bbInt l_id=this->m_inputDevices->m_Get(l_index);
  this->m_driver->GetInfo(l_id);
  bbString l_interf=bbString::fromCString(((void*)(this->m_driver->info->interf)));
  bbString l_name=bbString::fromCString(((void*)(this->m_driver->info->name)));
  return l_name;
}

bbInt t_portmidi_PortMidi::m_HasEvent(){
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1ii_KeyIterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    f1.l_0=this->m_openInputs->m_Keys().m_All();
    for(;f1.l_0.m_Valid();f1.l_0.m_Bump()){
      bbInt l_index=f1.l_0.m_Current();
      bbInt l_id=this->m_openInputs->m__idx(l_index);
      if(this->m_driver->HasInput(l_id)){
        return 1;
      }
    }
  }
  return bbInt(0);
}

bbDouble t_portmidi_PortMidi::m_EventTime(){
  return this->m_driver->MidiEventTimestamp();
}

bbArray<bbUByte>* t_portmidi_PortMidi::m_EventDataBytes(){
  bbInt l_i=this->m_EventData();
  return bbArray<bbUByte>::create({bbUByte((l_i&255)),bbUByte(((l_i>>8)&255)),bbUByte(((l_i>>16)&255)),bbUByte(((l_i>>24)&255))},4);
}

bbInt t_portmidi_PortMidi::m_EventData(){
  return this->m_driver->MidiEventData();
}

bbArray<bbByte>* t_portmidi_PortMidi::m_EventContent(){
  bbByte* l_b=&this->m_sysexBuffer->at(bbInt(0));
  bbInt l_n=this->m_driver->MidiEventMessage(((void*)(l_b)),65536);
  return this->m_sysexBuffer->slice(bbInt(0),l_n);
}

void t_portmidi_PortMidi::m_CloseOutput(bbInt l_index){
  bbInt l_id=this->m_openOutputs->m__idx(l_index);
  this->m_driver->CloseOutput(l_id);
  puts((((BB_T("PortMidi Close output")+bbString(l_index))+BB_T("@"))+bbString(l_id)).c_str());fflush( stdout );
  this->m_openOutputs->m_Remove(l_index);
}

void t_portmidi_PortMidi::m_CloseInput(bbInt l_index){
  bbInt l_id=this->m_openInputs->m__idx(l_index);
  this->m_driver->CloseInput(l_id);
  puts((((BB_T("PortMidi Close input")+bbString(l_index))+BB_T("@"))+bbString(l_id)).c_str());fflush( stdout );
  this->m_openInputs->m_Remove(l_index);
}

void t_portmidi_PortMidi::m_CloseAll(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Stack_1i* l_indexes{};
    void gcMark(){
      bbGCMarkPtr(l_indexes);
    }
  }f0{};
  f0.l_indexes=bbGCNew<t_std_collections_Stack_1i>();
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1ii_KeyIterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    f1.l_0=this->m_openInputs->m_Keys().m_All();
    for(;f1.l_0.m_Valid();f1.l_0.m_Bump()){
      bbInt l_in=f1.l_0.m_Current();
      f0.l_indexes->m_Push(l_in);
    }
  }
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1i_Iterator l_1{};
      void gcMark(){
        bbGCMark(l_1);
      }
    }f1{};
    f1.l_1=f0.l_indexes->m_All();
    for(;!f1.l_1.m_AtEnd();f1.l_1.m_Bump()){
      bbInt l_index=f1.l_1.m_Current();
      this->m_CloseInput(l_index);
    }
  }
  f0.l_indexes->m_Clear();
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1ii_KeyIterator l_2{};
      void gcMark(){
        bbGCMark(l_2);
      }
    }f1{};
    f1.l_2=this->m_openOutputs->m_Keys().m_All();
    for(;f1.l_2.m_Valid();f1.l_2.m_Bump()){
      bbInt l_out=f1.l_2.m_Current();
      f0.l_indexes->m_Push(l_out);
    }
  }
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1i_Iterator l_3{};
      void gcMark(){
        bbGCMark(l_3);
      }
    }f1{};
    f1.l_3=f0.l_indexes->m_All();
    for(;!f1.l_3.m_AtEnd();f1.l_3.m_Bump()){
      bbInt l_index=f1.l_3.m_Current();
      this->m_CloseOutput(l_index);
    }
  }
}

void mx2_portmidi_portmidi_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_portmidi_portmidi_init_v("portmidi_portmidi",&mx2_portmidi_portmidi_init);
