
#include "../../desktop_debug_pi/portmidi_midiutil.h"

// ***** External *****

// ***** Internal *****

bbGCRootVar<bbArray<bbString>> g_default_Higit;

bbString g_default_Hex2(bbInt l_b){
  bbDBFrame db_f{"Hex2:String(b:Int)","/home/pi/monkey2/modules/portmidi/midiutil.monkey2"};
  bbDBLocal("b",&l_b);
  bbDBStmt(16391);
  bbInt l_b0=((l_b>>4)&15);
  bbDBLocal("b0",&l_b0);
  bbDBStmt(20487);
  bbInt l_b1=(l_b&15);
  bbDBLocal("b1",&l_b1);
  bbDBStmt(24577);
  return (g_default_Higit->at(l_b0)+g_default_Higit->at(l_b1));
}

void mx2_portmidi_midiutil_init(){
  static bool done;
  if(done) return;
  done=true;
  g_default_Higit=bbArray<bbString>::create({BB_T("0"),BB_T("1"),BB_T("2"),BB_T("3"),BB_T("4"),BB_T("5"),BB_T("6"),BB_T("7"),BB_T("8"),BB_T("9"),BB_T("A"),BB_T("B"),BB_T("C"),BB_T("D"),BB_T("E"),BB_T("F")},16);
}

bbInit mx2_portmidi_midiutil_init_v("portmidi_midiutil",&mx2_portmidi_midiutil_init);
