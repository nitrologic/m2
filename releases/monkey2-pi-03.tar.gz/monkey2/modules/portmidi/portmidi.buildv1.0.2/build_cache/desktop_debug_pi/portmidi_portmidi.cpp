
#include "../../desktop_debug_pi/portmidi_portmidi.h"

// ***** External *****

#include "../../desktop_debug_pi/portmidi_externs.h"
#include "../../desktop_debug_pi/portmidi_std_collections_2map.h"
#include "../../../../std/std.buildv1.0.2/desktop_debug_pi/std_collections_2stack.h"

// ***** Internal *****

void t_portmidi_PortMidi::init(){
  m_version=BB_T("0.02");
  m_inputDevices=bbGCNew<t_std_collections_Stack_1i>();
  m_outputDevices=bbGCNew<t_std_collections_Stack_1i>();
  m_openInputs=bbGCNew<t_std_collections_Map_1ii>();
  m_openOutputs=bbGCNew<t_std_collections_Map_1ii>();
  m_sysexBuffer=bbArray<bbByte>::create(65536);
}

void t_portmidi_PortMidi::gcMark(){
  bbGCMark(m_inputDevices);
  bbGCMark(m_outputDevices);
  bbGCMark(m_openInputs);
  bbGCMark(m_openOutputs);
  bbGCMark(m_sysexBuffer);
}

void t_portmidi_PortMidi::dbEmit(){
  bbDBEmit("version",&m_version);
  bbDBEmit("deviceCount",&m_deviceCount);
  bbDBEmit("driver",&m_driver);
  bbDBEmit("inputDevices",&m_inputDevices);
  bbDBEmit("outputDevices",&m_outputDevices);
  bbDBEmit("openInputs",&m_openInputs);
  bbDBEmit("openOutputs",&m_openOutputs);
  bbDBEmit("sysexBuffer",&m_sysexBuffer);
}

t_portmidi_PortMidi::t_portmidi_PortMidi(){
  init();
  bbDBFrame db_f{"new:Void()","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  bbDBStmt(176130);
  puts(BB_T("PortMidi courtesy github/nitrologic/monkey2/modules").c_str());fflush( stdout );
  bbDBStmt(180226);
  this->m_driver=new MidiDriver();
  bbDBStmt(184322);
  puts((BB_T("countDevices=")+bbString(this->m_driver->deviceCount)).c_str());fflush( stdout );
  bbDBStmt(188418);
  {
    bbDBLoop db_loop;
    bbInt l_id=bbInt(0);
    bbDBLocal("id",&l_id);
    bbDBStmt(188418);
    for(;(l_id<this->m_driver->deviceCount);l_id+=1){
      bbDBBlock db_blk;
      bbDBStmt(192515);
      this->m_driver->GetInfo(l_id);
      bbDBStmt(196611);
      if(bbBool(this->m_driver->info->input)){
        bbDBBlock db_blk;
        bbDBStmt(196632);
        this->m_inputDevices->m_Push(l_id);
      }
      bbDBStmt(200707);
      if(bbBool(this->m_driver->info->output)){
        bbDBBlock db_blk;
        bbDBStmt(200729);
        this->m_outputDevices->m_Push(l_id);
      }
    }
  }
}

void t_portmidi_PortMidi::m_Sleep(bbDouble l_seconds){
  bbDBFrame db_f{"Sleep:Void(seconds:Double)","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("seconds",&l_seconds);
  bbDBStmt(151554);
  this->m_driver->Sleep(l_seconds);
}

void t_portmidi_PortMidi::m_SendMessages(bbInt l_index,bbArray<bbInt>* l_data){
  bbDBFrame db_f{"SendMessages:Void(index:Int,data:Int[])","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("data",&l_data);
  bbDBStmt(491528);
  bbInt l_id=this->m_outputDevices->m_Get(l_index);
  bbDBLocal("id",&l_id);
  bbDBStmt(495618);
  this->m_driver->OutputMessages(l_id,l_data->data(),l_data->length());
}

void t_portmidi_PortMidi::m_SendMessage(bbInt l_index,bbInt l_data){
  bbDBFrame db_f{"SendMessage:Void(index:Int,data:Int)","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBLocal("data",&l_data);
  bbDBStmt(462856);
  bbInt l_id=this->m_outputDevices->m_Get(l_index);
  bbDBLocal("id",&l_id);
  bbDBStmt(466946);
  this->m_driver->OutputMessage(l_id,l_data);
}

bbString t_portmidi_PortMidi::m_OutputName(bbInt l_index){
  bbDBFrame db_f{"OutputName:String(index:Int)","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(348168);
  bbInt l_id=this->m_inputDevices->m_Get(l_index);
  bbDBLocal("id",&l_id);
  bbDBStmt(352258);
  this->m_driver->GetInfo(l_id);
  bbDBStmt(356360);
  bbString l_interf=bbString::fromCString(((void*)(this->m_driver->info->interf)));
  bbDBLocal("interf",&l_interf);
  bbDBStmt(360457);
  bbString l_name=bbString::fromCString(((void*)(this->m_driver->info->name)));
  bbDBLocal("name",&l_name);
  bbDBStmt(364546);
  return l_name;
}

void t_portmidi_PortMidi::m_OpenOutput(bbInt l_index){
  bbDBFrame db_f{"OpenOutput:Void(index:Int)","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(425992);
  bbInt l_id=this->m_outputDevices->m_Get(l_index);
  bbDBLocal("id",&l_id);
  bbDBStmt(430088);
  bbInt l_output=this->m_driver->OpenOutput(l_id);
  bbDBLocal("output",&l_output);
  bbDBStmt(434178);
  puts((((((BB_T("PortMidi Open output")+bbString(l_index))+BB_T("@"))+bbString(l_id))+BB_T("="))+bbString(l_output)).c_str());fflush( stdout );
  bbDBStmt(438274);
  this->m_openOutputs->m__idxeq(l_index,l_id);
}

void t_portmidi_PortMidi::m_OpenInput(bbInt l_index){
  bbDBFrame db_f{"OpenInput:Void(index:Int)","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(389128);
  bbInt l_id=this->m_inputDevices->m_Get(l_index);
  bbDBLocal("id",&l_id);
  bbDBStmt(393224);
  bbInt l_input=this->m_driver->OpenInput(l_id);
  bbDBLocal("input",&l_input);
  bbDBStmt(397314);
  puts((((((BB_T("PortMidi Open input")+bbString(l_index))+BB_T("@"))+bbString(l_id))+BB_T("="))+bbString(l_input)).c_str());fflush( stdout );
  bbDBStmt(401410);
  this->m_openInputs->m__idxeq(l_index,l_id);
}

bbString t_portmidi_PortMidi::m_InputName(bbInt l_index){
  bbDBFrame db_f{"InputName:String(index:Int)","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(307208);
  bbInt l_id=this->m_inputDevices->m_Get(l_index);
  bbDBLocal("id",&l_id);
  bbDBStmt(311298);
  this->m_driver->GetInfo(l_id);
  bbDBStmt(315400);
  bbString l_interf=bbString::fromCString(((void*)(this->m_driver->info->interf)));
  bbDBLocal("interf",&l_interf);
  bbDBStmt(319497);
  bbString l_name=bbString::fromCString(((void*)(this->m_driver->info->name)));
  bbDBLocal("name",&l_name);
  bbDBStmt(323586);
  return l_name;
}

bbInt t_portmidi_PortMidi::m_HasEvent(){
  bbDBFrame db_f{"HasEvent:Int()","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(593922);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1ii_KeyIterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=this->m_openInputs->m_Keys().m_All();
    bbDBLocal("0",&f1.l_0);
    for(;f1.l_0.m_Valid();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      bbInt l_index=f1.l_0.m_Current();
      bbDBLocal("index",&l_index);
      bbDBStmt(598025);
      bbInt l_id=this->m_openInputs->m__idx(l_index);
      bbDBLocal("id",&l_id);
      bbDBStmt(602115);
      if(this->m_driver->HasInput(l_id)){
        bbDBBlock db_blk;
        bbDBStmt(602138);
        return 1;
      }
    }
  }
  bbDBStmt(610306);
  return bbInt(0);
}

bbDouble t_portmidi_PortMidi::m_EventTime(){
  bbDBFrame db_f{"EventTime:Double()","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(688130);
  return this->m_driver->MidiEventTimestamp();
}

bbArray<bbUByte>* t_portmidi_PortMidi::m_EventDataBytes(){
  bbDBFrame db_f{"EventDataBytes:Ubyte[]()","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(659464);
  bbInt l_i=this->m_EventData();
  bbDBLocal("i",&l_i);
  bbDBStmt(663554);
  return bbArray<bbUByte>::create({bbUByte((l_i&255)),bbUByte(((l_i>>8)&255)),bbUByte(((l_i>>16)&255)),bbUByte(((l_i>>24)&255))},4);
}

bbInt t_portmidi_PortMidi::m_EventData(){
  bbDBFrame db_f{"EventData:Int()","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(634882);
  return this->m_driver->MidiEventData();
}

bbArray<bbByte>* t_portmidi_PortMidi::m_EventContent(){
  bbDBFrame db_f{"EventContent:Byte[]()","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(720904);
  bbByte* l_b=&this->m_sysexBuffer->at(bbInt(0));
  bbDBLocal("b",&l_b);
  bbDBStmt(725000);
  bbInt l_n=this->m_driver->MidiEventMessage(((void*)(l_b)),65536);
  bbDBLocal("n",&l_n);
  bbDBStmt(729090);
  return this->m_sysexBuffer->slice(bbInt(0),l_n);
}

void t_portmidi_PortMidi::m_CloseOutput(bbInt l_index){
  bbDBFrame db_f{"CloseOutput:Void(index:Int)","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(557064);
  bbInt l_id=this->m_openOutputs->m__idx(l_index);
  bbDBLocal("id",&l_id);
  bbDBStmt(561154);
  this->m_driver->CloseOutput(l_id);
  bbDBStmt(565250);
  puts((((BB_T("PortMidi Close output")+bbString(l_index))+BB_T("@"))+bbString(l_id)).c_str());fflush( stdout );
  bbDBStmt(569346);
  this->m_openOutputs->m_Remove(l_index);
}

void t_portmidi_PortMidi::m_CloseInput(bbInt l_index){
  bbDBFrame db_f{"CloseInput:Void(index:Int)","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBLocal("index",&l_index);
  bbDBStmt(520200);
  bbInt l_id=this->m_openInputs->m__idx(l_index);
  bbDBLocal("id",&l_id);
  bbDBStmt(524290);
  this->m_driver->CloseInput(l_id);
  bbDBStmt(528386);
  puts((((BB_T("PortMidi Close input")+bbString(l_index))+BB_T("@"))+bbString(l_id)).c_str());fflush( stdout );
  bbDBStmt(532482);
  this->m_openInputs->m_Remove(l_index);
}

void t_portmidi_PortMidi::m_CloseAll(){
  struct f0_t : public bbGCFrame{
    t_std_collections_Stack_1i* l_indexes{};
    void gcMark(){
      bbGCMarkPtr(l_indexes);
    }
  }f0{};
  bbDBFrame db_f{"CloseAll:Void()","/home/pi/monkey2/modules/portmidi/portmidi.monkey2"};
  t_portmidi_PortMidi*self=this;
  bbDBLocal("Self",&self);
  bbDBStmt(229384);
  f0.l_indexes=bbGCNew<t_std_collections_Stack_1i>();
  bbDBLocal("indexes",&f0.l_indexes);
  bbDBStmt(233474);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1ii_KeyIterator l_0{};
      void gcMark(){
        bbGCMark(l_0);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_0=this->m_openInputs->m_Keys().m_All();
    bbDBLocal("0",&f1.l_0);
    for(;f1.l_0.m_Valid();f1.l_0.m_Bump()){
      bbDBBlock db_blk;
      bbInt l_in=f1.l_0.m_Current();
      bbDBLocal("in",&l_in);
      bbDBStmt(237571);
      f0.l_indexes->m_Push(l_in);
    }
  }
  bbDBStmt(245762);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1i_Iterator l_1{};
      void gcMark(){
        bbGCMark(l_1);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_1=f0.l_indexes->m_All();
    bbDBLocal("1",&f1.l_1);
    for(;!f1.l_1.m_AtEnd();f1.l_1.m_Bump()){
      bbDBBlock db_blk;
      bbInt l_index=f1.l_1.m_Current();
      bbDBLocal("index",&l_index);
      bbDBStmt(249859);
      this->m_CloseInput(l_index);
    }
  }
  bbDBStmt(258050);
  f0.l_indexes->m_Clear();
  bbDBStmt(262146);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Map_1ii_KeyIterator l_2{};
      void gcMark(){
        bbGCMark(l_2);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_2=this->m_openOutputs->m_Keys().m_All();
    bbDBLocal("2",&f1.l_2);
    for(;f1.l_2.m_Valid();f1.l_2.m_Bump()){
      bbDBBlock db_blk;
      bbInt l_out=f1.l_2.m_Current();
      bbDBLocal("out",&l_out);
      bbDBStmt(266243);
      f0.l_indexes->m_Push(l_out);
    }
  }
  bbDBStmt(274434);
  {
    struct f1_t : public bbGCFrame{
      t_std_collections_Stack_1i_Iterator l_3{};
      void gcMark(){
        bbGCMark(l_3);
      }
    }f1{};
    bbDBLoop db_loop;
    f1.l_3=f0.l_indexes->m_All();
    bbDBLocal("3",&f1.l_3);
    for(;!f1.l_3.m_AtEnd();f1.l_3.m_Bump()){
      bbDBBlock db_blk;
      bbInt l_index=f1.l_3.m_Current();
      bbDBLocal("index",&l_index);
      bbDBStmt(278531);
      this->m_CloseOutput(l_index);
    }
  }
}
bbString bbDBType(t_portmidi_PortMidi**){
  return "portmidi.PortMidi";
}
bbString bbDBValue(t_portmidi_PortMidi**p){
  return bbDBObjectValue(*p);
}

void mx2_portmidi_portmidi_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_portmidi_portmidi_init_v("portmidi_portmidi",&mx2_portmidi_portmidi_init);
