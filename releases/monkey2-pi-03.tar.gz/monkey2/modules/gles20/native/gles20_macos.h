
#ifndef BB_GLES20_MACOS_H
#define BB_GLES20_MACOS_H

#include <OpenGL/gl.h>

#define glClearDepthf glClearDepth

#endif
