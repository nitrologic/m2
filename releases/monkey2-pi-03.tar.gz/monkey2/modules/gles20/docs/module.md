
# The gles20 module

The gles20 module provides a monkey2 wrapper for the OpenGL ES2.0 API.

The OpenGL ES2.0 reference pages can be viewed at <a href=https://www.khronos.org/opengles/sdk/docs/man/ target=blank>https://www.khronos.org/opengles/sdk/docs/man/</a>.


