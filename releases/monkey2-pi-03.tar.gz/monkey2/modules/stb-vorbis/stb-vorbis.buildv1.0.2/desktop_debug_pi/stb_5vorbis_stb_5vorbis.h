
#ifndef MX2_STB_5VORBIS_STB_5VORBIS_H
#define MX2_STB_5VORBIS_STB_5VORBIS_H

#include <bbmonkey.h>
#include "../../native/stb-vorbis.h"

// ***** External *****

// ***** Internal *****

#endif
