
#include "../../desktop_release_pi/stb_5vorbis_stb_5vorbis.h"

// ***** External *****

// ***** Internal *****

void mx2_stb_5vorbis_stb_5vorbis_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_stb_5vorbis_stb_5vorbis_init_v("stb_5vorbis_stb_5vorbis",&mx2_stb_5vorbis_stb_5vorbis_init);
