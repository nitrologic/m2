
#include "../../desktop_debug_pi/litehtml_makefile.h"

// ***** External *****

// ***** Internal *****

void mx2_litehtml_makefile_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_litehtml_makefile_init_v("litehtml_makefile",&mx2_litehtml_makefile_init);
