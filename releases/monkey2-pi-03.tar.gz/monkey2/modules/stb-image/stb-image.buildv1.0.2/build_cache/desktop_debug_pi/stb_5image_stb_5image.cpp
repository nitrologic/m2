
#include "../../desktop_debug_pi/stb_5image_stb_5image.h"

// ***** External *****

// ***** Internal *****

void mx2_stb_5image_stb_5image_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_stb_5image_stb_5image_init_v("stb_5image_stb_5image",&mx2_stb_5image_stb_5image_init);
