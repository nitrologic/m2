
#include "../../desktop_debug_pi/stb_5image_5write_stb_5image_5write.h"

// ***** External *****

// ***** Internal *****

void mx2_stb_5image_5write_stb_5image_5write_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_stb_5image_5write_stb_5image_5write_init_v("stb_5image_5write_stb_5image_5write",&mx2_stb_5image_5write_stb_5image_5write_init);
