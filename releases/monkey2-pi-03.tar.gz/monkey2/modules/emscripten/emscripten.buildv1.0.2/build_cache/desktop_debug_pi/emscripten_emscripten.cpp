
#include "../../desktop_debug_pi/emscripten_emscripten.h"

// ***** External *****

// ***** Internal *****

void mx2_emscripten_emscripten_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_emscripten_emscripten_init_v("emscripten_emscripten",&mx2_emscripten_emscripten_init);
