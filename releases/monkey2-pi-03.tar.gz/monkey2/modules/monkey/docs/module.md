
# The monkey module

The monkey module provides core functionality required by all monkey apps.

You don't need to import the monkey module as it is implictly imported by all monkey code.

