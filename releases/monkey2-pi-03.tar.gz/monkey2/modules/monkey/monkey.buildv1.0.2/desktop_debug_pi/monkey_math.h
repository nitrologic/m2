
#ifndef MX2_MONKEY_MATH_H
#define MX2_MONKEY_MATH_H

#include <bbmonkey.h>

// ***** External *****

// ***** Internal *****

extern bbDouble g_monkey_math_Pi;
extern bbDouble g_monkey_math_TwoPi;

#endif
