
#include "../../desktop_debug_pi/monkey_gc.h"

// ***** External *****

// ***** Internal *****

void mx2_monkey_gc_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_monkey_gc_init_v("monkey_gc",&mx2_monkey_gc_init);
