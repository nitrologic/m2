
#include "../../desktop_release_pi/stb_5truetype_stb_5truetype.h"

// ***** External *****

// ***** Internal *****

void mx2_stb_5truetype_stb_5truetype_init(){
  static bool done;
  if(done) return;
  done=true;
}

bbInit mx2_stb_5truetype_stb_5truetype_init_v("stb_5truetype_stb_5truetype",&mx2_stb_5truetype_stb_5truetype_init);
