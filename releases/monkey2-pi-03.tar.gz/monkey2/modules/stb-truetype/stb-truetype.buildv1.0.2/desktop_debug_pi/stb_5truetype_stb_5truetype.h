
#ifndef MX2_STB_5TRUETYPE_STB_5TRUETYPE_H
#define MX2_STB_5TRUETYPE_STB_5TRUETYPE_H

#include <bbmonkey.h>
#include "../../native/stb_truetype.h"

// ***** External *****

// ***** Internal *****

#endif
